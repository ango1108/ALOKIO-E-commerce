// Trang thành công (3D bắn nước), tra cứu đơn, timeline realtime, đặt lịch, 404 giọt nước
import { $, api, toast, esc } from '../lib/core.js';
import * as live from '../lib/live.js';
import { webglOK, liteMode } from '../three/support.js';

const STATUS = ['pending', 'confirmed', 'packing', 'shipping', 'completed'];
const LABEL = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', packing: 'Đang đóng gói', shipping: 'Đang giao', completed: 'Hoàn thành', cancelled: 'Đã huỷ', returned: 'Hoàn trả' };
const PAY = { pending: 'Chờ thanh toán', paid: 'Đã thanh toán', deposit: 'Đã đặt cọc', cod: 'Thu khi giao', failed: 'Thất bại', refunded: 'Đã hoàn tiền', expired: 'Hết hạn' };

function renderTimeline(el, d) {
  if (['cancelled', 'returned'].includes(d.status)) { el.innerHTML = d.timeline.map((t) => `<li class="is-done"><b>${esc(t.label)}</b><small>${new Date(t.at).toLocaleString('vi-VN')}${t.note ? ' · ' + esc(t.note) : ''}</small></li>`).join(''); return; }
  const cur = STATUS.indexOf(d.status);
  el.innerHTML = STATUS.map((s, i) => { const t = d.timeline.find((x) => x.status === s); return `<li class="${i <= cur ? 'is-done' : ''} ${i === cur ? 'is-current' : ''}"><b>${LABEL[s]}</b><small>${t ? new Date(t.at).toLocaleString('vi-VN') : 'Chưa diễn ra'}</small></li>`; }).join('');
}
const tl = document.querySelector('[data-timeline]');
if (tl) {
  live.on('order.updated', async (d) => {
    if (d.order.code !== tl.dataset.code) return;
    const s = await api(`/api/orders/${tl.dataset.code}/status`);
    renderTimeline(tl, s);
    const ps = $('[data-paystatus]'); if (ps) { ps.className = `st st--${s.payStatus}`; ps.textContent = PAY[s.payStatus] || s.payStatus; }
    tl.animate([{ background: '#FFF6DE' }, { background: 'transparent' }], { duration: 1600 });
    toast(`Đơn ${d.order.code}: ${LABEL[d.order.status]}`, { type: 'info' });
  });
}

// Tra cứu
const tf = $('[data-track]');
tf && tf.addEventListener('submit', async (e) => {
  e.preventDefault();
  try { const r = await api('/api/track', { method: 'POST', body: { code: tf.code.value, phone: tf.phone.value } }); __alk.go(`/tra-cuu-don-hang?ma=${encodeURIComponent(r.code)}`); }
  catch (err) { $('[data-track-err]').textContent = err.message; }
});

// Đặt lịch nghe thử
const ap = $('[data-appointment]');
ap && ap.addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('[data-appt-msg]');
  try { await api('/api/appointment', { method: 'POST', body: Object.fromEntries(new FormData(ap)) }); msg.style.color = 'var(--success)'; msg.textContent = 'Đã đặt lịch! Alokio sẽ gọi điện xác nhận trong ngày.'; ap.reset(); }
  catch (err) { msg.style.color = ''; msg.textContent = err.message; }
});

// 3D: màn thành công (loa nảy lên, nước bắn) và 404 (giọt nước)
const succ = $('[data-success-3d]');
const nf = $('[data-nf]');
if ((succ || nf) && webglOK() && !liteMode()) {
  import('../three/splash.js').then(({ mountSplash }) => {
    const host = succ || nf;
    const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true');
    host.prepend(c);
    mountSplash(c, succ ? { model: JSON.parse(succ.dataset.model), finish: succ.dataset.finish } : { droplet: true });
  });
}
