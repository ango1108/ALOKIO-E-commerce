// Showroom 3D "Gallery trên vịnh": bục sơn mài nổi trên mặt nước, loa trên từng bục.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { $, $$, fmt, toast } from '../lib/core.js';
import * as cart from '../lib/cart.js';
import { createStage, webglOK, liteMode, reducedMotion, isMobile } from '../three/stage.js';
import { makeWater, makeSky, MAX_RIPPLES } from '../three/water.js';
import { buildModel } from '../three/models.js';
import * as M from '../three/materials.js';
import * as audio from '../audio.js';

const items = JSON.parse($('#sr-data').textContent);
let idx = 0;
const card = {
  tag: $('[data-sr-tag]'), name: $('[data-sr-name]'), tagline: $('[data-sr-tagline]'), specs: $('[data-sr-specs]'), price: $('[data-sr-price]'), link: $('[data-sr-link]'),
};
function showCard(i) {
  const p = items[i];
  card.tag.textContent = p.line === 'luxe' ? 'Alokio Luxe · ý tưởng' : 'Loa kéo chính hãng';
  card.tag.className = 'tag ' + (p.line === 'luxe' ? 'tag--concept' : 'tag--real');
  card.name.textContent = p.name; card.tagline.textContent = p.tagline;
  card.specs.innerHTML = p.highlights.map((h) => `<li>${h}</li>`).join('');
  card.price.textContent = fmt(p.price); card.link.href = '/san-pham/' + p.slug;
  $$('[data-sr-go]').forEach((b, j) => b.setAttribute('aria-current', String(j === i)));
}
$('[data-sr-add]').addEventListener('click', (e) => { const p = items[idx]; cart.add({ productId: p.id, finish: p.finish, qty: 1, options: {} }); window.__alokioFly && window.__alokioFly(e.currentTarget, p.image); toast(`Đã thêm ${p.name} vào giỏ.`, { link: '/gio-hang', linkText: 'Xem giỏ' }); });

let api3d = null;
function select(i) {
  idx = (i + items.length) % items.length;
  showCard(idx);
  api3d && api3d.focus(idx);
}
$$('[data-sr-go]').forEach((b) => b.addEventListener('click', () => select(Number(b.dataset.srGo))));
document.addEventListener('keydown', (e) => {
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
  if (e.key === 'ArrowRight') { select(idx + 1); e.preventDefault(); }
  if (e.key === 'ArrowLeft') { select(idx - 1); e.preventDefault(); }
  if (e.key === 'Enter' && document.activeElement === document.body) api3d && api3d.play(idx);
});
showCard(0);

if (webglOK() && !liteMode()) {
  const host = $('[data-showroom]');
  const canvas = document.createElement('canvas'); canvas.setAttribute('aria-hidden', 'true');
  host.prepend(canvas);
  const ripples = [];
  const spacing = 7.5;
  const stage = createStage(canvas, { fov: isMobile() ? 46 : 34, ground: false, shadows: true, background: '#EEF4FA', bloom: false, exposure: 0.85, onFrame });
  const { scene, camera } = stage;
  const { mesh: water, uniforms } = makeWater({ segments: isMobile() ? 120 : 220, size: 320 });
  uniforms.uFogNear.value = 30; uniforms.uFogFar.value = 120;
  scene.add(water); scene.add(makeSky(uniforms));
  const pedestals = [];
  const podMat = M.lacquer('#EDE8E0'), podTop = M.lacquer('#121A26'), ringMat = M.metal('#D8C49A', { rough: 0.25 });
  items.forEach((p, i) => {
    const g = new THREE.Group();
    const x = i * spacing;
    const kar = p.line === 'karaoke';
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.6, 0.9, 64), kar ? M.lacquer('#1a2233') : podMat);
    base.position.y = 0.25; base.castShadow = base.receiveShadow = true; g.add(base);
    const top = new THREE.Mesh(new THREE.CylinderGeometry(2.25, 2.25, 0.06, 64), kar ? M.lacquer('#0b1220') : podTop); top.position.y = 0.73; top.receiveShadow = true; g.add(top);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.4, 0.05, 12, 96), kar ? M.glow('#ff6a4c', 2) : ringMat); ring.rotation.x = Math.PI / 2; ring.position.y = 0.7; g.add(ring);
    const m = buildModel(p.model, { finish: p.finish });
    const box = new THREE.Box3().setFromObject(m); const s = box.getSize(new THREE.Vector3());
    const scale = Math.min(1.6, 3.4 / Math.max(s.x, s.z), 5.5 / s.y);
    m.scale.setScalar(scale); m.position.y = 0.76 + m.userData.lift * scale; m.rotation.y = -0.35;
    g.add(m);
    g.position.set(x, 0, 0);
    g.userData = { model: m, ring, playing: 0 };
    scene.add(g);
    pedestals.push(g);
  });
  // cầu tàu nối các bục
  const pier = new THREE.Mesh(new THREE.BoxGeometry(spacing * (items.length + 3), 0.12, 1.1), M.woodMat()); pier.position.set(spacing * (items.length - 1) / 2, 0.1, 3.4); pier.receiveShadow = true; scene.add(pier);
  stage.key.position.set(10, 20, 14);
  const controls = new OrbitControls(camera, canvas);
  controls.cursorStyle = 'grab'; // con trỏ hình bàn tay: báo hiệu có thể kéo để xoay
  controls.enablePan = false; controls.enableDamping = true; controls.minDistance = 7; controls.maxDistance = 22; controls.maxPolarAngle = Math.PI / 2 - 0.08; controls.minPolarAngle = 0.5;
  controls.enableZoom = false;
  const target = new THREE.Vector3(), camGoal = new THREE.Vector3();
  let current = 0;
  function focus(i) {
    current = i;
    const x = i * spacing;
    target.set(x, 2.0, 0);
    camGoal.set(x + 4.2, 4.4, 12.5);
    ripples.push({ x, y: 0, z: stage.time, w: 0.15 }); if (ripples.length > MAX_RIPPLES) ripples.shift();
    $('[data-sr-poster]')?.remove();
  }
  let flying = true;
  focus(0);
  camera.position.set(-6, 9, 22);
  controls.target.set(0, 2, 0);
  controls.addEventListener('start', () => { flying = false; });
  const ray = new THREE.Raycaster();
  canvas.addEventListener('click', (e) => {
    const r = canvas.getBoundingClientRect();
    ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), camera);
    const hits = ray.intersectObjects(pedestals, true);
    if (!hits.length) return;
    let o = hits[0].object; while (o.parent && !pedestals.includes(o)) o = o.parent;
    const i = pedestals.indexOf(o);
    if (i === idx) play(i); else select(i);
  });
  function play(i) {
    audio.play();
    pedestals[i].userData.playing = 6;
    ripples.push({ x: i * spacing, y: 0, z: stage.time, w: 0.35 }); if (ripples.length > MAX_RIPPLES) ripples.shift();
  }
  audio.onBeat((b) => { ripples.push({ x: current * spacing, y: 0, z: stage.time, w: 0.06 + b * 0.12 }); if (ripples.length > MAX_RIPPLES) ripples.shift(); });
  const rm = reducedMotion();
  function onFrame(t, dt) {
    const bands = audio.readBands(t);
    uniforms.uTime.value = t; uniforms.uBass.value = bands.bass; uniforms.uTreble.value = bands.treble;
    uniforms.uSpeaker.value.set(current * spacing, 0);
    for (let i = 0; i < MAX_RIPPLES; i++) { const r = ripples[i]; uniforms.uRipples.value[i].set(r ? r.x : 0, r ? r.y : 0, r ? r.z : -100, r ? r.w : 0); }
    pedestals.forEach((p, i) => {
      p.position.y = Math.sin(t * 0.8 + i) * 0.06;
      const m = p.userData.model;
      if (i === current && !rm) m.rotation.y += dt * 0.35;
      if (p.userData.playing > 0) { p.userData.playing -= dt; m.userData.update(t, bands); } else m.userData.update(t, { bass: 0, mid: 0, treble: 0 });
    });
    if (!rm) {
      controls.target.lerp(target, Math.min(1, dt * 2.2));
      if (flying) camera.position.lerp(camGoal, Math.min(1, dt * 1.6));
      else { const off = camera.position.clone().sub(controls.target); camera.position.copy(controls.target).add(off); camGoal.copy(camera.position).add(target.clone().sub(controls.target)); camera.position.lerp(camGoal, Math.min(1, dt * 2)); }
    } else { controls.target.copy(target); camera.position.copy(camGoal); }
    water.position.set(camera.position.x, 0, camera.position.z - 60);
    controls.update();
  }
  api3d = { focus: (i) => { flying = true; focus(i); }, play };
  stage.start();
}
