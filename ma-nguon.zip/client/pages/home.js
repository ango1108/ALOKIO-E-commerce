// Trang chủ: hero mặt nước, bộ sưu tập 3D, phòng vật liệu, tách lớp, núm vặn, karaoke, so kích thước.
import { $, $$, esc, countUp, toast } from '../lib/core.js';
import { webglOK, liteMode, reducedMotion, isMobile } from '../three/support.js';
import * as audio from '../audio.js';

const can3D = webglOK() && !liteMode();

// Tải lười một cảnh 3D khi khối sắp vào màn hình
function whenNear(el, fn, margin = '300px') {
  if (!el) return;
  const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { io.disconnect(); fn(); } }, { rootMargin: margin });
  io.observe(el);
}
const idle = (fn) => ('requestIdleCallback' in window ? requestIdleCallback(fn, { timeout: 1200 }) : setTimeout(fn, 300));

// ---------- Gắn / gỡ khung 3D theo vị trí cuộn (tiết kiệm RAM & bộ nhớ đồ hoạ) ----------
// Mỗi khung WebGL chỉ được tạo khi sắp cuộn tới (cách ~1 màn hình) và được GỠ HẲN khi đã cuộn xa (> ~2 màn hình):
// trước khi gỡ, chụp lại khung hình hiện tại làm ảnh giữ chỗ, nên người xem không thấy khoảng trống.
// Nhờ vậy cùng lúc chỉ còn 2–3 khung 3D thay vì 8, điện thoại không còn bị tràn bộ nhớ rồi tải lại trang.
function live3d(anchor, mount, { near = '100% 0px', far = '200% 0px', gate = () => true } = {}) {
  if (!anchor) return { refresh() {}, sleep() {} };
  let inst = null, busy = false, isNear = false, snap = null;
  const up = async () => {
    if (inst || busy || !gate()) return; busy = true;
    try { inst = await mount(); } catch (e) { inst = null; } finally { busy = false; }
    if (snap) { const s = snap; snap = null; setTimeout(() => s.remove(), 450); }
    if (inst && (!isNear || !gate())) down();
  };
  const down = () => {
    if (!inst || busy) return;
    const { canvas, render, dispose, extras = [] } = inst; inst = null;
    try {
      render && render();
      const img = document.createElement('img');
      img.src = canvas.toDataURL('image/jpeg', 0.86); img.alt = ''; img.setAttribute('aria-hidden', 'true'); img.className = 'live3d-snap';
      img.style.cssText = `position:absolute;left:${canvas.offsetLeft}px;top:${canvas.offsetTop}px;width:${canvas.offsetWidth}px;height:${canvas.offsetHeight}px;pointer-events:none`;
      canvas.before(img); snap = img;
    } catch (e) { /* bỏ qua: không chụp được thì để trống trong lúc ở xa */ }
    try { dispose(); } catch (e) {}
    extras.forEach((el) => el.remove());
    if (canvas.hasAttribute('data-hero-canvas')) canvas.style.visibility = 'hidden'; else canvas.remove();
  };
  new IntersectionObserver((es) => { if (es[es.length - 1].isIntersecting) { isNear = true; up(); } }, { rootMargin: near }).observe(anchor);
  new IntersectionObserver((es) => { if (!es[es.length - 1].isIntersecting) { isNear = false; down(); } }, { rootMargin: far }).observe(anchor);
  // refresh(): gọi khi điều kiện gate() đổi (vd đổi tab) — gắn lại nếu đang ở gần, hoặc gỡ nếu không còn được hiển thị
  return { refresh: () => { if (gate()) { if (isNear) up(); } else down(); }, sleep: down };
}
const newCanvas = (host) => { const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); host.prepend(c); return c; };
const added = (host, before) => [...host.children].filter((el) => !before.includes(el) && el.tagName !== 'CANVAS');

// ---------- HERO ----------
const heroCanvas = $('[data-hero-canvas]');
// Đoạn mở đầu (sóng đánh loa → "Alokio xin chào"): chỉ trang chủ, lần đầu trong mỗi lần truy cập.
// Màn chờ (browser/loader.html) đã gắn lớp .alk-intro ngay khi mở trang nếu đủ điều kiện.
const html = document.documentElement;
const introOn = html.classList.contains('alk-intro') && heroCanvas && can3D && !reducedMotion();
if (!introOn) html.classList.remove('alk-intro');
if (introOn) {
  heroCanvas.dataset.intro = '1';
  const hello = document.createElement('div');
  hello.className = 'intro-hello'; hello.setAttribute('aria-hidden', 'true');
  hello.innerHTML = 'Alokio <em>xin chào</em><small>Âm Thanh Việt</small>';
  heroCanvas.parentElement.append(hello);
  const finish = () => {
    if (!html.classList.contains('alk-intro')) return;
    hello.classList.remove('is-on'); hello.classList.add('is-off');
    html.classList.remove('alk-intro'); html.classList.add('alk-intro-out');
    setTimeout(() => { html.classList.remove('alk-intro-out'); hello.remove(); }, 1400);
  };
  heroCanvas.addEventListener('alk:intro-go', () => { try { sessionStorage.setItem('alokio:intro', '1'); } catch { /* noop */ } });
  heroCanvas.addEventListener('alk:intro-hello', () => hello.classList.add('is-on'));
  heroCanvas.addEventListener('alk:intro-done', finish);
  heroCanvas.addEventListener('alk:intro-skip', () => { heroCanvas.dataset.intro = '0'; hello.remove(); html.classList.remove('alk-intro'); });
  setTimeout(finish, 9000); // an toàn: nếu có trục trặc thì vẫn hiện trang
}
if (heroCanvas && can3D) {
  let heroCv = heroCanvas, firstHero = true;
  live3d(heroCanvas.parentElement, async () => {
    if (firstHero) await new Promise((r) => (introOn ? r() : idle(r)));
    else { const n = heroCv.cloneNode(false); n.classList.remove('is-ready'); n.style.visibility = ''; n.dataset.intro = '0'; heroCv.replaceWith(n); heroCv = n; }
    firstHero = false;
    const { mountHero } = await import('../three/hero.js');
    const hero = mountHero(heroCv, { onReady: () => $('.hero__poster')?.setAttribute('style', 'opacity:0;transition:opacity .6s') });
    window.__hero = hero;
    return { canvas: heroCv, render: () => hero.stage.render(), dispose: () => { window.__hero = null; hero.dispose(); } };
  }, { near: '60% 0px', far: '160% 0px' });
}

// ---------- Tabs bộ sưu tập ----------
const tabs = $$('[data-tab]');
const viewers = new Map();
async function activate(id) {
  tabs.forEach((t) => { const on = t.dataset.tab === id; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
  $$('[data-panel]').forEach((p) => { p.hidden = p.dataset.panel !== id; });
  for (const [k, v] of viewers) if (k !== id) { v.dispose(); viewers.delete(k); $(`[data-panel="${k}"] [data-stage-view]`)?.classList.remove('is-3d'); }
  const view = $(`[data-panel="${id}"] [data-stage-view]`);
  if (can3D && view && !viewers.has(id)) mountStage(id, view);
}
async function mountStage(id, view) {
  const { mountViewer } = await import('../three/viewer.js');
  let c = view.querySelector('canvas');
  if (!c) { c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); view.prepend(c); }
  viewers.set(id, mountViewer(c, { model: JSON.parse(view.dataset.model), finish: view.dataset.finish, knob: 'champagne', strap: 'bo', padding: 1.25 }));
}
tabs.forEach((t, i) => {
  t.addEventListener('click', () => activate(t.dataset.tab));
  t.addEventListener('keydown', (e) => {
    const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
    if (!d) return;
    const n = tabs[(i + d + tabs.length) % tabs.length]; n.focus(); activate(n.dataset.tab);
  });
});
const firstView = $('[data-panel]:not([hidden]) [data-stage-view]');
if (can3D && firstView) whenNear(firstView, () => mountStage(tabs[0].dataset.tab, firstView));

// ---------- Phòng vật liệu ----------
const mr = $('[data-matroom]');
// ---------- Chương "Bên trong Alokio": 3 tab, chỉ tab đang mở được giữ khung 3D ----------
let inTab = 0;
const inCtl = [];
const ins = $('[data-inside]');
if (can3D && mr) inCtl[0] = live3d(mr, async () => {
  const { mountMaterials } = await import('../three/scenes.js');
  const c = newCanvas(mr), st = mountMaterials(c);
  return { canvas: c, render: () => st.render(), dispose: () => st.dispose() };
}, { gate: () => inTab === 0 });

// ---------- Tách lớp ----------
const ex = $('[data-exploded]');
let exK = 0;
const setExplode = (k) => {
  exK = Math.min(1, Math.max(0, k));
  ex?.dispatchEvent(new CustomEvent('alk:explode', { detail: exK }));
  const r = $('[data-ex-range]'), o = $('[data-ex-out]');
  if (r) r.value = String(Math.round(exK * 100)); if (o) o.textContent = Math.round(exK * 100) + '%';
};
let exAnim = 0;
const animateExplode = (to, ms = 2200) => {
  cancelAnimationFrame(exAnim); const from = exK, t0 = performance.now();
  const step = (t) => { const u = Math.min(1, (t - t0) / ms), e = u < .5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2; setExplode(from + (to - from) * e); if (u < 1) exAnim = requestAnimationFrame(step); };
  exAnim = requestAnimationFrame(step);
};
if (ex) {
  const steps = $$('[data-exploded-steps] li', ex);
  whenNear(ex.closest('section'), () => $$('.stat b', ex).forEach((b) => countUp(b)));
  if (!can3D) steps.forEach((s) => s.classList.add('is-on'));
  $('[data-ex-range]', ex)?.addEventListener('input', (e) => { cancelAnimationFrame(exAnim); setExplode(Number(e.target.value) / 100); });
  // Bấm vào một bộ phận: mở loa tới đúng lớp đó; trên điện thoại bấm lần nữa để xem thông số
  steps.forEach((li, k) => li.querySelector('[data-ex-step]')?.addEventListener('click', () => {
    const open = li.classList.contains('is-open');
    steps.forEach((x) => x.classList.remove('is-open'));
    if (!open) li.classList.add('is-open');
    animateExplode((k + 0.65) / steps.length, 900);
  }));
  if (can3D) inCtl[1] = live3d($('[data-exploded-view]'), async () => {
    const { mountExploded } = await import('../three/scenes.js');
    const v = $('[data-exploded-view]'), before = [...v.children];
    const c = newCanvas(v), st = mountExploded(c, ex, steps);
    requestAnimationFrame(() => setExplode(exK));
    return { canvas: c, render: () => st.render(), dispose: () => st.dispose(), extras: added(v, before) };
  }, { gate: () => inTab === 1 });
}

// ---------- Núm vặn ----------
const kv = $('[data-knobs-view]'), ks = $('[data-knob-sliders]');
if (kv && ks) {
  // Thanh Volume luôn khớp với âm lượng thật (mặc định 15%), kể cả khi khách chỉnh ở thanh bên phải
  const kvol = $('[data-eq="volume"]', ks);
  const showVol = (v) => { const p = Math.round(v * 100); if (!kvol || Number(kvol.value) === p) return; kvol.value = p; kvol.parentElement.querySelector('output').textContent = p; };
  showVol(audio.getVolume()); audio.onVolume(showVol);
  // Thanh trượt luôn hoạt động (kể cả khi không có 3D)
  ks.addEventListener('input', (e) => {
    const s = e.target.closest('[data-eq]'); if (!s || window.__knob3d) return;
    const v = Number(s.value);
    s.parentElement.querySelector('output').textContent = s.dataset.eq === 'volume' ? v : `${v > 0 ? '+' : ''}${v} dB`;
    audio.setEQ({ [s.dataset.eq]: s.dataset.eq === 'volume' ? v / 100 : v });
  });
  if (can3D) live3d(kv, async () => {
    const { mountKnobs } = await import('../three/scenes.js');
    const c = newCanvas(kv);
    window.__knob3d = true;
    const st = mountKnobs(c, ks);
    return { canvas: c, render: () => st.render(), dispose: () => { window.__knob3d = false; st.dispose(); } };
  }, { gate: () => inTab === 2 });
}

// Đổi tab: chụp & gỡ khung 3D của tab cũ trước khi ẩn, rồi gắn khung của tab mới
if (ins) {
  const tabs = $$('[data-in-tab]', ins), panels = $$('[data-in-panel]', ins);
  let opened = false;
  const show = (i, focus) => {
    if (i === inTab) return;
    const prev = inTab; inTab = i;
    inCtl[prev]?.sleep();
    tabs.forEach((t, k) => { t.setAttribute('aria-selected', String(k === i)); t.tabIndex = k === i ? 0 : -1; });
    panels.forEach((p, k) => { p.hidden = k !== i; });
    inCtl[i]?.refresh();
    if (focus) tabs[i].focus();
    if (i === 1 && !opened && !reducedMotion()) { opened = true; setTimeout(() => animateExplode(0.72, 2600), 500); }
  };
  tabs.forEach((t, i) => t.addEventListener('click', () => show(i)));
  ins.querySelector('[role=tablist]').addEventListener('keydown', (e) => {
    const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0; if (!d) return;
    e.preventDefault(); show((inTab + d + tabs.length) % tabs.length, true);
  });
}

// ---------- Trình phát nghe thử ngay tại mục "Chạm vào âm thanh" ----------
const kp = $('[data-kplayer]');
if (kp) {
  const list = $('[data-kp-list]', kp), toggle = $('[data-kp-toggle]', kp);
  list.innerHTML = audio.TRACKS.map((t) => `<button type="button" role="radio" aria-checked="false" data-kp-track="${t.id}"><span class="kplayer__dot" aria-hidden="true"></span><span><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span></button>`).join('');
  const paint = () => {
    const m = audio.getMode(), on = audio.isPlaying();
    kp.classList.toggle('is-playing', on);
    toggle.setAttribute('aria-pressed', String(on));
    toggle.setAttribute('aria-label', on ? 'Tạm dừng' : 'Phát nhạc để nghe thử');
    $('[data-kp-title]', kp).textContent = audio.getTrack().title;
    $('[data-kp-state]', kp).textContent = on ? 'Đang phát' : 'Bấm ▶ để nghe thử';
    $$('[data-kp-track]', list).forEach((b) => b.setAttribute('aria-checked', String(b.dataset.kpTrack === m)));
  };
  paint(); audio.onChange(paint); audio.onMode(paint);
  toggle.addEventListener('click', () => audio.toggle());
  list.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-kp-track]'); if (!b) return;
    await audio.setMode(b.dataset.kpTrack);
    if (!audio.isPlaying()) audio.play();
  });
}

// ---------- Karaoke ----------
const kav = $('[data-karaoke-view]');
if (can3D && kav) live3d(kav, async () => {
  const { mountViewer } = await import('../three/viewer.js');
  const c = newCanvas(kav);
  const vw = mountViewer(c, { model: JSON.parse(kav.dataset.model), finish: 'go-den', dark: true, bloom: true, padding: 1.15, azim: -0.45, elev: 0.18 });
  const poster = kav.querySelector('img:not(.live3d-snap)'); if (poster) poster.style.opacity = '0';
  return { canvas: c, render: () => vw.stage.render(), dispose: () => vw.dispose() };
});
const micBtn = $('[data-karaoke-mic]');
let micOn = false, micRaf = 0;
micBtn && micBtn.addEventListener('click', async () => {
  const lvl = $('[data-mic-level]');
  if (micOn) { audio.stopMic(); micOn = false; cancelAnimationFrame(micRaf); lvl.style.width = '0'; micBtn.lastChild.textContent = ' Thử hát karaoke'; return; }
  try {
    const read = await audio.startMic();
    audio.setEQ({ echo: 0.45 });
    micOn = true; micBtn.lastChild.textContent = ' Dừng hát';
    const loop = () => { const v = read(); lvl.style.width = Math.min(100, v * 160) + '%'; if (v > 0.25 && window.__hero) window.__hero.splash(); micRaf = requestAnimationFrame(loop); };
    loop();
    toast('Micro đã bật — hãy hát thử! (nên dùng tai nghe để tránh hú)', { type: 'info' });
  } catch { toast('Không bật được micro. Hãy cho phép quyền micro trong trình duyệt.', { type: 'info' }); }
});

// ---------- So kích thước ----------
const sz = $('[data-sizecmp]');
if (can3D && sz) live3d(sz, async () => {
  const { mountSizeCompare } = await import('../three/scenes.js');
  const before = [...sz.children], c = newCanvas(sz);
  const st = mountSizeCompare(c, [
    { name: 'Luxe Giọt', model: { type: 'pebble' }, finish: 'suong-som', slot: 'table' },
    { name: 'Luxe Hạ Long', model: { type: 'halong' }, finish: 'ngoc-trai', slot: 'tvRight', rot: -.25 },
    { name: 'Luxe Sông Hương', model: { type: 'bar' }, finish: 'huyen', slot: 'bar' },
    { name: 'Luxe Hội An', model: { type: 'hifi', size: 's' }, finish: 'oc-cho', slot: 'shelf' },
    { name: 'Luxe Tràng An', model: { type: 'hifi', size: 'l' }, finish: 'huyen', slot: 'sbR', rot: -.12 },
    { name: 'Luxe Lễ Hội', model: { type: 'tower' }, finish: 'huyen', slot: 'floorR', rot: .2 },
    { name: 'Loa kéo AL-AK18', model: { type: 'trolley', bass: 5, style: 'ak' }, finish: 'go-den', slot: 'floorL', rot: .3 },
  ]);
  return { canvas: c, render: () => st.render(), dispose: () => st.dispose(), extras: added(sz, before) };
});

if (reducedMotion()) $$('.stat b').forEach((b) => countUp(b));
