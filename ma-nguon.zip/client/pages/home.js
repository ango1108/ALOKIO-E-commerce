// Trang chủ: hero mặt nước, bộ sưu tập 3D, phòng vật liệu, tách lớp, núm vặn, karaoke, so kích thước.
import { $, $$, esc, countUp, toast } from '../lib/core.js';
import { webglOK, liteMode, reducedMotion, isMobile } from '../three/support.js';
import * as audio from '../audio.js';

const can3D = webglOK() && !liteMode();

// Tải lười một cảnh 3D khi khối sắp vào màn hình
function whenNear(el, fn, margin = '300px') {
  if (!el) return;
  const io = new IntersectionObserver((es) => { if (es[0].isIntersecting) { io.disconnect(); fn(); } }, { rootMargin: margin });
  io.observe(el);
}
const idle = (fn) => ('requestIdleCallback' in window ? requestIdleCallback(fn, { timeout: 1200 }) : setTimeout(fn, 300));

// ---------- HERO ----------
const heroCanvas = $('[data-hero-canvas]');
if (heroCanvas && can3D) {
  idle(async () => {
    const { mountHero } = await import('../three/hero.js');
    const hero = mountHero(heroCanvas, { onReady: () => $('.hero__poster')?.setAttribute('style', 'opacity:0;transition:opacity .6s') });
    window.__hero = hero;
  });
}

// ---------- Tabs bộ sưu tập ----------
const tabs = $$('[data-tab]');
const viewers = new Map();
async function activate(id) {
  tabs.forEach((t) => { const on = t.dataset.tab === id; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
  $$('[data-panel]').forEach((p) => { p.hidden = p.dataset.panel !== id; });
  for (const [k, v] of viewers) if (k !== id) { v.dispose(); viewers.delete(k); $(`[data-panel="${k}"] [data-stage-view]`)?.classList.remove('is-3d'); }
  const view = $(`[data-panel="${id}"] [data-stage-view]`);
  if (can3D && view && !viewers.has(id)) mountStage(id, view);
}
async function mountStage(id, view) {
  const { mountViewer } = await import('../three/viewer.js');
  let c = view.querySelector('canvas');
  if (!c) { c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); view.prepend(c); }
  viewers.set(id, mountViewer(c, { model: JSON.parse(view.dataset.model), finish: view.dataset.finish, knob: 'champagne', strap: 'bo', padding: 1.25 }));
}
tabs.forEach((t, i) => {
  t.addEventListener('click', () => activate(t.dataset.tab));
  t.addEventListener('keydown', (e) => {
    const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
    if (!d) return;
    const n = tabs[(i + d + tabs.length) % tabs.length]; n.focus(); activate(n.dataset.tab);
  });
});
const firstView = $('[data-panel]:not([hidden]) [data-stage-view]');
if (can3D && firstView) whenNear(firstView, () => mountStage(tabs[0].dataset.tab, firstView));

// ---------- Phòng vật liệu ----------
const mr = $('[data-matroom]');
if (can3D && mr) whenNear(mr, async () => {
  const { mountMaterials } = await import('../three/scenes.js');
  const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); mr.prepend(c);
  mountMaterials(c);
});

// ---------- Tách lớp ----------
const ex = $('[data-exploded]');
if (ex) {
  const steps = $$('[data-exploded-steps] li');
  whenNear(ex, async () => {
    $$('.stat b', ex).forEach((b) => countUp(b));
    if (!can3D) { steps.forEach((s) => s.classList.add('is-on')); return; }
    const { mountExploded } = await import('../three/scenes.js');
    const v = $('[data-exploded-view]');
    const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); v.prepend(c);
    mountExploded(c, ex, steps);
    if (isMobile() && !reducedMotion()) touchExplode(v, c);
  });
}

// Điện thoại: vuốt lên / xuống NGAY TRONG khung loa để tách / ghép các lớp.
// Vuốt ở ngoài khung thì trang cuộn bình thường. Khi loa đã mở hết (hoặc đã ghép lại hết)
// mà khách vẫn vuốt tiếp, phần vuốt dư được chuyển thành cuộn trang để không bị "kẹt".
function touchExplode(view, canvas) {
  view.classList.add('is-touch');
  const verb = $('[data-ex-verb]'); if (verb) verb.textContent = 'Vuốt trong khung';
  view.style.touchAction = 'none'; canvas.style.touchAction = 'none';
  const ui = document.createElement('div');
  ui.className = 'exploded__touch'; ui.setAttribute('aria-hidden', 'true');
  ui.innerHTML = '<span class="exploded__hint"><i></i>Vuốt lên trong khung để mở loa</span><span class="exploded__meter"><i></i></span>';
  view.append(ui);
  const hint = ui.querySelector('.exploded__hint'), bar = ui.querySelector('.exploded__meter i');
  let k = 0, lastY = null, id = null, used = false;
  const set = (nk) => {
    k = Math.min(1, Math.max(0, nk));
    ex.dispatchEvent(new CustomEvent('alk:explode', { detail: k }));
    bar.style.transform = `scaleY(${k})`;
    hint.lastChild.textContent = k > 0.97 ? 'Vuốt xuống để ghép loa lại' : 'Vuốt lên trong khung để mở loa';
  };
  set(0);
  view.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' || id != null) return;
    id = e.pointerId; lastY = e.clientY;
    if (!used) { used = true; view.classList.add('is-used'); }
  });
  view.addEventListener('pointermove', (e) => {
    if (e.pointerId !== id || lastY == null) return;
    const dy = lastY - e.clientY; lastY = e.clientY;
    const span = Math.max(260, view.clientHeight * 0.85);
    const nk = k + dy / span;
    if (nk > 1 && k >= 1) window.scrollBy(0, dy);        // đã mở hết → đẩy trang lên
    else if (nk < 0 && k <= 0) window.scrollBy(0, dy);   // đã ghép hết → kéo trang xuống
    set(nk);
  });
  const end = (e) => { if (e.pointerId === id) { id = null; lastY = null; } };
  view.addEventListener('pointerup', end);
  view.addEventListener('pointercancel', end);
}

// ---------- Núm vặn ----------
const kv = $('[data-knobs-view]'), ks = $('[data-knob-sliders]');
if (kv && ks) {
  // Thanh Volume luôn khớp với âm lượng thật (mặc định 15%), kể cả khi khách chỉnh ở thanh bên phải
  const kvol = $('[data-eq="volume"]', ks);
  const showVol = (v) => { const p = Math.round(v * 100); if (!kvol || Number(kvol.value) === p) return; kvol.value = p; kvol.parentElement.querySelector('output').textContent = p; };
  showVol(audio.getVolume()); audio.onVolume(showVol);
  // Thanh trượt luôn hoạt động (kể cả khi không có 3D)
  ks.addEventListener('input', (e) => {
    const s = e.target.closest('[data-eq]'); if (!s || window.__knob3d) return;
    const v = Number(s.value);
    s.parentElement.querySelector('output').textContent = s.dataset.eq === 'volume' ? v : `${v > 0 ? '+' : ''}${v} dB`;
    audio.setEQ({ [s.dataset.eq]: s.dataset.eq === 'volume' ? v / 100 : v });
  });
  if (can3D) whenNear(kv, async () => {
    const { mountKnobs } = await import('../three/scenes.js');
    const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); kv.prepend(c);
    window.__knob3d = true;
    mountKnobs(c, ks);
  });
}

// ---------- Trình phát nghe thử ngay tại mục "Chạm vào âm thanh" ----------
const kp = $('[data-kplayer]');
if (kp) {
  const list = $('[data-kp-list]', kp), toggle = $('[data-kp-toggle]', kp);
  list.innerHTML = audio.TRACKS.map((t) => `<button type="button" role="radio" aria-checked="false" data-kp-track="${t.id}"><span class="kplayer__dot" aria-hidden="true"></span><span><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span></button>`).join('');
  const paint = () => {
    const m = audio.getMode(), on = audio.isPlaying();
    kp.classList.toggle('is-playing', on);
    toggle.setAttribute('aria-pressed', String(on));
    toggle.setAttribute('aria-label', on ? 'Tạm dừng' : 'Phát nhạc để nghe thử');
    $('[data-kp-title]', kp).textContent = audio.getTrack().title;
    $('[data-kp-state]', kp).textContent = on ? 'Đang phát' : 'Bấm ▶ để nghe thử';
    $$('[data-kp-track]', list).forEach((b) => b.setAttribute('aria-checked', String(b.dataset.kpTrack === m)));
  };
  paint(); audio.onChange(paint); audio.onMode(paint);
  toggle.addEventListener('click', () => audio.toggle());
  list.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-kp-track]'); if (!b) return;
    await audio.setMode(b.dataset.kpTrack);
    if (!audio.isPlaying()) audio.play();
  });
}

// ---------- Karaoke ----------
const kav = $('[data-karaoke-view]');
if (can3D && kav) whenNear(kav, async () => {
  const { mountViewer } = await import('../three/viewer.js');
  const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); kav.prepend(c);
  mountViewer(c, { model: JSON.parse(kav.dataset.model), finish: 'go-den', dark: true, bloom: true, padding: 1.15, azim: -0.45, elev: 0.18 });
  kav.querySelector('img').style.opacity = '0';
});
const micBtn = $('[data-karaoke-mic]');
let micOn = false, micRaf = 0;
micBtn && micBtn.addEventListener('click', async () => {
  const lvl = $('[data-mic-level]');
  if (micOn) { audio.stopMic(); micOn = false; cancelAnimationFrame(micRaf); lvl.style.width = '0'; micBtn.lastChild.textContent = ' Thử hát karaoke'; return; }
  try {
    const read = await audio.startMic();
    audio.setEQ({ echo: 0.45 });
    micOn = true; micBtn.lastChild.textContent = ' Dừng hát';
    const loop = () => { const v = read(); lvl.style.width = Math.min(100, v * 160) + '%'; if (v > 0.25 && window.__hero) window.__hero.splash(); micRaf = requestAnimationFrame(loop); };
    loop();
    toast('Micro đã bật — hãy hát thử! (nên dùng tai nghe để tránh hú)', { type: 'info' });
  } catch { toast('Không bật được micro. Hãy cho phép quyền micro trong trình duyệt.', { type: 'info' }); }
});

// ---------- So kích thước ----------
const sz = $('[data-sizecmp]');
if (can3D && sz) whenNear(sz, async () => {
  const { mountSizeCompare } = await import('../three/scenes.js');
  const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); sz.prepend(c);
  mountSizeCompare(c, [
    { model: { type: 'pebble' }, finish: 'suong-som' }, { model: { type: 'halong' }, finish: 'ngoc-trai' },
    { model: { type: 'hifi', size: 's' }, finish: 'oc-cho' }, { model: { type: 'hifi', size: 'l' }, finish: 'huyen' },
    { model: { type: 'tower' }, finish: 'huyen' }, { model: { type: 'trolley', bass: 5, style: 'ak' }, finish: 'go-den' },
  ]);
});

if (reducedMotion()) $$('.stat b').forEach((b) => countUp(b));
