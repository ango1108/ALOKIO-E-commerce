// Hành vi dùng chung cho mọi trang cửa hàng: nav, âm thanh, giỏ hàng, tìm kiếm, chat, realtime…
import { $, $$, api, fmt, esc, toast, openDialog, reveal, store, boot, timeAgo, debounce } from '../lib/core.js';
import * as cart from '../lib/cart.js';
import * as live from '../lib/live.js';
import * as audio from '../audio.js';
import { paintPage } from '../paint.js';

const B = boot();
if (window.__alk) window.__alk.audio = audio; // tiện kiểm tra trong DevTools

// ---------- Nav đổi nền khi cuộn ----------
const nav = $('[data-nav]');
const onScroll = () => nav && nav.classList.toggle('is-scrolled', window.scrollY > 30);
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

// ---------- Âm thanh ----------
function syncSound(on) {
  $$('[data-sound-toggle]').forEach((b) => {
    b.setAttribute('aria-pressed', String(on));
    b.title = `Âm thanh: ${on ? 'Bật' : 'Tắt'}`;
    const l = b.querySelector('[data-sound-label]'); if (l) l.textContent = `Âm thanh: ${on ? 'Bật' : 'Tắt'}`;
  });
  $$('[data-audio-hint]').forEach((h) => { h.hidden = on; });
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-sound-toggle], [data-audio-hint], [data-listen]');
  if (!b) return;
  if (b.matches('[data-listen]')) { audio.play(); return; }
  audio.toggle();
});
audio.onChange(syncSound);
syncSound(false);

// ---------- Thanh điều khiển cạnh phải: âm lượng · chế độ nhạc · lên đầu trang ----------
const rail = $('[data-rail]');
if (rail) {
  const vol = $('[data-vol]', rail), fill = $('[data-vol-fill]', rail), thumb = $('[data-vol-thumb]', rail), pct = $('[data-vol-pct]', rail);
  const tip = $('[data-rail-tip]', rail);
  let tipT = 0;
  const say = (text) => { tip.textContent = text; tip.classList.add('is-on'); clearTimeout(tipT); tipT = setTimeout(() => tip.classList.remove('is-on'), 1800); };
  const paintVol = (v) => {
    const p = Math.round(v * 100);
    fill.style.height = p + '%'; thumb.style.bottom = p + '%'; pct.textContent = p;
    vol.setAttribute('aria-valuenow', String(p)); vol.setAttribute('aria-valuetext', p + '%');
    rail.classList.toggle('is-muted', p === 0);
  };
  paintVol(audio.getVolume());
  audio.onVolume(paintVol);
  const fromY = (y) => { const r = $('.dock__track', rail).getBoundingClientRect(); return Math.min(1, Math.max(0, (r.bottom - y) / r.height)); };
  const setV = (v, start) => { audio.setVolume(v); if (start && v > 0 && !audio.isPlaying()) audio.play(); };
  vol.addEventListener('pointerdown', (e) => {
    e.preventDefault(); vol.setPointerCapture(e.pointerId); rail.classList.add('is-drag'); setV(fromY(e.clientY), true);
    const move = (ev) => setV(fromY(ev.clientY));
    const up = () => { rail.classList.remove('is-drag'); vol.removeEventListener('pointermove', move); vol.removeEventListener('pointerup', up); vol.removeEventListener('pointercancel', up); say(`Âm lượng ${Math.round(audio.getVolume() * 100)}%`); };
    vol.addEventListener('pointermove', move); vol.addEventListener('pointerup', up); vol.addEventListener('pointercancel', up);
  });
  vol.addEventListener('keydown', (e) => {
    const k = { ArrowUp: 0.05, ArrowRight: 0.05, ArrowDown: -0.05, ArrowLeft: -0.05, PageUp: 0.2, PageDown: -0.2 }[e.key];
    if (e.key === 'Home') { e.preventDefault(); setV(0); } else if (e.key === 'End') { e.preventDefault(); setV(1, true); }
    else if (k) { e.preventDefault(); setV(Math.round((audio.getVolume() + k) * 100) / 100, k > 0); }
  });
  vol.addEventListener('wheel', (e) => { e.preventDefault(); setV(Math.round((audio.getVolume() - Math.sign(e.deltaY) * 0.05) * 100) / 100); }, { passive: false });

  // Menu chọn nhạc nền
  const openBtn = $('[data-music-open]', rail), menu = $('[data-music-menu]', rail), list = $('[data-music-list]', rail);
  list.innerHTML = audio.TRACKS.map((t) => `<button type="button" role="menuitemradio" aria-checked="false" data-track="${t.id}"><span class="eqbars" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span class="dock__song"><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></span></button>`).join('');
  const paintMode = () => {
    const m = audio.getMode(), on = audio.isPlaying();
    $$('[data-track]', list).forEach((b) => { const act = b.dataset.track === m; b.setAttribute('aria-checked', String(act)); b.classList.toggle('is-playing', act && on); });
    rail.classList.toggle('is-playing', on);
    openBtn.title = `Nhạc nền: ${audio.getTrack().title}`;
  };
  paintMode();
  audio.onMode(paintMode);
  audio.onChange(paintMode);
  const closeMenu = () => { menu.hidden = true; openBtn.setAttribute('aria-expanded', 'false'); };
  openBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open; openBtn.setAttribute('aria-expanded', String(open));
    if (open) ($('[aria-checked="true"]', list) || $('[data-track]', list)).focus();
  });
  list.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-track]'); if (!b) return;
    const same = b.dataset.track === audio.getMode();
    if (same && audio.isPlaying()) { audio.pause(); return; }
    await audio.setMode(b.dataset.track);
    if (!audio.isPlaying()) audio.play();
    say(`♪ ${audio.getTrack().title}`);
  });
  menu.addEventListener('keydown', (e) => {
    const items = $$('[data-track]', list); const i = items.indexOf(document.activeElement);
    if (e.key === 'Escape') { closeMenu(); openBtn.focus(); }
    if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
  });
  document.addEventListener('click', (e) => { if (!menu.hidden && !e.target.closest('.dock__music')) closeMenu(); });

  const topBtn = $('[data-to-top]', rail);
  topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }));
  const onScroll = () => rail.classList.toggle('is-top', window.scrollY < 200);
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
}
// Đã từng bật → bật lại ở lần chạm đầu tiên (trình duyệt không cho tự phát)
if (audio.wantsSound()) {
  const resume = (e) => { if (e.target.closest('[data-sound-toggle], [data-knobs-view], [data-knob-sliders], [data-kplayer], [data-music-open], [data-music-menu]')) return; audio.play(); window.removeEventListener('pointerdown', resume); window.removeEventListener('keydown', resume); };
  window.addEventListener('pointerdown', resume); window.addEventListener('keydown', resume);
}

// ---------- Chế độ nhẹ ----------
function syncLite() {
  const on = document.documentElement.classList.contains('lite');
  $$('[data-lite-toggle]').forEach((b) => { b.setAttribute('aria-pressed', String(on)); const s = b.querySelector('span'); if (s) s.textContent = `Chế độ nhẹ: ${on ? 'Bật' : 'Tắt'}`; });
}
document.addEventListener('click', (e) => {
  if (!e.target.closest('[data-lite-toggle]')) return;
  const on = !document.documentElement.classList.contains('lite');
  document.documentElement.classList.toggle('lite', on);
  try { localStorage.setItem('alokio:lite', on ? '1' : '0'); } catch { /* noop */ }
  syncLite();
  toast(on ? 'Đã bật chế độ nhẹ: tắt hiệu ứng 3D để tiết kiệm pin.' : 'Đã tắt chế độ nhẹ. Tải lại trang để bật 3D.', { type: 'info' });
});
syncLite();

// ---------- Badge giỏ, yêu thích, so sánh ----------
function badges() {
  const set = (sel, n) => $$(sel).forEach((b) => { b.textContent = n; b.hidden = !n; });
  set('[data-cart-count]', cart.count());
  set('[data-wish-count]', store.get('wish', []).length);
  set('[data-compare-count]', store.get('compare', []).length);
  $$('[data-wish]').forEach((b) => b.setAttribute('aria-pressed', String(store.get('wish', []).includes(b.dataset.wish))));
}
badges();
cart.onChange(() => { badges(); if (!$('[data-minicart]').hidden) renderMini(); });
live.on('wish.changed', badges);
live.on('compare.changed', badges);

// ---------- Mini cart ----------
const mini = $('[data-minicart]');
let closeMini = null;
async function renderMini() {
  const body = $('[data-minicart-body]'), foot = $('[data-minicart-foot]');
  try {
    const p = await cart.price();
    body.innerHTML = cart.freeShipHTML(p, p.freeThreshold || 3000000) + cart.renderLines(p);
    foot.innerHTML = p.lines.length ? `<div class="row row--total"><span>Tạm tính</span><span>${fmt(p.subtotal)}</span></div>
      <a class="btn btn--primary btn--block" href="/thanh-toan">Thanh toán</a><a class="btn btn--ghost btn--block" href="/gio-hang">Xem giỏ hàng</a>` : '';
  } catch (err) { body.innerHTML = `<p class="err">${esc(err.message)}</p>`; }
}
cart.bindLineControls($('[data-minicart-body]'), renderMini);
export function openMini() { renderMini(); closeMini = openDialog(mini); }
document.addEventListener('click', (e) => { if (e.target.closest('[data-cart-open]')) { e.preventDefault(); openMini(); } });

// Thêm vào giỏ từ các nút [data-add]
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-add]');
  if (!b) return;
  e.preventDefault();
  const item = { productId: b.dataset.add, finish: b.dataset.finish, qty: 1, options: {} };
  cart.add(item);
  flyToCart(b);
  toast(`Đã thêm ${b.dataset.name || 'sản phẩm'} vào giỏ.`, { link: '/gio-hang', linkText: 'Xem giỏ' });
});

// Hiệu ứng "bay vào giỏ"
export function flyToCart(from, imgSrc) {
  const target = $('[data-cart-open]');
  if (!target || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const a = from.getBoundingClientRect(), b = target.getBoundingClientRect();
  const src = imgSrc || from.closest('.pcard, .stage, .pdp, .kcard')?.querySelector('img')?.src;
  const el = document.createElement(src ? 'img' : 'div');
  if (src) el.src = src;
  Object.assign(el.style, { position: 'fixed', left: a.left + a.width / 2 - 40 + 'px', top: a.top + a.height / 2 - 40 + 'px', width: '80px', height: '80px', objectFit: 'contain', zIndex: 400, borderRadius: '20px', background: src ? 'rgba(255,255,255,.9)' : 'var(--primary)', boxShadow: '0 20px 40px rgba(43,92,148,.25)', pointerEvents: 'none' });
  document.body.appendChild(el);
  const dx = b.left + b.width / 2 - (a.left + a.width / 2), dy = b.top + b.height / 2 - (a.top + a.height / 2);
  el.animate([
    { transform: 'translate(0,0) scale(1) rotate(0deg)', opacity: 1 },
    { transform: `translate(${dx * 0.5}px, ${dy * 0.5 - 120}px) scale(.8) rotate(-12deg)`, opacity: 1, offset: 0.55 },
    { transform: `translate(${dx}px, ${dy}px) scale(.15) rotate(10deg)`, opacity: 0.3 },
  ], { duration: 900, easing: 'cubic-bezier(.22,1,.36,1)' }).onfinish = () => {
    el.remove();
    target.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.25)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(.22,1,.36,1)' });
    const ring = document.createElement('span');
    Object.assign(ring.style, { position: 'fixed', left: b.left + b.width / 2 - 20 + 'px', top: b.top + b.height / 2 - 20 + 'px', width: '40px', height: '40px', borderRadius: '99px', border: '2px solid var(--primary)', zIndex: 400, pointerEvents: 'none' });
    document.body.appendChild(ring);
    ring.animate([{ transform: 'scale(.6)', opacity: 1 }, { transform: 'scale(2.4)', opacity: 0 }], { duration: 700, easing: 'ease-out' }).onfinish = () => ring.remove();
  };
}
window.__alokioFly = flyToCart;

// ---------- Yêu thích / so sánh ----------
document.addEventListener('click', (e) => {
  const w = e.target.closest('[data-wish]');
  if (w) {
    e.preventDefault();
    const list = store.get('wish', []); const id = w.dataset.wish; const i = list.indexOf(id);
    if (i >= 0) list.splice(i, 1); else list.push(id);
    store.set('wish', list); live.local('wish.changed', list);
    toast(i >= 0 ? 'Đã bỏ khỏi danh sách yêu thích.' : 'Đã thêm vào danh sách yêu thích.', { type: i >= 0 ? 'info' : 'ok', link: '/yeu-thich', linkText: 'Xem' });
    if (B.user) api('/api/account/wishlist', { method: 'POST', body: { ids: list } }).catch(() => {});
  }
  const c = e.target.closest('[data-compare]');
  if (c) {
    e.preventDefault();
    const list = store.get('compare', []); const id = c.dataset.compare; const i = list.indexOf(id);
    if (i >= 0) list.splice(i, 1); else { if (list.length >= 4) list.shift(); list.push(id); }
    store.set('compare', list); live.local('compare.changed', list);
    c.setAttribute('aria-pressed', String(i < 0));
    toast(i >= 0 ? 'Đã bỏ khỏi so sánh.' : `Đã thêm vào so sánh (${list.length}/4).`, { type: 'info', link: '/so-sanh', linkText: 'So sánh' });
  }
});

// ---------- Menu di động ----------
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-drawer-open]');
  if (!b) return;
  b.setAttribute('aria-expanded', 'true');
  openDialog($('[data-mobile-menu]'), { onClose: () => b.setAttribute('aria-expanded', 'false') });
});

// ---------- Tìm kiếm tức thì ----------
const searchBox = $('[data-search]');
document.addEventListener('click', (e) => { if (e.target.closest('[data-search-open]')) openDialog(searchBox); });
document.addEventListener('keydown', (e) => { if ((e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) || ((e.ctrlKey || e.metaKey) && e.key === 'k')) { e.preventDefault(); openDialog(searchBox); } });
const sInput = $('[data-search-input]'), sList = $('[data-search-suggest]');
sInput && sInput.addEventListener('input', debounce(async () => {
  const q = sInput.value.trim();
  if (q.length < 2) { sList.innerHTML = ''; return; }
  const r = await api('/api/search?q=' + encodeURIComponent(q)).catch(() => ({ items: [] }));
  sList.innerHTML = r.items.map((it) => `<li role="option"><a href="${esc(it.href)}">${it.image ? `<img src="${esc(it.image)}" alt="" width="52" height="52">` : ''}<span><b>${esc(it.title)}</b><br><small class="muted">${esc(it.sub)}</small></span></a></li>`).join('') || '<li class="muted" style="padding:10px 14px">Không tìm thấy kết quả phù hợp.</li>';
}, 160));

// ---------- Nhận tin ----------
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('[data-newsletter]');
  if (!f) return;
  e.preventDefault();
  const msg = f.querySelector('.form-msg');
  const email = f.email.value.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { msg.textContent = 'Email chưa đúng định dạng.'; msg.classList.add('is-err'); f.email.setAttribute('aria-invalid', 'true'); f.email.focus(); return; }
  f.email.removeAttribute('aria-invalid');
  try { await api('/api/newsletter', { method: 'POST', body: { email } }); msg.classList.remove('is-err'); msg.textContent = 'Cảm ơn bạn! Alokio sẽ gửi tin mới nhất tới ' + email + '.'; f.reset(); }
  catch (err) { msg.classList.add('is-err'); msg.textContent = err.message; }
});

// ---------- Nút liên hệ nổi + chat ----------
const fabBtn = $('[data-fab-toggle]'), fabMenu = $('#fab-menu');
fabBtn && fabBtn.addEventListener('click', () => { const open = fabMenu.hidden; fabMenu.hidden = !open; fabBtn.setAttribute('aria-expanded', String(open)); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && fabMenu && !fabMenu.hidden) { fabMenu.hidden = true; fabBtn.setAttribute('aria-expanded', 'false'); fabBtn.focus(); } });
const chat = $('[data-chat]'), chatBody = $('[data-chat-body]'), chatForm = $('[data-chat-form]');
let chatId = store.get('chatId', null);
function msgHTML(m) { return `<div class="msg msg--${m.from === 'customer' ? 'me' : m.from}">${esc(m.text)}<small>${m.from === 'customer' ? 'Bạn' : m.from === 'bot' ? 'Alokio' : 'Nhân viên Alokio'} · ${new Date(m.at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</small></div>`; }
async function loadChat() {
  if (!chatId) { chatBody.innerHTML = msgHTML({ from: 'bot', text: 'Xin chào! Alokio có thể giúp gì cho bạn? Nhân viên đang trực tuyến sẽ trả lời ngay tại đây.', at: Date.now() }); return; }
  try { const c = await api('/api/chat/' + chatId); chatBody.innerHTML = c.messages.map(msgHTML).join(''); chatBody.scrollTop = 1e6; } catch { chatId = null; store.set('chatId', null); loadChat(); }
}
document.addEventListener('click', (e) => {
  if (e.target.closest('[data-chat-open]')) { chat.hidden = false; fabMenu.hidden = true; loadChat(); setTimeout(() => $('#chat-input').focus(), 50); }
  if (e.target.closest('[data-chat-close]')) chat.hidden = true;
  const q = e.target.closest('[data-chat-quick] button');
  if (q) { $('#chat-input').value = q.textContent; chatForm.requestSubmit(); }
});
chatForm && chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatForm.text.value.trim();
  if (!text) return;
  chatForm.text.value = '';
  chatBody.insertAdjacentHTML('beforeend', msgHTML({ from: 'customer', text, at: Date.now() }));
  chatBody.scrollTop = 1e6;
  try {
    const r = await api('/api/chat', { method: 'POST', body: { id: chatId, text, name: B.user?.name } });
    if (!chatId) { chatId = r.id; store.set('chatId', chatId); }
    if (r.bot) setTimeout(() => { chatBody.insertAdjacentHTML('beforeend', msgHTML(r.bot)); chatBody.scrollTop = 1e6; }, 600);
  } catch (err) { toast(err.message, { type: 'info' }); }
});
live.on('chat.message', (d) => {
  if (!chatId || d.chatId !== chatId || d.message.from === 'customer') return;
  if (chat.hidden) { chat.hidden = false; }
  chatBody.insertAdjacentHTML('beforeend', msgHTML(d.message));
  chatBody.scrollTop = 1e6;
});

// ---------- Realtime: băng "đơn hàng gần đây" + flash sale + cập nhật tồn kho ----------
live.connect('public');
const ticker = $('[data-ticker]');
let tickTimer = null;
function showTicker(o) {
  if (!ticker || (B.page === 'home' && scrollY < innerHeight * 0.7) || B.page === 'checkout' || B.page === 'pay' || B.page === 'sandbox') return;
  ticker.innerHTML = `<img src="${esc(o.image || 'img/favicon.svg')}" alt="" width="48" height="48"><div><b>${esc(o.name)}</b> ở ${esc(o.province)} vừa đặt <b>${esc(o.items[0]?.name || 'sản phẩm')}</b><small>${timeAgo(o.createdAt)} · dữ liệu demo</small></div>`;
  ticker.hidden = false; ticker.classList.remove('is-out');
  clearTimeout(tickTimer);
  tickTimer = setTimeout(() => { ticker.classList.add('is-out'); setTimeout(() => (ticker.hidden = true), 500); }, 6000);
}
live.on('order.created', (d) => { if (B.tickerOn !== false) showTicker(d.order); });
// Một lần khi vào trang: hiện 1 đơn gần nhất (nếu admin bật)
setTimeout(async () => {
  try { const r = await api('/api/recent-orders'); if (r.enabled && r.items[0]) { B.tickerOn = true; showTicker(r.items[0]); } else B.tickerOn = false; } catch { /* noop */ }
}, 9000);
live.on('stock.changed', (d) => { $$(`[data-stock-for="${d.productId}"]`).forEach((el) => el.dispatchEvent(new CustomEvent('stock', { detail: d }))); });
live.on('settings.updated', () => {});

// Đếm ngược flash sale trên thanh thông báo
(async () => {
  const el = $('[data-flash-countdown]');
  if (!el) return;
  try {
    const r = await api('/api/flash');
    if (!r.active) return;
    const tick = () => {
      const ms = r.active.endsAt - Date.now();
      if (ms <= 0) { el.hidden = true; return; }
      const h = Math.floor(ms / 36e5), m = Math.floor((ms % 36e5) / 6e4), s = Math.floor((ms % 6e4) / 1000);
      el.textContent = `⚡ FLASH SALE · CÒN ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
      el.hidden = false;
    };
    tick(); setInterval(tick, 1000);
  } catch { /* noop */ }
})();

// ---------- Thẻ sản phẩm nghiêng 3D theo chuột ----------
if (!matchMedia('(prefers-reduced-motion: reduce)').matches && matchMedia('(hover: hover)').matches) {
  document.addEventListener('pointermove', (e) => {
    const c = e.target.closest('.pcard');
    if (!c) return;
    const r = c.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    c.style.transform = `perspective(900px) rotateY(${x * 7}deg) rotateX(${-y * 7}deg) translateY(-6px)`;
  });
  document.addEventListener('pointerout', (e) => { const c = e.target.closest('.pcard'); if (c && !c.contains(e.relatedTarget)) c.style.transform = ''; });
}

reveal();
// Logo thật cho mô hình 3D (nếu có file logo)
const logoEl = $('.logo-img');
if (logoEl) window.__alokioLogo = logoEl.src;

// ---------- Hiệu ứng vẩy sơn trên nền (trừ trang quản trị) ----------
const startPaint = () => paintPage(window.__alk ? __alk.path() : location.pathname);
if (document.readyState === 'complete') setTimeout(startPaint, 200); else window.addEventListener('load', () => setTimeout(startPaint, 200));
