// Showroom 3D – phần giao diện dùng chung cho máy tính & điện thoại (không cần three.js):
//   · nút ‹ › hai bên thanh danh sách mẫu
//   · vuốt ngang trên điện thoại để đổi sang mẫu loa kế tiếp / trước đó
//   · thanh danh sách tự cuộn để mẫu đang xem luôn nằm giữa
//   · nút thu gọn thẻ thông tin để nhìn trọn chiếc loa
import { $, $$ } from '../lib/core.js';

const host = $('[data-showroom]');
if (host) {
  const gos = $$('[data-sr-go]');
  const list = $('[data-sr-list]');
  const cur = () => Math.max(0, gos.findIndex((b) => b.getAttribute('aria-current') === 'true'));
  const step = (d) => gos[(cur() + d + gos.length) % gos.length].click();
  $$('[data-sr-step]').forEach((b) => b.addEventListener('click', () => step(Number(b.dataset.srStep))));

  const center = () => {
    const b = gos[cur()];
    if (!b || !list) return;
    list.scrollTo({ left: b.offsetLeft - (list.clientWidth - b.offsetWidth) / 2, behavior: 'smooth' });
  };
  if (list) new MutationObserver(center).observe(list, { attributes: true, subtree: true, attributeFilter: ['aria-current'] });

  // Vuốt ngang: kéo ngón tay sang trái → mẫu bên phải (kế tiếp), sang phải → mẫu trước
  let sx = null, sy = 0, st = 0;
  host.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1 || e.target.closest('button, a, input, .showroom__bar')) { sx = null; return; }
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; st = performance.now();
  }, { passive: true });
  host.addEventListener('touchend', (e) => {
    if (sx == null) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - sx, dy = t.clientY - sy, dt = performance.now() - st;
    sx = null;
    if (Math.abs(dx) > Math.abs(dy) * 1.3 && (Math.abs(dx) > 110 || (Math.abs(dx) > 45 && dt < 900))) step(dx < 0 ? 1 : -1);
  }, { passive: true });
  host.addEventListener('touchcancel', () => { sx = null; }, { passive: true });

  // Thu gọn / mở thẻ thông tin (chủ yếu dùng trên điện thoại)
  const card = $('[data-sr-card]'), minB = $('[data-sr-min]');
  const setMin = (min) => {
    card.classList.toggle('is-min', min);
    minB.setAttribute('aria-expanded', String(!min));
    minB.setAttribute('aria-label', min ? 'Mở thông tin sản phẩm' : 'Thu gọn thông tin để xem loa');
  };
  if (card && minB) {
    minB.addEventListener('click', () => setMin(!card.classList.contains('is-min')));
    // Chạm vào phần đầu thẻ khi đang thu gọn cũng mở lại
    card.addEventListener('click', (e) => { if (card.classList.contains('is-min') && !e.target.closest('button, a')) setMin(false); });
  }

  // Thanh zoom bám mép trái: kéo thanh, bấm + / −, lăn chuột trên thanh hoặc phím + / −
  const zr = $('[data-sr-zr]');
  if (zr) {
    const apply = () => { const v = Number(zr.value); window.__alkSrZoom = 1.6 - (v / 100) * 1.05; zr.style.setProperty('--v', v + '%'); };
    const nudge = (d) => { zr.value = String(Math.max(0, Math.min(100, Number(zr.value) + d))); apply(); };
    zr.addEventListener('input', apply);
    $('[data-sr-zin]')?.addEventListener('click', () => nudge(12));
    $('[data-sr-zout]')?.addEventListener('click', () => nudge(-12));
    zr.closest('.srzoom').addEventListener('wheel', (e) => { e.preventDefault(); nudge(e.deltaY < 0 ? 6 : -6); }, { passive: false });
    document.addEventListener('keydown', (e) => {
      if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && document.activeElement !== zr) return;
      if (e.key === '+' || e.key === '=') nudge(10); else if (e.key === '-' || e.key === '_') nudge(-10);
    });
    apply();
  }
}
