// Trang chi tiết: trình xem 3D + Atelier tuỳ biến, mua hàng, đánh giá, realtime tồn kho & người xem.
import { $, $$, api, fmt, toast, store, debounce } from '../lib/core.js';
import * as cart from '../lib/cart.js';
import * as live from '../lib/live.js';
import { webglOK, liteMode } from '../three/support.js';

const P = JSON.parse($('#product-data').textContent);
const form = $('[data-atelier]');
const viewerBox = $('[data-viewer]');
let viewer = null;
let stock = { ...P.stock };

function opts() {
  const fd = new FormData(form);
  const o = {};
  if (fd.get('knob')) o.knob = fd.get('knob');
  if (fd.get('strap')) o.strap = fd.get('strap');
  if ((fd.get('engraving') || '').trim()) o.engraving = fd.get('engraving').trim().slice(0, 18);
  if (fd.get('giftbox')) o.giftbox = true;
  return { finish: fd.get('finish'), options: o };
}

function unitPrice() {
  const { options } = opts();
  let p = P.flashPrice || P.price;
  if (options.engraving) p += P.engravingPrice;
  if (options.giftbox) p += P.giftboxPrice;
  return p;
}
function renderPrice() {
  const extra = unitPrice() - (P.flashPrice || P.price);
  const el = $('[data-price]');
  if (extra > 0) el.innerHTML = `<span class="price">${fmt(unitPrice())}</span><span class="muted" style="font-size:15px;font-weight:300">gồm tuỳ chọn +${fmt(extra)}</span>`;
}
function renderStock() {
  const f = opts().finish;
  const n = stock[f] ?? 0;
  const label = $('[data-stock-label]');
  label.textContent = n <= 0 ? 'Màu này đã hết hàng' : n <= 3 ? `Chỉ còn ${n} sản phẩm` : `Còn hàng (${n})`;
  label.style.color = n <= 0 ? 'var(--danger)' : n <= 3 ? 'var(--warning)' : '';
  $$('[data-buy]').forEach((b) => { b.disabled = n <= 0; });
  $('[data-restock]').hidden = n > 0;
  $('[data-finish-name]').textContent = P.finishNames[f];
}

// ---------- 3D ----------
async function mount3D() {
  const { mountViewer } = await import('../three/viewer.js');
  const c = document.createElement('canvas');
  c.setAttribute('aria-label', `Mô hình 3D ${P.name}. Kéo để xoay, cuộn để phóng to.`);
  c.setAttribute('role', 'img');
  viewerBox.prepend(c);
  const o = opts();
  viewer = mountViewer(c, { model: P.model, finish: o.finish, knob: o.options.knob, strap: o.options.strap, engraving: o.options.engraving, padding: P.model.type === 'trolley' ? 1.12 : 1.25 });
  window.__viewer = viewer;
}
if (webglOK() && !liteMode()) {
  const io = new IntersectionObserver((es) => { if (es[0].isIntersecting) { io.disconnect(); mount3D(); } });
  io.observe(viewerBox);
}

let rebuildT = 0;
form.addEventListener('change', (e) => {
  renderStock(); renderPrice();
  if (!viewer) { const img = $('[data-viewer-img]'); const f = opts().finish; const src = f === P.finishes[0] ? P.image : `img/products/${P.slug}--${f}.webp`; img.src = src; return; }
  if (e.target.name === 'finish' || e.target.name === 'knob') { const o = opts(); viewer.setFinish(o.finish, o.options.knob); }
  if (e.target.name === 'strap') { clearTimeout(rebuildT); rebuildT = setTimeout(() => { const o = opts(); viewer.rebuild({ finish: o.finish, ...o.options }); }, 60); }
});
const engr = form.querySelector('[name=engraving]');
engr && engr.addEventListener('input', debounce(() => { renderPrice(); if (viewer) { const o = opts(); viewer.rebuild({ finish: o.finish, ...o.options }); } }, 350));

// Tách lớp xem cấu tạo
const exBtn = $('[data-explode]');
let exK = 0, exTarget = 0, exRaf = 0;
exBtn && exBtn.addEventListener('click', async () => {
  if (!viewer) { toast('Mô hình 3D đang tải…', { type: 'info' }); return; }
  const { setExplode } = await import('../three/models.js');
  exTarget = exTarget ? 0 : 1;
  exBtn.setAttribute('aria-pressed', String(!!exTarget));
  const obj = viewer.object;
  const internals = obj.userData.parts.filter((p) => p.userData.internal);
  cancelAnimationFrame(exRaf);
  const step = () => {
    exK += (exTarget - exK) * 0.08;
    setExplode(obj, exK); internals.forEach((p) => (p.visible = exK > 0.04));
    viewer.stage.render();
    if (Math.abs(exTarget - exK) > 0.002) exRaf = requestAnimationFrame(step);
  };
  step();
});

// Gallery ảnh tĩnh
$$('[data-gallery]').forEach((b) => b.addEventListener('click', () => {
  $$('[data-gallery]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
  if (viewer) { viewer.dispose(); viewer = null; viewerBox.querySelector('canvas')?.remove(); viewerBox.classList.remove('is-3d'); }
  $('[data-viewer-img]').src = b.dataset.gallery;
}));

// ---------- Mua ----------
const qtyInput = $('[data-qty]');
$$('[data-q]').forEach((b) => b.addEventListener('click', () => { qtyInput.value = Math.max(1, Math.min(10, (parseInt(qtyInput.value, 10) || 1) + Number(b.dataset.q))); }));
$$('[data-buy]').forEach((b) => b.addEventListener('click', () => {
  const o = opts();
  const qty = Math.max(1, Math.min(10, parseInt(qtyInput.value, 10) || 1));
  if ((stock[o.finish] ?? 0) < qty) { toast(`Chỉ còn ${stock[o.finish] ?? 0} sản phẩm màu này.`, { type: 'info' }); return; }
  cart.add({ productId: P.id, finish: o.finish, qty, options: o.options });
  if (b.dataset.buy === 'now') { __alk.go('/thanh-toan'); return; }
  const snap = viewer ? viewer.snapshot('image/webp') : P.image;
  window.__alokioFly && window.__alokioFly(b, snap);
  toast(`Đã thêm ${P.name} vào giỏ.`, { link: '/gio-hang', linkText: 'Xem giỏ' });
}));

// Báo khi có hàng
$('[data-restock]').addEventListener('click', async () => {
  const contact = prompt('Nhập email hoặc số điện thoại để nhận thông báo khi có hàng:');
  if (!contact) return;
  await api('/api/restock', { method: 'POST', body: { productId: P.id, finish: opts().finish, contact } }).catch(() => {});
  toast('Alokio sẽ báo cho bạn khi màu này có hàng lại.');
});

// ---------- Realtime ----------
live.on('stock.changed', (d) => { if (d.productId === P.id) { stock = d.stock; renderStock(); } });
// Số người đang xem = số kết nối realtime thật đang mở đúng trang này (không bịa số)
const setViewers = (d) => { const el = $('[data-viewers-n]'); if (el) el.textContent = Math.max(1, d.pages[__alk.path()] || 1); };
live.on('presence.count', setViewers);
api('/api/presence').then(setViewers).catch(() => {});

// Đếm ngược flash
$$('[data-flash-end]').forEach((el) => {
  const end = Number(el.dataset.flashEnd);
  const tick = () => { const ms = end - Date.now(); if (ms <= 0) { el.textContent = 'đã kết thúc'; return; } const h = Math.floor(ms / 36e5), m = Math.floor((ms % 36e5) / 6e4), s = Math.floor((ms % 6e4) / 1000); el.textContent = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };
  tick(); setInterval(tick, 1000);
});

// ---------- Đánh giá ----------
$$('[data-star-filter]').forEach((b) => b.addEventListener('click', () => {
  const n = Number(b.dataset.starFilter);
  $$('[data-star-filter]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
  $$('[data-reviews] .review').forEach((r) => { r.hidden = n && Number(r.dataset.stars) !== n; });
}));
const rf = $('[data-review-form]');
rf && rf.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(rf);
  const msg = $('[data-review-msg]');
  try {
    const r = await api('/api/reviews', { method: 'POST', body: { productId: P.id, stars: fd.get('stars'), name: fd.get('name'), text: fd.get('text') } });
    msg.style.color = 'var(--success)'; msg.textContent = r.message; rf.reset();
  } catch (err) { msg.style.color = ''; msg.textContent = err.message; }
});

// ---------- Vừa xem ----------
const recent = store.get('recent', []).filter((id) => id !== P.id);
store.set('recent', [P.id, ...recent].slice(0, 8));
if (recent.length) {
  api('/api/products').then(({ items }) => {
    const list = recent.map((id) => items.find((x) => x.id === id)).filter(Boolean).slice(0, 4);
    if (!list.length) return;
    $('[data-recent]').hidden = false;
    $('[data-recent-grid]').innerHTML = list.map((x) => `<a class="pcard" href="/san-pham/${x.slug}" style="text-decoration:none"><span class="pcard__media"><img src="${x.image}" alt="" loading="lazy" width="400" height="400"></span><span class="pcard__body"><span class="pcard__name" style="pointer-events:none">${x.name}</span><span class="price">${fmt(x.price)}</span></span></a>`).join('');
  }).catch(() => {});
}

// Thanh mua dính đáy (mobile)
const sticky = $('[data-sticky-buy]');
const buyBox = $('.pdp__buy');
new IntersectionObserver((es) => sticky.classList.toggle('is-on', !es[0].isIntersecting && es[0].boundingClientRect.top < 0)).observe(buyBox);

// Mở thẳng Atelier khi có #atelier
if (location.hash === '#atelier') setTimeout(() => form.scrollIntoView({ behavior: 'smooth', block: 'center' }), 300);

renderStock();
