// Trang quản trị realtime — mỗi mục là một hàm render, dữ liệu lấy qua /api/admin/*, cập nhật qua SSE.
import { $, $$, api, fmt, esc, toast, openDialog, timeAgo, debounce } from '../lib/core.js';
import * as live from '../lib/live.js';
import * as audio from '../audio.js';
import qrcode from '../../vendor/qrcode.js';
import * as CH from '../admin/charts.js';
import { paintFixed } from '../paint.js';

// Bản tĩnh: ảnh lưu trong localStorage nên thu nhỏ còn tối đa 900px (webp) trước khi lưu
function shrinkImage(dataUrl, max = 900) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      try { resolve(c.toDataURL('image/webp', 0.85)); } catch { resolve(dataUrl); }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

// Phiếu giao hàng: chỉ cần vẽ QR rồi dừng
if (window.__INVOICE_QR__) {
  const q = qrcode(0, 'M'); q.addData(window.__INVOICE_QR__); q.make();
  document.getElementById('qr').innerHTML = q.createSvgTag({ cellSize: 4, margin: 2 });
}

const body = document.body;
const PAGE = body.dataset.admin;
if (PAGE) paintFixed('admin-' + PAGE); // nền vẩy sơn nghệ thuật cho trang quản trị
const content = $('[data-content]');
let BOOT = null;
const ST = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', packing: 'Đang đóng gói', shipping: 'Đang giao', completed: 'Hoàn thành', cancelled: 'Đã huỷ', returned: 'Hoàn trả' };
const PM = { cod: 'COD', vietqr: 'VietQR', wallet: 'Ví điện tử', card: 'Thẻ', installment: 'Trả góp', deposit: 'Đặt cọc' };
const PS = { unpaid: 'Chưa TT', pending: 'Chờ TT', scanned: 'Đã quét', paid: 'Đã TT', deposit: 'Đã cọc', failed: 'Thất bại', expired: 'Hết hạn', refunded: 'Hoàn tiền', cod: 'Thu khi giao', cancelled: 'Đã thay mã' };
const WAL = { momo: 'MoMo', zalopay: 'ZaloPay', shopeepay: 'ShopeePay', vnpay: 'VNPAY-QR', viettelmoney: 'Viettel Money' };
const FIN = { 'ngoc-trai': 'Ngọc Trai', 'suong-som': 'Sương Sớm', huyen: 'Huyền', 'oc-cho': 'Óc Chó', 'go-den': 'Gỗ sơn đen' };
const dt = (t) => new Date(t).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
const st = (s, map = ST) => `<span class="st st--${esc(s)}">${esc(map[s] || s)}</span>`;
const pct = (a, b) => (b ? Math.round(((a - b) / b) * 100) : 0);
const trend = (a, b) => { const p = pct(a, b); return `<small class="${p >= 0 ? 'up' : 'down'}">${p >= 0 ? '▲' : '▼'} ${Math.abs(p)}% so với kỳ trước</small>`; };
const canDo = (area) => BOOT.me.can.includes('*') || BOOT.me.can.includes(area);

// ---------- Khung chung ----------
const side = $('[data-side]');
$('[data-side-toggle]')?.addEventListener('click', () => side.classList.toggle('is-open'));
$('[data-logout]')?.addEventListener('click', async () => { await api('/api/admin/logout', { method: 'POST' }); __alk.go('/admin/dang-nhap'); });
$('[data-theme]')?.addEventListener('click', () => { const d = !document.documentElement.classList.contains('dark'); document.documentElement.classList.toggle('dark', d); try { localStorage.setItem('alokio:admin-theme', d ? 'dark' : 'light'); } catch { /* noop */ } });
$('[data-sim-toggle]')?.addEventListener('change', async (e) => {
  await api('/api/admin/settings', { method: 'POST', body: { simulator: { ...BOOT.settings.simulator, enabled: e.target.checked } } });
  BOOT.settings.simulator.enabled = e.target.checked;
  toast(e.target.checked ? `Đã bật mô phỏng đơn hàng: đơn mới sẽ xuất hiện mỗi ${BOOT.settings.simulator.minSec}–${BOOT.settings.simulator.maxSec} giây.` : 'Đã tắt mô phỏng đơn hàng.', { type: 'info' });
});
// Thông báo
const notes = [];
const bellBtn = $('[data-bell]'), notesBox = $('[data-notes]'), bellN = $('[data-bell-n]');
function addNote(text, href) {
  notes.unshift({ text, href, at: Date.now() }); notes.length = Math.min(notes.length, 30);
  bellN.hidden = false; bellN.textContent = Number(bellN.textContent || 0) + 1;
  notesBox.innerHTML = notes.map((n) => `<a href="${esc(n.href || '#')}">${esc(n.text)}<small>${timeAgo(n.at)}</small></a>`).join('');
}
bellBtn?.addEventListener('click', () => { const open = notesBox.hidden; notesBox.hidden = !open; bellBtn.setAttribute('aria-expanded', String(open)); if (open) { bellN.hidden = true; bellN.textContent = '0'; } });
function desktopNotify(title, bodyText) {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'granted') new Notification(title, { body: bodyText, icon: 'img/favicon.svg' });
}
document.addEventListener('click', () => { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); }, { once: true });

// Tìm kiếm nhanh Ctrl+K
const cmdk = $('[data-cmdk-box]');
const openCmdk = () => { openDialog(cmdk); $('[data-cmdk-input]').value = ''; $('[data-cmdk-list]').innerHTML = ''; };
$('[data-cmdk]')?.addEventListener('click', openCmdk);
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCmdk(); } });
$('[data-cmdk-input]')?.addEventListener('input', debounce(async (e) => {
  const q = e.target.value.trim(); if (q.length < 2) return;
  const [o, p] = await Promise.all([api('/api/admin/orders?limit=6&q=' + encodeURIComponent(q)).catch(() => ({ items: [] })), api('/api/search?q=' + encodeURIComponent(q))]);
  $('[data-cmdk-list]').innerHTML = [...o.items.map((x) => `<li><a href="/admin/don-hang/${esc(x.code)}"><b>${esc(x.code)}</b> · ${esc(x.name)} · ${fmt(x.total)}</a></li>`), ...p.items.filter((x) => x.href.startsWith('/san-pham')).map((x) => `<li><a href="/admin/san-pham#${esc(x.href.split('/').pop())}">${esc(x.title)}</a></li>`)].join('') || '<li class="muted" style="padding:10px">Không có kết quả.</li>';
}, 200));

// Modal
const modal = $('[data-modal]');
function showModal(html, onMount) {
  $('[data-modal-panel]').innerHTML = `<div class="drawer__head"><span></span><button class="icon-btn" type="button" data-close aria-label="Đóng">✕</button></div><div class="drawer__body">${html}</div>`;
  const close = openDialog(modal);
  onMount && onMount($('[data-modal-panel]'), close);
  return close;
}

// ---------- Realtime chung ----------
if (PAGE) live.connect('admin');
live.on('presence.count', (d) => { const el = $('[data-online]'); if (el) el.textContent = d.online; });
live.on('admin.order.created', (d) => {
  audio.ting();
  addNote(`Đơn mới ${d.code} · ${d.name} (${d.province}) · ${fmt(d.total)}${d.source === 'sim' ? ' · mô phỏng' : ''}`, `/admin/don-hang/${d.code}`);
  toast(`🛒 Đơn mới ${d.code} · ${fmt(d.total)}`, { link: `/admin/don-hang/${d.code}`, linkText: 'Xem' });
  desktopNotify('Alokio · Đơn hàng mới', `${d.code} · ${d.name} · ${fmt(d.total)}`);
  badge('don-hang', 1);
});
live.on('admin.payment.paid', (d) => { addNote(`Đã nhận thanh toán ${fmt(d.amount)} · ${d.code} (${PM[d.method] || d.method}${d.wallet ? ' · ' + WAL[d.wallet] : ''})`, `/admin/don-hang/${d.code}`); toast(`💸 ${d.code}: đã thanh toán ${fmt(d.amount)}`); });
live.on('admin.chat', (d) => { addNote(`Tin nhắn từ ${d.name}: ${d.message.text.slice(0, 60)}`, '/admin/chat'); if (PAGE !== 'chat') { toast(`💬 ${d.name}: ${d.message.text.slice(0, 50)}`, { link: '/admin/chat', linkText: 'Trả lời' }); badge('chat', 1); } audio.tick(1400); });
live.on('admin.lowstock', (d) => addNote(`Tồn kho thấp: ${d.name}`, '/admin/kho'));
live.on('admin.review', (d) => { addNote(`Đánh giá mới chờ duyệt: ${d.name}`, '/admin/danh-gia'); badge('danh-gia', 1); });
live.on('admin.appointment', (d) => addNote(`Lịch nghe thử mới: ${d.name}`, '/admin/noi-dung'));
live.on('catalog.reset', () => { toast('Dữ liệu demo đã được khôi phục.', { type: 'info' }); setTimeout(() => location.reload(), 900); });
function badge(id, inc, set) { const b = $(`[data-badge="${id}"]`); if (!b) return; const n = set != null ? set : Number(b.textContent || 0) + inc; b.textContent = n; b.hidden = !n; }

// ======================================================================
// TỔNG QUAN
// ======================================================================
async function pageDashboard() {
  let days = 30;
  const draw = async () => {
    const s = await api('/api/admin/stats?days=' + days);
    content.innerHTML = `
    <div class="adm-head"><h1>Tổng quan</h1><div class="actions"><div class="tabs" role="tablist" aria-label="Khoảng thời gian">${[7, 30, 90].map((d) => `<button class="tab" role="tab" aria-selected="${d === days}" data-days="${d}">${d} ngày</button>`).join('')}</div></div></div>
    <div class="kpis kpis--lux">
      <div class="kpi"><span>Doanh thu hôm nay</span><b>${fmt(s.today.revenue)}</b><small class="muted">${s.today.orders} đơn</small></div>
      <div class="kpi"><span>Doanh thu ${days} ngày</span><b>${fmt(s.revenue)}</b>${trend(s.revenue, s.prevRevenue)}${CH.sparkline(s.series.map((x) => x.revenue))}</div>
      <div class="kpi"><span>Số đơn</span><b>${s.orders}</b>${trend(s.orders, s.prevOrders)}${CH.sparkline(s.series.map((x) => x.orders), { color: '#86AEDD' })}</div>
      <div class="kpi"><span>Giá trị đơn TB</span><b>${fmt(s.aov)}</b>${trend(s.aov, s.prevAov)}</div>
      <div class="kpi"><span>Khách mới · Tỉ lệ huỷ</span><b>${s.newCustomers} · ${(s.cancelRate * 100).toFixed(1)}%</b>${trend(s.newCustomers, s.prevCustomers)}</div>
    </div>
    <div class="dash">
      <section class="panel"><div class="row"><h2 class="h3" style="margin:0">Doanh thu theo ngày</h2><div class="legend"><span><i style="background:#2B5C94"></i>Doanh thu</span><span><i style="background:#E8735A;opacity:.5"></i>Số đơn</span></div></div><div class="chart" data-rev></div></section>
      <section class="panel"><h2 class="h3">Bản đồ đơn hàng 3D</h2><div class="map3d" data-map><p class="map3d__legend">Cột sáng = số đơn ${days} ngày · xung sóng = đơn mới (minh hoạ)</p></div></section>
      <section class="panel"><h2 class="h3">Doanh thu theo phương thức thanh toán</h2><div class="chart" data-pm></div></section>
      <section class="panel"><h2 class="h3">Theo dòng sản phẩm</h2><div class="chart" data-line></div></section>
      <section class="panel"><h2 class="h3">Giờ cao điểm đặt hàng (90 ngày)</h2><div data-heat></div></section>
      <section class="panel"><h2 class="h3">Đơn theo trạng thái</h2><div data-status></div></section>
      <section class="panel"><h2 class="h3">Sản phẩm bán chạy</h2><table class="tbl"><thead><tr><th>Sản phẩm</th><th>SL</th><th>Doanh thu</th></tr></thead><tbody>${s.top.map((p) => `<tr><td>${esc(p.name)}</td><td>${p.qty}</td><td>${fmt(p.revenue)}</td></tr>`).join('')}</tbody></table></section>
      <section class="panel"><h2 class="h3">Hoạt động realtime</h2><ul class="feed" data-feed></ul></section>
      <section class="panel span2"><div class="row"><h2 class="h3" style="margin:0">Đơn hàng mới nhất</h2><a href="/admin/don-hang" class="link-arrow">Tất cả đơn →</a></div><div class="tbl-wrap" style="margin-top:12px"><table class="tbl tbl--cards"><thead><tr><th>Mã</th><th>Thời gian</th><th>Khách</th><th>Tỉnh/TP</th><th>Tổng</th><th>Thanh toán</th><th>Trạng thái</th></tr></thead><tbody data-recent>${s.recent.map(orderRow).join('')}</tbody></table></div></section>
      ${s.low.length ? `<section class="panel span2"><h2 class="h3">⚠ Cảnh báo tồn kho thấp</h2>${s.low.map((p) => `<p style="margin:4px 0">${esc(p.name)}: ${Object.entries(p.stock).map(([f, n]) => `<span class="${n <= 3 ? 'stock-low' : ''}">${FIN[f] || f} ${n}</span>`).join(' · ')}</p>`).join('')}<a class="btn btn--soft btn--sm" href="/admin/kho">Nhập kho</a></section>` : ''}
    </div>`;
    $$('[data-days]').forEach((b) => b.addEventListener('click', () => { days = Number(b.dataset.days); draw(); }));
    $('[data-rev]').innerHTML = lineChart(s.series);
    $('[data-pm]').innerHTML = donut(Object.entries(s.byMethod).map(([k, v]) => [PM[k] || k, v]));
    $('[data-line]').innerHTML = donut([['Alokio Luxe', s.byLine.luxe || 0], ['Loa kéo karaoke', s.byLine.karaoke || 0]], ['#2B5C94', '#E8735A']);
    $('[data-heat]').innerHTML = heat(s.heat);
    $('[data-status]').innerHTML = Object.entries(ST).map(([k, l]) => { const n = s.byStatus[k] || 0; const max = Math.max(...Object.values(s.byStatus)); return `<div style="display:grid;grid-template-columns:120px 1fr 40px;gap:10px;align-items:center;font-size:14px;margin:6px 0"><span>${l}</span><span style="height:10px;border-radius:9px;background:var(--mist);overflow:hidden"><i style="display:block;height:100%;width:${(n / max) * 100}%;background:var(--primary)"></i></span><b>${n}</b></div>`; }).join('');
    const act = await api('/api/admin/activity');
    $('[data-feed]').innerHTML = act.items.slice(0, 30).map((a) => `<li><b>${esc(a.user)}</b> · ${esc(a.action)}<small>${timeAgo(a.at)}</small></li>`).join('');
    badge('don-hang', 0, s.pending); badge('chat', 0, s.unreadChats); badge('danh-gia', 0, s.pendingReviews);
    // bản đồ 3D
    const mapBox = $('[data-map]');
    try {
      const { mountVNMap } = await import('../three/vnmap.js');
      const c = document.createElement('canvas'); c.setAttribute('aria-hidden', 'true'); mapBox.prepend(c);
      window.__map = mountVNMap(c, { outline: BOOT.outline, provinces: BOOT.provinces, counts: s.byProv });
    } catch (e) { mapBox.innerHTML += '<p class="muted" style="color:#B6C3D4;padding:14px">Trình duyệt không hỗ trợ WebGL.</p>'; }
  };
  await draw();
  live.on('order.created', (d) => {
    const tb = $('[data-recent]'); if (!tb) return;
    tb.insertAdjacentHTML('afterbegin', orderRow(d.full).replace('<tr', '<tr class="is-new"'));
    while (tb.children.length > 8) tb.lastElementChild.remove();
    const prov = BOOT.provinces.find((p) => p.name === d.full.province);
    window.__map && prov && window.__map.pulse(prov.code);
    $('[data-feed]')?.insertAdjacentHTML('afterbegin', `<li class="is-new"><b>Đơn mới ${esc(d.full.code)}</b> · ${esc(d.full.name)} · ${fmt(d.full.total)}<small>vừa xong</small></li>`);
  });
  live.on('order.updated', (d) => { const r = $(`[data-recent] tr[data-code="${d.full.code}"]`); if (r) r.outerHTML = orderRow(d.full).replace('<tr', '<tr class="is-new"'); });
}

// ======================================================================
// PHÂN TÍCH CHUYÊN SÂU
// ======================================================================
async function pageAnalytics() {
  let days = 90;
  const draw = async () => {
    const a = await api('/api/admin/analytics?days=' + days);
    const wk = a.weeks.map((w) => { const d = new Date(w.start + 6 * 864e5); return `${d.getDate()}/${d.getMonth() + 1}`; });
    const segE = Object.entries(a.segments);
    const m = a.month;
    const mRatio = m.revenue / m.target, mExp = m.day / m.daysInMonth;
    const chTotal = Object.values(a.channels).reduce((x, c) => x + c.revenue, 0) || 1;
    content.innerHTML = `
    <div class="adm-head"><div><p class="label" style="margin:0 0 6px">Phân tích kinh doanh</p><h1>Phân tích <em>chuyên sâu</em></h1></div><div class="actions"><div class="tabs" role="tablist" aria-label="Khoảng thời gian">${[30, 90, 180].map((d) => `<button class="tab" role="tab" aria-selected="${d === days}" data-adays="${d}">${d} ngày</button>`).join('')}</div></div></div>
    <div class="kpis kpis--lux">
      <div class="kpi"><span>Doanh thu ${days} ngày</span><b>${CH.money(a.revenue)} ₫</b>${CH.sparkline(a.weeks.map((w) => w.revenue))}</div>
      <div class="kpi"><span>Đơn thành công</span><b>${a.orders}</b>${CH.sparkline(a.weeks.map((w) => w.orders), { color: '#86AEDD' })}</div>
      <div class="kpi"><span>Giá trị đơn trung bình</span><b>${CH.money(a.aov)} ₫</b>${CH.sparkline(a.weeks.map((w) => w.aov), { color: '#C9A86A' })}</div>
      <div class="kpi"><span>Tỉ lệ khách quay lại</span><b>${(a.repeatRate * 100).toFixed(1).replace('.', ',')}%</b><small class="muted">${a.customers} khách · CLV ${CH.money(a.clv)} ₫</small></div>
      <div class="kpi"><span>Tỉ lệ huỷ / hoàn</span><b>${(a.cancelRate * 100).toFixed(1).replace('.', ',')}%</b>${CH.sparkline(a.weeks.map((w) => w.cancelRate), { color: '#E8735A' })}</div>
    </div>
    <div class="dash dash--3">
      <section class="panel panel--lux"><h2 class="h3">Mục tiêu doanh thu tháng</h2><div class="ring-wrap">${CH.ring(mRatio, { label: 'Tiến độ mục tiêu tháng', sub: `${CH.money(m.revenue)} / ${CH.money(m.target)}`, expected: mExp })}<p class="muted" style="font-size:13px;margin:0">Vạch cam = tiến độ kỳ vọng sau ${m.day}/${m.daysInMonth} ngày. ${mRatio >= mExp ? '<b style="color:var(--success)">Đang vượt kế hoạch.</b>' : '<b style="color:#C2410C">Đang chậm hơn kế hoạch.</b>'}</p></div></section>
      <section class="panel"><h2 class="h3">Phễu chuyển đổi <small class="muted">(ước tính)</small></h2>${CH.funnel(a.funnel)}</section>
      <section class="panel"><h2 class="h3">Phân khúc khách hàng</h2>${CH.donut(segE.map(([k, v]) => [k, v.revenue]), { colors: ['#C9A86A', '#2B5C94', '#BCD6F2'] })}<p class="muted" style="font-size:13px;margin:10px 0 0">${segE.map(([k, v]) => `${k}: <b>${v.count}</b>`).join(' · ')} khách</p></section>
      <section class="panel span2"><div class="row"><h2 class="h3" style="margin:0">Doanh thu & giá trị đơn theo tuần</h2><div class="legend"><span><i style="background:#2B5C94"></i>Doanh thu</span><span><i style="background:#C9A86A"></i>AOV (quy đổi)</span></div></div>${CH.area(wk, [{ values: a.weeks.map((w) => w.revenue), color: '#2B5C94' }, { values: a.weeks.map((w) => w.aov * (Math.max(...a.weeks.map((x) => x.revenue)) / Math.max(1, ...a.weeks.map((x) => x.aov))) * 0.8), color: '#C9A86A', dash: true }], { showEvery: Math.ceil(wk.length / 8) })}</section>
      <section class="panel"><h2 class="h3">Kênh bán hàng <small class="muted">(giả lập)</small></h2>${CH.hbars(Object.entries(a.channels).map(([k, v], i) => [k, v.revenue, ['#1877F2', '#111827', '#EE4D2D', '#34A853', '#C9A86A'][i]]), { sub: (i) => `${Math.round((Object.values(a.channels)[i].revenue / chTotal) * 100)}% · ${Object.values(a.channels)[i].orders} đơn` })}</section>
      <section class="panel span2"><h2 class="h3">Top 10 tỉnh/thành theo doanh thu</h2>${CH.hbars(a.provinces.map((p) => [p.name, p.revenue]), { sub: (i) => `${a.provinces[i].orders} đơn` })}</section>
      <section class="panel"><h2 class="h3">Doanh thu theo danh mục</h2>${CH.donut(Object.entries(a.categories).sort((x, y) => y[1] - x[1]))}</section>
      <section class="panel"><h2 class="h3">Doanh thu theo thứ trong tuần</h2>${CH.bars(['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((d, i) => [d, a.weekday[i].revenue]))}</section>
      <section class="panel"><h2 class="h3">Khung giờ đặt hàng</h2>${CH.hoursChart(a.hours)}<p class="muted" style="font-size:13px;margin:12px 0 0">Cao điểm: <b>${a.hours.indexOf(Math.max(...a.hours))}h</b> · ${Math.max(...a.hours)} đơn</p></section>
      <section class="panel"><h2 class="h3">Màu hoàn thiện được chọn nhiều</h2>${CH.hbars(a.finishes.map((f) => [f.name, f.qty, f.hex]), { value: (v) => v + ' sp' })}</section>
      <section class="panel span2"><div class="row"><h2 class="h3" style="margin:0">Tỉ trọng phương thức thanh toán theo tuần</h2><div class="legend">${['wallet', 'vietqr', 'cod', 'card', 'installment'].map((k, i) => `<span><i style="background:${CH.COLORS[i]}"></i>${PM[k]}</span>`).join('')}</div></div>${CH.stacked(wk, a.weeks.map((w) => w.methods), ['wallet', 'vietqr', 'cod', 'card', 'installment'], CH.COLORS)}</section>
      <section class="panel"><h2 class="h3">Vận chuyển & khuyến mãi</h2>${CH.donut(Object.entries(a.shipping).map(([k, v]) => [{ standard: 'Tiêu chuẩn', express: 'Hoả tốc 2h', pickup: 'Nhận tại showroom' }[k] || k, v]), { colors: ['#2B5C94', '#C9A86A', '#86AEDD'], value: (v) => String(v), center: String(Object.values(a.shipping).reduce((x, y) => x + y, 0)) })}${a.coupon.orders ? `<p class="muted" style="font-size:13px;margin:10px 0 0">Đơn dùng mã giảm giá: <b>${Math.round(a.coupon.share * 100)}%</b> · tổng giảm ${fmt(a.coupon.discount)}</p>` : ''}</section>
      <section class="panel span2"><h2 class="h3">Sản phẩm dẫn đầu doanh thu</h2>${CH.hbars(a.products.map((p) => [p.name, p.revenue]), { sub: (i) => `${a.products[i].qty} sp` })}</section>
      <section class="panel"><h2 class="h3">Giá trị tồn kho</h2>${CH.donut(Object.entries(a.stockValue), { colors: ['#2B5C94', '#E8735A'] })}</section>
      <section class="panel span3"><h2 class="h3">Tỉ lệ khách quay lại theo tháng (cohort)</h2>${CH.cohort(a.cohorts)}<p class="muted" style="font-size:13px;margin:10px 0 0">Mỗi hàng là nhóm khách mua lần đầu trong tháng đó; các cột cho biết bao nhiêu % đã quay lại mua tiếp sau 1–5 tháng.</p></section>
    </div>`;
    $$('[data-adays]').forEach((b) => b.addEventListener('click', () => { days = Number(b.dataset.adays); draw(); }));
  };
  await draw();
  live.on('order.created', debounce(() => { if (document.visibilityState === 'visible') draw(); }, 1500));
}

function orderRow(o) {
  return `<tr data-code="${esc(o.code)}"><td><a href="/admin/don-hang/${esc(o.code)}">${esc(o.code)}</a>${o.source === 'sim' ? ' <small class="muted">· mô phỏng</small>' : ''}</td><td>${dt(o.createdAt)}</td><td>${esc(o.name)}<br><small class="muted">${esc(o.phone || '')}</small></td><td>${esc(o.province)}</td><td>${fmt(o.total)}</td><td>${esc(PM[o.method] || o.method)} ${st(o.payStatus, PS)}</td><td>${st(o.status)}</td></tr>`;
}

// ---------- Biểu đồ SVG (không thư viện) ----------
function smooth(pts) {
  // Đường cong Catmull-Rom → Bézier, giữ nguyên các điểm dữ liệu
  if (pts.length < 2) return '';
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += ` C${c1[0].toFixed(1)},${Math.min(c1[1], 999).toFixed(1)} ${c2[0].toFixed(1)},${c2[1].toFixed(1)} ${p2[0]},${p2[1]}`;
  }
  return d;
}
function lineChart(series) {
  const W = 760, H = 340, pl = 58, pb = 30, pt = 12;
  const maxR = Math.max(1, ...series.map((s) => s.revenue)), maxO = Math.max(1, ...series.map((s) => s.orders));
  const x = (i) => pl + (i / Math.max(1, series.length - 1)) * (W - pl - 10);
  const base = H - pb;
  const y = (v) => pt + (1 - v / maxR) * (base - pt);
  const pts = series.map((s, i) => [+x(i).toFixed(1), +y(s.revenue).toFixed(1)]);
  const line = smooth(pts).replace(/C([\d.]+),([\d.]+)/g, (m, a, b) => `C${a},${Math.min(+b, base)}`);
  const bw = Math.max(2, ((W - pl - 10) / series.length) * 0.5);
  const bars = series.map((s, i) => `<rect x="${(x(i) - bw / 2).toFixed(1)}" y="${(base - (s.orders / maxO) * (base - pt) * 0.45).toFixed(1)}" width="${bw.toFixed(1)}" height="${((s.orders / maxO) * (base - pt) * 0.45).toFixed(1)}" rx="${Math.min(3, bw / 2)}" fill="#E8735A" fill-opacity=".38"><title>${new Date(s.date).toLocaleDateString('vi-VN')}: ${s.orders} đơn · ${fmt(s.revenue)}</title></rect>`).join('');
  const grid = [0, 0.25, 0.5, 0.75, 1].map((g) => `<line x1="${pl}" x2="${W - 10}" y1="${y(maxR * g)}" y2="${y(maxR * g)}" stroke="currentColor" stroke-opacity=".08"/><text x="${pl - 8}" y="${y(maxR * g) + 4}" text-anchor="end">${(maxR * g / 1e6).toFixed(maxR > 5e7 ? 0 : 1)}tr</text>`).join('');
  const lbl = series.map((s, i) => (i % Math.ceil(series.length / 8) === 0 ? `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${new Date(s.date).getDate()}/${new Date(s.date).getMonth() + 1}</text>` : '')).join('');
  const last = pts[pts.length - 1];
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Biểu đồ doanh thu và số đơn theo ngày"><defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2B5C94" stop-opacity=".30"/><stop offset="1" stop-color="#A9C9EC" stop-opacity="0"/></linearGradient></defs>${grid}${bars}<path d="${line} L${last[0]},${base} L${pts[0][0]},${base} Z" fill="url(#ga)"/><path d="${line}" fill="none" stroke="#2B5C94" stroke-width="2.4" stroke-linecap="round"/><circle cx="${last[0]}" cy="${last[1]}" r="4.5" fill="#2B5C94" stroke="#fff" stroke-width="2"/>${lbl}</svg>
  <table class="sr-only"><caption>Doanh thu theo ngày</caption><tbody>${series.map((s) => `<tr><td>${new Date(s.date).toLocaleDateString('vi-VN')}</td><td>${fmt(s.revenue)}</td><td>${s.orders} đơn</td></tr>`).join('')}</tbody></table>`;
}
function donut(entries, colors = ['#2B5C94', '#A9C9EC', '#E8735A', '#C9B48A', '#1F7A55', '#5B6B80']) {
  const total = entries.reduce((s, e) => s + e[1], 0) || 1;
  let a = -Math.PI / 2;
  const arcs = entries.map(([, v], i) => {
    const a2 = a + (v / total) * Math.PI * 2;
    const large = a2 - a > Math.PI ? 1 : 0;
    const p = (ang, r) => `${100 + Math.cos(ang) * r},${100 + Math.sin(ang) * r}`;
    const d = `M${p(a, 80)} A80 80 0 ${large} 1 ${p(a2 - 0.0001, 80)} L${p(a2 - 0.0001, 50)} A50 50 0 ${large} 0 ${p(a, 50)} Z`;
    a = a2;
    return `<path d="${d}" fill="${colors[i % colors.length]}"/>`;
  }).join('');
  return `<div style="display:grid;grid-template-columns:160px 1fr;gap:16px;align-items:center"><svg viewBox="0 0 200 200" role="img" aria-label="Biểu đồ tròn">${arcs}<text x="100" y="104" text-anchor="middle" style="font:500 15px var(--sans);fill:currentColor">${(total / 1e6).toFixed(0)} tr</text></svg>
  <div class="legend" style="display:grid;gap:6px">${entries.map(([k, v], i) => `<span><i style="background:${colors[i % colors.length]}"></i>${esc(k)} · <b style="color:var(--ink)">${Math.round((v / total) * 100)}%</b> (${fmt(v)})</span>`).join('')}</div></div>`;
}
function heat(m) {
  const max = Math.max(1, ...m.flat());
  const days = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
  return `<div class="heat" role="img" aria-label="Bản đồ nhiệt giờ đặt hàng"><span style="background:none"></span>${Array.from({ length: 24 }, (_, h) => `<span style="background:none;text-align:center">${h % 3 === 0 ? h : ''}</span>`).join('')}${m.map((row, d) => `<span style="background:none">${days[d]}</span>${row.map((v, h) => `<span title="${days[d]} ${h}h: ${v} đơn" style="opacity:${0.06 + (v / max) * 0.94}"></span>`).join('')}`).join('')}</div>`;
}

// ======================================================================
// ĐƠN HÀNG (bảng + kanban + chi tiết)
// ======================================================================
async function pageOrders() {
  const detail = body.dataset.detail;
  if (detail) return orderDetail(detail);
  let view = localStorage.getItem('alokio:orders-view') || 'table';
  const q = { status: '', method: '', province: '', q: '', sort: 'new', page: 1 };
  content.innerHTML = `<div class="adm-head"><h1>Đơn hàng</h1><div class="actions">
    <div class="tabs" role="tablist" aria-label="Kiểu hiển thị"><button class="tab" data-view="table" aria-selected="${view === 'table'}">Bảng</button><button class="tab" data-view="kanban" aria-selected="${view === 'kanban'}">Kanban</button></div>
    <a class="btn btn--soft btn--sm" data-csv href="/api/admin/orders?format=csv">⬇ Xuất CSV</a></div></div>
    <div class="filters-row">
      <input class="input" type="search" placeholder="Tìm mã, tên, SĐT…" data-f="q" aria-label="Tìm đơn">
      <select class="select" data-f="status" aria-label="Trạng thái"><option value="">Mọi trạng thái</option>${Object.entries(ST).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <select class="select" data-f="method" aria-label="Thanh toán"><option value="">Mọi phương thức</option>${Object.entries(PM).filter(([k]) => k !== 'deposit').map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <select class="select" data-f="province" aria-label="Tỉnh/thành"><option value="">Mọi tỉnh/thành</option>${BOOT.provinces.map((p) => `<option value="${p.code}">${esc(p.name)}</option>`).join('')}</select>
      <select class="select" data-f="sort" aria-label="Sắp xếp"><option value="new">Mới nhất</option><option value="old">Cũ nhất</option><option value="total">Giá trị cao</option></select>
    </div><div data-orders></div>`;
  const box = $('[data-orders]');
  const load = async () => {
    const u = new URLSearchParams(Object.entries(q).filter(([, v]) => v !== '' && v != null));
    $('[data-csv]').href = '/api/admin/orders?format=csv&' + u;
    if (view === 'kanban') {
      u.set('limit', 300);
      const r = await api('/api/admin/orders?' + u);
      const cols = ['pending', 'confirmed', 'packing', 'shipping', 'completed', 'cancelled'];
      box.innerHTML = `<p class="muted" style="font-size:13px">Kéo thả thẻ giữa các cột (hoặc dùng nút mũi tên) để đổi trạng thái — khách hàng thấy ngay trên trang tra cứu.</p><div class="kanban">${cols.map((c) => { const list = r.items.filter((o) => o.status === c).slice(0, c === 'completed' || c === 'cancelled' ? 15 : 60); return `<section class="kcol" data-col="${c}" aria-label="${ST[c]}"><h3>${ST[c]} <span class="muted">${r.items.filter((o) => o.status === c).length}</span></h3>${list.map(kCard).join('')}</section>`; }).join('')}</div>`;
      bindKanban();
    } else {
      u.set('limit', 25);
      const r = await api('/api/admin/orders?' + u);
      const pages = Math.ceil(r.total / 25);
      box.innerHTML = `<div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Mã</th><th>Thời gian</th><th>Khách</th><th>Tỉnh/TP</th><th>Tổng</th><th>Thanh toán</th><th>Trạng thái</th></tr></thead><tbody data-tbody>${r.items.map(orderRow).join('') || '<tr><td colspan="7" class="muted">Không có đơn phù hợp.</td></tr>'}</tbody></table></div>
      <div class="pager">${Array.from({ length: Math.min(pages, 12) }, (_, i) => i + 1).map((n) => (n === q.page ? `<span aria-current="page">${n}</span>` : `<a href="#" data-page="${n}">${n}</a>`)).join('')}</div><p class="muted" style="text-align:center;font-size:13px">${r.total} đơn</p>`;
      $$('[data-page]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); q.page = Number(a.dataset.page); load(); }));
    }
  };
  $$('[data-f]').forEach((el) => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', debounce(() => { q[el.dataset.f] = el.value; q.page = 1; load(); }, 250)));
  $$('[data-view]').forEach((b) => b.addEventListener('click', () => { view = b.dataset.view; localStorage.setItem('alokio:orders-view', view); $$('[data-view]').forEach((x) => x.setAttribute('aria-selected', String(x === b))); load(); }));
  await load();
  live.on('order.created', (d) => {
    if (view === 'table' && q.page === 1 && !q.q && !q.status) $('[data-tbody]')?.insertAdjacentHTML('afterbegin', orderRow(d.full).replace('<tr', '<tr class="is-new"'));
    if (view === 'kanban') { const col = $('[data-col="pending"]'); col?.querySelector('h3').insertAdjacentHTML('afterend', kCard(d.full)); bump('pending', 1); bindKanban(); }
  });
  live.on('order.updated', (d) => {
    const r = $(`[data-tbody] tr[data-code="${d.full.code}"]`); if (r) r.outerHTML = orderRow(d.full).replace('<tr', '<tr class="is-new"');
    const k = $(`.kcard2[data-code="${d.full.code}"]`); if (k && k.closest('[data-col]').dataset.col !== d.full.status) { bump(k.closest('[data-col]').dataset.col, -1); bump(d.full.status, 1); k.remove(); $(`[data-col="${d.full.status}"] h3`)?.insertAdjacentHTML('afterend', kCard(d.full)); bindKanban(); }
  });
}
const bump = (col, d) => { const n = $(`[data-col="${col}"] h3 span`); if (n) n.textContent = Math.max(0, Number(n.textContent) + d); };
const FLOW = ['pending', 'confirmed', 'packing', 'shipping', 'completed'];
function kCard(o) {
  const i = FLOW.indexOf(o.status);
  return `<article class="kcard2" draggable="true" tabindex="0" data-code="${esc(o.code)}" data-status="${esc(o.status)}" aria-label="Đơn ${esc(o.code)}, ${esc(ST[o.status])}"><b>${esc(o.code)}</b><small>${esc(o.name)} · ${esc(o.province)}</small><div>${fmt(o.total)} · ${st(o.payStatus, PS)}</div>
  ${i >= 0 && i < 4 ? `<div class="kmove"><button type="button" data-move="${FLOW[i + 1]}" aria-label="Chuyển sang ${ST[FLOW[i + 1]]}">→ ${ST[FLOW[i + 1]]}</button>${i < 3 ? `<button type="button" data-move="cancelled" aria-label="Huỷ đơn">Huỷ</button>` : ''}</div>` : ''}</article>`;
}
function bindKanban() {
  $$('.kcard2').forEach((c) => {
    if (c.dataset.bound) return; c.dataset.bound = 1;
    c.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', c.dataset.code); c.style.opacity = '.5'; });
    c.addEventListener('dragend', () => (c.style.opacity = ''));
    c.addEventListener('dblclick', () => __alk.go('/admin/don-hang/' + c.dataset.code));
    c.addEventListener('keydown', (e) => { if (e.key === 'Enter') __alk.go('/admin/don-hang/' + c.dataset.code); });
    c.querySelectorAll('[data-move]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); move(c.dataset.code, b.dataset.move); }));
  });
  $$('[data-col]').forEach((col) => {
    if (col.dataset.bound) return; col.dataset.bound = 1;
    col.addEventListener('dragover', (e) => { e.preventDefault(); col.classList.add('is-over'); });
    col.addEventListener('dragleave', () => col.classList.remove('is-over'));
    col.addEventListener('drop', (e) => { e.preventDefault(); col.classList.remove('is-over'); move(e.dataTransfer.getData('text/plain'), col.dataset.col); });
  });
}
async function move(code, to) {
  try { await api(`/api/admin/orders/${code}/status`, { method: 'POST', body: { status: to } }); toast(`${code} → ${ST[to]}`); }
  catch (err) { toast(err.message, { type: 'info' }); }
}
async function orderDetail(code) {
  const o = await api('/api/admin/orders/' + code);
  const render = (o) => {
    content.innerHTML = `<div class="adm-head"><div><a href="/admin/don-hang" class="link-arrow">← Đơn hàng</a><h1>Đơn ${esc(o.code)}</h1><p class="muted" style="margin:0">${dt(o.createdAt)} · ${o.source === 'sim' ? 'Bộ mô phỏng' : o.source === 'seed' ? 'Dữ liệu mẫu' : 'Website'}</p></div>
      <div class="actions">${st(o.status)} <a class="btn btn--soft btn--sm" target="_blank" href="/admin/don-hang/${esc(o.code)}/in">🖨 Hoá đơn</a><a class="btn btn--soft btn--sm" target="_blank" href="/admin/don-hang/${esc(o.code)}/in?kieu=giao-hang">📦 Phiếu giao</a></div></div>
    <div class="dash">
      <section class="panel"><h2 class="h3">Sản phẩm</h2><table class="tbl"><thead><tr><th>Sản phẩm</th><th>Màu / tuỳ chọn</th><th>SL</th><th>Thành tiền</th></tr></thead><tbody>${o.items.map((l) => `<tr><td>${esc(l.name)}</td><td>${esc(FIN[l.finish] || l.finish)}${l.options?.engraving ? ' · Khắc “' + esc(l.options.engraving) + '”' : ''}${l.options?.giftbox ? ' · Hộp quà' : ''}</td><td>${l.qty}</td><td>${fmt(l.total)}</td></tr>`).join('')}</tbody></table>
        <div style="max-width:320px;margin-left:auto;margin-top:12px"><div class="row"><span>Tạm tính</span><span>${fmt(o.subtotal)}</span></div>${o.discount ? `<div class="row"><span>Giảm (${esc(o.coupon)})</span><span>−${fmt(o.discount)}</span></div>` : ''}<div class="row"><span>Vận chuyển (${o.shippingMethod === 'express' ? 'hoả tốc' : 'tiêu chuẩn'})</span><span>${fmt(o.shippingFee)}</span></div><div class="row row--total"><span>Tổng</span><span>${fmt(o.total)}</span></div></div></section>
      <section class="panel"><h2 class="h3">Cập nhật trạng thái</h2>${o.allowed.length ? `<div style="display:flex;gap:8px;flex-wrap:wrap">${o.allowed.map((s) => `<button class="btn ${s === 'cancelled' || s === 'returned' ? 'btn--ghost' : 'btn--primary'} btn--sm" type="button" data-to="${s}">→ ${ST[s]}</button>`).join('')}</div><label class="field" style="margin-top:12px"><span>Ghi chú kèm trạng thái</span><input class="input" data-tonote placeholder="Ví dụ: mã vận đơn GHN123"></label>` : '<p class="muted">Đơn đã ở trạng thái cuối.</p>'}
        <h3 style="margin-top:24px;font-size:20px">Thanh toán</h3><p>${esc(PM[o.payment.method])}${o.payment.wallet ? ' · ' + WAL[o.payment.wallet] : ''} ${st(o.payment.status, PS)}${o.payment.deposit ? ` · cọc ${fmt(o.payment.deposit)}` : ''}</p>
        ${o.payments.map((p) => `<p style="font-size:14px">${esc(p.id)} · ${fmt(p.amount)} ${st(p.status, PS)} ${p.status === 'pending' || p.status === 'scanned' ? `<button class="copy-btn" data-markpaid="${esc(p.id)}">Đã nhận tiền</button>` : ''}${p.status === 'paid' ? `<button class="copy-btn" data-refund="${esc(p.id)}">Hoàn tiền</button>` : ''}</p>`).join('')}</section>
      <section class="panel"><h2 class="h3">Khách hàng & giao hàng</h2><p><b>${esc(o.contact.name)}</b> · ${esc(o.contact.phone)}${o.contact.email ? ' · ' + esc(o.contact.email) : ''}<br>${esc(o.address.street)}, ${esc(o.address.ward)}, ${esc(o.address.provinceName)}</p>${o.note ? `<p class="note">Ghi chú của khách: ${esc(o.note)}</p>` : ''}</section>
      <section class="panel"><h2 class="h3">Dòng thời gian</h2><ol class="timeline">${o.timeline.map((t) => `<li class="is-done"><b>${ST[t.status]}</b><small>${new Date(t.at).toLocaleString('vi-VN')}${t.note ? ' · ' + esc(t.note) : ''}</small></li>`).join('')}</ol></section>
      <section class="panel span2"><h2 class="h3">Ghi chú nội bộ</h2>${o.internalNotes.map((n) => `<p style="font-size:14px"><b>${esc(n.by)}</b> · ${dt(n.at)}<br>${esc(n.text)}</p>`).join('') || '<p class="muted">Chưa có ghi chú.</p>'}<form class="pill-form" data-note style="max-width:none"><label class="sr-only" for="note">Ghi chú</label><input id="note" name="text" placeholder="Thêm ghi chú nội bộ…"><button class="btn btn--primary btn--sm">Lưu</button></form></section>
    </div>`;
    $$('[data-to]').forEach((b) => b.addEventListener('click', async () => { if (b.dataset.to === 'cancelled' && !confirm('Huỷ đơn này? Tồn kho sẽ được hoàn lại.')) return; try { await api(`/api/admin/orders/${code}/status`, { method: 'POST', body: { status: b.dataset.to, note: $('[data-tonote]')?.value } }); toast('Đã cập nhật trạng thái.'); reload(); } catch (e) { toast(e.message, { type: 'info' }); } }));
    $$('[data-markpaid]').forEach((b) => b.addEventListener('click', async () => { await api(`/api/admin/payments/${b.dataset.markpaid}/mark`, { method: 'POST', body: { status: 'paid' } }).catch((e) => toast(e.message)); reload(); }));
    $$('[data-refund]').forEach((b) => b.addEventListener('click', async () => { if (!confirm('Hoàn tiền giao dịch này (sandbox)?')) return; await api(`/api/admin/payments/${b.dataset.refund}/mark`, { method: 'POST', body: { status: 'refunded' } }).catch((e) => toast(e.message)); reload(); }));
    $('[data-note]').addEventListener('submit', async (e) => { e.preventDefault(); await api(`/api/admin/orders/${code}/note`, { method: 'POST', body: { text: e.target.text.value } }).catch((x) => toast(x.message)); reload(); });
  };
  const reload = async () => render(await api('/api/admin/orders/' + code));
  render(o);
  live.on('order.updated', (d) => { if (d.full.code === code) reload(); });
  live.on('payment.updated', (p) => { if (p.orderCode === code) reload(); });
}

// ======================================================================
// GIAO DỊCH
// ======================================================================
async function pagePayments() {
  const f = { status: '', method: '' };
  content.innerHTML = `<div class="adm-head"><h1>Giao dịch</h1><p class="muted" style="margin:0">Phiên thanh toán QR động, thẻ, đặt cọc — cập nhật realtime khi khách quét & xác nhận.</p></div>
  <div class="filters-row"><select class="select" data-pf="status" aria-label="Trạng thái"><option value="">Mọi trạng thái</option>${Object.entries(PS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select><select class="select" data-pf="method" aria-label="Phương thức"><option value="">Mọi phương thức</option>${Object.entries(PM).filter(([k]) => k !== 'cod').map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
  <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Mã GD</th><th>Đơn</th><th>Phương thức</th><th>Số tiền</th><th>Tạo lúc</th><th>Trạng thái</th><th></th></tr></thead><tbody data-ptb></tbody></table></div>`;
  const row = (p) => `<tr data-id="${esc(p.id)}"><td>${esc(p.id)}</td><td><a href="/admin/don-hang/${esc(p.orderCode)}">${esc(p.orderCode)}</a></td><td>${esc(PM[p.method] || p.method)}${p.wallet ? ' · ' + WAL[p.wallet] : ''}${p.card ? ` · ${esc(p.card.brand)} ••${esc(p.card.last4)}` : ''}</td><td>${fmt(p.amount)}</td><td>${dt(p.createdAt || p.updatedAt)}</td><td>${st(p.status, PS)}</td><td>${p.status === 'pending' || p.status === 'scanned' ? `<button class="copy-btn" data-mp="${esc(p.id)}">Đối soát: đã nhận</button>` : ''}</td></tr>`;
  const load = async () => { const u = new URLSearchParams(Object.entries(f).filter(([, v]) => v)); const r = await api('/api/admin/payments?' + u); $('[data-ptb]').innerHTML = r.items.map(row).join(''); };
  $$('[data-pf]').forEach((s) => s.addEventListener('change', () => { f[s.dataset.pf] = s.value; load(); }));
  content.addEventListener('click', async (e) => { const b = e.target.closest('[data-mp]'); if (!b) return; await api(`/api/admin/payments/${b.dataset.mp}/mark`, { method: 'POST', body: { status: 'paid' } }).catch((x) => toast(x.message)); });
  await load();
  live.on('payment.updated', (p) => { const r = $(`[data-ptb] tr[data-id="${p.id}"]`); if (r) r.outerHTML = row(p).replace('<tr', '<tr class="is-new"'); else $('[data-ptb]').insertAdjacentHTML('afterbegin', row({ ...p, createdAt: Date.now() }).replace('<tr', '<tr class="is-new"')); });
}

// ======================================================================
// SẢN PHẨM
// ======================================================================
async function pageProducts() {
  const { items } = await api('/api/admin/products');
  let list = items;
  content.innerHTML = `<div class="adm-head"><h1>Sản phẩm</h1><div class="actions"><input class="input" type="search" placeholder="Tìm sản phẩm…" data-ps style="width:220px" aria-label="Tìm sản phẩm"><select class="select" data-pl aria-label="Dòng"><option value="">Mọi dòng</option><option value="luxe">Alokio Luxe</option><option value="karaoke">Loa kéo karaoke</option></select><button class="btn btn--primary btn--sm" data-new>+ Thêm sản phẩm</button></div></div>
  <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th></th><th>Sản phẩm</th><th>Dòng</th><th>Giá</th><th>Tồn kho</th><th>Đã bán</th><th>Hiển thị</th><th></th></tr></thead><tbody data-prtb></tbody></table></div>`;
  const draw = () => {
    const q = $('[data-ps]').value.toLowerCase(), l = $('[data-pl]').value;
    $('[data-prtb]').innerHTML = list.filter((p) => (!l || p.line === l) && p.name.toLowerCase().includes(q)).map((p) => {
      const total = Object.values(p.stock).reduce((a, b) => a + b, 0);
      return `<tr id="${esc(p.slug)}"><td><img src="${esc(p.image)}" alt="" width="52" height="52" style="object-fit:contain;border-radius:10px;background:var(--pearl)"></td><td><b>${esc(p.name)}</b><br><small class="muted">${esc(BOOT.categories.find((c) => c.slug === p.category)?.name || p.category)}${p.needsVerify ? ' · ⚠ cần xác nhận thông số' : ''}</small></td><td>${p.line === 'luxe' ? '<span class="tag tag--concept">Luxe · ý tưởng</span>' : '<span class="tag tag--real">Thật</span>'}</td><td>${fmt(p.price)}${p.compareAt ? `<br><small class="muted"><s>${fmt(p.compareAt)}</s></small>` : ''}</td><td class="${Object.values(p.stock).some((v) => v <= 3) ? 'stock-low' : ''}">${total}</td><td>${p.sold}</td><td><label class="switch"><input type="checkbox" ${p.hidden ? '' : 'checked'} data-vis="${esc(p.id)}" aria-label="Hiển thị ${esc(p.name)}"></label></td><td><button class="copy-btn" data-edit="${esc(p.id)}">Sửa</button> <a class="copy-btn" href="/san-pham/${esc(p.slug)}" target="_blank" style="text-decoration:none">Xem</a></td></tr>`;
    }).join('');
  };
  draw();
  $('[data-ps]').addEventListener('input', draw); $('[data-pl]').addEventListener('change', draw);
  content.addEventListener('change', async (e) => { const v = e.target.closest('[data-vis]'); if (!v) return; const p = list.find((x) => x.id === v.dataset.vis); await api('/api/admin/products', { method: 'POST', body: { id: p.id, name: p.name, price: p.price, hidden: !v.checked } }); p.hidden = !v.checked; toast(v.checked ? 'Đã hiện sản phẩm trên cửa hàng.' : 'Đã ẩn sản phẩm khỏi cửa hàng.'); });
  content.addEventListener('click', (e) => { const b = e.target.closest('[data-edit]'); if (b) editProduct(list.find((x) => x.id === b.dataset.edit)); if (e.target.closest('[data-new]')) editProduct(null); });
  if (location.hash) setTimeout(() => { const p = list.find((x) => x.slug === location.hash.slice(1)); p && editProduct(p); }, 200);
  async function editProduct(p) {
    const isNew = !p;
    p = p || { name: '', line: 'luxe', category: 'loa-di-dong', price: 0, compareAt: null, tagline: '', highlights: [], specs: [], description: [''], hidden: false, finishes: ['ngoc-trai'], stock: { 'ngoc-trai': 0 }, model: { type: 'halong' } };
    showModal(`<h2 style="font-size:30px">${isNew ? 'Thêm sản phẩm' : 'Sửa: ' + esc(p.name)}</h2>
      <div class="mini3d" data-mini3d><img src="${esc(p.image || '')}" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;padding:8%"></div>
      <form class="stack" data-pform style="margin-top:16px" novalidate>
        <div class="grid2"><label class="field"><span>Tên *</span><input class="input" name="name" value="${esc(p.name)}" required><small class="err" data-err="name"></small></label>
        <label class="field"><span>Dòng</span><select class="select" name="line"><option value="luxe" ${p.line === 'luxe' ? 'selected' : ''}>Alokio Luxe (ý tưởng)</option><option value="karaoke" ${p.line === 'karaoke' ? 'selected' : ''}>Loa kéo karaoke (thật)</option></select></label>
        <label class="field"><span>Giá bán (₫) *</span><input class="input" name="price" type="number" min="0" step="1000" value="${p.price}"><small class="err" data-err="price"></small></label>
        <label class="field"><span>Giá gốc gạch ngang (₫)</span><input class="input" name="compareAt" type="number" min="0" step="1000" value="${p.compareAt || ''}"></label>
        <label class="field"><span>Danh mục</span><select class="select" name="category">${BOOT.categories.map((c) => `<option value="${c.slug}" ${p.category === c.slug ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
        <label class="field"><span>Ảnh (tải lên)</span><input class="input" name="image" type="file" accept="image/png,image/jpeg,image/webp" style="padding-top:10px"></label></div>
        <label class="field"><span>Câu giới thiệu ngắn</span><input class="input" name="tagline" value="${esc(p.tagline)}"></label>
        <label class="field"><span>Điểm nổi bật (mỗi dòng một ý)</span><textarea class="textarea" name="highlights">${esc(p.highlights.join('\n'))}</textarea></label>
        <label class="field"><span>Thông số (mỗi dòng: Tên | Giá trị)</span><textarea class="textarea" name="specs" style="min-height:140px">${esc(p.specs.map((s) => s.join(' | ')).join('\n'))}</textarea></label>
        <label class="field"><span>Mô tả (đoạn cách nhau bằng dòng trống)</span><textarea class="textarea" name="description" style="min-height:140px">${esc(p.description.join('\n\n'))}</textarea></label>
        <label class="check"><input type="checkbox" name="needsVerify" ${p.needsVerify ? 'checked' : ''}> Gắn cờ "cần xác nhận thông số"</label>
        <p class="err" data-perr aria-live="assertive"></p>
        <button class="btn btn--primary" type="submit">Lưu sản phẩm</button>
      </form>`, async (panel, close) => {
      if (!isNew) {
        try {
          const { mountViewer } = await import('../three/viewer.js');
          const box = panel.querySelector('[data-mini3d]'); const c = document.createElement('canvas'); box.prepend(c);
          mountViewer(c, { model: p.model, finish: p.finishes[0], padding: 1.2 });
          box.querySelector('img').style.opacity = 0;
        } catch { /* không có WebGL */ }
      }
      const form = panel.querySelector('[data-pform]');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const file = fd.get('image');
        let imageData = null;
        if (file && file.size) { if (file.size > 3e6) { panel.querySelector('[data-perr]').textContent = 'Ảnh tối đa 3 MB.'; return; } imageData = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); }); imageData = await shrinkImage(imageData); }
        const payload = {
          id: isNew ? undefined : p.id, name: fd.get('name'), line: fd.get('line'), price: Number(fd.get('price')), compareAt: Number(fd.get('compareAt')) || null, category: fd.get('category'),
          tagline: fd.get('tagline'), highlights: fd.get('highlights').split('\n').map((x) => x.trim()).filter(Boolean),
          specs: fd.get('specs').split('\n').map((x) => x.split('|').map((y) => y.trim())).filter((x) => x[0] && x[1]),
          description: fd.get('description').split(/\n\s*\n/).map((x) => x.trim()).filter(Boolean), needsVerify: !!fd.get('needsVerify'), imageData,
        };
        try { const r = await api('/api/admin/products', { method: 'POST', body: payload }); toast('Đã lưu sản phẩm — cửa hàng cập nhật ngay.'); close(); const i = list.findIndex((x) => x.id === r.product.id); if (i >= 0) list[i] = r.product; else list.unshift(r.product); draw(); }
        catch (err) { panel.querySelector('[data-perr]').textContent = err.message; if (err.data?.fields) for (const [k, v] of Object.entries(err.data.fields)) { const el = panel.querySelector(`[data-err="${k}"]`); if (el) el.textContent = v; } }
      });
    });
  }
}

// ======================================================================
// KHO
// ======================================================================
async function pageInventory() {
  const [{ items }, logs] = await Promise.all([api('/api/admin/products'), api('/api/admin/inventory-log')]);
  content.innerHTML = `<div class="adm-head"><h1>Kho hàng</h1><p class="muted" style="margin:0">Nhập số dương để nhập kho, số âm để xuất kho. Tồn kho cập nhật realtime trên trang sản phẩm.</p></div>
  <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Sản phẩm</th><th>Tồn theo màu</th><th>Điều chỉnh</th></tr></thead><tbody>${items.map((p) => `<tr data-pid="${esc(p.id)}"><td><b>${esc(p.name)}</b><br><small class="muted">Đã bán ${p.sold}</small></td><td data-stock>${Object.entries(p.stock).map(([f, n]) => `<span class="stockcell ${n <= 3 ? 'stock-low' : ''}">${FIN[f] || f}: <b>${n}</b></span>`).join('')}</td>
    <td><form class="stockform" style="display:flex;gap:6px;flex-wrap:wrap"><select class="select" name="finish" style="min-height:34px;width:auto" aria-label="Màu">${p.finishes.map((f) => `<option value="${f}">${FIN[f] || f}</option>`).join('')}</select><input class="input" name="delta" type="number" value="10" style="min-height:34px;width:80px" aria-label="Số lượng"><input class="input" name="reason" placeholder="Lý do" style="min-height:34px;width:130px" aria-label="Lý do"><button class="btn btn--soft btn--sm">Lưu</button></form></td></tr>`).join('')}</tbody></table></div>
  <section class="panel" style="margin-top:16px"><h2 class="h3">Lịch sử nhập/xuất</h2><ul class="feed" data-ilog>${logs.items.map((l) => `<li><b>${l.delta > 0 ? '+' : ''}${l.delta}</b> ${esc(l.name)} (${FIN[l.finish] || l.finish}) → ${l.after} · ${esc(l.reason || '')}<small>${esc(l.by)} · ${timeAgo(l.at)}</small></li>`).join('') || '<li class="muted">Chưa có.</li>'}</ul></section>`;
  content.addEventListener('submit', async (e) => {
    const f = e.target.closest('.stockform'); if (!f) return; e.preventDefault();
    const pid = f.closest('tr').dataset.pid;
    try { const r = await api(`/api/admin/products/${pid}/stock`, { method: 'POST', body: { finish: f.finish.value, delta: Number(f.delta.value), reason: f.reason.value } }); f.closest('tr').querySelector('[data-stock]').innerHTML = Object.entries(r.stock).map(([k, n]) => `<span class="stockcell ${n <= 3 ? 'stock-low' : ''}">${FIN[k] || k}: <b>${n}</b></span>`).join(''); toast('Đã cập nhật tồn kho.'); $('[data-ilog]').insertAdjacentHTML('afterbegin', `<li class="is-new"><b>${f.delta.value}</b> · ${esc(f.reason.value)}<small>vừa xong</small></li>`); }
    catch (err) { toast(err.message, { type: 'info' }); }
  });
  live.on('stock.changed', (d) => { const r = $(`tr[data-pid="${d.productId}"] [data-stock]`); if (r) r.innerHTML = Object.entries(d.stock).map(([k, n]) => `<span class="stockcell ${n <= 3 ? 'stock-low' : ''}">${FIN[k] || k}: <b>${n}</b></span>`).join(''); });
}

// ======================================================================
// KHÁCH HÀNG
// ======================================================================
async function pageCustomers() {
  const { items } = await api('/api/admin/customers');
  content.innerHTML = `<div class="adm-head"><h1>Khách hàng</h1><div class="actions"><input class="input" type="search" placeholder="Tìm khách…" data-cs aria-label="Tìm khách" style="width:240px"><select class="select" data-ct aria-label="Hạng"><option value="">Mọi hạng</option><option>VIP</option><option>Thân thiết</option><option>Mới</option></select></div></div>
  <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Khách</th><th>Tỉnh/TP</th><th>Đơn</th><th>Chi tiêu</th><th>Hạng</th><th>Đơn gần nhất</th></tr></thead><tbody data-ctb></tbody></table></div>`;
  const draw = () => { const q = $('[data-cs]').value.toLowerCase(), t = $('[data-ct]').value; $('[data-ctb]').innerHTML = items.filter((c) => (!t || c.tier === t) && `${c.name} ${c.phone} ${c.email}`.toLowerCase().includes(q)).slice(0, 200).map((c) => `<tr><td><a href="#" data-cust="${esc(c.id)}">${esc(c.name)}</a><br><small class="muted">${esc(c.phone)} · ${esc(c.email)}${c.hasAccount ? ' · có tài khoản' : ''}</small></td><td>${esc(c.province)}</td><td>${c.orders}</td><td>${fmt(c.spend)}</td><td><span class="tag ${c.tier === 'VIP' ? 'tag--concept' : ''}">${c.tier}</span></td><td>${c.last ? timeAgo(c.last) : '—'}</td></tr>`).join(''); };
  draw(); $('[data-cs]').addEventListener('input', draw); $('[data-ct]').addEventListener('change', draw);
  content.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-cust]'); if (!a) return; e.preventDefault();
    const c = await api('/api/admin/customers/' + a.dataset.cust);
    showModal(`<h2 style="font-size:30px">${esc(c.name)}</h2><p class="muted">${esc(c.phone)} · ${esc(c.email)}<br>${esc(c.addresses[0] ? `${c.addresses[0].street}, ${c.addresses[0].ward}, ${c.addresses[0].provinceName}` : '')}</p>
      <h3>Lịch sử mua (${c.orders.length})</h3><table class="tbl"><tbody>${c.orders.map((o) => `<tr><td><a href="/admin/don-hang/${esc(o.code)}">${esc(o.code)}</a></td><td>${dt(o.createdAt)}</td><td>${fmt(o.total)}</td><td>${st(o.status)}</td></tr>`).join('')}</tbody></table>
      <form data-cnote class="stack" style="margin-top:16px"><label class="field"><span>Ghi chú CRM</span><textarea class="textarea" name="note">${esc(c.note || '')}</textarea></label><button class="btn btn--primary btn--sm">Lưu ghi chú</button></form>`, (panel) => {
      panel.querySelector('[data-cnote]').addEventListener('submit', async (ev) => { ev.preventDefault(); await api(`/api/admin/customers/${c.id}/note`, { method: 'POST', body: { note: ev.target.note.value } }); toast('Đã lưu ghi chú.'); });
    });
  });
}

// ======================================================================
// CHAT
// ======================================================================
async function pageChat() {
  content.innerHTML = `<div class="adm-head"><h1>Hộp thư chat</h1><p class="muted" style="margin:0">Trả lời khách đang chat trên cửa hàng — tin nhắn hiện ngay bên phía khách.</p></div>
  <div class="split"><div class="split__list" data-chats role="list"></div><div class="split__pane"><div class="split__msgs" data-msgs aria-live="polite"><p class="muted">Chọn một cuộc trò chuyện.</p></div>
  <div style="display:flex;gap:6px;padding:8px 12px;flex-wrap:wrap;border-top:1px solid var(--line)" data-quick>${['Dạ Alokio chào anh/chị ạ!', 'Sản phẩm vẫn còn hàng ạ.', 'Loa kéo chính hãng có bán tại Shopee và TikTok Shop của Alokio ạ.', 'Alokio Luxe là dòng sản phẩm ý tưởng của đồ án ạ.'].map((q) => `<button class="chip" type="button">${esc(q)}</button>`).join('')}</div>
  <form class="chat__form" data-reply><label class="sr-only" for="reply">Trả lời</label><input id="reply" name="text" placeholder="Nhập câu trả lời…" autocomplete="off" disabled><button class="btn btn--primary btn--sm" disabled>Gửi</button><button class="btn btn--soft btn--sm" type="button" data-resolve disabled>Đã xử lý</button></form></div></div>`;
  let cur = null;
  const list = async () => { const r = await api('/api/admin/chats'); $('[data-chats]').innerHTML = r.items.sort((a, b) => b.updatedAt - a.updatedAt).map((c) => `<button type="button" data-chat="${esc(c.id)}" aria-current="${c.id === cur}" role="listitem"><b>${esc(c.name)} ${c.unread ? `<span class="adm__badge" style="margin-left:6px">${c.unread}</span>` : ''} ${c.status === 'resolved' ? '<small>· đã xử lý</small>' : ''}</b><small>${esc(c.last?.text || '')}</small><small>${timeAgo(c.updatedAt)}</small></button>`).join(''); badge('chat', 0, r.items.reduce((a, c) => a + c.unread, 0)); };
  const open = async (id) => {
    cur = id; const c = await api('/api/admin/chats/' + id);
    $('[data-msgs]').innerHTML = c.messages.map((m) => `<div class="msg msg--${m.from === 'customer' ? 'customer' : 'staff'}">${esc(m.text)}<small>${m.from === 'customer' ? esc(c.name) : m.from === 'bot' ? 'Trả lời tự động' : esc(m.by || 'Nhân viên')} · ${dt(m.at)}</small></div>`).join('');
    $('[data-msgs]').scrollTop = 1e6;
    $$('[data-reply] input, [data-reply] button').forEach((x) => (x.disabled = false));
    list();
  };
  content.addEventListener('click', (e) => { const b = e.target.closest('[data-chat]'); if (b) open(b.dataset.chat); const q = e.target.closest('[data-quick] .chip'); if (q && cur) { $('#reply').value = q.textContent; $('[data-reply]').requestSubmit(); } });
  $('[data-reply]').addEventListener('submit', async (e) => { e.preventDefault(); const t = e.target.text.value.trim(); if (!t || !cur) return; e.target.text.value = ''; await api('/api/admin/chats/' + cur, { method: 'POST', body: { text: t } }); open(cur); });
  $('[data-resolve]').addEventListener('click', async () => { if (!cur) return; await api('/api/admin/chats/' + cur, { method: 'POST', body: { status: 'resolved' } }); toast('Đã đánh dấu đã xử lý.'); list(); });
  await list();
  live.on('admin.chat', (d) => { if (d.chatId === cur) open(cur); else list(); });
}

// ======================================================================
// MÃ GIẢM GIÁ
// ======================================================================
async function pageCoupons() {
  const draw = async () => {
    const { items } = await api('/api/admin/coupons');
    content.innerHTML = `<div class="adm-head"><h1>Mã giảm giá</h1><button class="btn btn--primary btn--sm" data-cnew>+ Tạo mã</button></div>
    <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Mã</th><th>Mô tả</th><th>Đã dùng</th><th>Hạn</th><th>Bật</th><th></th></tr></thead><tbody>${items.map((c) => `<tr><td><b>${esc(c.code)}</b></td><td>${esc(c.desc || '')}</td><td>${c.used}/${c.limit || '∞'}</td><td>${c.expiresAt ? new Date(c.expiresAt).toLocaleDateString('vi-VN') : '—'}</td><td>${c.enabled ? '✓' : '—'}</td><td><button class="copy-btn" data-cedit="${esc(c.code)}">Sửa</button> <button class="copy-btn" data-cdel="${esc(c.code)}">Xoá</button></td></tr>`).join('')}</tbody></table></div>`;
    $('[data-cnew]').addEventListener('click', () => edit(null));
    $$('[data-cedit]').forEach((b) => b.addEventListener('click', () => edit(items.find((c) => c.code === b.dataset.cedit))));
    $$('[data-cdel]').forEach((b) => b.addEventListener('click', async () => { if (!confirm('Xoá mã ' + b.dataset.cdel + '?')) return; await api('/api/admin/coupons/' + b.dataset.cdel, { method: 'DELETE' }); draw(); }));
  };
  const edit = (c) => {
    c = c || { code: '', type: 'percent', value: 10, max: null, minOrder: 0, line: '', limit: 100, enabled: true, expiresAt: Date.now() + 30 * 864e5, desc: '' };
    showModal(`<h2 style="font-size:30px">${c.code ? 'Sửa mã ' + esc(c.code) : 'Tạo mã giảm giá'}</h2><form class="stack" data-cform novalidate><div class="grid2">
      <label class="field"><span>Mã</span><input class="input" name="code" value="${esc(c.code)}" ${c.code ? 'readonly' : ''} style="text-transform:uppercase"></label>
      <label class="field"><span>Loại</span><select class="select" name="type"><option value="percent" ${c.type === 'percent' ? 'selected' : ''}>Giảm %</option><option value="fixed" ${c.type === 'fixed' ? 'selected' : ''}>Giảm số tiền</option><option value="freeship" ${c.type === 'freeship' ? 'selected' : ''}>Miễn phí ship</option></select></label>
      <label class="field"><span>Giá trị</span><input class="input" type="number" name="value" value="${c.value}"></label><label class="field"><span>Giảm tối đa (₫)</span><input class="input" type="number" name="max" value="${c.max || ''}"></label>
      <label class="field"><span>Đơn tối thiểu (₫)</span><input class="input" type="number" name="minOrder" value="${c.minOrder || 0}"></label><label class="field"><span>Áp dụng cho dòng</span><select class="select" name="line"><option value="">Tất cả</option><option value="luxe" ${c.line === 'luxe' ? 'selected' : ''}>Alokio Luxe</option><option value="karaoke" ${c.line === 'karaoke' ? 'selected' : ''}>Loa kéo</option></select></label>
      <label class="field"><span>Số lượt</span><input class="input" type="number" name="limit" value="${c.limit || ''}"></label><label class="field"><span>Hết hạn</span><input class="input" type="date" name="expiresAt" value="${c.expiresAt ? new Date(c.expiresAt).toISOString().slice(0, 10) : ''}"></label></div>
      <label class="field"><span>Mô tả</span><input class="input" name="desc" value="${esc(c.desc || '')}"></label><label class="check"><input type="checkbox" name="enabled" ${c.enabled ? 'checked' : ''}> Đang bật</label>
      <p class="err" data-cerr></p><button class="btn btn--primary">Lưu</button></form>`, (panel, close) => {
      panel.querySelector('[data-cform]').addEventListener('submit', async (e) => { e.preventDefault(); const fd = Object.fromEntries(new FormData(e.target)); try { await api('/api/admin/coupons', { method: 'POST', body: { ...fd, enabled: !!fd.enabled, expiresAt: fd.expiresAt ? new Date(fd.expiresAt + 'T23:59:59').getTime() : null } }); close(); toast('Đã lưu mã.'); draw(); } catch (err) { panel.querySelector('[data-cerr]').textContent = err.message; } });
    });
  };
  draw();
}

// ======================================================================
// FLASH SALE
// ======================================================================
async function pageFlash() {
  const [{ items }, prods] = await Promise.all([api('/api/admin/flash'), api('/api/admin/products')]);
  const f = items[0] || { name: 'Flash sale', enabled: true, startsAt: Date.now(), endsAt: Date.now() + 2 * 864e5, items: [] };
  const local = (t) => new Date(t - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
  content.innerHTML = `<div class="adm-head"><h1>Flash sale</h1><p class="muted" style="margin:0">Cửa hàng tự bật/tắt đúng giờ; số suất đã bán cập nhật realtime.</p></div>
  <form class="panel stack" data-fform><div class="grid2"><label class="field"><span>Tên chương trình</span><input class="input" name="name" value="${esc(f.name)}"></label><label class="switch" style="align-self:end"><input type="checkbox" name="enabled" ${f.enabled ? 'checked' : ''}> Đang bật</label>
    <label class="field"><span>Bắt đầu</span><input class="input" type="datetime-local" name="startsAt" value="${local(f.startsAt)}"></label><label class="field"><span>Kết thúc</span><input class="input" type="datetime-local" name="endsAt" value="${local(f.endsAt)}"></label></div>
    <table class="tbl"><thead><tr><th>Sản phẩm</th><th>Giá flash</th><th>Số suất</th><th>Đã bán</th><th></th></tr></thead><tbody data-fitems>${f.items.map((it) => fRow(it)).join('')}</tbody></table>
    <div style="display:flex;gap:8px"><select class="select" data-fadd style="width:auto"><option value="">+ Thêm sản phẩm…</option>${prods.items.map((p) => `<option value="${esc(p.id)}">${esc(p.name)} (${fmt(p.price)})</option>`).join('')}</select></div>
    <button class="btn btn--primary">Lưu flash sale</button></form>`;
  function fRow(it) { const p = prods.items.find((x) => x.id === it.productId); return `<tr data-fid="${esc(it.productId)}"><td>${esc(p?.name || it.productId)}<br><small class="muted">Giá thường ${fmt(p?.price)}</small></td><td><input class="input" type="number" name="price" value="${it.price}" style="min-height:36px;width:140px" aria-label="Giá flash"></td><td><input class="input" type="number" name="quota" value="${it.quota}" style="min-height:36px;width:90px" aria-label="Số suất"></td><td>${it.sold || 0}<input type="hidden" name="sold" value="${it.sold || 0}"></td><td><button class="copy-btn" type="button" data-frm>Bỏ</button></td></tr>`; }
  $('[data-fadd]').addEventListener('change', (e) => { const p = prods.items.find((x) => x.id === e.target.value); if (!p) return; $('[data-fitems]').insertAdjacentHTML('beforeend', fRow({ productId: p.id, price: Math.round(p.price * 0.85 / 1000) * 1000, quota: 20, sold: 0 })); e.target.value = ''; });
  content.addEventListener('click', (e) => { if (e.target.closest('[data-frm]')) e.target.closest('tr').remove(); });
  $('[data-fform]').addEventListener('submit', async (e) => {
    e.preventDefault(); const fm = e.target;
    const its = $$('[data-fitems] tr').map((r) => ({ productId: r.dataset.fid, price: r.querySelector('[name=price]').value, quota: r.querySelector('[name=quota]').value, sold: r.querySelector('[name=sold]').value }));
    await api('/api/admin/flash', { method: 'POST', body: { id: f.id, name: fm.name.value, enabled: fm.enabled.checked, startsAt: new Date(fm.startsAt.value).getTime(), endsAt: new Date(fm.endsAt.value).getTime(), items: its } });
    toast('Đã lưu flash sale — cửa hàng đã cập nhật.');
  });
}

// ======================================================================
// ĐÁNH GIÁ
// ======================================================================
async function pageReviews() {
  const { items } = await api('/api/admin/reviews');
  const draw = (filter) => {
    const list = items.filter((r) => !filter || r.status === filter);
    content.innerHTML = `<div class="adm-head"><h1>Đánh giá</h1><div class="tabs">${[['', 'Tất cả'], ['pending', 'Chờ duyệt'], ['approved', 'Đã duyệt'], ['hidden', 'Đã ẩn']].map(([k, l]) => `<button class="tab" data-rf="${k}" aria-selected="${(filter || '') === k}">${l}</button>`).join('')}</div></div>
    <div class="tbl-wrap"><table class="tbl tbl--cards"><thead><tr><th>Sản phẩm</th><th>Khách</th><th>Sao</th><th>Nội dung</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>${list.slice(0, 150).map((r) => `<tr data-rid="${esc(r.id)}"><td>${esc(r.product)}</td><td>${esc(r.name)}${r.sample ? '<br><small class="muted">mẫu</small>' : ''}</td><td>${'★'.repeat(r.stars)}</td><td style="max-width:360px">${esc(r.text)}${r.reply ? `<br><small class="muted">↳ ${esc(r.reply)}</small>` : ''}</td><td>${st(r.status === 'approved' ? 'completed' : r.status === 'pending' ? 'pending' : 'cancelled', { completed: 'Đã duyệt', pending: 'Chờ duyệt', cancelled: 'Đã ẩn' })}</td>
      <td><button class="copy-btn" data-rs="approved">Duyệt</button> <button class="copy-btn" data-rs="hidden">Ẩn</button> <button class="copy-btn" data-rr>Trả lời</button></td></tr>`).join('')}</tbody></table></div>`;
    $$('[data-rf]').forEach((b) => b.addEventListener('click', () => draw(b.dataset.rf)));
  };
  content.addEventListener('click', async (e) => {
    const tr = e.target.closest('[data-rid]'); if (!tr) return;
    const r = items.find((x) => x.id === tr.dataset.rid);
    const s = e.target.closest('[data-rs]');
    if (s) { await api('/api/admin/reviews/' + r.id, { method: 'POST', body: { status: s.dataset.rs } }); r.status = s.dataset.rs; toast('Đã cập nhật đánh giá.'); draw(); }
    if (e.target.closest('[data-rr]')) { const t = prompt('Trả lời khách:', r.reply || 'Cảm ơn anh/chị đã tin chọn Alokio!'); if (t != null) { await api('/api/admin/reviews/' + r.id, { method: 'POST', body: { reply: t, status: 'approved' } }); r.reply = t; r.status = 'approved'; draw(); } }
  });
  draw(items.some((r) => r.status === 'pending') ? 'pending' : '');
}

// ======================================================================
// NỘI DUNG
// ======================================================================
async function pageContent() {
  const d = await api('/api/admin/content');
  content.innerHTML = `<div class="adm-head"><h1>Nội dung & blog</h1><button class="btn btn--primary btn--sm" data-pnew>+ Bài viết mới</button></div>
  <div class="dash"><section class="panel"><h2 class="h3">Bài viết</h2><table class="tbl"><tbody>${d.posts.map((p) => `<tr><td><b>${esc(p.title)}</b><br><small class="muted">${new Date(p.publishedAt).toLocaleDateString('vi-VN')} · /blog/${esc(p.slug)}</small></td><td><button class="copy-btn" data-pedit="${esc(p.id)}">Sửa</button> <button class="copy-btn" data-pdel="${esc(p.id)}">Xoá</button></td></tr>`).join('')}</tbody></table></section>
  <section class="panel"><h2 class="h3">Lịch nghe thử (${d.appointments.length})</h2><ul class="feed">${d.appointments.map((a) => `<li><b>${esc(a.name)}</b> · ${esc(a.phone)} · ${esc(a.product || '')}<small>${esc(a.date || '')} ${esc(a.note || '')}</small></li>`).join('') || '<li class="muted">Chưa có.</li>'}</ul>
  <h2 class="h3" style="margin-top:20px">Đăng ký nhận tin (${d.newsletter.length})</h2><ul class="feed">${d.newsletter.map((e) => `<li>${esc(e)}</li>`).join('') || '<li class="muted">Chưa có.</li>'}</ul></section></div>`;
  const edit = (p) => {
    p = p || { title: '', excerpt: '', body: '## Tiêu đề mục\n\nNội dung…' };
    showModal(`<h2 style="font-size:30px">${p.id ? 'Sửa bài' : 'Bài mới'}</h2><form class="stack" data-postf><label class="field"><span>Tiêu đề</span><input class="input" name="title" value="${esc(p.title)}"></label><label class="field"><span>Mô tả ngắn</span><input class="input" name="excerpt" value="${esc(p.excerpt)}"></label>
      <div class="grid2"><label class="field"><span>Nội dung (Markdown: ## tiêu đề, - gạch đầu dòng)</span><textarea class="textarea" name="body" style="min-height:320px;font-family:var(--mono);font-size:13px">${esc(p.body)}</textarea></label><div><span style="font-size:14px;font-weight:500">Xem trước</span><div class="prose panel" data-prev style="font-size:15px;max-height:340px;overflow:auto"></div></div></div>
      <p class="err" data-poerr></p><button class="btn btn--primary">Lưu & xuất bản</button></form>`, (panel, close) => {
      const f = panel.querySelector('[data-postf]');
      const prev = () => { panel.querySelector('[data-prev]').innerHTML = f.body.value.split(/\n{2,}/).map((b) => b.startsWith('## ') ? `<h2 style="font-size:24px">${esc(b.slice(3))}</h2>` : b.split('\n').every((l) => l.startsWith('- ')) ? `<ul>${b.split('\n').map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>` : `<p>${esc(b)}</p>`).join(''); };
      f.body.addEventListener('input', prev); prev();
      f.addEventListener('submit', async (e) => { e.preventDefault(); try { await api('/api/admin/posts', { method: 'POST', body: { id: p.id, title: f.title.value, excerpt: f.excerpt.value, body: f.body.value } }); close(); toast('Đã xuất bản bài viết.'); pageContent(); } catch (err) { panel.querySelector('[data-poerr]').textContent = err.message; } });
    });
  };
  $('[data-pnew]').addEventListener('click', () => edit(null));
  $$('[data-pedit]').forEach((b) => b.addEventListener('click', () => edit(d.posts.find((p) => p.id === b.dataset.pedit))));
  $$('[data-pdel]').forEach((b) => b.addEventListener('click', async () => { if (!confirm('Xoá bài viết này?')) return; await api('/api/admin/posts/' + b.dataset.pdel, { method: 'DELETE' }); pageContent(); }));
}

// ======================================================================
// CÀI ĐẶT
// ======================================================================
async function pageSettings() {
  const s = BOOT.settings;
  content.innerHTML = `<div class="adm-head"><h1>Cài đặt</h1></div>
  <form class="dash" data-sform novalidate>
    <section class="panel stack"><h2 class="h3">Cửa hàng & kênh chính thức</h2>
      <label class="field"><span>Thanh thông báo</span><input class="input" name="announcement" value="${esc(s.announcement)}"></label>
      <label class="field"><span>Facebook</span><input class="input" name="facebook" value="${esc(s.links.facebook)}"></label>
      <label class="field"><span>TikTok Shop</span><input class="input" name="tiktok" value="${esc(s.links.tiktok)}"></label>
      <label class="field"><span>Shopee</span><input class="input" name="shopee" value="${esc(s.links.shopee)}"></label>
      <label class="switch"><input type="checkbox" name="recentTicker" ${s.recentTicker ? 'checked' : ''}> Hiện băng “đơn hàng gần đây” trên cửa hàng</label>
      <label class="switch"><input type="checkbox" name="liveViewers" ${s.liveViewers ? 'checked' : ''}> Hiện “đang có N người xem” (đếm kết nối thật)</label></section>
    <section class="panel stack"><h2 class="h3">Vận chuyển</h2>
      <label class="field"><span>Miễn phí ship từ (₫)</span><input class="input" type="number" name="freeThreshold" value="${s.shipping.freeThreshold}"></label>
      <label class="field"><span>Phí hoả tốc (₫)</span><input class="input" type="number" name="express" value="${s.shipping.express}"></label>
      ${s.shipping.tiers.map((t, i) => `<div class="grid2"><label class="field"><span>Bậc ${i + 1}: tối đa (kg)</span><input class="input" type="number" name="tierKg${i}" value="${t.maxKg}"></label><label class="field"><span>Phí (₫)</span><input class="input" type="number" name="tierFee${i}" value="${t.fee}"></label></div>`).join('')}</section>
    <section class="panel stack"><h2 class="h3">Thanh toán (sandbox)</h2>
      ${[['cod', 'COD'], ['vietqr', 'VietQR động'], ['wallet', 'Ví điện tử QR động'], ['card', 'Thẻ'], ['installment', 'Trả góp 0%']].map(([k, l]) => `<label class="switch"><input type="checkbox" name="pay_${k}" ${s.payments[k] ? 'checked' : ''}> ${l}</label>`).join('')}
      <div class="wallets">${Object.entries(WAL).map(([k, l]) => `<label class="wallet-chip"><input type="checkbox" name="wallet_${k}" ${s.payments.wallets.includes(k) ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div>
      <div class="grid2"><label class="field"><span>Đặt cọc (%)</span><input class="input" type="number" name="depositPercent" value="${s.payments.depositPercent}"></label><label class="field"><span>Cọc cho đơn từ (₫)</span><input class="input" type="number" name="depositMin" value="${s.payments.depositMin}"></label>
      <label class="field"><span>Hạn mã QR (phút)</span><input class="input" type="number" name="qrMinutes" value="${s.payments.qrMinutes}"></label></div></section>
    <section class="panel stack"><h2 class="h3">VietQR</h2><p class="note">Mặc định là tài khoản DEMO để không phát sinh giao dịch thật. Chỉ điền tài khoản thật nếu bạn hiểu rõ rủi ro.</p>
      <div class="grid2"><label class="field"><span>Mã BIN ngân hàng</span><input class="input" name="bin" value="${esc(s.vietqr.bin)}"></label><label class="field"><span>Số tài khoản</span><input class="input" name="account" value="${esc(s.vietqr.account)}"></label></div>
      <label class="field"><span>Tên chủ tài khoản</span><input class="input" name="accountName" value="${esc(s.vietqr.accountName)}"></label></section>
    <section class="panel stack span2"><h2 class="h3">Công cụ demo</h2>
      <div class="grid2"><label class="switch"><input type="checkbox" name="simEnabled" ${s.simulator.enabled ? 'checked' : ''}> Mô phỏng đơn hàng tự động</label><div class="grid2"><label class="field"><span>Từ (giây)</span><input class="input" type="number" name="simMin" value="${s.simulator.minSec}"></label><label class="field"><span>Đến (giây)</span><input class="input" type="number" name="simMax" value="${s.simulator.maxSec}"></label></div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn--soft" type="button" data-sim10>⚡ Tạo nhanh 10 đơn</button><button class="btn btn--ghost" type="button" data-reset>↺ Khôi phục dữ liệu demo</button></div>
      <p class="muted" style="font-size:14px">Dữ liệu demo lưu ngay trong trình duyệt (localStorage). Khi mở trang quản trị, cứ ${s.simulator.minSec}–${s.simulator.maxSec} giây lại có một đơn giả mới. “Khôi phục dữ liệu demo” sẽ xoá mọi thay đổi và tạo lại dữ liệu mẫu.</p></section>
    <div class="span2"><button class="btn btn--primary btn--lg">Lưu cài đặt</button></div>
  </form>`;
  $('[data-sform]').addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.target; const v = (n) => f.elements[n]; const ck = (n) => v(n).checked;
    const body = {
      announcement: v('announcement').value, links: { facebook: v('facebook').value, tiktok: v('tiktok').value, shopee: v('shopee').value }, recentTicker: ck('recentTicker'), liveViewers: ck('liveViewers'),
      shipping: { freeThreshold: v('freeThreshold').value, express: v('express').value, tiers: s.shipping.tiers.map((_, i) => ({ maxKg: v('tierKg' + i).value, fee: v('tierFee' + i).value })) },
      payments: { cod: ck('pay_cod'), vietqr: ck('pay_vietqr'), wallet: ck('pay_wallet'), card: ck('pay_card'), installment: ck('pay_installment'), wallets: Object.keys(WAL).filter((k) => ck('wallet_' + k)), depositPercent: v('depositPercent').value, depositMin: v('depositMin').value, qrMinutes: v('qrMinutes').value },
      vietqr: { bin: v('bin').value, account: v('account').value, accountName: v('accountName').value },
      simulator: { enabled: ck('simEnabled'), minSec: v('simMin').value, maxSec: v('simMax').value },
    };
    try { const r = await api('/api/admin/settings', { method: 'POST', body }); BOOT.settings = r.settings; toast('Đã lưu cài đặt.'); const t = $('[data-sim-toggle]'); if (t) t.checked = r.settings.simulator.enabled; } catch (err) { toast(err.message, { type: 'info' }); }
  });
  $('[data-sim10]').addEventListener('click', async () => { const r = await api('/api/admin/simulate', { method: 'POST', body: { count: 10 } }); toast(`Đã tạo ${r.codes.length} đơn mô phỏng.`); });
  $('[data-reset]').addEventListener('click', async () => { if (!confirm('Khôi phục toàn bộ dữ liệu demo? Mọi thay đổi sẽ mất.')) return; await api('/api/admin/reset', { method: 'POST' }); });
}

// ======================================================================
// NHÂN VIÊN & NHẬT KÝ
// ======================================================================
async function pageStaff() {
  const [s, a] = await Promise.all([api('/api/admin/staff'), api('/api/admin/activity')]);
  content.innerHTML = `<div class="adm-head"><h1>Nhân viên & nhật ký</h1></div><div class="dash">
  <section class="panel"><h2 class="h3">Nhân viên</h2><table class="tbl"><thead><tr><th>Tên</th><th>Email</th><th>Vai trò</th></tr></thead><tbody>${s.items.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.roleLabel)}</td></tr>`).join('')}</tbody></table>
    <form class="stack" data-staff style="margin-top:16px"><h3 style="font-size:20px">Thêm nhân viên</h3><div class="grid2"><input class="input" name="name" placeholder="Họ tên" aria-label="Họ tên"><input class="input" name="email" placeholder="Email" aria-label="Email"><input class="input" name="password" type="password" placeholder="Mật khẩu (≥ 8 ký tự)" aria-label="Mật khẩu"><select class="select" name="role" aria-label="Vai trò">${Object.entries(s.roles).map(([k, r]) => `<option value="${k}">${esc(r.label)}</option>`).join('')}</select></div><p class="err" data-serr></p><button class="btn btn--primary btn--sm">Thêm</button></form>
    <h3 style="font-size:20px;margin-top:20px">Phân quyền</h3>${Object.values(s.roles).map((r) => `<p style="font-size:14px"><b>${esc(r.label)}:</b> ${r.can.includes('*') ? 'toàn quyền' : r.can.join(', ')}</p>`).join('')}</section>
  <section class="panel"><h2 class="h3">Nhật ký hoạt động</h2><ul class="feed" style="max-height:600px" data-feed>${a.items.map((x) => `<li><b>${esc(x.user)}</b> · ${esc(x.action)}<small>${new Date(x.at).toLocaleString('vi-VN')}</small></li>`).join('')}</ul></section></div>`;
  $('[data-staff]').addEventListener('submit', async (e) => { e.preventDefault(); try { await api('/api/admin/staff', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) }); toast('Đã thêm nhân viên.'); pageStaff(); } catch (err) { $('[data-serr]').textContent = err.message; } });
}

// ---------- Khởi động ----------
const PAGES = { 'tong-quan': pageDashboard, 'phan-tich': pageAnalytics, 'don-hang': pageOrders, 'giao-dich': pagePayments, 'san-pham': pageProducts, kho: pageInventory, 'khach-hang': pageCustomers, chat: pageChat, 'ma-giam-gia': pageCoupons, 'flash-sale': pageFlash, 'danh-gia': pageReviews, 'noi-dung': pageContent, 'cai-dat': pageSettings, 'nhan-vien': pageStaff };
if (PAGE && content && !content.querySelector('h1')) {
  api('/api/admin/bootstrap').then((b) => { BOOT = b; $('[data-online]').textContent = b.presence.online; return (PAGES[PAGE] || pageDashboard)(); })
    .catch((err) => { if (err.status === 401) __alk.go('/admin/dang-nhap?next=' + encodeURIComponent(__alk.path())); else content.innerHTML = `<div class="panel"><p class="err">${esc(err.message)}</p></div>`; });
}
