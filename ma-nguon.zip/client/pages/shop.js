// Cửa hàng / danh mục / bộ sưu tập / flash sale / so sánh / yêu thích
import { $, $$, api, fmt, esc, store } from '../lib/core.js';
import * as live from '../lib/live.js';

// ---------- Bộ lọc: tự áp dụng khi thay đổi, đồng bộ URL ----------
const form = $('[data-filters]');
if (form) {
  const apply = () => {
    const fd = new FormData(form);
    const u = new URLSearchParams();
    for (const [k, v] of fd) if (v) u.append(k, v);
    const sort = $('[data-sort]')?.value; if (sort && sort !== 'noi-bat') u.set('sap-xep', sort); else u.delete('sap-xep');
    __alk.go(form.getAttribute('action') + (u.toString() ? '?' + u : '') + '#main');
  };
  form.addEventListener('change', apply);
  $('[data-sort]')?.addEventListener('change', apply);
  const t = $('[data-filter-toggle]');
  t && t.addEventListener('click', () => { const open = !form.classList.contains('is-open'); form.classList.toggle('is-open', open); t.setAttribute('aria-expanded', String(open)); });
}

// ---------- Flash sale: đếm ngược + realtime ----------
$$('[data-flash-end]').forEach((el) => {
  const end = Number(el.dataset.flashEnd);
  const tick = () => { const ms = end - Date.now(); if (ms <= 0) { el.textContent = 'Đã kết thúc'; return; } const h = Math.floor(ms / 36e5), m = Math.floor((ms % 36e5) / 6e4), s = Math.floor((ms % 6e4) / 1000); el.textContent = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };
  tick(); setInterval(tick, 1000);
});
live.on('flashsale.updated', () => { if (__alk.path() === '/flash-sale') location.reload(); });
live.on('stock.changed', async (d) => {
  const box = $(`[data-flash-item="${d.productId}"]`);
  if (!box) return;
  const r = await api('/api/flash'); const it = r.active?.items.find((x) => x.productId === d.productId);
  if (!it) return;
  box.querySelector('i').style.width = Math.round((it.sold / it.quota) * 100) + '%';
  box.querySelector('small').textContent = `Đã bán ${it.sold}/${it.quota} · còn ${it.quota - it.sold} suất`;
});

// ---------- So sánh ----------
const cmp = $('[data-compare-table]');
if (cmp) {
  const render = async () => {
    const ids = store.get('compare', []);
    if (!ids.length) { cmp.innerHTML = '<div class="empty"><p>Chưa có sản phẩm nào để so sánh.</p><a class="btn btn--primary btn--sm" href="/cua-hang">Chọn sản phẩm</a></div>'; return; }
    const items = (await Promise.all(ids.map((id) => api('/api/products/' + id).catch(() => null)))).filter(Boolean);
    const full = await Promise.all(items.map((p) => fetch('/san-pham/' + p.slug).then((r) => r.text()).then((h) => {
      const doc = new DOMParser().parseFromString(h, 'text/html');
      return { ...p, specs: [...doc.querySelectorAll('.specs tr')].map((tr) => [tr.querySelector('th').textContent, tr.querySelector('td').textContent]) };
    })));
    const keys = [...new Set(full.flatMap((p) => p.specs.map((s) => s[0])))];
    const onlyDiff = $('[data-only-diff]').checked;
    const rows = keys.map((k) => {
      const vals = full.map((p) => (p.specs.find((s) => s[0] === k) || [, '—'])[1]);
      const diff = new Set(vals).size > 1;
      if (onlyDiff && !diff) return '';
      return `<tr class="${diff ? 'is-diff' : ''}"><th scope="row">${esc(k)}</th>${vals.map((v) => `<td>${esc(v)}</td>`).join('')}</tr>`;
    }).join('');
    cmp.innerHTML = `<table><thead><tr><th></th>${full.map((p) => `<td><img src="${esc(p.image)}" alt="" width="140" height="140"><a href="/san-pham/${esc(p.slug)}"><b>${esc(p.name)}</b></a><div class="price">${fmt(p.flash ? p.flash.price : p.price)}</div><button class="copy-btn" type="button" data-compare="${esc(p.id)}" style="margin-top:8px">Bỏ khỏi so sánh</button> <button class="copy-btn" type="button" data-add="${esc(p.id)}" data-finish="${esc(p.finishes[0])}" data-name="${esc(p.name)}">Thêm vào giỏ</button></td>`).join('')}</tr></thead>
      <tbody><tr><th scope="row">Đánh giá</th>${full.map((p) => `<td>${p.rating ? String(p.rating).replace('.', ',') + ' ★ (' + p.reviewCount + ')' : '—'}</td>`).join('')}</tr>${rows}</tbody></table>`;
  };
  render();
  $('[data-only-diff]').addEventListener('change', render);
  live.on('compare.changed', render);
}

// ---------- Yêu thích ----------
const wg = $('[data-wish-grid]');
if (wg) {
  const render = async () => {
    const ids = store.get('wish', []);
    if (!ids.length) { wg.innerHTML = '<div class="empty panel" style="grid-column:1/-1"><p>Danh sách yêu thích đang trống.</p><a class="btn btn--primary btn--sm" href="/cua-hang">Khám phá sản phẩm</a></div>'; return; }
    const { items } = await api('/api/products');
    wg.innerHTML = ids.map((id) => items.find((p) => p.id === id)).filter(Boolean).map((p) => `
      <article class="pcard"><a class="pcard__media" href="/san-pham/${esc(p.slug)}" tabindex="-1" aria-hidden="true"><img src="${esc(p.image)}" alt="" width="600" height="600" loading="lazy"></a>
      <button class="icon-btn pcard__wish" type="button" data-wish="${esc(p.id)}" aria-pressed="true" aria-label="Bỏ yêu thích ${esc(p.name)}"><svg class="ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M12 20s-7-4.4-9.2-8.6C1.2 8.3 3 4.8 6.5 4.5c2-.2 3.6.9 4.5 2.4.9-1.5 2.5-2.6 4.5-2.4 3.5.3 5.3 3.8 3.7 6.9C19 15.6 12 20 12 20Z"/></svg></button>
      <div class="pcard__body"><a class="pcard__name" href="/san-pham/${esc(p.slug)}">${esc(p.name)}</a><p class="pcard__sub">${esc(p.tagline)}</p><div class="pcard__foot"><span class="price">${fmt(p.price)}</span></div>
      <button class="btn btn--soft btn--sm pcard__add" type="button" data-add="${esc(p.id)}" data-finish="${esc(p.finishes[0])}" data-name="${esc(p.name)}">Thêm vào giỏ</button></div></article>`).join('');
  };
  render();
  live.on('wish.changed', render);
}
