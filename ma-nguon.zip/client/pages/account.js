// Đăng nhập / đăng ký / tài khoản
import { $, $$, api, store, toast } from '../lib/core.js';
import * as live from '../lib/live.js';

const STATUS = { pending: 'Chờ xác nhận', confirmed: 'Đã xác nhận', packing: 'Đang đóng gói', shipping: 'Đang giao', completed: 'Hoàn thành', cancelled: 'Đã huỷ', returned: 'Hoàn trả' };
const af = $('[data-auth]');
if (af) {
  af.addEventListener('submit', async (e) => {
    e.preventDefault();
    const mode = af.dataset.auth;
    const fd = Object.fromEntries(new FormData(af));
    $$('[data-err]', af).forEach((x) => (x.textContent = ''));
    $('[data-form-err]').textContent = '';
    try {
      if (mode === 'forgot') { $('[data-form-err]').style.color = 'var(--success)'; $('[data-form-err]').textContent = 'Nếu email tồn tại, Alokio đã gửi liên kết đặt lại mật khẩu.'; return; }
      const r = await api(`/api/account/${mode === 'login' ? 'login' : 'register'}`, { method: 'POST', body: { ...fd, wishlist: store.get('wish', []) } });
      if (r.wishlist && r.wishlist.length) { const merged = [...new Set([...store.get('wish', []), ...r.wishlist])]; store.set('wish', merged); }
      __alk.go(af.dataset.next || '/tai-khoan');
    } catch (err) {
      $('[data-form-err]').textContent = err.message;
      if (err.data?.fields) for (const [k, v] of Object.entries(err.data.fields)) { const el = af.querySelector(`[data-err="${k}"]`); if (el) el.textContent = v; }
    }
  });
  // Nút "Dùng tài khoản demo": điền sẵn email/mật khẩu rồi đăng nhập
  $$('[data-demo]', af).forEach((b) => b.addEventListener('click', () => { const [em, pw] = b.dataset.demo.split('|'); af.email.value = em; af.password.value = pw; af.requestSubmit(); }));
}
document.addEventListener('click', async (e) => {
  if (e.target.closest('[data-logout]')) { e.preventDefault(); await api('/api/account/logout', { method: 'POST' }); __alk.go('/'); }
  const c = e.target.closest('[data-cancel-order]');
  if (c) {
    if (!confirm('Bạn chắc chắn muốn huỷ đơn hàng này?')) return;
    try { await api(`/api/account/orders/${c.dataset.cancelOrder}/cancel`, { method: 'POST' }); toast('Đã huỷ đơn hàng.'); setTimeout(() => location.reload(), 800); } catch (err) { toast(err.message, { type: 'info' }); }
  }
});
const pf = $('[data-profile]');
pf && pf.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(pf));
  try { await api('/api/account/profile', { method: 'POST', body: { address: fd } }); $('[data-profile-msg]').textContent = 'Đã lưu địa chỉ.'; } catch (err) { $('[data-profile-msg]').textContent = err.message; }
});
const pw = $('[data-password]');
pw && pw.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(pw));
  $$('[data-err]', pw).forEach((x) => (x.textContent = ''));
  try { await api('/api/account/profile', { method: 'POST', body: fd }); $('[data-pw-msg]').textContent = 'Đã lưu thay đổi.'; pw.oldPassword.value = pw.newPassword.value = ''; }
  catch (err) { $('[data-pw-msg]').textContent = err.message; if (err.data?.fields) for (const [k, v] of Object.entries(err.data.fields)) { const el = pw.querySelector(`[data-err="${k}"]`); if (el) el.textContent = v; } }
});
// Trạng thái đơn cập nhật realtime trong bảng
live.on('order.updated', (d) => {
  const row = $(`[data-my-orders] tr[data-code="${d.order.code}"]`);
  if (!row) return;
  const st = row.querySelector('[data-st]');
  st.className = `st st--${d.order.status}`; st.textContent = STATUS[d.order.status];
  row.animate([{ background: '#FFF6DE' }, { background: 'transparent' }], { duration: 1600 });
  toast(`Đơn ${d.order.code}: ${STATUS[d.order.status]}`, { type: 'info' });
});
