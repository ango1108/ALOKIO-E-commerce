// Cổng thanh toán sandbox (mở trên điện thoại sau khi quét QR)
const box = document.querySelector('[data-sandbox]');
if (box) {
  const id = box.dataset.id, sig = box.dataset.sig;
  const state = box.querySelector('[data-sb-state]');
  const actions = box.querySelector('[data-sb-actions]');
  const show = (s, text) => { state.innerHTML = `<p class="pay-status" data-s="${s}">${text}</p>`; };
  fetch(`/api/pay/${id}/scan`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sig }) }).then((r) => r.json()).then((p) => {
    if (p.status === 'paid') { show('paid', 'Đơn này đã được thanh toán'); actions.hidden = true; }
    if (p.status === 'expired') { show('expired', 'Mã QR đã hết hạn'); actions.hidden = true; }
  }).catch(() => {});
  actions.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-sb]'); if (!b) return;
    actions.querySelectorAll('button').forEach((x) => (x.disabled = true));
    b.textContent = 'Đang xử lý…';
    const r = await fetch(`/api/pay/${id}/confirm`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sig, action: b.dataset.sb }) });
    const d = await r.json();
    if (!r.ok) { show('failed', d.error || 'Có lỗi xảy ra'); actions.hidden = true; return; }
    actions.hidden = true;
    if (d.status === 'paid') {
      state.innerHTML = `<svg viewBox="0 0 100 100" width="120" height="120" style="margin:20px auto" aria-hidden="true"><circle cx="50" cy="50" r="44" fill="#E3F4EC"/><path d="M30 52l13 13 27-29" fill="none" stroke="#1F7A55" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="pay-status" data-s="paid">Thanh toán thành công</p><p class="muted">Màn hình trên máy tính đã tự cập nhật. Bạn có thể đóng trang này.</p>`;
      navigator.vibrate && navigator.vibrate([60, 40, 60]);
    } else show('failed', 'Bạn đã từ chối thanh toán');
  });
}
