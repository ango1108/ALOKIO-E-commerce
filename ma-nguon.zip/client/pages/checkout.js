// Thanh toán 3 bước: thông tin → vận chuyển → thanh toán. Lưu tạm vào sessionStorage để F5 không mất dữ liệu.
import { $, $$, api, fmt, esc, store, toast } from '../lib/core.js';
import * as cart from '../lib/cart.js';

const form = $('[data-checkout]');
const KEY = 'alokio:checkout';
let coupon = store.get('coupon', '');
let last = null;
let wards = {};

// Khôi phục dữ liệu đã nhập
try {
  const saved = JSON.parse(sessionStorage.getItem(KEY) || '{}');
  for (const [k, v] of Object.entries(saved)) {
    const el = form.elements[k];
    if (!el || (el.value && el.type !== 'radio' && el.type !== 'checkbox')) continue;
    if (el instanceof RadioNodeList) { [...el].forEach((r) => (r.checked = r.value === v)); } else if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
  }
} catch { /* noop */ }
form.addEventListener('input', persist); form.addEventListener('change', persist);
function persist() {
  const o = {};
  for (const el of form.elements) { if (!el.name) continue; if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; } else if (el.type === 'checkbox') o[el.name] = el.checked; else o[el.name] = el.value; }
  try { sessionStorage.setItem(KEY, JSON.stringify(o)); } catch { /* noop */ }
}

// Phường/xã gợi ý theo tỉnh
api('/api/places').then((d) => { wards = d.wards; fillWards(); });
function fillWards() { const list = wards[form.province.value] || []; $('#ward-list').innerHTML = list.map((w) => `<option value="${esc(w)}">`).join(''); }
form.province.addEventListener('change', () => { fillWards(); refresh(); });

// ---------- Bước ----------
const steps = $$('[data-step]');
function go(n) {
  steps.forEach((s) => (s.hidden = s.dataset.step !== String(n)));
  $$('[data-step-i]').forEach((li) => { const i = Number(li.dataset.stepI); li.toggleAttribute('aria-current', i === n); if (i === n) li.setAttribute('aria-current', 'step'); li.classList.toggle('is-done', i < n); });
  const sec = $(`[data-step="${n}"]`);
  sec.querySelector('h2').setAttribute('tabindex', '-1'); sec.querySelector('h2').focus();
  window.scrollTo({ top: form.getBoundingClientRect().top + scrollY - 120, behavior: 'smooth' });
}
const showErr = (fields) => {
  $$('[data-err]', form).forEach((e) => { e.textContent = fields[e.dataset.err] || ''; const inp = form.elements[e.dataset.err]; if (inp && inp.setAttribute) { if (fields[e.dataset.err]) inp.setAttribute('aria-invalid', 'true'); else inp.removeAttribute('aria-invalid'); } });
  const first = Object.keys(fields)[0]; const el = first && form.elements[first]; if (el && el.focus) el.focus();
};
function validate1() {
  const f = {};
  if (form.name.value.trim().length < 2) f.name = 'Vui lòng nhập họ tên người nhận.';
  if (!/^0\d{9}$/.test(form.phone.value.replace(/\s/g, ''))) f.phone = 'Số điện thoại gồm 10 số, bắt đầu bằng 0.';
  if (form.email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.value)) f.email = 'Email chưa đúng định dạng.';
  if (!form.province.value) f.province = 'Chọn tỉnh/thành phố.';
  if (form.ward.value.trim().length < 2) f.ward = 'Nhập phường/xã/đặc khu.';
  if (form.street.value.trim().length < 4) f.street = 'Nhập số nhà, tên đường.';
  showErr(f); return !Object.keys(f).length;
}
$$('[data-next]').forEach((b) => b.addEventListener('click', () => { const n = Number(b.dataset.next); if (n === 2 && !validate1()) return; go(n); }));
$$('[data-prev]').forEach((b) => b.addEventListener('click', () => go(Number(b.dataset.prev))));

// ---------- Tóm tắt ----------
async function refresh() {
  const method = form.method?.value;
  const deposit = method === 'cod' && form.deposit?.checked;
  last = await cart.price({ coupon, shipping: form.shipping.value, deposit });
  if (!last.lines.length) { $('[data-co-lines]').innerHTML = '<p>Giỏ hàng trống. <a href="/cua-hang">Mua sắm ngay</a></p>'; $('[data-place]').disabled = true; return; }
  $('[data-co-lines]').innerHTML = cart.renderLines(last, { editable: false });
  $('[data-co-totals]').innerHTML = `
    <div class="row"><span>Tạm tính</span><span>${fmt(last.subtotal)}</span></div>
    ${last.discount ? `<div class="row"><span>Giảm giá (${esc(last.coupon)})</span><span>−${fmt(last.discount)}</span></div>` : ''}
    <div class="row"><span>Vận chuyển</span><span>${last.shipping ? fmt(last.shipping) : 'Miễn phí'}</span></div>
    <div class="row row--total"><span>Tổng cộng</span><span>${fmt(last.total)}</span></div>
    ${deposit ? `<div class="row"><span>Đặt cọc hôm nay</span><b>${fmt(last.depositAmount)}</b></div>` : ''}
    ${last.errors.length ? `<p class="err">${last.errors.map(esc).join('<br>')}</p>` : ''}`;
  const dw = $('[data-deposit-wrap]'); if (dw) dw.hidden = last.total < last.depositMin;
  $$('[data-inst]').forEach((el) => { const m = Number(el.dataset.inst); el.textContent = fmt(Math.ceil(last.total / m / 1000) * 1000); });
  const cm = $('[data-co-coupon] .form-msg');
  if (last.coupon) { cm.textContent = `Đã áp dụng ${last.coupon}`; cm.classList.remove('is-err'); $('#co-coupon').value = last.coupon; }
  else if (coupon && last.couponError) { cm.textContent = last.couponError; cm.classList.add('is-err'); }
  $('[data-place]').textContent = method === 'cod' ? (deposit ? `Đặt hàng & cọc ${fmt(last.depositAmount)}` : 'Đặt hàng (COD)') : method === 'card' || method === 'installment' ? 'Tiếp tục tới cổng thẻ' : `Đặt hàng & tạo mã QR`;
}
form.addEventListener('change', (e) => { if (['shipping', 'method', 'deposit', 'installment'].includes(e.target.name)) refresh(); });
$('[data-co-coupon] button').addEventListener('click', async () => {
  const code = $('#co-coupon').value.trim().toUpperCase();
  const cm = $('[data-co-coupon] .form-msg');
  if (!code) { coupon = ''; store.set('coupon', ''); refresh(); return; }
  try { await api('/api/coupon', { method: 'POST', body: { code, items: cart.items() } }); coupon = code; store.set('coupon', code); refresh(); }
  catch (err) { cm.textContent = err.message; cm.classList.add('is-err'); }
});

// ---------- Đặt hàng ----------
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!validate1()) { go(1); return; }
  const btn = $('[data-place]');
  const errBox = $('[data-form-err]');
  btn.disabled = true; const label = btn.textContent; btn.textContent = 'Đang xử lý…'; errBox.textContent = '';
  const fd = new FormData(form);
  try {
    const r = await api('/api/orders', { method: 'POST', body: {
      items: cart.items(), name: fd.get('name'), phone: fd.get('phone'), email: fd.get('email'), province: fd.get('province'), ward: fd.get('ward'), street: fd.get('street'), note: fd.get('note'),
      shipping: fd.get('shipping'), method: fd.get('method'), wallet: fd.get('wallet'), installment: fd.get('method') === 'installment' ? fd.get('installment') : null, deposit: fd.get('method') === 'cod' && !!fd.get('deposit'), coupon,
    } });
    cart.clear(); store.set('coupon', ''); sessionStorage.removeItem(KEY);
    __alk.go(r.next);
  } catch (err) {
    btn.disabled = false; btn.textContent = label;
    errBox.textContent = err.message;
    if (err.data?.fields) { showErr(err.data.fields); if (['name', 'phone', 'province', 'ward', 'street', 'email'].some((k) => err.data.fields[k])) go(1); }
    toast(err.message, { type: 'info' });
  }
});
refresh();
