// Trang giỏ hàng
import { $, api, fmt, esc, store } from '../lib/core.js';
import * as cart from '../lib/cart.js';

const linesBox = $('[data-cart-lines]');
let coupon = store.get('coupon', '');

async function render() {
  const p = await cart.price({ coupon });
  linesBox.innerHTML = cart.renderLines(p);
  $('[data-cart-freeship]').innerHTML = cart.freeShipHTML(p, p.freeThreshold);
  const msg = $('[data-coupon] .form-msg');
  if (coupon && p.couponError) { msg.textContent = p.couponError; msg.classList.add('is-err'); }
  else if (p.coupon) { msg.textContent = `Đã áp dụng ${p.coupon}: −${fmt(p.discount)}`; msg.classList.remove('is-err'); $('#coupon').value = p.coupon; }
  $('[data-cart-totals]').innerHTML = p.lines.length ? `
    <div class="row"><span>Tạm tính</span><span>${fmt(p.subtotal)}</span></div>
    ${p.discount ? `<div class="row"><span>Giảm giá (${esc(p.coupon)})</span><span>−${fmt(p.discount)}</span></div>` : ''}
    <div class="row"><span>Vận chuyển (ước tính)</span><span>${p.shipping ? fmt(p.shipping) : 'Miễn phí'}</span></div>
    <div class="row row--total"><span>Tổng cộng</span><span>${fmt(p.total)}</span></div>
    ${p.errors.length ? `<p class="err">${p.errors.map(esc).join('<br>')}</p>` : ''}` : '';
  const btn = $('[data-to-checkout]');
  btn.toggleAttribute('aria-disabled', !p.lines.length);
  btn.style.pointerEvents = p.lines.length ? '' : 'none';
  btn.style.opacity = p.lines.length ? '' : '.5';
  // Gợi ý phụ kiện theo dòng sản phẩm trong giỏ
  if (p.lines.length) {
    const { items } = await api('/api/products');
    const inCart = new Set(p.lines.map((l) => l.productId));
    const lines = new Set(p.lines.map((l) => l.line));
    const sug = items.filter((x) => x.category === 'phu-kien' && lines.has(x.line) && !inCart.has(x.id)).slice(0, 4);
    $('[data-cart-suggest]').hidden = !sug.length;
    $('[data-suggest-grid]').innerHTML = sug.map((x) => `<article class="pcard" style="min-width:220px"><a class="pcard__media" href="/san-pham/${esc(x.slug)}"><img src="${esc(x.image)}" alt="" loading="lazy" width="300" height="300"></a><div class="pcard__body"><span class="pcard__name" style="font-size:18px">${esc(x.name)}</span><span class="price">${fmt(x.price)}</span><button class="btn btn--soft btn--sm pcard__add" type="button" data-add="${esc(x.id)}" data-finish="${esc(x.finishes[0])}" data-name="${esc(x.name)}">Thêm</button></div></article>`).join('');
  } else $('[data-cart-suggest]').hidden = true;
}
cart.bindLineControls(linesBox, render);
cart.onChange(render);
$('[data-coupon]').addEventListener('submit', async (e) => {
  e.preventDefault();
  const code = $('#coupon').value.trim().toUpperCase();
  const msg = $('[data-coupon] .form-msg');
  if (!code) { coupon = ''; store.set('coupon', ''); msg.textContent = ''; render(); return; }
  try { await api('/api/coupon', { method: 'POST', body: { code, items: cart.items() } }); coupon = code; store.set('coupon', code); render(); }
  catch (err) { msg.textContent = err.message; msg.classList.add('is-err'); }
});
render();
