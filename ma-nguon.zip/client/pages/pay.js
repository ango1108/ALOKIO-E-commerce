// Màn hình chờ thanh toán: QR động (VietQR / ví điện tử), đếm ngược, realtime khi điện thoại xác nhận; cổng thẻ + OTP.
import { $, $$, api, fmt, esc, toast } from '../lib/core.js';
import * as live from '../lib/live.js';
import qrcode from '../../vendor/qrcode.js';

const box = $('[data-pay]');
let payId = box?.dataset.payId;
const code = box?.dataset.code;
const method = box?.dataset.method;
let expiresAt = 0;
let timer = 0;
const LABEL = { pending: 'Chờ quét mã', scanned: 'Đã quét – chờ xác nhận', paid: 'Đã thanh toán', failed: 'Thanh toán thất bại', expired: 'Mã đã hết hạn', cancelled: 'Đã thay mã mới' };

function qrSVG(text) {
  const q = qrcode(0, 'M');
  q.addData(text); q.make();
  const n = q.getModuleCount();
  let path = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) path += `M${c + 4},${r + 4}h1v1h-1z`;
  return `<svg viewBox="0 0 ${n + 8} ${n + 8}" role="img" aria-label="Mã QR thanh toán" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${path}" fill="#0F1E33"/></svg>`;
}

async function loadQR() {
  const d = await api(`/api/pay/${payId}/qr`);
  expiresAt = d.expiresAt;
  // Ví điện tử: QR chứa URL sandbox (quét bằng camera điện thoại). VietQR: chuỗi EMVCo chuẩn NAPAS + link sandbox để mô phỏng.
  $('[data-qr]').innerHTML = qrSVG(method === 'wallet' ? d.sandboxUrl : d.vietqr || d.sandboxUrl);
  $('[data-sim]').href = d.sandboxUrl;
  const app = $('[data-app]'); if (app) app.href = d.sandboxUrl;
  if (d.lan) $('[data-lan-hint]').innerHTML = `Điện thoại cùng Wi-Fi có thể quét mã ngay (máy chủ: <code>${esc(d.lan)}</code>).${method !== 'wallet' ? ' Mã VietQR chuẩn NAPAS; bấm “Mô phỏng quét mã” để xác nhận trong sandbox.' : ''}`;
  else if (method !== 'wallet') $('[data-lan-hint]').innerHTML = 'Mã VietQR chuẩn NAPAS (số tài khoản demo). Bấm “Mô phỏng quét mã” để xác nhận trong sandbox.';
  const bank = $('[data-bank]');
  if (bank) bank.innerHTML = `<dt>Ngân hàng</dt><dd>${esc(d.bank.bankName)} (BIN ${esc(d.bank.bin)})</dd><dd></dd>
    <dt>Số tài khoản</dt><dd>${esc(d.bank.account)}</dd><dd><button class="copy-btn" type="button" data-copy="${esc(d.bank.account)}">Sao chép</button></dd>
    <dt>Chủ tài khoản</dt><dd>${esc(d.bank.accountName)}</dd><dd></dd>
    <dt>Nội dung</dt><dd>ALOKIO ${esc(code)}</dd><dd><button class="copy-btn" type="button" data-copy="ALOKIO ${esc(code)}">Sao chép</button></dd>`;
  setStatus(d.status);
  clearInterval(timer); timer = setInterval(tick, 1000); tick();
}
function tick() {
  const ms = expiresAt - Date.now();
  const el = $('[data-countdown]');
  if (ms <= 0) { el.textContent = '00:00'; setStatus('expired'); clearInterval(timer); return; }
  el.textContent = `${String(Math.floor(ms / 60000)).padStart(2, '0')}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}`;
}
function setStatus(s) {
  const el = $('[data-pay-status]'); if (!el) return;
  el.dataset.s = s; el.textContent = LABEL[s] || s;
  const card = $('[data-qr-card]');
  card.classList.toggle('is-expired', s === 'expired' || s === 'failed');
  card.classList.toggle('is-paid', s === 'paid');
  $('[data-renew]').hidden = !(s === 'expired' || s === 'failed');
  if (s === 'paid') {
    clearInterval(timer);
    $('[data-qr]').innerHTML = `<svg viewBox="0 0 100 100" width="200" height="200" aria-hidden="true"><circle cx="50" cy="50" r="44" fill="#E3F4EC"/><path d="M30 52l13 13 27-29" fill="none" stroke="#1F7A55" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    toast('Thanh toán thành công! Đang chuyển trang…');
    setTimeout(() => __alk.go(`/dat-hang-thanh-cong/${code}`), 1600);
  }
  if (s === 'scanned') toast('Điện thoại đã quét mã — chờ xác nhận…', { type: 'info' });
}

if (payId && (method === 'wallet' || method === 'vietqr' || method === 'deposit')) {
  loadQR();
  live.on('payment.updated', (p) => { if (p.id === payId) setStatus(p.status); });
  // Phòng khi SSE bị chặn: hỏi lại mỗi 4 giây
  setInterval(async () => { try { const p = await api('/api/pay/' + payId); if (p.status !== $('[data-pay-status]').dataset.s) setStatus(p.status); } catch { /* noop */ } }, 4000);
  $('[data-renew]').addEventListener('click', async () => { const p = await api(`/api/pay/${payId}/renew`, { method: 'POST' }); payId = p.id; box.dataset.payId = p.id; $('[data-qr-card]').classList.remove('is-expired'); loadQR(); });
  document.addEventListener('click', (e) => { const c = e.target.closest('[data-copy]'); if (c) { navigator.clipboard?.writeText(c.dataset.copy); c.textContent = 'Đã chép'; setTimeout(() => (c.textContent = 'Sao chép'), 1500); } });
}

// ---------- Cổng thẻ (sandbox) ----------
const cf = $('[data-card-form]');
if (cf) {
  const num = cf.number;
  num.addEventListener('input', () => { num.value = num.value.replace(/\D/g, '').slice(0, 19).replace(/(\d{4})(?=\d)/g, '$1 '); });
  cf.exp.addEventListener('input', () => { let v = cf.exp.value.replace(/\D/g, '').slice(0, 4); if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2); cf.exp.value = v; });
  let step = 'card';
  cf.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('[data-card-submit]'); const err = $('[data-card-err]');
    $$('[data-err]', cf).forEach((x) => (x.textContent = '')); err.textContent = '';
    btn.disabled = true;
    try {
      const r = await api(`/api/pay/${payId}/card`, { method: 'POST', body: { number: num.value, exp: cf.exp.value, cvc: cf.cvc.value, holder: cf.holder.value, otp: cf.otp.value, step } });
      if (r.otpRequired) { step = 'otp'; $('[data-otp]').hidden = false; cf.otp.focus(); btn.textContent = `Xác nhận OTP · ${r.brand} •••• ${r.last4}`; }
      else if (r.status === 'paid') { btn.textContent = 'Thành công!'; toast('Thanh toán thẻ thành công!'); setTimeout(() => __alk.go(`/dat-hang-thanh-cong/${code}`), 1200); return; }
    } catch (ex) {
      err.textContent = ex.message;
      if (ex.data?.fields) for (const [k, v] of Object.entries(ex.data.fields)) { const el = cf.querySelector(`[data-err="${k}"]`); if (el) el.textContent = v; }
      if (ex.data?.status === 'failed') { step = 'card'; $('[data-otp]').hidden = true; btn.textContent = 'Thử thẻ khác'; }
    }
    btn.disabled = false;
  });
}
