// =====================================================================
// Hiệu ứng "vẩy sơn" kiểu tranh trừu tượng (pouring / drip painting) cho nền website.
// Mỗi mảng tranh gồm:
//   · mảng màu loang lốm đốm (texture sinh bằng feTurbulence, giống lớp acrylic khô)
//   · những sợi sơn mảnh chảy dài, dày mỏng thất thường như sơn thật được vẩy từ cọ
//   · vệt sơn kem/trắng viền mảnh, giọt sơn và hạt nhũ vàng champagne
// Nền trắng → tông xanh pastel + nhũ vàng; nền navy (.dark-band, .karaoke) → sơn trắng + vàng.
// Tranh được vẽ thành ảnh SVG (seed theo từng trang: mở lại vẫn giống hệt) và "loang" ra khi cuộn tới.
// =====================================================================

function rng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const hashStr = (s) => { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };
const f = (n) => Math.round(n * 10) / 10;
const pick = (R, arr) => arr[Math.floor(R() * arr.length)];

const PALETTE = {
  light: {
    wash: ['#C9DDF3', '#B3CFEE', '#DCE9F7'], wash2: ['#8FB5E0', '#9EC0E6'], ochre: '#E8D6B0',
    lines: [['#24395A', 0.9], ['#5F8FC9', 0.85], ['#7EA7D8', 0.8], ['gold', 0.95], ['#FFFFFF', 0.95]],
    cream: '#FFFDF7', rim: '#2A3E5E', dot: '#5F8FC9',
  },
  dark: {
    wash: ['#3A5478', '#2E4566', '#4A6488'], wash2: ['#6E8DB5', '#5C7CA5'], ochre: '#8A7650',
    lines: [['#FFFFFF', 0.85], ['#CFE2F6', 0.7], ['gold', 0.9], ['#9DBCE0', 0.6]],
    cream: '#FFFFFF', rim: '#C9B48A', dot: '#FFFFFF',
  },
};

// Đa giác bao quanh một đường có độ dày thay đổi
function ribbonPath(pts, widths) {
  const L = [], Rr = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
    const ang = Math.atan2(b[1] - a[1], b[0] - a[0]) + Math.PI / 2;
    const w = widths[i] / 2;
    L.push([pts[i][0] + Math.cos(ang) * w, pts[i][1] + Math.sin(ang) * w]);
    Rr.push([pts[i][0] - Math.cos(ang) * w, pts[i][1] - Math.sin(ang) * w]);
  }
  const all = L.concat(Rr.reverse());
  return 'M' + all.map((p) => `${f(p[0])},${f(p[1])}`).join('L') + 'Z';
}

// Đường đi của dòng sơn: bước ngẫu nhiên có quán tính, thỉnh thoảng uốn vòng như sợi sơn rơi
function walk(R, x, y, a, n, step, { loop = 0.012, wiggle = 0.1 } = {}) {
  const pts = [[x, y]];
  let c = 0;
  for (let i = 0; i < n; i++) {
    c += (R() - 0.5) * wiggle; c *= 0.94;
    if (R() < loop) c += (R() < 0.5 ? -1 : 1) * (0.25 + R() * 0.35);
    a += c; x += Math.cos(a) * step; y += Math.sin(a) * step;
    pts.push([x, y]);
  }
  return pts;
}

// Độ dày dọc sợi sơn: thuôn hai đầu + những chỗ sơn đọng lại phình to
function pourWidths(R, n, base) {
  const bumps = Array.from({ length: 1 + Math.floor(R() * 4) }, () => ({ at: R(), amp: 0.8 + R() * 2.6, sp: 0.01 + R() * 0.04 }));
  return Array.from({ length: n }, (_, i) => {
    const t = i / (n - 1);
    let w = base * (0.25 + 0.75 * Math.pow(Math.sin(Math.PI * t), 0.35)) * (0.75 + 0.5 * Math.sin(t * 17 + base));
    for (const b of bumps) w += base * b.amp * Math.exp(-(((t - b.at) / b.sp) ** 2));
    return Math.max(0.25, w);
  });
}

function painting(R, W, H, dark, side, id, style = 'mixed') {
  // 'ribbon' (lề trái): nhiều vệt kem viền mảnh, sợi vàng & navy, mảng loang ấm · 'wash' (lề phải): mảng loang xanh lớn, sợi xanh mảnh
  const P = dark ? PALETTE.dark : PALETTE.light;
  const outer = side === 'right' ? W : 0;
  const dir = side === 'right' ? -1 : 1; // hướng từ mép vào trong
  const gold = `url(#gd${id})`;
  const col = (c) => (c === 'gold' ? gold : c);
  let svg = '';

  // 1) Mảng màu loang lốm đốm (2–3 lớp)
  const washes = style === 'wash' ? 3 + Math.floor(R() * 2) : 2 + Math.floor(R() * 2);
  for (let i = 0; i < washes; i++) {
    const cx = outer + dir * (W * (0.06 + R() * 0.3)), cy = H * (0.15 + R() * 0.7);
    const rx = W * (0.3 + R() * 0.35), ry = H * (0.14 + R() * 0.22);
    const color = i === 0 ? pick(R, P.wash) : R() < (style === 'ribbon' ? 0.55 : 0.2) ? P.ochre : pick(R, P.wash2);
    svg += `<ellipse cx="${f(cx)}" cy="${f(cy)}" rx="${f(rx)}" ry="${f(ry)}" transform="rotate(${f((R() - 0.5) * 50)} ${f(cx)} ${f(cy)})" fill="url(#soft${id}-${i})" filter="url(#mot${id}-${i % 2})" opacity="${dark ? 0.55 : 0.9}"/>`;
    defsExtra.push(`<radialGradient id="soft${id}-${i}"><stop offset="0" stop-color="${color}"/><stop offset=".65" stop-color="${color}" stop-opacity=".85"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></radialGradient>`);
  }

  // 2) Vệt sơn kem viền mảnh (giống sơn trắng đổ đọng)
  const ribs = style === 'ribbon' ? 4 + Math.floor(R() * 3) : 1 + Math.floor(R() * 2);
  for (let i = 0; i < ribs; i++) {
    const n = 18 + Math.floor(R() * 26);
    const pts = walk(R, outer + dir * W * (0.1 + R() * 0.45), H * (0.1 + R() * 0.8), dir > 0 ? (R() - 0.5) * 1.2 : Math.PI + (R() - 0.5) * 1.2, n, 4 + R() * 3, { loop: 0.01, wiggle: 0.08 });
    const Wm = 5 + R() * 14;
    const ws = pts.map((_, k) => { const t = k / n; return Math.max(0.6, Wm * Math.pow(Math.sin(Math.PI * t), 0.8) * (0.7 + 0.6 * Math.abs(Math.sin(t * 9 + i)))); });
    svg += `<path d="${ribbonPath(pts, ws)}" fill="${P.cream}" stroke="${P.rim}" stroke-width="${f(0.6 + R() * 0.8)}" stroke-linejoin="round" opacity=".95"/>`;
    if (R() < 0.6) svg += `<path d="${ribbonPath(pts.slice(3, -3), ws.slice(3, -3).map((w) => w * 0.25))}" fill="${pick(R, P.wash2)}" opacity=".35"/>`;
  }

  // 3) Sợi sơn vẩy (dày mỏng, đọng giọt)
  const pours = 9 + Math.floor(R() * 9);
  for (let i = 0; i < pours; i++) {
    const [c, op] = style === 'ribbon' && R() < 0.45 ? pick(R, [P.lines[0], ['gold', 0.95]]) : style === 'wash' && R() < 0.5 ? pick(R, P.lines.slice(1, 3)) : pick(R, P.lines);
    const thin = R() < 0.45;
    const n = 60 + Math.floor(R() * 160);
    const pts = walk(R, outer + dir * W * R() * 0.3, H * R(), (dir > 0 ? 0 : Math.PI) + (R() - 0.5) * 2.2, n, 3.2 + R() * 2.5, { loop: thin ? 0.02 : 0.01, wiggle: thin ? 0.16 : 0.09 });
    if (thin) svg += `<path d="M${pts.map((p) => `${f(p[0])},${f(p[1])}`).join('L')}" fill="none" stroke="${col(c)}" stroke-width="${f(0.5 + R() * 0.7)}" stroke-linecap="round" stroke-linejoin="round" opacity="${op}"/>`;
    else svg += `<path d="${ribbonPath(pts, pourWidths(R, pts.length, 0.8 + R() * 1.8))}" fill="${col(c)}" opacity="${op}"/>`;
    const e = pts[pts.length - 1];
    if (R() < 0.6) svg += `<circle cx="${f(e[0])}" cy="${f(e[1])}" r="${f(1 + R() * 2.4)}" fill="${col(c)}" opacity="${op}"/>`;
  }

  // 4) Giọt sơn có viền, hạt nhũ & bụi sơn
  for (let i = 0; i < 4 + Math.floor(R() * 5); i++) {
    const x = outer + dir * W * R() * 0.6, y = H * R(), r = 2 + R() * 6;
    svg += `<ellipse cx="${f(x)}" cy="${f(y)}" rx="${f(r * (1 + R()))}" ry="${f(r)}" transform="rotate(${f(R() * 180)} ${f(x)} ${f(y)})" fill="${P.cream}" stroke="${P.rim}" stroke-width=".7"/>`;
  }
  for (let i = 0; i < 70; i++) {
    const x = outer + dir * W * Math.pow(R(), 1.4) * 0.8, y = H * R(), r = 0.4 + Math.pow(R(), 4) * 3;
    svg += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="${R() < 0.35 ? gold : P.dot}" opacity="${f(0.35 + R() * 0.6)}"/>`;
  }
  return svg;
}

let defsExtra = [];
function paintingSVG(R, W, H, dark, side, id, fadeA = 0.55, fadeB = 1, style = 'mixed') {
  defsExtra = [];
  const body = painting(R, W, H, dark, side, id, style);
  const fadeX1 = side === 'right' ? '1' : '0', fadeX2 = side === 'right' ? '0' : '1';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <linearGradient id="gd${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F6E7C1"/><stop offset=".45" stop-color="#D2B47A"/><stop offset=".7" stop-color="#B8995F"/><stop offset="1" stop-color="#EBD9AE"/></linearGradient>
  ${defsExtra.join('')}
  <filter id="mot${id}-0" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.011 0.018" numOctaves="5" seed="${Math.floor(R() * 999)}" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -5.5 3.4" result="a"/><feComposite in="SourceGraphic" in2="a" operator="in"/></filter>
  <filter id="mot${id}-1" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.022 0.03" numOctaves="4" seed="${Math.floor(R() * 999)}" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 7 -3.1" result="a"/><feComposite in="SourceGraphic" in2="a" operator="in"/></filter>
  <linearGradient id="fade${id}" x1="${fadeX1}" y1="0" x2="${fadeX2}" y2="0"><stop offset="0" stop-color="#fff"/><stop offset="${f(fadeA * 100) / 100}" stop-color="#fff"/><stop offset="${f(fadeB * 100) / 100}" stop-color="#fff" stop-opacity="0"/></linearGradient>
  <linearGradient id="vfade${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".12" stop-color="#fff"/><stop offset=".88" stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
  <mask id="mk${id}"><rect width="${W}" height="${H}" fill="url(#fade${id})"/></mask>
  <mask id="mv${id}"><rect width="${W}" height="${H}" fill="url(#vfade${id})"/></mask>
</defs>
<g mask="url(#mk${id})"><g mask="url(#mv${id})">${body}</g></g></svg>`;
}

// ---------- Đặt tranh lên trang ----------
let io = null, uid = 0;
function observe(el) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) { el.classList.add('is-in'); return; }
  io = io || new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px' });
  io.observe(el);
}

function place(layer, R, { left, top, w, h, dark, side, opacity, fadeA, fadeB, style = 'mixed' }) {
  const img = new Image();
  img.className = `paint paint--${side}`;
  img.alt = '';
  img.decoding = 'async';
  img.style.cssText = `left:${Math.round(left)}px;top:${Math.round(top)}px;width:${w}px;height:${h}px;--op:${opacity};--d:${Math.round(R() * 250)}ms`;
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(paintingSVG(R, w, h, dark, side, ++uid, fadeA, fadeB, style));
  layer.appendChild(img);
  observe(img);
}

function pageLayer(seed) {
  let layer = document.querySelector('.paint-layer');
  if (!layer) { layer = document.createElement('div'); layer.className = 'paint-layer'; layer.setAttribute('aria-hidden', 'true'); document.body.prepend(layer); }
  layer.innerHTML = '';
  const W = document.documentElement.clientWidth;
  const H = document.documentElement.scrollHeight;
  layer.style.height = H + 'px';
  const cont = document.querySelector('main .container');
  const cw = cont ? Math.min(cont.getBoundingClientRect().width, W) : Math.min(W, 1320);
  const gut = Math.max(0, (W - cw) / 2);
  const mobile = W < 768;
  const hero = document.querySelector('.hero');
  const y0 = (hero ? hero.getBoundingClientRect().bottom + window.scrollY : 120) + 40;
  const end = H - 200;
  // Mỗi bên lề có "dòng tranh" riêng: hạt giống ngẫu nhiên riêng, nhịp dọc riêng, phong cách riêng
  // → bên trái và bên phải luôn khác nhau, không lặp lại kiểu soi gương.
  for (const side of ['left', 'right']) {
    const R = rng(seed ^ (side === 'left' ? 0x9E3779B9 : 0x7F4A7C15));
    const style = side === 'left' ? 'ribbon' : 'wash';
    let y = y0 + (side === 'left' ? R() * 260 : 0);
    while (y < end) {
      const w = Math.round(mobile ? 140 + R() * 30 : Math.min(640, Math.max(300, gut + 190 + R() * 110)));
      const h = Math.round(mobile ? 420 + R() * 200 : 640 + R() * 380);
      const left = side === 'left' ? -R() * 30 : W - w + R() * 30;
      // Tranh đậm trong lề trống, nhạt dần khi chạm vùng nội dung để chữ luôn dễ đọc
      const edge = side === 'left' ? gut - left : left + w - (W - gut);
      const fadeA = mobile ? 0.3 : Math.min(0.85, Math.max(0.3, (edge - 90) / w));
      const fadeB = mobile ? 1 : Math.min(1, Math.max(fadeA + 0.14, (edge + 5) / w));
      place(layer, R, { left, top: y, w, h, dark: false, side, opacity: mobile ? 0.55 : 1, fadeA, fadeB, style });
      y += h * (mobile ? 1.1 : 0.72 + R() * 0.18);
    }
  }
}

function darkHosts(seed) {
  document.querySelectorAll('.dark-band, .karaoke').forEach((host, hi) => {
    let layer = host.querySelector(':scope > .paint-host');
    if (!layer) { layer = document.createElement('div'); layer.className = 'paint-host'; layer.setAttribute('aria-hidden', 'true'); host.prepend(layer); host.classList.add('has-paint'); if (getComputedStyle(host).position === 'static') host.style.position = 'relative'; }
    layer.innerHTML = '';
    const R = rng(seed + 977 * (hi + 1));
    const W = host.clientWidth, H = host.clientHeight;
    const w = Math.round(Math.min(560, Math.max(220, W * 0.32)));
    place(layer, R, { left: -10, top: 0, w, h: H, dark: true, side: 'left', opacity: 0.85 });
    place(layer, R, { left: W - w + 10, top: 0, w, h: H, dark: true, side: 'right', opacity: 0.85 });
  });
}

export function paintPage(key = location.pathname) {
  const seed = hashStr(key);
  const draw = () => { uid = 0; pageLayer(seed); darkHosts(seed); };
  draw();
  let lastH = document.documentElement.scrollHeight, lastW = document.documentElement.clientWidth, t = 0;
  new ResizeObserver(() => {
    clearTimeout(t);
    t = setTimeout(() => {
      const H = document.documentElement.scrollHeight, W = document.documentElement.clientWidth;
      if (Math.abs(H - lastH) < 160 && W === lastW) return;
      lastH = H; lastW = W; draw();
    }, 450);
  }).observe(document.body);
}

// Trang quản trị: hai mảng tranh cố định phía sau nội dung (bám theo màn hình khi cuộn)
export function paintFixed(key = 'admin') {
  const hasSide = !!document.querySelector('.adm__side');
  const draw = () => {
    let layer = document.querySelector('.paint-fixed');
    if (!layer) { layer = document.createElement('div'); layer.className = 'paint-fixed'; layer.setAttribute('aria-hidden', 'true'); document.body.prepend(layer); }
    layer.innerHTML = '';
    const dark = document.documentElement.classList.contains('dark');
    const R = rng(hashStr(key) + (dark ? 7 : 0));
    const W = window.innerWidth, H = window.innerHeight;
    const side = hasSide && W > 960 ? 248 : 0;
    const w = Math.round(Math.min(700, Math.max(260, (W - side) * 0.42)));
    uid = 500;
    place(layer, R, { left: W - w, top: -40, w, h: H + 80, dark, side: 'right', opacity: dark ? 0.5 : 0.75, fadeA: 0.3, fadeB: 1 });
    place(layer, R, { left: side, top: H * 0.35, w: Math.round(w * 0.8), h: Math.round(H * 0.7), dark, side: 'left', opacity: dark ? 0.4 : 0.6, fadeA: 0.25, fadeB: 1 });
  };
  draw();
  let t = 0;
  window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(draw, 300); });
  new MutationObserver(draw).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
}
