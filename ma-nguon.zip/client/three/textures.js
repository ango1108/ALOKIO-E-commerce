// Texture thủ tục (vẽ bằng canvas) — không cần file ảnh, sắc nét ở mọi độ phân giải.
import * as THREE from 'three';

const cache = new Map();
const memo = (key, fn) => { if (!cache.has(key)) cache.set(key, fn()); return cache.get(key); };

function canvas(w, h = w) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

function rand(seed) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

// Chuyển heightmap (kênh đỏ) thành normal map
function heightToNormal(src, strength = 2) {
  const w = src.width, h = src.height;
  const sctx = src.getContext('2d');
  const sd = sctx.getImageData(0, 0, w, h).data;
  const out = canvas(w, h);
  const octx = out.getContext('2d');
  const img = octx.createImageData(w, h);
  const H = (x, y) => sd[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = (H(x + 1, y) - H(x - 1, y)) * strength;
      const dy = (H(x, y + 1) - H(x, y - 1)) * strength;
      const nz = 1 / Math.sqrt(dx * dx + dy * dy + 1);
      const i = (y * w + x) * 4;
      img.data[i] = (-dx * nz * 0.5 + 0.5) * 255;
      img.data[i + 1] = (dy * nz * 0.5 + 0.5) * 255;
      img.data[i + 2] = nz * 255;
      img.data[i + 3] = 255;
    }
  }
  octx.putImageData(img, 0, 0);
  return out;
}

function tex(c, { repeat = [1, 1], srgb = false, aniso = 8 } = {}) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat[0], repeat[1]);
  t.anisotropy = aniso;
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.needsUpdate = true;
  return t;
}

// ---------- Vải lanh dệt kim ----------
export function linen() {
  return memo('linen', () => {
    const S = 256;
    const h = canvas(S);
    const g = h.getContext('2d');
    const r = rand(7);
    g.fillStyle = '#808080'; g.fillRect(0, 0, S, S);
    const cells = 32, cs = S / cells;
    for (let y = 0; y < cells; y++) {
      for (let x = 0; x < cells; x++) {
        const over = (x + y) % 2 === 0;
        const grad = over ? g.createLinearGradient(x * cs, 0, x * cs + cs, 0) : g.createLinearGradient(0, y * cs, 0, y * cs + cs);
        const v = 150 + r() * 40;
        grad.addColorStop(0, `rgb(${v * 0.55},0,0)`);
        grad.addColorStop(0.5, `rgb(${v},0,0)`);
        grad.addColorStop(1, `rgb(${v * 0.55},0,0)`);
        g.fillStyle = grad;
        g.fillRect(x * cs + 0.5, y * cs + 0.5, cs - 1, cs - 1);
      }
    }
    // sợi vải lệch nhẹ
    g.globalAlpha = 0.18;
    for (let i = 0; i < 900; i++) { g.fillStyle = r() < 0.5 ? '#ff0000' : '#000000'; g.fillRect(r() * S, r() * S, 1 + r() * 3, 1); }
    g.globalAlpha = 1;
    const n = heightToNormal(h, 3.2);
    // map màu: biến thiên rất nhẹ để vải có chiều sâu
    const c = canvas(S); const cg = c.getContext('2d');
    cg.drawImage(h, 0, 0); cg.globalCompositeOperation = 'source-over';
    const id = cg.getImageData(0, 0, S, S);
    for (let i = 0; i < id.data.length; i += 4) { const v = 200 + (id.data[i] - 128) * 0.35; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; }
    cg.putImageData(id, 0, 0);
    return { normal: tex(n), ao: tex(c) };
  });
}

// ---------- Lưới kim loại đục lỗ ----------
// pattern: 'round' | 'hex' | 'wave'
export function perforated(pattern = 'round', density = 26) {
  return memo('perf:' + pattern + density, () => {
    const S = 512;
    const a = canvas(S); const g = a.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#000';
    const step = S / density;
    for (let j = 0; j < density + 1; j++) {
      for (let i = 0; i < density + 1; i++) {
        let x = i * step + (j % 2 ? step / 2 : 0);
        let y = j * step;
        let rad = step * 0.32;
        if (pattern === 'wave') {
          const w = Math.sin((x / S) * Math.PI * 4 + (y / S) * Math.PI * 2);
          rad = step * (0.18 + 0.16 * (w * 0.5 + 0.5));
        }
        if (pattern === 'hex') {
          g.beginPath();
          for (const [ox, oy] of [[0, 0], [S, 0], [0, S], [-S, 0], [0, -S]]) { g.beginPath(); for (let k = 0; k < 6; k++) { const ang = Math.PI / 6 + (k * Math.PI) / 3; g.lineTo(x + ox + Math.cos(ang) * step * 0.4, y + oy + Math.sin(ang) * step * 0.4); } g.closePath(); g.fill(); }
        } else {
          for (const [ox, oy] of [[0, 0], [S, 0], [0, S], [-S, 0], [0, -S]]) { g.beginPath(); g.arc(x + ox, y + oy, rad, 0, Math.PI * 2); g.fill(); }
        }
      }
    }
    // height: lỗ thấp, mép lỗ vát
    const h = canvas(S); const hg = h.getContext('2d');
    hg.filter = 'blur(1.2px)'; hg.drawImage(a, 0, 0); hg.filter = 'none';
    const n = heightToNormal(h, 4);
    return { alpha: tex(a), normal: tex(n) };
  });
}

// ---------- Khảm trai: mảnh ghép voronoi ----------
export function pearl() {
  return memo('pearl', () => {
    const S = 384;
    const c = canvas(S); const g = c.getContext('2d');
    const r = rand(11);
    const pts = Array.from({ length: 70 }, () => [r() * S, r() * S, r()]);
    const img = g.createImageData(S, S);
    const h = canvas(S); const hg = h.getContext('2d'); const himg = hg.createImageData(S, S);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        let d1 = 1e9, d2 = 1e9, k = 0;
        for (let p = 0; p < pts.length; p++) {
          let dx = Math.abs(x - pts[p][0]); dx = Math.min(dx, S - dx);
          let dy = Math.abs(y - pts[p][1]); dy = Math.min(dy, S - dy);
          const d = dx * dx + dy * dy;
          if (d < d1) { d2 = d1; d1 = d; k = p; } else if (d < d2) d2 = d;
        }
        const edge = Math.sqrt(d2) - Math.sqrt(d1);
        const seam = edge < 1.6 ? 0.55 : 1;
        const t = pts[k][2];
        // Màu xà cừ: ngà – hồng – xanh – vàng nhạt
        const hue = [[246, 240, 232], [240, 224, 230], [222, 236, 244], [244, 238, 214], [232, 240, 236]][Math.floor(t * 5)];
        const band = 0.92 + 0.08 * Math.sin((x * 0.06 + y * 0.03) + t * 40);
        const i = (y * S + x) * 4;
        img.data[i] = hue[0] * seam * band; img.data[i + 1] = hue[1] * seam * band; img.data[i + 2] = hue[2] * seam * band; img.data[i + 3] = 255;
        const hv = (edge < 1.6 ? 90 : 160 + t * 60);
        himg.data[i] = hv; himg.data[i + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0); hg.putImageData(himg, 0, 0);
    return { map: tex(c, { srgb: true }), normal: tex(heightToNormal(h, 2.5)), thickness: tex(h) };
  });
}

// ---------- Gỗ (óc chó) ----------
export function wood(dark = '#3e2718', light = '#7a5236') {
  return memo('wood' + dark, () => {
    const W = 1024, H = 256;
    const c = canvas(W, H); const g = c.getContext('2d');
    const r = rand(3);
    g.fillStyle = light; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 140; i++) {
      const y0 = r() * H;
      g.strokeStyle = dark; g.globalAlpha = 0.08 + r() * 0.22; g.lineWidth = 0.6 + r() * 3;
      g.beginPath();
      for (let x = 0; x <= W; x += 16) {
        const y = y0 + Math.sin(x * 0.006 + i) * 6 + Math.sin(x * 0.02 + i * 3) * 2;
        x === 0 ? g.moveTo(x, y) : g.lineTo(x, y);
      }
      g.stroke();
    }
    g.globalAlpha = 1;
    const rough = canvas(W, H); const rg = rough.getContext('2d');
    rg.drawImage(c, 0, 0);
    const id = rg.getImageData(0, 0, W, H);
    for (let i = 0; i < id.data.length; i += 4) { const v = 120 + (255 - id.data[i]) * 0.4; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; }
    rg.putImageData(id, 0, 0);
    return { map: tex(c, { srgb: true }), roughness: tex(rough), bump: tex(heightToNormal(rough, 1.2)) };
  });
}

// ---------- Da thuộc ----------
export function leather() {
  return memo('leather', () => {
    const S = 256;
    const h = canvas(S); const g = h.getContext('2d');
    const r = rand(5);
    g.fillStyle = '#808080'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 2600; i++) {
      g.fillStyle = `rgba(${r() < 0.5 ? 40 : 220},0,0,${0.08 + r() * 0.12})`;
      g.beginPath(); g.arc(r() * S, r() * S, 1 + r() * 4, 0, Math.PI * 2); g.fill();
    }
    return { normal: tex(heightToNormal(h, 1.6), { repeat: [3, 3] }) };
  });
}

// ---------- Nhôm phay tròn (núm vặn) ----------
export function brushedRadial() {
  return memo('brushedR', () => {
    const S = 512;
    const c = canvas(S); const g = c.getContext('2d');
    const r = rand(9);
    g.fillStyle = '#9a9a9a'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 380; i++) {
      const rad = r() * S * 0.5;
      g.strokeStyle = `rgba(${r() < 0.5 ? 255 : 0},${r() < 0.5 ? 255 : 0},${r() < 0.5 ? 255 : 0},${0.05 + r() * 0.08})`;
      g.lineWidth = 0.5 + r();
      g.beginPath(); g.arc(S / 2, S / 2, rad, 0, Math.PI * 2); g.stroke();
    }
    return { roughness: tex(c) };
  });
}

// ---------- Nhôm xước thẳng ----------
export function brushedLinear() {
  return memo('brushedL', () => {
    const W = 512, H = 64;
    const c = canvas(W, H); const g = c.getContext('2d');
    const r = rand(13);
    g.fillStyle = '#8a8a8a'; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 500; i++) { g.fillStyle = `rgba(255,255,255,${r() * 0.12})`; g.fillRect(0, r() * H, W, 0.6); g.fillStyle = `rgba(0,0,0,${r() * 0.1})`; g.fillRect(0, r() * H, W, 0.6); }
    return { roughness: tex(c) };
  });
}

// ---------- Khía núm vặn (knurl) ----------
export function knurl(lines = 72) {
  return memo('knurl' + lines, () => {
    const W = 512, H = 32;
    const h = canvas(W, H); const g = h.getContext('2d');
    for (let x = 0; x < W; x++) { const v = 128 + 120 * Math.sin((x / W) * Math.PI * 2 * lines); g.fillStyle = `rgb(${v},0,0)`; g.fillRect(x, 0, 1, H); }
    return { normal: tex(heightToNormal(h, 3)) };
  });
}

// ---------- Logo / chữ dập ----------
export function wordmark({ text = 'ALOKIO', color = '#1a1a1a', bg = null, w = 1024, h = 256, weight = 500, spacing = 0.32, font = '"Playfair Display", serif', image = null } = {}) {
  const key = `wm:${text}:${color}:${bg}:${w}:${h}:${!!image}`;
  return memo(key, () => {
    const c = canvas(w, h); const g = c.getContext('2d');
    if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
    if (image) {
      const s = Math.min((w * 0.86) / image.width, (h * 0.8) / image.height);
      g.drawImage(image, (w - image.width * s) / 2, (h - image.height * s) / 2, image.width * s, image.height * s);
    } else {
      g.fillStyle = color;
      const size = h * 0.5;
      g.font = `${weight} ${size}px ${font}`;
      g.textBaseline = 'middle';
      const chars = [...text];
      const widths = chars.map((ch) => g.measureText(ch).width);
      const total = widths.reduce((s, x) => s + x, 0) + spacing * size * (chars.length - 1);
      let x = (w - total) / 2;
      chars.forEach((ch, i) => { g.fillText(ch, x, h / 2); x += widths[i] + spacing * size; });
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  });
}

export function engraving(text) {
  const c = canvas(1024, 160); const g = c.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, 1024, 160);
  g.fillStyle = '#fff';
  g.font = 'italic 500 92px "Playfair Display", serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text || '', 512, 84);
  const t = new THREE.CanvasTexture(c);
  t.anisotropy = 8;
  return t;
}

// ---------- Màn hình LED loa kéo ----------
export function lcd(text = '88:88', color = '#7FE3FF') {
  const c = canvas(256, 96); const g = c.getContext('2d');
  g.fillStyle = '#050a10'; g.fillRect(0, 0, 256, 96);
  g.fillStyle = color; g.shadowColor = color; g.shadowBlur = 12;
  g.font = '700 54px ui-monospace, monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 128, 50);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

// Bóng đổ mềm dưới vật thể (radial gradient)
export function softShadow() {
  return memo('shadow', () => {
    const S = 256; const c = canvas(S); const g = c.getContext('2d');
    const grad = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    grad.addColorStop(0, 'rgba(0,0,0,0.55)'); grad.addColorStop(0.45, 'rgba(0,0,0,0.28)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grad; g.fillRect(0, 0, S, S);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  });
}

let logoImage = null;
export function setLogoImage(img) { logoImage = img; }
export function getLogoImage() { return logoImage; }
