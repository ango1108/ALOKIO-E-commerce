// Cảnh nhỏ: loa nảy lên khỏi mặt nước + tia nước (trang đặt hàng thành công) hoặc giọt nước rơi (404)
import * as THREE from 'three';
import { createStage, isMobile } from './stage.js';
import { makeWater, makeSky, heightAtCPU, MAX_RIPPLES } from './water.js';
import { buildModel } from './models.js';

export function mountSplash(canvas, { model, finish, droplet = false } = {}) {
  const ripples = [];
  const stage = createStage(canvas, { fov: 34, ground: false, shadows: false, onFrame });
  const { scene, camera } = stage;
  const { mesh: water, uniforms } = makeWater({ segments: isMobile() ? 100 : 180, size: 120 });
  uniforms.uFogNear.value = 10; uniforms.uFogFar.value = 55;
  scene.add(water); scene.add(makeSky(uniforms));
  const holder = new THREE.Group(); scene.add(holder);
  let obj = null;
  if (!droplet) {
    obj = buildModel(model, { finish });
    const box = new THREE.Box3().setFromObject(obj); const s = box.getSize(new THREE.Vector3());
    const k = 2.4 / Math.max(s.x, s.y); obj.scale.setScalar(k);
    obj.position.y = obj.userData.lift * k - 0.05;
    holder.add(obj);
  } else {
    const drop = new THREE.Mesh(new THREE.SphereGeometry(0.35, 48, 32), new THREE.MeshPhysicalMaterial({ color: '#cfe2f6', roughness: 0.02, transmission: 1, thickness: 0.6, ior: 1.33, envMapIntensity: 1.5 }));
    drop.scale.set(0.85, 1.15, 0.85);
    holder.add(drop);
  }
  // hạt nước bắn
  const N = 160;
  const pos = new Float32Array(N * 3), vel = new Float32Array(N * 3);
  const pgeo = new THREE.BufferGeometry(); pgeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const points = new THREE.Points(pgeo, new THREE.PointsMaterial({ color: '#ffffff', size: 0.09, transparent: true, opacity: 0.85, depthWrite: false }));
  scene.add(points);
  camera.position.set(0, 2.6, 8.2); camera.lookAt(0, 1.0, 0);
  let vy = 0, y = droplet ? 6 : -1.6, phase = 0, splashT = -1;
  function splash(strength) {
    ripples.push({ x: 0, y: 0, z: stage.time, w: strength }); if (ripples.length > MAX_RIPPLES) ripples.shift();
    for (let i = 0; i < N; i++) {
      const a = Math.random() * Math.PI * 2, r = Math.random() * 0.6;
      pos[i * 3] = Math.cos(a) * r; pos[i * 3 + 1] = 0.05; pos[i * 3 + 2] = Math.sin(a) * r;
      vel[i * 3] = Math.cos(a) * (1 + Math.random() * 2.5); vel[i * 3 + 1] = 2.5 + Math.random() * 4 * strength * 3; vel[i * 3 + 2] = Math.sin(a) * (1 + Math.random() * 2.5);
    }
    splashT = stage.time;
  }
  function onFrame(t, dt) {
    uniforms.uTime.value = t;
    for (let i = 0; i < MAX_RIPPLES; i++) { const r = ripples[i]; uniforms.uRipples.value[i].set(r ? r.x : 0, r ? r.y : 0, r ? r.z : -100, r ? r.w : 0); }
    if (droplet) {
      if (phase === 0) { vy -= 9.8 * dt; y += vy * dt; if (y < 0.3) { splash(0.35); phase = 1; y = 6; vy = 0; holder.visible = false; setTimeout(() => { holder.visible = true; phase = 0; }, 2600); } }
      holder.position.y = y;
    } else {
      if (phase === 0) { vy = 6.2; phase = 1; splash(0.25); }
      if (phase === 1) { vy -= 9.8 * dt; y += vy * dt; holder.rotation.y += dt * 2.4; if (y <= 0 && vy < 0) { y = 0; phase = 2; splash(0.4); } }
      if (phase === 2) { const h = heightAtCPU(0, 0, t, 1, ripples, 0, { x: 0, y: 0 }); y += (h - y) * Math.min(1, dt * 6); holder.rotation.y += (Math.round(holder.rotation.y / (Math.PI * 2)) * Math.PI * 2 + 0.5 - holder.rotation.y) * Math.min(1, dt * 2); }
      holder.position.y = y;
    }
    if (splashT >= 0) {
      for (let i = 0; i < N; i++) { vel[i * 3 + 1] -= 9.8 * dt; pos[i * 3] += vel[i * 3] * dt; pos[i * 3 + 1] = Math.max(-1, pos[i * 3 + 1] + vel[i * 3 + 1] * dt); pos[i * 3 + 2] += vel[i * 3 + 2] * dt; }
      pgeo.attributes.position.needsUpdate = true;
      points.material.opacity = Math.max(0, 0.85 - (t - splashT) * 0.5);
    }
    obj && obj.userData.update(t, { bass: 0.2, mid: 0.2, treble: 0.1 });
  }
  stage.start();
  return stage;
}
