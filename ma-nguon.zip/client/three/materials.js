// Bộ vật liệu PBR của Alokio: sơn mài, khảm trai, vải lanh, nhôm champagne, gỗ, da, cao su…
import * as THREE from 'three';
import * as T from './textures.js';

export const FINISH = {
  'ngoc-trai': { lacquer: '#E3D4BA', linen: '#C9BEAB', accent: 'pearl', deep: '#B8A88C' },
  'suong-som': { lacquer: '#97BCE3', linen: '#D6E2EE', accent: 'pearl', deep: '#7EA6D3' },
  huyen: { lacquer: '#0E141D', linen: '#232932', accent: 'champagne', deep: '#05080C' },
  'oc-cho': { lacquer: '#5C3B27', linen: '#D9D0C2', accent: 'champagne', deep: '#3A2416', wood: true },
  'go-den': { lacquer: '#1A1B1E', linen: '#1A1B1E', accent: 'black', deep: '#0d0d0e' },
};
export const KNOB = { champagne: '#D8C49A', bac: '#D3D7DD' };
export const STRAP = { bo: '#8A5534', kem: '#E3D2B6', den: '#262321' };

export function lacquer(color) {
  const dark = new THREE.Color(color).getHSL({}).l < 0.2;
  return new THREE.MeshPhysicalMaterial({
    color, roughness: dark ? 0.22 : 0.3, metalness: 0, clearcoat: 1, clearcoatRoughness: dark ? 0.02 : 0.04,
    sheen: 0, specularIntensity: 0.6, envMapIntensity: 1.15,
  });
}

export function pearlMat() {
  const p = T.pearl();
  const m0 = new THREE.MeshPhysicalMaterial({
    color: '#ffffff', map: p.map, normalMap: p.normal, normalScale: new THREE.Vector2(0.35, 0.35),
    roughness: 0.18, metalness: 0.15, clearcoat: 1, clearcoatRoughness: 0.03,
    iridescence: 1, iridescenceIOR: 1.32, iridescenceThicknessMap: p.thickness,
    envMapIntensity: 1.4,
  });
  if ('iridescenceThicknessMinimum' in m0) { m0.iridescenceThicknessMinimum = 180; m0.iridescenceThicknessMaximum = 620; } else m0.iridescenceThicknessRange = [180, 620];
  return m0;
}

export function linenMat(color) {
  const l = T.linen();
  const n = l.normal.clone(); n.needsUpdate = true; n.repeat.set(9, 9);
  const a = l.ao.clone(); a.needsUpdate = true; a.repeat.set(9, 9);
  return new THREE.MeshPhysicalMaterial({
    color, roughness: 0.92, metalness: 0, normalMap: n, normalScale: new THREE.Vector2(1.6, 1.6),
    sheen: 1, sheenRoughness: 0.7, sheenColor: new THREE.Color(color).lerp(new THREE.Color('#ffffff'), 0.5),
    roughnessMap: a, envMapIntensity: 0.5,
  });
}

export function metal(color = KNOB.champagne, { rough = 0.26, brushed = 'radial', aniso = 0.7 } = {}) {
  const m = new THREE.MeshPhysicalMaterial({
    color, metalness: 1, roughness: rough, envMapIntensity: 1.25, anisotropy: aniso, anisotropyRotation: brushed === 'radial' ? 0 : Math.PI / 2,
    clearcoat: 0.3, clearcoatRoughness: 0.15,
  });
  const map = brushed === 'radial' ? T.brushedRadial().roughness : T.brushedLinear().roughness;
  m.roughnessMap = map;
  return m;
}

export function knurlMetal(color = KNOB.champagne) {
  const k = T.knurl(80);
  return new THREE.MeshPhysicalMaterial({ color, metalness: 1, roughness: 0.3, normalMap: k.normal, normalScale: new THREE.Vector2(0.8, 0.8), envMapIntensity: 1.2 });
}

export function perforatedMetal(color = '#C9CDD3', pattern = 'wave', density = 30, repeat = [2, 1]) {
  const p = T.perforated(pattern, density);
  const a = p.alpha.clone(); a.needsUpdate = true; a.repeat.set(...repeat);
  const n = p.normal.clone(); n.needsUpdate = true; n.repeat.set(...repeat);
  return new THREE.MeshPhysicalMaterial({
    color, metalness: 0.95, roughness: 0.32, alphaMap: a, alphaTest: 0.5, normalMap: n, normalScale: new THREE.Vector2(0.6, 0.6),
    side: THREE.DoubleSide, envMapIntensity: 1.1,
  });
}

export function woodMat() {
  const w = T.wood();
  return new THREE.MeshPhysicalMaterial({ map: w.map, roughnessMap: w.roughness, normalMap: w.bump, normalScale: new THREE.Vector2(0.4, 0.4), roughness: 0.55, clearcoat: 0.6, clearcoatRoughness: 0.2, envMapIntensity: 0.8 });
}

export function leatherMat(color = STRAP.bo) {
  const l = T.leather();
  return new THREE.MeshPhysicalMaterial({ color, roughness: 0.62, normalMap: l.normal, normalScale: new THREE.Vector2(0.7, 0.7), sheen: 0.4, sheenColor: new THREE.Color('#ffffff'), envMapIntensity: 0.6 });
}

export const rubber = (color = '#1b1c1f') => new THREE.MeshPhysicalMaterial({ color, roughness: 0.85, metalness: 0, envMapIntensity: 0.4 });
export const plastic = (color = '#16171a', rough = 0.45) => new THREE.MeshPhysicalMaterial({ color, roughness: rough, metalness: 0, clearcoat: 0.2, clearcoatRoughness: 0.3, envMapIntensity: 0.7 });
export const cone = (color = '#1d1e22') => new THREE.MeshPhysicalMaterial({ color, roughness: 0.75, metalness: 0.05, sheen: 0.4, sheenColor: new THREE.Color('#666'), side: THREE.DoubleSide, envMapIntensity: 0.5 });
export const glow = (color = '#ffffff', intensity = 2) => new THREE.MeshStandardMaterial({ color: '#000', emissive: color, emissiveIntensity: intensity, roughness: 0.4 });
export const pcb = () => new THREE.MeshPhysicalMaterial({ color: '#0F4D3A', roughness: 0.4, clearcoat: 0.6, clearcoatRoughness: 0.2 });

// Bộ vật liệu đầy đủ cho một mẫu loa theo lựa chọn hoàn thiện
export function kit(finish = 'ngoc-trai', knob = 'champagne', strap = 'bo') {
  const f = FINISH[finish] || FINISH['ngoc-trai'];
  const knobColor = KNOB[knob] || KNOB.champagne;
  return {
    finish,
    body: f.wood ? woodMat() : lacquer(f.lacquer),
    lacquer: lacquer(f.wood ? '#2a1a10' : f.lacquer),
    side: f.wood ? woodMat() : lacquer(f.lacquer),
    deep: lacquer(f.deep),
    linen: linenMat(f.linen),
    accent: f.accent === 'pearl' ? pearlMat() : metal(knobColor, { rough: 0.22 }),
    pearl: pearlMat(),
    knob: metal(knobColor, { rough: 0.24 }),
    knurl: knurlMetal(knobColor),
    frame: metal(knobColor, { rough: 0.3, brushed: 'linear', aniso: 0.5 }),
    grille: perforatedMetal(knob === 'bac' ? '#C8CCD3' : '#CDBA92', 'wave', 34, [3, 1.4]),
    strap: leatherMat(STRAP[strap] || STRAP.bo),
    rubber: rubber(),
    plastic: plastic(),
    cone: cone(),
    led: glow('#ffffff', 1.4),
    ledWarm: glow('#F2D9A6', 2.2),
    pcb: pcb(),
    chip: plastic('#0b0b0c', 0.3),
    battery: plastic('#2C3440', 0.5),
  };
}

export function kitKaraoke() {
  return {
    body: new THREE.MeshPhysicalMaterial({ color: '#17181b', roughness: 0.62, clearcoat: 0.15, clearcoatRoughness: 0.6, envMapIntensity: 0.6 }),
    trim: plastic('#202227', 0.35),
    grille: perforatedMetal('#24262b', 'hex', 40, [2, 2.6]),
    cone: cone('#121316'),
    dust: plastic('#2a2c31', 0.3),
    chrome: metal('#d9dde3', { rough: 0.12, brushed: 'linear', aniso: 0.2 }),
    alu: metal('#b8bdc4', { rough: 0.3, brushed: 'linear', aniso: 0.5 }),
    rubber: rubber('#101012'),
    knob: plastic('#0f1012', 0.35),
    knobCap: metal('#c9cdd3', { rough: 0.2 }),
    panel: plastic('#0c0d0f', 0.5),
    led: glow('#ff5a3c', 2.6),
    ledB: glow('#4fd1ff', 2.4),
    mic: metal('#2b2d31', { rough: 0.35, brushed: 'linear' }),
    micHead: perforatedMetal('#9aa0a8', 'round', 40, [2, 2]),
    pcb: pcb(),
    chip: plastic('#0b0b0c', 0.3),
    battery: plastic('#2C3440', 0.5),
  };
}

// Chuyển màu mượt cho vật liệu (dùng khi đổi hoàn thiện)
export function tweenColor(mat, to, ms = 400) {
  if (!mat || !mat.color) return;
  const from = mat.color.clone();
  const target = new THREE.Color(to);
  const t0 = performance.now();
  const step = (t) => {
    const k = Math.min(1, (t - t0) / ms);
    const e = 1 - Math.pow(1 - k, 3);
    mat.color.copy(from).lerp(target, e);
    if (k < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
