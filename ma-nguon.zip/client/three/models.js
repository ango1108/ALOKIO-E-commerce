// Mô hình 3D dựng hoàn toàn bằng code. Đơn vị: 1 = 10 cm (đúng tỉ lệ thông số sản phẩm).
// Mỗi model trả về THREE.Group với userData:
//   parts: các bộ phận (để tách lớp), mỗi part có userData.explode (Vector3 offset)
//   update(t, bands): hiệu ứng theo thời gian/âm thanh (LED, màng loa rung)
//   size: kích thước bao (Vector3), mats: bộ vật liệu
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import * as M from './materials.js';
import * as T from './textures.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const gcache = new Map();
const G = (key, fn) => { if (!gcache.has(key)) gcache.set(key, fn()); return gcache.get(key); };

function mesh(geo, mat, { pos, rot, scale, name, cast = true, receive = true } = {}) {
  const m = new THREE.Mesh(geo, mat);
  if (pos) m.position.set(...pos);
  if (rot) m.rotation.set(...rot);
  if (scale) m.scale.set(...scale);
  if (name) m.name = name;
  m.castShadow = cast; m.receiveShadow = receive;
  return m;
}

const rbox = (w, h, d, r, seg = 6) => G(`rb:${w}:${h}:${d}:${r}:${seg}`, () => new RoundedBoxGeometry(w, h, d, seg, Math.min(r, Math.min(w, h, d) / 2 - 1e-4)));

function roundedRect(w, h, r) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}

// Khung viền (vòng chữ nhật bo góc) — kim loại phay
function frameRing(w, h, r, t, depth) {
  return G(`fr:${w}:${h}:${r}:${t}:${depth}`, () => {
    const outer = roundedRect(w, h, r);
    outer.holes.push(roundedRect(w - t * 2, h - t * 2, Math.max(0.01, r - t)));
    const g = new THREE.ExtrudeGeometry(outer, { depth, bevelEnabled: true, bevelThickness: depth * 0.35, bevelSize: t * 0.25, bevelSegments: 4, curveSegments: 24 });
    g.translate(0, 0, -depth / 2);
    return g;
  });
}

function plateGeo(w, h, r, depth) {
  return G(`pl:${w}:${h}:${r}:${depth}`, () => {
    const g = new THREE.ExtrudeGeometry(roundedRect(w, h, r), { depth, bevelEnabled: true, bevelThickness: depth * 0.3, bevelSize: Math.min(w, h) * 0.02, bevelSegments: 3, curveSegments: 20 });
    g.translate(0, 0, -depth / 2);
    // UV phẳng theo mặt trước
    const pos = g.attributes.position, uv = g.attributes.uv;
    for (let i = 0; i < pos.count; i++) uv.setXY(i, pos.getX(i) / w + 0.5, pos.getY(i) / h + 0.5);
    return g;
  });
}

// ---------- Củ loa (driver) ----------
function driver(R, mats, { cap = 'dome', rimMat } = {}) {
  const g = new THREE.Group();
  const conePts = [[0.24, -0.28], [0.36, -0.24], [0.5, -0.17], [0.66, -0.1], [0.82, -0.035], [0.86, 0]].map(([r, y]) => new THREE.Vector2(r * R, y * R));
  const surPts = [];
  for (let i = 0; i <= 12; i++) { const a = Math.PI - (i / 12) * Math.PI; surPts.push(new THREE.Vector2((0.925 + Math.cos(a) * 0.065) * R, Math.sin(a) * 0.06 * R)); }
  const rimPts = [[0.99, 0], [1.06, 0], [1.08, -0.02], [1.08, -0.08]].map(([r, y]) => new THREE.Vector2(r * R, y * R));
  const coneMesh = mesh(G(`cone:${R}`, () => new THREE.LatheGeometry(conePts, 64)), mats.cone);
  const sur = mesh(G(`sur:${R}`, () => new THREE.LatheGeometry(surPts, 64)), mats.rubber);
  const rim = mesh(G(`rim:${R}`, () => new THREE.LatheGeometry(rimPts, 64)), rimMat || mats.frame || mats.alu);
  g.add(coneMesh, sur, rim);
  if (cap === 'dome') {
    const capGeo = G(`cap:${R}`, () => new THREE.SphereGeometry(0.26 * R, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.32));
    const c = mesh(capGeo, mats.dust || mats.deep || mats.plastic, { pos: [0, -0.34 * R, 0] });
    g.add(c);
  }
  g.rotation.x = Math.PI / 2; // hướng ra +Z
  const wrap = new THREE.Group();
  wrap.add(g);
  wrap.userData.cone = g;
  return wrap;
}

function tweeter(R, mats) {
  const g = new THREE.Group();
  const face = mesh(G(`tw:${R}`, () => new THREE.CylinderGeometry(R * 1.25, R * 1.3, R * 0.25, 48)), mats.plastic || mats.trim, { rot: [Math.PI / 2, 0, 0] });
  const dome = mesh(G(`twd:${R}`, () => new THREE.SphereGeometry(R * 0.7, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2)), mats.knob || mats.chrome, { rot: [Math.PI / 2, 0, 0], pos: [0, 0, R * 0.12] });
  g.add(face, dome);
  return g;
}

// ---------- Núm vặn nhôm phay ----------
function knob(r, h, mats, { indicator = true, pearlRing = false } = {}) {
  const g = new THREE.Group();
  const side = mesh(G(`ks:${r}:${h}`, () => {
    const c = new THREE.CylinderGeometry(r, r * 1.02, h * 0.82, 96, 1, true);
    c.translate(0, h * 0.41, 0);
    return c;
  }), mats.knurl || mats.knob);
  const top = mesh(G(`kt:${r}`, () => { const c = new THREE.CircleGeometry(r * 0.86, 64); c.rotateX(-Math.PI / 2); return c; }), mats.knob, { pos: [0, h, 0] });
  const chamfer = mesh(G(`kc:${r}:${h}`, () => new THREE.LatheGeometry([new THREE.Vector2(r, h * 0.82), new THREE.Vector2(r * 0.97, h * 0.95), new THREE.Vector2(r * 0.86, h)], 96)), mats.knob);
  g.add(side, top, chamfer);
  if (indicator) g.add(mesh(G(`ki:${r}`, () => new THREE.BoxGeometry(r * 0.08, h * 0.04, r * 0.5)), M.plastic('#1a1a1a', 0.5), { pos: [0, h + 0.002, -r * 0.45] }));
  if (pearlRing && mats.pearl) {
    const ring = mesh(G(`kr:${r}`, () => { const t = new THREE.TorusGeometry(r * 1.32, r * 0.16, 16, 96); t.rotateX(Math.PI / 2); return t; }), mats.pearl, { pos: [0, r * 0.06, 0], scale: [1, 0.45, 1] });
    g.add(ring);
  }
  g.userData.isKnob = true;
  return g;
}

function button(r, h, mat) {
  return mesh(G(`btn:${r}:${h}`, () => { const c = new THREE.CylinderGeometry(r, r, h, 32); c.translate(0, h / 2, 0); return c; }), mat);
}

function logoDecal(w, h, color, mats, { metal = true } = {}) {
  const img = T.getLogoImage();
  const t = T.wordmark({ color: '#ffffff', w: 1024, h: 256, image: img });
  const mat = metal
    ? new THREE.MeshPhysicalMaterial({ color, metalness: 1, roughness: 0.25, alphaMap: t, transparent: true, alphaTest: 0.3, envMapIntensity: 1.3, polygonOffset: true, polygonOffsetFactor: -2 })
    : new THREE.MeshStandardMaterial({ color, alphaMap: t, transparent: true, alphaTest: 0.3, roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -2 });
  return mesh(G(`logo:${w}:${h}`, () => new THREE.PlaneGeometry(w, h)), mat, { cast: false });
}

function strapMesh(points, width, thick, mat) {
  const key = 'strap:' + points.map((p) => p.join(',')).join('|') + width;
  const geo = G(key, () => {
    const curve = new THREE.CatmullRomCurve3(points.map((p) => V(...p)));
    const shape = roundedRect(thick, width, thick * 0.45);
    return new THREE.ExtrudeGeometry(shape, { steps: 80, bevelEnabled: false, extrudePath: curve });
  });
  return mesh(geo, mat);
}

function part(group, obj, name, explode = V(0, 0, 0), { internal = false } = {}) {
  obj.name = name;
  obj.userData.explode = explode;
  obj.userData.home = obj.position.clone();
  obj.userData.internal = internal;
  group.userData.parts.push(obj);
  group.add(obj);
  return obj;
}

function base(type, mats, size) {
  const g = new THREE.Group();
  g.userData = { type, parts: [], mats, size, cones: [], leds: [], knobs: [], update: null };
  return g;
}

function internals(g, mats, { w, h, d, woofers = [], tweeters = [], up = 1 }) {
  // Bo mạch ampli + pin + chip, chỉ hiện khi tách lớp
  const board = new THREE.Group();
  board.add(mesh(new THREE.BoxGeometry(w * 0.5, 0.025, d * 0.5), mats.pcb));
  const chipGeo = new THREE.BoxGeometry(w * 0.06, 0.03, w * 0.06);
  for (let i = 0; i < 6; i++) board.add(mesh(chipGeo, mats.chip, { pos: [(-0.2 + (i % 3) * 0.2) * w * 0.5, 0.025, (i < 3 ? -0.1 : 0.12) * d] }));
  board.add(mesh(new THREE.CylinderGeometry(w * 0.03, w * 0.03, 0.12, 20), M.metal('#b0b4ba', { rough: 0.3 }), { pos: [w * 0.18, 0.07, d * 0.1] }));
  board.position.set(0, -h * 0.05, -d * 0.18);
  part(g, board, 'Bo mạch ampli Class-D', V(0, h * 0.9 * up, -d * 0.4), { internal: true });
  const batt = mesh(rbox(w * 0.42, h * 0.18, d * 0.3, 0.03), mats.battery, { pos: [0, -h * 0.28, -d * 0.12] });
  part(g, batt, 'Pin', V(0, -h * 1.0, -d * 0.2), { internal: true });
  return { board, batt };
}

// =====================================================================
// HẠ LONG — loa di động biểu tượng (230 × 110 × 98 mm)
// =====================================================================
function halong(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const w = 2.3, h = 1.1, d = 0.98;
  const g = base('halong', mats, V(w, h + 0.5, d));
  const shell = mesh(rbox(w, h, d, 0.17, 8), mats.body);
  part(g, shell, 'Vỏ sơn mài', V(0, 0, -0.9));
  // Woofer & tweeter (bên trong)
  [-0.56, 0.56].forEach((x, i) => {
    const wf = driver(0.3, mats); wf.position.set(x, -0.05, d * 0.3);
    part(g, wf, i ? 'Woofer 3" phải' : 'Woofer 3" trái', V(x * 0.4, 0, 1.3), { internal: true });
    g.userData.cones.push(wf.userData.cone);
  });
  [-0.14, 0.14].forEach((x, i) => { const tw = tweeter(0.075, mats); tw.position.set(x, 0.22, d * 0.34); part(g, tw, i ? 'Tweeter phải' : 'Tweeter trái', V(x * 2, 0.55, 1.5), { internal: true }); });
  internals(g, mats, { w, h, d });
  // Mặt vải lanh
  const front = mesh(plateGeo(w - 0.26, h - 0.26, 0.09, 0.03), mats.linen, { pos: [0, 0, d / 2 - 0.002] });
  part(g, front, 'Mặt vải lanh', V(0, 0, 2.4));
  const frame = mesh(frameRing(w - 0.16, h - 0.16, 0.12, 0.055, 0.035), mats.frame, { pos: [0, 0, d / 2 + 0.006] });
  part(g, frame, 'Khung nhôm champagne', V(0, 0, 1.9));
  const logo = logoDecal(0.5, 0.125, M.KNOB[opts.knob] || M.KNOB.champagne, mats);
  logo.position.set(0, -0.3, d / 2 + 0.03);
  frame.add(logo); logo.position.set(0, -0.3, 0.03);
  // Mặt trên: dải nhôm + núm đa hướng viền khảm trai
  const top = new THREE.Group();
  top.add(mesh(rbox(1.36, 0.03, 0.4, 0.012, 3), mats.frame, { pos: [0, 0, 0] }));
  const k = knob(0.12, 0.09, mats, { pearlRing: true });
  k.position.set(0, 0.015, 0);
  top.add(k);
  g.userData.knobs.push(k);
  [-0.42, -0.3, 0.3, 0.42].forEach((x) => { const b = button(0.035, 0.022, mats.knob); b.position.set(x, 0.015, 0); top.add(b); });
  for (let i = 0; i < 5; i++) { const led = mesh(G('led', () => new THREE.SphereGeometry(0.012, 10, 8)), mats.led.clone()); led.position.set(-0.56 + i * 0.03 + (i > 2 ? 0 : 0), 0.02, 0.12); top.add(led); g.userData.leds.push(led); }
  if (opts.engraving) {
    const em = new THREE.MeshPhysicalMaterial({ color: '#7a6640', metalness: 1, roughness: 0.55, alphaMap: T.engraving(opts.engraving), transparent: true, alphaTest: 0.3, polygonOffset: true, polygonOffsetFactor: -2 });
    const p = mesh(new THREE.PlaneGeometry(0.7, 0.11), em, { rot: [-Math.PI / 2, 0, 0], pos: [0.22, 0.017, 0.12], cast: false });
    p.position.set(0, 0.017, -0.13);
    top.add(p);
  }
  top.position.set(0, h / 2 - 0.006, -0.02);
  part(g, top, 'Bảng điều khiển trên đỉnh', V(0, 0.9, 0));
  // Quai da
  const strap = new THREE.Group();
  strap.add(strapMesh([[-0.82, 0.5, -0.24], [-0.7, 0.86, -0.24], [0, 1.0, -0.24], [0.7, 0.86, -0.24], [0.82, 0.5, -0.24]], 0.14, 0.03, mats.strap));
  [-0.82, 0.82].forEach((x) => strap.add(mesh(G('rivet', () => new THREE.CylinderGeometry(0.04, 0.04, 0.05, 24)), mats.knob, { pos: [x, 0.5, -0.24], rot: [0, 0, 0] })));
  part(g, strap, 'Quai da thật', V(0, 1.1, -0.4));
  // Chân cao su
  [-0.75, 0.75].forEach((x) => g.add(mesh(rbox(0.36, 0.02, 0.5, 0.008, 2), mats.rubber, { pos: [x, -h / 2 - 0.004, 0] })));
  // Màng cộng hưởng hai bên hông
  [-1, 1].forEach((sx) => {
    const pr = mesh(G('pr', () => { const c = new THREE.CylinderGeometry(0.28, 0.28, 0.02, 48); c.rotateZ(Math.PI / 2); return c; }), mats.rubber, { pos: [sx * (w / 2 + 0.002), 0, 0] });
    g.add(pr);
    const ring = mesh(G('prr', () => { const t = new THREE.TorusGeometry(0.3, 0.018, 12, 64); t.rotateY(Math.PI / 2); return t; }), mats.frame, { pos: [sx * (w / 2 + 0.006), 0, 0] });
    g.add(ring);
  });
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// HI-FI TẠI GIA — Hội An / Huế / Tràng An
// =====================================================================
function hifi(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const dims = { s: [2.6, 1.7, 1.5, 3], m: [3.5, 2.03, 1.88, 4], l: [4.0, 3.17, 2.03, 5] }[opts.size || 's'];
  const [w, h, d, nk] = dims;
  const g = base('hifi', mats, V(w, h, d));
  const cheek = 0.16;
  // Thân chính (lõi) + hai má hông sơn mài/gỗ
  const core = mesh(rbox(w - cheek * 2 + 0.02, h - 0.02, d - 0.02, 0.04, 4), mats.deep);
  part(g, core, 'Thân loa', V(0, 0, -1.2));
  [-1, 1].forEach((sx) => {
    const ch = mesh(rbox(cheek, h, d, 0.06, 5), mats.side, { pos: [sx * (w / 2 - cheek / 2), 0, 0] });
    part(g, ch, sx < 0 ? 'Má hông trái' : 'Má hông phải', V(sx * 1.2, 0, 0));
  });
  // Dải nhôm mặt trên
  const topStrip = new THREE.Group();
  const stripD = Math.min(0.42, d * 0.28);
  topStrip.add(mesh(rbox(w - cheek * 2 - 0.02, 0.06, d - 0.02, 0.02, 3), mats.lacquer, { pos: [0, 0, 0] }));
  topStrip.add(mesh(rbox(w * 0.62, 0.02, stripD, 0.01, 3), mats.frame, { pos: [0, 0.035, d / 2 - stripD / 2 - 0.08] }));
  const spacing = (w * 0.5) / Math.max(1, nk - 1);
  const labels = ['VOLUME', 'BASS', 'TREBLE', 'SOURCE', 'BALANCE'];
  for (let i = 0; i < nk; i++) {
    const kn = knob(0.12 + (i === 0 ? 0.02 : 0), 0.11, mats, { pearlRing: mats.accent.iridescence > 0 });
    kn.position.set(-w * 0.25 + i * spacing, 0.045, d / 2 - stripD / 2 - 0.08);
    kn.userData.label = labels[i];
    topStrip.add(kn);
    g.userData.knobs.push(kn);
  }
  // công tắc gạt + đèn nguồn
  const toggle = new THREE.Group();
  toggle.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.02, 24), mats.knob));
  toggle.add(mesh(new THREE.CylinderGeometry(0.012, 0.016, 0.14, 16), mats.knob, { pos: [0, 0.06, 0], rot: [0.5, 0, 0] }));
  toggle.position.set(w * 0.36, 0.045, d / 2 - stripD / 2 - 0.08);
  topStrip.add(toggle);
  const pled = mesh(new THREE.SphereGeometry(0.018, 12, 8), mats.ledWarm.clone(), { pos: [w * 0.36, 0.05, d / 2 - 0.08 - stripD + 0.06] });
  topStrip.add(pled); g.userData.leds.push(pled);
  topStrip.position.set(0, h / 2 - 0.02, 0);
  part(g, topStrip, 'Dải núm nhôm champagne', V(0, 1.2, 0));
  // Driver bên trong
  const wR = h * 0.24;
  const wf = driver(wR, mats); wf.position.set(0, -h * 0.12, d / 2 - 0.2);
  part(g, wf, 'Woofer', V(0, -0.2, 1.4), { internal: true }); g.userData.cones.push(wf.userData.cone);
  [-1, 1].forEach((sx) => { const tw = tweeter(h * 0.05, mats); tw.position.set(sx * w * 0.28, h * 0.2, d / 2 - 0.18); tw.rotation.y = sx * 0.35; part(g, tw, sx < 0 ? 'Tweeter trái' : 'Tweeter phải', V(sx * 0.8, 0.4, 1.5), { internal: true }); });
  if (opts.size === 'l') [-1, 1].forEach((sx) => { const md = driver(h * 0.08, mats); md.position.set(sx * w * 0.22, -h * 0.02, d / 2 - 0.18); part(g, md, 'Loa mid', V(sx * 0.6, 0.1, 1.45), { internal: true }); });
  internals(g, mats, { w: w * 0.7, h, d });
  // Mặt vải lanh + logo
  const front = mesh(plateGeo(w - cheek * 2 - 0.08, h - 0.16, 0.04, 0.04), mats.linen, { pos: [0, -0.02, d / 2 + 0.005] });
  part(g, front, 'Mặt vải lanh', V(0, 0, 2.6));
  const plate = mesh(rbox(0.72, 0.16, 0.02, 0.02, 3), mats.frame, { pos: [0, h * 0.34, 0.03] });
  front.add(plate);
  const lg = logoDecal(0.62, 0.155, '#2a2418', mats, { metal: false }); lg.position.set(0, h * 0.34, 0.042); front.add(lg);
  // Chân
  [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => g.add(mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.05, 24), mats.knob, { pos: [sx * (w / 2 - 0.25), -h / 2 - 0.025, sz * (d / 2 - 0.25)] }))));
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// GIỌT — loa mini (100 × 100 × 44 mm)
// =====================================================================
function pebble(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const w = 1.0, h = 1.0, d = 0.44;
  const g = base('pebble', mats, V(w, h, d));
  const body = mesh(rbox(w, h, d, 0.2, 10), mats.body);
  part(g, body, 'Thân sơn mài', V(0, 0, -0.8));
  const wf = driver(0.27, mats); wf.position.set(0, 0, d / 2 - 0.06);
  part(g, wf, 'Driver 2"', V(0, 0, 0.9), { internal: true }); g.userData.cones.push(wf.userData.cone);
  const grille = mesh(plateGeo(0.78, 0.78, 0.18, 0.012), mats.grille, { pos: [0, 0, d / 2 + 0.002] });
  part(g, grille, 'Lưới nhôm hoạ tiết sóng', V(0, 0, 1.5));
  const ring = mesh(frameRing(0.86, 0.86, 0.22, 0.045, 0.03), mats.accent, { pos: [0, 0, d / 2 + 0.006] });
  part(g, ring, 'Viền khảm trai', V(0, 0, 1.2));
  const kn = knob(0.07, 0.05, mats, { pearlRing: false }); kn.position.set(0.18, h / 2 - 0.01, 0); g.add(kn); g.userData.knobs.push(kn);
  const led = mesh(new THREE.SphereGeometry(0.012, 10, 8), mats.led.clone(), { pos: [-0.12, h / 2 + 0.001, 0.06] }); g.add(led); g.userData.leds.push(led);
  const strap = strapMesh([[-0.36, 0.42, 0], [-0.5, 0.66, 0], [-0.3, 0.86, 0], [-0.08, 0.66, 0], [-0.2, 0.46, 0]], 0.08, 0.02, mats.strap);
  part(g, strap, 'Quai da', V(-0.3, 0.8, 0));
  const lg = logoDecal(0.3, 0.075, M.KNOB[opts.knob] || M.KNOB.champagne, mats); lg.position.set(0, -0.3, d / 2 + 0.02); ring.add(lg); lg.position.set(0, -0.32, 0.03);
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// SÓNG — loa stereo 360° (160 × 77 × 68 mm) — đặt nằm ngang: w=1.6, h=0.68, d=0.77
// =====================================================================
function wave(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const w = 1.6, h = 0.77, d = 0.68;
  const g = base('wave', mats, V(w, h, d));
  const core = mesh(rbox(w - 0.04, h - 0.06, d - 0.06, 0.14, 6), M.plastic('#0e1116', 0.6));
  part(g, core, 'Lõi', V(0, 0, -0.7));
  const grille = mesh(rbox(w, h * 0.74, d, 0.16, 8), mats.grille, { pos: [0, -h * 0.12, 0] });
  part(g, grille, 'Lưới nhôm ôm 3 mặt', V(0, -0.2, 1.1));
  const top = mesh(rbox(w, h * 0.3, d, 0.14, 8), mats.body, { pos: [0, h * 0.36, 0] });
  part(g, top, 'Dải sơn mài', V(0, 0.8, 0));
  const strip = mesh(rbox(w * 0.6, 0.02, d * 0.3, 0.01, 3), mats.frame, { pos: [0, h * 0.51, 0] });
  top.add(strip); strip.position.set(0, h * 0.15 + 0.004, 0);
  [-0.3, -0.15, 0, 0.15, 0.3].forEach((x, i) => { const b = button(i === 2 ? 0.05 : 0.032, 0.02, mats.knob); b.position.set(x * w * 0.7, h * 0.15 + 0.01, 0); top.add(b); });
  [-0.4, 0.4].forEach((x, i) => { const wf = driver(0.22, mats); wf.position.set(x, -0.1, d * 0.18); part(g, wf, i ? 'Driver phải' : 'Driver trái', V(x, 0, 0.9), { internal: true }); g.userData.cones.push(wf.userData.cone); });
  const lg = logoDecal(0.36, 0.09, M.KNOB[opts.knob] || M.KNOB.champagne, mats); lg.position.set(0, h * 0.02, d / 2 + 0.006); top.add(lg); lg.position.set(0, -0.0, d / 2 + 0.004);
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// HỒ TÂY — loa thông minh dáng hòn cuội
// =====================================================================
function stone(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const H = 1.83, R = 0.66;
  const g = base('stone', mats, V(R * 2, H, R * 2));
  const pts = [];
  for (let i = 0; i <= 40; i++) { const t = i / 40; const y = t * H; const r = R * Math.pow(Math.sin(Math.PI * (0.06 + t * 0.88)), 0.55) * (1 - 0.12 * t); pts.push(new THREE.Vector2(Math.max(0.001, r), y)); }
  const body = mesh(G('stoneBody', () => new THREE.LatheGeometry(pts, 96)), mats.linen, { pos: [0, -H / 2, 0] });
  part(g, body, 'Vỏ vải lanh', V(0, 0, 1.2));
  const topY = H / 2 - 0.08;
  const capR = pts[37].x;
  const cap = mesh(G('stoneCap', () => new THREE.CylinderGeometry(capR * 0.95, capR, 0.05, 64)), mats.body, { pos: [0, topY, 0] });
  const ring = mesh(G('stoneRing', () => { const t = new THREE.TorusGeometry(capR * 0.72, 0.03, 16, 96); t.rotateX(Math.PI / 2); return t; }), mats.accent, { pos: [0, topY + 0.03, 0] });
  const topG = new THREE.Group(); topG.add(cap, ring);
  for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; const led = mesh(G('sled', () => new THREE.SphereGeometry(0.01, 8, 6)), mats.led.clone(), { pos: [Math.cos(a) * capR * 0.55, topY + 0.03, Math.sin(a) * capR * 0.55] }); topG.add(led); g.userData.leds.push(led); }
  part(g, topG, 'Vòng cảm ứng', V(0, 0.9, 0));
  const wf = driver(0.36, mats); wf.position.set(0, -0.2, 0.3); part(g, wf, 'Mid-woofer 90 mm', V(0, -0.2, 1.6), { internal: true }); g.userData.cones.push(wf.userData.cone);
  const base2 = mesh(new THREE.CylinderGeometry(R * 0.5, R * 0.52, 0.04, 48), mats.rubber, { pos: [0, -H / 2 + 0.02, 0] }); g.add(base2);
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// SÔNG HƯƠNG — soundbar (651 × 69 × 100 mm)
// =====================================================================
function bar(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const w = 6.51, h = 0.69, d = 1.0;
  const g = base('bar', mats, V(w, h, d));
  const body = mesh(rbox(w, h, d, 0.22, 8), mats.body);
  part(g, body, 'Thân sơn mài', V(0, 0, -0.8));
  const gm = M.perforatedMetal(opts.knob === 'bac' ? '#C8CCD3' : '#CDBA92', 'wave', 34, [12, 1.2]);
  const grille = mesh(plateGeo(w - 0.3, h - 0.18, 0.18, 0.02), gm, { pos: [0, 0, d / 2 + 0.002] });
  part(g, grille, 'Lưới nhôm', V(0, 0, 1.2));
  for (let i = 0; i < 4; i++) { const wf = driver(0.2, mats); wf.scale.set(1.5, 1, 1); wf.position.set(-2.4 + i * 1.6 + (i > 1 ? 0.0 : 0), 0, d * 0.32); part(g, wf, 'Mid-woofer elip', V(0, 0, 0.8), { internal: true }); g.userData.cones.push(wf.userData.cone); }
  const lg = logoDecal(0.5, 0.12, M.KNOB[opts.knob] || M.KNOB.champagne, mats); grille.add(lg); lg.position.set(0, 0, 0.03);
  const led = mesh(new THREE.BoxGeometry(0.4, 0.008, 0.01), mats.ledWarm.clone(), { pos: [0, h / 2 - 0.08, d / 2 + 0.01] }); g.add(led); g.userData.leds.push(led);
  g.userData.update = makeUpdater(g);
  return g;
}

// =====================================================================
// SƠN ĐOÒNG — siêu trầm
// =====================================================================
function cube(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const s = 3.0;
  const g = base('cube', mats, V(s, s, s));
  const body = mesh(rbox(s, s, s, 0.24, 8), mats.body);
  part(g, body, 'Khối sơn mài', V(0, 0, -1));
  const port = mesh(G('cubePort', () => new THREE.CircleGeometry(1.12, 64)), M.plastic('#0b0c0e', 0.6), { pos: [0, 0, s / 2 + 0.003] }); g.add(port);
  const wf = driver(1.0, { ...mats, cone: M.cone('#2b2d31') }); wf.position.set(0, 0, s / 2 + 0.3);
  part(g, wf, 'Driver 6,5" (trước)', V(0, 0, 1.6)); g.userData.cones.push(wf.userData.cone);
  const ring = mesh(G('cubeRing', () => new THREE.TorusGeometry(1.14, 0.05, 16, 96)), mats.accent, { pos: [0, 0, s / 2 + 0.01] }); part(g, ring, 'Viền khảm trai', V(0, 0, 2.1));
  const lg = logoDecal(0.6, 0.15, M.KNOB[opts.knob] || M.KNOB.champagne, mats); lg.position.set(0, -1.3, s / 2 + 0.005); g.add(lg);
  g.add(mesh(new THREE.BoxGeometry(s * 0.9, 0.06, s * 0.9), mats.rubber, { pos: [0, -s / 2 - 0.02, 0] }));
  g.userData.update = makeUpdater(g, { coneAmp: 0.12 });
  return g;
}

// =====================================================================
// LỄ HỘI — loa party cao cấp
// =====================================================================
function tower(opts) {
  const mats = M.kit(opts.finish, opts.knob, opts.strap);
  const w = 3.35, h = 6.7, d = 3.85;
  const g = base('tower', mats, V(w, h + 1.2, d));
  const body = mesh(rbox(w, h, d, 0.22, 6), mats.deep);
  part(g, body, 'Thân', V(0, 0, -1.6));
  [-1, 1].forEach((sx) => { const side = mesh(rbox(0.18, h, d, 0.08, 4), M.woodMat(), { pos: [sx * (w / 2 - 0.08), 0, 0] }); part(g, side, 'Hông gỗ óc chó', V(sx * 1.2, 0, 0)); });
  const front = mesh(plateGeo(w - 0.4, h - 0.5, 0.15, 0.04), mats.linen, { pos: [0, 0, d / 2 + 0.005] });
  part(g, front, 'Mặt vải lanh', V(0, 0, 2.6));
  [1.35, -1.25].forEach((y, i) => {
    const wf = driver(1.15, mats); wf.position.set(0, y, d / 2 - 0.3); part(g, wf, i ? 'Woofer 6,5" dưới' : 'Woofer 6,5" trên', V(0, 0, 1.6), { internal: true }); g.userData.cones.push(wf.userData.cone);
    const ring = mesh(G('twr', () => new THREE.TorusGeometry(1.32, 0.045, 16, 128)), mats.ledWarm.clone(), { pos: [0, y, 0.05] });
    front.add(ring); g.userData.leds.push(ring);
    const ring2 = mesh(G('twr2', () => new THREE.TorusGeometry(1.42, 0.03, 12, 128)), mats.frame, { pos: [0, y, 0.05] }); front.add(ring2);
  });
  const lg = logoDecal(0.9, 0.22, M.KNOB[opts.knob] || M.KNOB.champagne, mats); lg.position.set(0, 2.85, 0.045); front.add(lg);
  // tay cầm trên đỉnh + tay kéo
  const handle = new THREE.Group();
  handle.add(mesh(rbox(1.6, 0.12, 0.4, 0.05, 3), mats.frame, { pos: [0, h / 2 + 0.06, 0] }));
  const tele = new THREE.Group();
  [-0.8, 0.8].forEach((x) => tele.add(mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.6, 20), mats.knob, { pos: [x, h / 2 + 0.7, -d / 2 + 0.2] })));
  tele.add(mesh(rbox(1.8, 0.16, 0.2, 0.07, 3), M.rubber('#1d1b19'), { pos: [0, h / 2 + 1.5, -d / 2 + 0.2] }));
  handle.add(tele);
  part(g, handle, 'Tay kéo nhôm', V(0, 1.2, 0));
  [-1, 1].forEach((sx) => { const wh = mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.26, 40), mats.rubber, { rot: [0, 0, Math.PI / 2], pos: [sx * (w / 2 + 0.05), -h / 2 + 0.2, -d / 2 + 0.6] }); g.add(wh); g.add(mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.28, 30), mats.knob, { rot: [0, 0, Math.PI / 2], pos: [sx * (w / 2 + 0.06), -h / 2 + 0.2, -d / 2 + 0.6] })); });
  g.userData.update = makeUpdater(g, { ledMode: 'pulse' });
  return g;
}

// =====================================================================
// LOA KÉO KARAOKE (dòng thật) — dựng theo "họ" sản phẩm, đúng tỉ lệ bass 3/4/5 tấc
// =====================================================================
function trolley(opts) {
  const mats = M.kitKaraoke();
  const bass = opts.bass || 4;
  const style = opts.style || 'g95';
  const vali = style === 'vali';
  // Mỗi mẫu một "chữ ký" riêng: màu thùng, màu dải trên, màu LED
  const SIG = {
    ak: { body: '#141518', band: '#1d1f24', led: 'rainbow', wood: false },
    gd: { body: '#2a1c14', band: '#16171a', led: '#ff5a3c', wood: true },
    bt: { body: '#141518', band: '#2b2e35', led: '#3cc8ff', wood: false },
    bp: { body: '#3a2617', band: '#141518', led: '#ffb43c', wood: true },
    vip: { body: '#141518', band: '#8f949c', led: '#ff3c8c', wood: false },
    g95: { body: '#33221a', band: '#141518', led: '#ff5a3c', wood: true },
    r95: { body: '#2e1f16', band: '#2a2c31', led: '#5aff9a', wood: true },
    vb71: { body: '#141518', band: '#6c7178', led: '#3c8cff', wood: false },
    nb: { body: '#141518', band: '#1d1f24', led: '#ff5a3c', wood: false },
    vb1: { body: '#3b281a', band: '#141518', led: '#3cc8ff', wood: true },
    t12: { body: '#141518', band: '#2b2e35', led: '#ff5a3c', wood: false },
    vali: { body: '#241811', band: '#141518', led: 'rainbow', wood: true },
  }[style] || { body: '#141518', band: '#1d1f24', led: '#ff5a3c' };
  const dims = vali ? [5.6, 3.6, 3.0] : bass === 5 ? [5.6, 8.2, 4.6] : bass === 4 ? [4.8, 7.0, 4.0] : [3.8, 5.4, 3.2];
  const [w, h, d] = dims;
  const g = base('trolley', mats, V(w, h + 2.2, d));
  const bodyMat = SIG.wood ? M.woodMat() : new THREE.MeshPhysicalMaterial({ color: SIG.body, roughness: 0.6, clearcoat: 0.2, clearcoatRoughness: 0.5, envMapIntensity: 0.6 });
  if (SIG.wood) { bodyMat.color = new THREE.Color(SIG.body).multiplyScalar(2.2); }
  const body = mesh(rbox(w, h, d, 0.18, 4), bodyMat);
  part(g, body, 'Thùng gỗ sơn chống trầy', V(0, 0, -1.6));
  const bandMat = M.plastic(SIG.band, 0.35);
  const ledColor = SIG.led === 'rainbow' ? '#ff5a3c' : SIG.led;
  const ledMat = M.glow(ledColor, 2.6);
  // --- Dải trên: họng kèn treble + (mid) + dải LED + logo ---
  const bandH = vali ? h * 0.28 : h * 0.24;
  const bandY = h / 2 - bandH / 2 - 0.22;
  const band = new THREE.Group();
  band.add(mesh(rbox(w - 0.3, bandH, 0.12, 0.08, 3), bandMat));
  const horn = new THREE.Group();
  const hw = Math.min(w * 0.36, 2.0), hh = bandH * 0.62;
  horn.add(mesh(rbox(hw, hh, 0.1, 0.12, 3), M.plastic('#0b0c0e', 0.25)));
  horn.add(mesh(new THREE.CylinderGeometry(hh * 0.12, hh * 0.32, 0.22, 32), M.cone('#16171a'), { rot: [Math.PI / 2, 0, 0], pos: [0, 0, 0.02] }));
  horn.add(mesh(new THREE.SphereGeometry(hh * 0.12, 24, 12), mats.chrome, { pos: [0, 0, -0.04] }));
  horn.position.set(vali ? w * 0.18 : -w * 0.16, 0, 0.07);
  band.add(horn);
  if (bass === 5 || style === 'ak') { const md = driver(bandH * 0.32, { ...mats, cone: M.cone('#3a3d44') }, { rimMat: mats.chrome }); md.position.set(w * 0.27, 0, 0.0); band.add(md); }
  else { const strip = mesh(rbox(w * 0.3, 0.07, 0.04, 0.03, 2), ledMat.clone(), { pos: [w * 0.24, -bandH * 0.18, 0.08] }); band.add(strip); g.userData.leds.push(strip); }
  const lg = logoDecal(Math.min(1.5, w * 0.3), Math.min(0.37, w * 0.075), '#e8ecf1', mats); lg.position.set(w * 0.24, bandH * 0.22, 0.075); band.add(lg);
  band.position.set(0, bandY, d / 2 + 0.01);
  part(g, band, 'Dải treble họng kèn + logo', V(0, 0.6, 1.5));
  // --- Phần bass: lưới kim loại + củ bass nhìn xuyên qua + vòng LED phía trước ---
  const gridTop = bandY - bandH / 2 - 0.12;
  const gridBot = -h / 2 + (vali ? 0.25 : 0.55);
  const gh = gridTop - gridBot, gw = w - 0.36;
  const gy = (gridTop + gridBot) / 2;
  const frame = mesh(frameRing(gw + 0.18, gh + 0.18, 0.16, 0.12, 0.08), SIG.band === '#6c7178' ? bandMat : M.plastic('#202227', 0.3), { pos: [0, gy, d / 2 + 0.02] });
  part(g, frame, 'Viền lưới', V(0, 0, 1.7));
  const gm = M.perforatedMetal('#3b3f47', 'hex', 24, [gw / 2.2, gh / 2.2]);
  gm.metalness = 0.7; gm.roughness = 0.45;
  const grille = mesh(plateGeo(gw, gh, 0.1, 0.02), gm, { pos: [0, gy, d / 2 + 0.03] });
  part(g, grille, 'Lưới kim loại sơn tĩnh điện', V(0, 0, 2.5));
  const R = Math.min(gw, gh) * 0.43;
  const bassX = vali ? -w * 0.22 : 0;
  const cmats = { ...mats, cone: M.cone('#3a3d44'), rubber: M.rubber('#1b1c1f'), dust: mats.chrome };
  const wf = driver(R, cmats, { rimMat: mats.chrome }); wf.position.set(bassX, gy, d / 2 - 0.25);
  part(g, wf, `Loa bass ${bass} tấc`, V(0, 0, 1.2)); g.userData.cones.push(wf.userData.cone);
  if (vali) { const wf2 = driver(R, cmats, { rimMat: mats.chrome }); wf2.position.set(-bassX, gy, d / 2 - 0.25); part(g, wf2, 'Loa bass phải', V(0, 0, 1.2)); g.userData.cones.push(wf2.userData.cone); }
  const ringGeo = G(`kled:${R}`, () => new THREE.TorusGeometry(R * 1.08, 0.05, 12, 128));
  const xs = vali ? [bassX, -bassX] : [bassX];
  xs.forEach((x) => {
    const ring = mesh(ringGeo, ledMat.clone(), { pos: [x, gy, d / 2 + 0.07], cast: false });
    g.add(ring); g.userData.leds.push(ring);
    const ring2 = mesh(G(`kled2:${R}`, () => new THREE.TorusGeometry(R * 1.16, 0.02, 10, 128)), mats.chrome, { pos: [x, gy, d / 2 + 0.065] }); g.add(ring2);
  });
  // --- Bảng điều khiển trên đỉnh + 2 micro ---
  const panel = new THREE.Group();
  panel.add(mesh(rbox(w * 0.82, 0.08, d * 0.46, 0.04, 3), mats.panel));
  const scrTex = T.lcd(style === 'ak' ? 'AK-18' : 'BT-05');
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.2, w * 0.075), new THREE.MeshStandardMaterial({ map: scrTex, emissive: '#ffffff', emissiveMap: scrTex, emissiveIntensity: 0.9, roughness: 0.2 }));
  scr.rotation.x = -Math.PI / 2; scr.position.set(-w * 0.26, 0.045, 0); panel.add(scr);
  const kl = ['MIC', 'ECHO', 'BASS', 'TREBLE', 'MASTER'];
  for (let i = 0; i < 5; i++) {
    const kn = knob(0.13, 0.16, { knob: mats.knob, knurl: mats.knob }, { indicator: true });
    kn.position.set(-w * 0.05 + i * w * 0.095, 0.04, 0.05);
    kn.add(mesh(new THREE.CircleGeometry(0.07, 32), mats.knobCap, { rot: [-Math.PI / 2, 0, 0], pos: [0, 0.162, 0] }));
    kn.userData.label = kl[i];
    panel.add(kn); g.userData.knobs.push(kn);
  }
  [-1, 1].forEach((sx, i) => {
    const mic = new THREE.Group();
    mic.add(mesh(new THREE.CylinderGeometry(0.13, 0.09, 1.5, 32), mats.mic));
    mic.add(mesh(new THREE.SphereGeometry(0.22, 32, 20), mats.micHead, { pos: [0, 0.86, 0] }));
    mic.add(mesh(new THREE.TorusGeometry(0.17, 0.03, 12, 40), mats.chrome, { rot: [Math.PI / 2, 0, 0], pos: [0, 0.72, 0] }));
    mic.rotation.z = Math.PI / 2; mic.position.set(sx * w * 0.2, 0.16, -d * 0.16 - i * 0.02);
    panel.add(mic);
  });
  panel.position.set(0, h / 2 + 0.03, 0);
  part(g, panel, 'Bảng điều khiển + 2 micro không dây', V(0, 1.2, 0));
  // --- Tay kéo, bánh xe, tay nắm ---
  const tele = new THREE.Group();
  [-1, 1].forEach((sx) => tele.add(mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.4, 20), mats.chrome, { pos: [sx * w * 0.32, h / 2 + 1.1, -d / 2 + 0.12] })));
  tele.add(mesh(rbox(w * 0.74, 0.22, 0.26, 0.09, 3), mats.rubber, { pos: [0, h / 2 + 2.3, -d / 2 + 0.12] }));
  part(g, tele, 'Tay kéo ống lồng', V(0, 1.4, -0.6));
  [-1, 1].forEach((sx) => {
    g.add(mesh(new THREE.CylinderGeometry(0.48, 0.48, 0.34, 40), mats.rubber, { rot: [0, 0, Math.PI / 2], pos: [sx * (w / 2 - 0.1), -h / 2 + 0.3, -d / 2 + 0.5] }));
    g.add(mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.36, 30), mats.alu, { rot: [0, 0, Math.PI / 2], pos: [sx * (w / 2 - 0.1), -h / 2 + 0.3, -d / 2 + 0.5] }));
    g.add(mesh(rbox(0.18, 0.5, 1.2, 0.08, 3), M.plastic('#202227', 0.35), { pos: [sx * (w / 2 + 0.06), h * 0.3, 0] }));
  });
  [-1, 1].forEach((sx) => g.add(mesh(new THREE.CylinderGeometry(0.2, 0.24, 0.16, 24), mats.rubber, { pos: [sx * (w / 2 - 0.5), -h / 2 - 0.05, d / 2 - 0.5] })));
  internals(g, mats, { w: w * 0.6, h: h * 0.6, d });
  g.userData.update = makeUpdater(g, { ledMode: SIG.led === 'rainbow' ? 'karaoke' : 'pulse' });
  return g;
}

// =====================================================================
// PHỤ KIỆN
// =====================================================================
function accessory(opts) {
  const kind = opts.kind;
  const mats = M.kit(opts.finish || 'oc-cho', opts.knob, opts.strap);
  const g = base('acc', mats, V(1.6, 1.4, 1));
  if (kind === 'bag') {
    const l = M.leatherMat(opts.finish === 'huyen' ? '#1f1d1c' : '#7a4a2e');
    const b = mesh(rbox(1.5, 1.2, 0.6, 0.28, 8), l); g.add(b);
    const flap = mesh(rbox(1.52, 0.6, 0.04, 0.02, 3), l, { pos: [0, 0.32, 0.31], rot: [0.08, 0, 0] }); g.add(flap);
    g.add(mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.04, 24), mats.knob, { rot: [Math.PI / 2, 0, 0], pos: [0, 0.1, 0.34] }));
    g.add(strapMesh([[-0.6, 0.5, 0], [-0.5, 1.2, 0], [0, 1.4, 0], [0.5, 1.2, 0], [0.6, 0.5, 0]], 0.1, 0.03, l));
  } else if (kind === 'strap') {
    const l = M.leatherMat(M.STRAP[opts.strap] || M.STRAP.bo);
    g.add(strapMesh([[-1.2, 0, 0], [-0.9, 0.6, 0.2], [0, 0.85, 0], [0.9, 0.6, -0.2], [1.2, 0, 0]], 0.16, 0.035, l));
    [-1.2, 1.2].forEach((x) => g.add(mesh(rbox(0.22, 0.12, 0.08, 0.03, 3), mats.knob, { pos: [x, -0.05, 0] })));
  } else if (kind === 'stand') {
    const wm = M.woodMat();
    g.add(mesh(rbox(2.8, 0.12, 1.6, 0.05, 4), wm, { pos: [0, 0.6, 0] }));
    [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => g.add(mesh(new THREE.CylinderGeometry(0.06, 0.04, 1.2, 16), wm, { pos: [sx * 1.2, 0, sz * 0.65], rot: [sz * 0.08, 0, -sx * 0.08] }))));
    g.add(mesh(rbox(2.4, 0.06, 0.04, 0.02, 2), mats.knob, { pos: [0, 0.6, 0.81] }));
  } else if (kind === 'mount') {
    const m = M.metal('#2b2f36', { rough: 0.45, brushed: 'linear' });
    g.add(mesh(rbox(2.4, 0.6, 0.06, 0.03, 3), m, { pos: [0, 0.3, -0.4] }));
    [-0.9, 0.9].forEach((x) => g.add(mesh(rbox(0.12, 0.06, 0.9, 0.02, 2), m, { pos: [x, 0.03, 0] })));
  } else if (kind === 'battery') {
    g.add(mesh(rbox(1.4, 0.5, 0.8, 0.08, 4), mats.battery));
    g.add(mesh(rbox(1.42, 0.12, 0.82, 0.04, 3), mats.knob, { pos: [0, 0.2, 0] }));
    for (let i = 0; i < 4; i++) g.add(mesh(new THREE.BoxGeometry(0.16, 0.02, 0.06), M.glow('#7CE3A8', 1.5), { pos: [-0.36 + i * 0.24, 0.27, 0.3] }));
  } else if (kind === 'mic') {
    const km = M.kitKaraoke();
    [-0.4, 0.4].forEach((x, i) => {
      const mic = new THREE.Group();
      mic.add(mesh(new THREE.CylinderGeometry(0.13, 0.09, 1.5, 32), km.mic));
      mic.add(mesh(new THREE.SphereGeometry(0.22, 32, 20), km.micHead, { pos: [0, 0.86, 0] }));
      mic.add(mesh(new THREE.TorusGeometry(0.17, 0.03, 12, 40), km.chrome, { rot: [Math.PI / 2, 0, 0], pos: [0, 0.72, 0] }));
      mic.position.set(x, 0, 0); mic.rotation.z = i ? -0.25 : 0.25;
      g.add(mic);
    });
  } else if (kind === 'cover') {
    g.add(mesh(rbox(1.6, 2.2, 1.3, 0.25, 6), M.linenMat('#2a3442')));
    g.add(mesh(rbox(1.7, 0.08, 1.4, 0.03, 3), M.rubber('#1d2531'), { pos: [0, -1.06, 0] }));
  } else if (kind === 'remote') {
    const km = M.kitKaraoke();
    g.add(mesh(rbox(0.5, 1.5, 0.12, 0.08, 4), km.panel, { rot: [-0.9, 0, 0] }));
    for (let i = 0; i < 12; i++) g.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.03, 16), i === 0 ? km.led : km.knob, { rot: [-0.9 + Math.PI / 2, 0, 0], pos: [-0.12 + (i % 3) * 0.12, 0.35 - Math.floor(i / 3) * 0.13, 0.05 + Math.floor(i / 3) * 0.16] }));
  }
  g.userData.update = () => {};
  return g;
}

// ---------- Hiệu ứng theo âm thanh ----------
function makeUpdater(g, { coneAmp = 0.06, ledMode = 'breath' } = {}) {
  const leds = g.userData.leds;
  const base = leds.map((l) => (l.material.emissiveIntensity ?? 1));
  return (t, bands = { bass: 0, mid: 0, treble: 0 }) => {
    for (const c of g.userData.cones) c.position.y = -bands.bass * coneAmp * (0.6 + 0.4 * Math.sin(t * 60));
    leds.forEach((l, i) => {
      if (!l.material.emissive) return;
      if (ledMode === 'karaoke') {
        const hue = (t * 0.08 + i * 0.5 + bands.bass * 0.2) % 1;
        l.material.emissive.setHSL(hue, 0.85, 0.55);
        l.material.emissiveIntensity = 1.2 + bands.bass * 4;
      } else if (ledMode === 'pulse') {
        l.material.emissiveIntensity = base[i] * (0.6 + bands.bass * 2.2 + 0.2 * Math.sin(t * 2));
      } else {
        l.material.emissiveIntensity = base[i] * (0.65 + 0.35 * Math.sin(t * 1.6 + i * 0.4) + bands.mid * 1.5);
      }
    });
  };
}

const BUILDERS = { halong, hifi, pebble, wave, stone, bar, cube, tower, trolley, acc: accessory };

/**
 * Dựng model theo cấu hình sản phẩm.
 * @param {object} model {type, ...} từ dữ liệu sản phẩm
 * @param {object} opts {finish, knob, strap, engraving}
 */
export function buildModel(model, opts = {}) {
  const fn = BUILDERS[model.type] || halong;
  const g = fn({ ...model, ...opts });
  g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  // Chuẩn hoá: đặt đáy chạm y = 0
  const box = new THREE.Box3().setFromObject(g);
  g.userData.bounds = box;
  g.userData.lift = -box.min.y;
  return g;
}

// Đổi hoàn thiện mà không dựng lại toàn bộ (giữ hướng xoay)
export function applyFinish(g, finish, knob) {
  const f = M.FINISH[finish];
  if (!f || !g.userData.mats) return;
  const mats = g.userData.mats;
  if (!f.wood && mats.body && mats.body.color && !mats.body.map) M.tweenColor(mats.body, f.lacquer);
  if (!f.wood && mats.side && mats.side.color && !mats.side.map) M.tweenColor(mats.side, f.lacquer);
  if (mats.deep) M.tweenColor(mats.deep, f.deep);
  if (mats.linen) M.tweenColor(mats.linen, f.linen);
  if (knob && M.KNOB[knob]) { M.tweenColor(mats.knob, M.KNOB[knob]); M.tweenColor(mats.knurl, M.KNOB[knob]); M.tweenColor(mats.frame, M.KNOB[knob]); }
}

export function setExplode(g, k) {
  for (const p of g.userData.parts) {
    const e = p.userData.explode;
    p.position.copy(p.userData.home).addScaledVector(e, k);
  }
}

export function partList(g) {
  return g.userData.parts.map((p) => p.name);
}
