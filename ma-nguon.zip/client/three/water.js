// Shader mặt nước + bầu trời cho hero. Toàn bộ tham số được chú thích để trình bày trong báo cáo.
import * as THREE from 'three';

export const MAX_RIPPLES = 10;

// Hàm độ cao dùng chung cho shader (GLSL) và CPU (để loa nổi đúng theo sóng)
const GERSTNER = [
  // [hướng x, hướng z, bước sóng, biên độ, tốc độ]
  [1.0, 0.25, 9.0, 0.075, 0.9],
  [-0.4, 1.0, 5.5, 0.05, 1.2],
  [0.7, -0.7, 3.2, 0.028, 1.6],
  [-0.9, -0.3, 1.9, 0.012, 2.1],
];

export const waterVertex = /* glsl */ `
uniform float uTime;       // thời gian (giây)
uniform float uCalm;       // 1 = sóng bình thường, giảm dần khi cuộn trang (mặt nước dịu lại)
uniform float uBass;       // năng lượng dải bass 0–1 (từ AnalyserNode)
uniform vec2  uSpeaker;    // vị trí loa trên mặt nước (x, z)
uniform vec4  uRipples[${MAX_RIPPLES}]; // các nguồn sóng tròn: (x, z, thời điểm bắt đầu, cường độ)
uniform vec4  uSurge;     // con sóng lớn của đoạn mở đầu: (vị trí đỉnh x, độ cao, bề rộng, –)
varying vec3 vWorld;
varying vec3 vNormal;
varying float vFoam;
varying float vSurge;

const int NW = ${GERSTNER.length};
const vec4 W[NW] = vec4[NW](${GERSTNER.map((g) => `vec4(${g[0].toFixed(3)}, ${g[1].toFixed(3)}, ${g[2].toFixed(3)}, ${g[3].toFixed(3)})`).join(', ')});
const float S[NW] = float[NW](${GERSTNER.map((g) => g[4].toFixed(3)).join(', ')});

float heightAt(vec2 p) {
  float h = 0.0;
  // 1) Tổng các sóng Gerstner biên độ nhỏ: mặt nước êm, chuyển động tự nhiên
  for (int i = 0; i < NW; i++) {
    vec2 d = normalize(W[i].xy);
    float k = 6.2831853 / W[i].z;
    h += W[i].w * uCalm * sin(dot(d, p) * k + uTime * S[i]);
  }
  // 2) Các vòng sóng tròn lan ra từ nguồn (nhịp bass, con trỏ chuột, cú chạm)
  for (int i = 0; i < ${MAX_RIPPLES}; i++) {
    vec4 r = uRipples[i];
    float age = uTime - r.z;
    if (r.w <= 0.0 || age < 0.0 || age > 6.0) continue;
    float dist = distance(p, r.xy);
    float front = age * 2.6;                                  // tốc độ lan của vòng sóng
    float env = smoothstep(front + 0.6, front - 0.4, dist);  // chỉ có sóng phía sau mép sóng
    h += r.w * env * sin((dist - front) * 4.2) * exp(-dist * 0.22) * exp(-age * 0.75);
  }
  // 3) Hoa văn cymatics quanh loa: sóng đứng hình học khi bass mạnh
  float rr = distance(p, uSpeaker);
  float ang = atan(p.y - uSpeaker.y, p.x - uSpeaker.x);
  h += uBass * 0.07 * cos(rr * 8.0 - uTime * 5.0) * (0.75 + 0.25 * cos(ang * 6.0)) * exp(-rr * 0.75);
  // 4) Đoạn mở đầu: một dải sóng lớn chạy ngang từ trái sang phải (mặt trước dốc hơn mặt sau)
  if (uSurge.y > 0.0) {
    float sx = (p.x - uSurge.x) / (p.x > uSurge.x ? uSurge.z * 0.55 : uSurge.z);
    h += uSurge.y * exp(-sx * sx) * (0.85 + 0.15 * sin(p.y * 0.6 + uTime * 1.3));
  }
  return h;
}

void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  float h = heightAt(wp.xz);
  // Pháp tuyến bằng sai phân hữu hạn
  float e = 0.06;
  float hx = heightAt(wp.xz + vec2(e, 0.0));
  float hz = heightAt(wp.xz + vec2(0.0, e));
  vNormal = normalize(vec3(-(hx - h) / e, 1.0, -(hz - h) / e));
  wp.y += h;
  vWorld = wp.xyz;
  vFoam = clamp(h * 6.0, 0.0, 1.0);
  vSurge = 0.0;
  if (uSurge.y > 0.0) { float sx = (wp.x - uSurge.x) / (wp.x > uSurge.x ? uSurge.z * 0.55 : uSurge.z); vSurge = uSurge.y * exp(-sx * sx); }
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

export const skyChunk = /* glsl */ `
uniform vec3 uZenith;   // màu đỉnh trời (xanh biển)
uniform vec3 uHorizon;  // màu chân trời (trắng ngà, hơi sương)
uniform vec3 uSunDir;   // hướng mặt trời (thấp, phía trước bên phải → vệt nắng trên mặt biển)
uniform vec3 uSunCol;   // màu nắng (trang chủ: vàng cam hoàng hôn)
uniform vec3 uHaze;     // màu sương sát chân trời
uniform float uWarm;    // 0 = trưa trong xanh, 1 = ánh hoàng hôn
uniform float uVivid;
uniform float uTime;
float hash12(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x), mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
  float h = 0.0, a = 0.5;
  mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 5; i++) { h += a * vnoise(p); p = m * p; a *= 0.5; }
  return h;
}
float fbm3(vec2 p) {
  float h = 0.0, a = 0.5;
  mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 3; i++) { h += a * vnoise(p); p = m * p; a *= 0.5; }
  return h;
}
vec3 skyColor(vec3 dir) {
  vec3 sd = normalize(uSunDir);
  float y = clamp(dir.y, -1.0, 1.0);
  float t = pow(smoothstep(0.0, 0.13, y), 0.7);
  vec3 c = mix(uHorizon, uZenith, t);
  float sun = max(dot(normalize(dir), sd), 0.0);
  // dải sương ấm sát chân trời, đậm hơn về phía mặt trời
  c = mix(c, uHaze, (1.0 - smoothstep(0.0, 0.06, y)) * (0.15 + 0.6 * pow(sun, 4.0)));
  // hoàng hôn: quầng vàng cam loang quanh mặt trời, nhạt dần lên cao → trời vẫn xanh là chủ đạo
  float low = 1.0 - smoothstep(0.0, 0.34, y);
  c = mix(c, vec3(1.0, 0.77, 0.52), uWarm * low * (0.8 * pow(sun, 5.0) + 0.3 * pow(sun, 1.4)));
  c = mix(c, vec3(0.99, 0.87, 0.72), uWarm * (1.0 - smoothstep(0.0, 0.09, y)) * 0.5);
  // mây tầng cao mỏng (cirrus) trôi chậm
  if (y > 0.015) {
    vec2 cp = dir.xz / (y + 0.08) * 0.9 + vec2(uTime * 0.012, uTime * 0.004);
    float cl = smoothstep(0.6, 0.86, fbm(cp * vec2(1.0, 2.6)));
    c = mix(c, vec3(1.0, 0.99, 0.97) + vec3(0.06, 0.04, 0.0) * pow(sun, 6.0) + uWarm * vec3(0.0, -0.09, -0.2) * pow(sun, 2.0), cl * 0.55 * smoothstep(0.015, 0.12, y));
  }
  // đĩa mặt trời + quầng sáng + tia nắng (crepuscular rays)
  vec3 sunCol = uSunCol;
  c += sunCol * (pow(sun, 2600.0) * 14.0 + pow(sun, 300.0) * 1.1 + pow(sun, 40.0) * 0.3 + pow(sun, 8.0) * 0.06);
  vec3 tang = normalize(cross(sd, vec3(0.0, 1.0, 0.0)));
  vec3 bit = cross(tang, sd);
  float ang = atan(dot(dir, bit), dot(dir, tang));
  float rays = 0.55 + 0.45 * sin(ang * 23.0 + 0.4 * sin(uTime * 0.25)) * sin(ang * 9.0 - uTime * 0.07);
  c += sunCol * pow(sun, 14.0) * rays * 0.22;
  // nửa dưới (phản chiếu): xanh nước
  if (y < 0.0) c = mix(uHorizon, vec3(0.5, 0.66, 0.82), clamp(-y * 2.0, 0.0, 1.0));
  return c;
}
// Bầu trời trang chủ: màu lấy theo ảnh biển mẫu (chân trời #3CABCF → #078CE2 → đỉnh #0662BE),
// mây trắng trôi chậm, quầng nắng hoàng hôn vàng cam dịu quanh mặt trời. Ghi thẳng ra màn hình (sRGB).
vec3 vividSky(vec3 dir) {
  vec3 sd = normalize(uSunDir);
  float y = max(dir.y, 0.0);
  vec3 c = mix(vec3(0.2, 0.64, 0.86), vec3(0.17, 0.62, 0.88), smoothstep(0.0, 0.04, y));
  c = mix(c, vec3(0.02, 0.52, 0.9), smoothstep(0.03, 0.13, y));
  c = mix(c, vec3(0.004, 0.412, 0.824), smoothstep(0.12, 0.3, y));
  c = mix(c, vec3(0.024, 0.384, 0.745), smoothstep(0.3, 0.6, y));
  float sun = max(dot(dir, sd), 0.0);
  // mây tích (cumulus) trắng, đáy hơi xanh xám
  vec2 cp = dir.xz / (y + 0.12) * 0.55 + vec2(uTime * 0.01, uTime * 0.003);
  float d = fbm(cp) * 0.75 + fbm(cp * 2.3 + 7.1) * 0.25;
  float cov = smoothstep(0.52, 0.72, d) * smoothstep(0.004, 0.05, y) * (1.0 - smoothstep(0.32, 0.6, y));
  float lit = smoothstep(0.45, 0.85, fbm(cp * 1.7 + vec2(3.0, 1.0)) + (d - 0.6));
  vec3 cloud = mix(vec3(0.565, 0.769, 0.871), vec3(0.97, 0.98, 0.99), lit);
  cloud = mix(cloud, vec3(1.0, 0.86, 0.66), pow(sun, 5.0) * 0.6);
  c = mix(c, cloud, cov * 0.92);
  // hoàng hôn dịu: quầng vàng cam sát chân trời quanh mặt trời
  float low = 1.0 - smoothstep(0.0, 0.22, y);
  c = mix(c, vec3(1.0, 0.8, 0.55), low * (0.5 * pow(sun, 8.0) + 0.07 * pow(sun, 2.0)));
  c += vec3(1.0, 0.85, 0.62) * (pow(sun, 2600.0) * 3.0 + pow(sun, 300.0) * 0.6 + pow(sun, 40.0) * 0.18);
  return min(c, vec3(1.0));
}`;

export const waterFragment = /* glsl */ `
uniform vec3 uDeep;        // màu nước sâu
uniform vec3 uShallow;     // màu nước nông (gần mặt)
uniform float uTreble;     // dải treble → độ lấp lánh
uniform sampler2D uReflect;// ảnh phản chiếu của loa (render phản chiếu qua mặt nước)
uniform vec2 uResolution;
uniform float uFogNear;
uniform float uFogFar;
varying vec3 vWorld;
varying vec3 vNormal;
varying float vFoam;
varying float vSurge;
${skyChunk}

// Gợn sóng li ti (capillary waves): 2 lớp nhiễu trôi ngược chiều → pháp tuyến chi tiết từng điểm ảnh
float microH(vec2 p) {
  vec2 q1 = p * 1.7 + vec2(uTime * 0.32, uTime * 0.21);
  vec2 q2 = p * 3.1 + vec2(-uTime * 0.27, uTime * 0.33);
  return fbm3(q1) + 0.55 * fbm3(q2);
}
vec3 detailNormal(vec2 p, float amp) {
  float e = 0.04;
  float h = microH(p);
  float hx = microH(p + vec2(e, 0.0));
  float hz = microH(p + vec2(0.0, e));
  return normalize(vec3(-(hx - h) / e * amp, 1.0, -(hz - h) / e * amp));
}

void main() {
  float dist = distance(cameraPosition.xz, vWorld.xz);
  vec3 v = normalize(cameraPosition - vWorld);
  vec3 sd = normalize(uSunDir);
  // pháp tuyến sóng lớn (từ vertex) + gợn li ti, mờ dần theo khoảng cách để tránh nhiễu răng cưa
  float amp = 0.22 * exp(-dist * 0.035);
  vec3 dn = detailNormal(vWorld.xz, amp);
  vec3 n = normalize(vec3(vNormal.x + dn.x, vNormal.y, vNormal.z + dn.z));
  // Fresnel Schlick (F0 = 0.02 cho nước): nhìn xiên → phản chiếu nhiều, nhìn thẳng → thấy màu nước
  float fres = 0.02 + 0.98 * pow(1.0 - max(dot(n, v), 0.0), 5.0);
  vec3 r = reflect(-v, n);
  r.y = abs(r.y);
  vec3 refl = skyColor(r);
  // Phản chiếu phẳng của loa, bị méo theo pháp tuyến sóng
  vec2 suv = gl_FragCoord.xy / uResolution + n.xz * 0.06;
  vec4 obj = texture2D(uReflect, suv);
  refl = mix(refl * vec3(0.86, 0.93, 1.0), obj.rgb, obj.a * 0.92);
  // màu thân nước: sâu ở chỗ thấp, sáng ngọc ở đỉnh sóng + tán xạ dưới bề mặt khi ngược nắng
  vec3 body = mix(uShallow, uDeep, clamp(0.35 + n.y * 0.3, 0.0, 1.0));
  float sss = pow(max(dot(v, -sd) * 0.5 + 0.5, 0.0), 3.0) * (0.35 + vFoam);
  body += vec3(0.30, 0.62, 0.64) * sss * 0.22;
  refl *= mix(vec3(1.0), vec3(0.8, 0.93, 1.0), uVivid * 0.6);
  vec3 col = mix(body, refl, clamp(fres * 1.1 + 0.06, 0.0, 1.0) * (1.0 - 0.6 * uVivid));
  col *= 0.94 + 0.12 * n.y;
  col += vec3(1.0) * vFoam * 0.05;
  // Sương mù về phía chân trời → mặt nước "vô tận"; về phía mặt trời sương ấm hơn
  float fog = smoothstep(uFogNear, uFogFar, dist);
  vec3 fogCol = mix(uHorizon, uHaze, pow(max(dot(-v, sd), 0.0), 8.0) * 0.8);
  fogCol = mix(fogCol, mix(vec3(0.22, 0.6, 0.82), uHaze, pow(max(dot(-v, sd), 0.0), 6.0) * 0.7), uVivid * 0.85);
  col = mix(col, fogCol, fog * 0.92 * (1.0 - 0.45 * uVivid));
  // ánh hoàng hôn trải trên mặt nước về phía mặt trời (vàng cam dịu, phần còn lại vẫn xanh)
  col = mix(col, vec3(1.0, 0.8, 0.6), uWarm * pow(max(dot(-v, sd), 0.0), 4.0) * 0.38);
  // Vệt nắng trên mặt biển (vẽ sau sương để luôn rực sáng): quầng rộng + đốm lấp lánh (glitter)
  float sdot = max(dot(r, sd), 0.0);
  vec3 sunCol = uSunCol;
  float path = pow(sdot, 40.0) * 0.5 + pow(sdot, 400.0) * 3.5;
  float glint = smoothstep(0.78, 1.0, hash12(floor(vWorld.xz * vec2(10.0, 4.0)) + floor(uTime * 7.0)));
  col += sunCol * (path + glint * pow(sdot, 90.0) * 3.0) * (1.0 + uTreble * 2.5);
  // Con đường nắng lấp lánh từ chân trời về phía người xem (hẹp ở xa, loe rộng khi lại gần)
  vec3 vd = -v;
  float az = dot(normalize(vd.xz), normalize(sd.xz));
  float wdt = 0.0015 + 0.09 * max(-vd.y, 0.0);
  float pathMask = smoothstep(1.0 - wdt * 2.2, 1.0 - wdt * 0.2, az);
  float sparkle = smoothstep(0.45, 0.9, fbm3(vWorld.xz * vec2(2.6, 0.9) + vec2(uTime * 0.5, uTime * 0.15)));
  float twinkle = smoothstep(0.7, 1.0, hash12(floor(vWorld.xz * vec2(12.0, 5.0)) + floor(uTime * 8.0)));
  col += sunCol * pathMask * (0.18 + 1.6 * sparkle + 2.4 * twinkle * sparkle) * (0.6 + 0.4 * fog) * (1.0 - 0.3 * uVivid);
  // Trang chủ: màu nước xanh ngọc trong (phương án D: #A1EBED gần → #A4EDEF xa),
  // chỉ thêm gợn sóng, vệt nắng và chút ánh hoàng hôn về phía mặt trời
  vec3 tq = vec3(0.0);
  if (uVivid > 0.5) {
    // màu ghi thẳng ra màn hình (hệ sRGB), không qua tone mapping → đúng sắc ảnh mẫu
    tq = mix(vec3(0.631, 0.922, 0.929), vec3(0.643, 0.929, 0.937), smoothstep(8.0, 90.0, dist));
    float wv = (vNormal.x + vNormal.z) * 0.8 + (dn.x + dn.z) * 2.0;
    tq *= 0.9 + 0.14 * smoothstep(-0.25, 0.25, wv);
    tq += vec3(0.8) * vFoam * 0.05;
    // bọt trắng lăn tăn trên đỉnh con sóng mở đầu, mặt trước sóng xanh đậm hơn một chút
    float froth = smoothstep(0.3, 0.75, fbm3(vWorld.xz * vec2(2.2, 3.4) + vec2(uTime * 1.5, 0.0)));
    tq *= 1.0 - 0.14 * smoothstep(0.04, 0.25, vSurge);
    tq = mix(tq, vec3(0.98, 1.0, 1.0), smoothstep(0.2, 0.48, vSurge) * (0.35 + 0.5 * froth));
    tq = mix(tq, pow(max(obj.rgb, vec3(0.0)), vec3(0.4545)), obj.a * clamp(fres * 1.4 + 0.25, 0.0, 0.85));
    tq = mix(tq, vec3(1.0, 0.8, 0.58), pow(max(dot(-v, sd), 0.0), 6.0) * 0.14 * fog);
    tq += sunCol * (pow(sdot, 600.0) * 1.2 + glint * pow(sdot, 120.0) * 0.9);
    tq += sunCol * pathMask * (0.03 + 0.35 * sparkle + 0.8 * twinkle * sparkle) * (0.5 + 0.5 * fog);
  }
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  if (uVivid > 0.5) gl_FragColor = vec4(min(tq, vec3(1.0)), 1.0);
}`;

export const skyVertex = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize((modelMatrix * vec4(position, 1.0)).xyz - cameraPosition);
  vec4 p = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
  gl_Position = p.xyww;
}`;
export const skyFragment = /* glsl */ `
varying vec3 vDir;
${skyChunk}
void main() {
  gl_FragColor = vec4(skyColor(normalize(vDir)), 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  if (uVivid > 0.5) gl_FragColor = vec4(vividSky(normalize(vDir)), 1.0);
}`;

// Bản CPU của hàm độ cao (để loa nhấp nhô đúng theo mặt nước)
export function heightAtCPU(x, z, t, calm, ripples, bass, speaker) {
  let h = 0;
  for (let i = 0; i < GERSTNER.length; i++) {
    const [dx, dz, wl, a, s] = GERSTNER[i];
    const len = Math.hypot(dx, dz);
    const k = (Math.PI * 2) / wl;
    h += a * calm * Math.sin(((dx / len) * x + (dz / len) * z) * k + t * s);
  }
  for (const r of ripples) {
    const age = t - r.z;
    if (r.w <= 0 || age < 0 || age > 6) continue;
    const dist = Math.hypot(x - r.x, z - r.y);
    const front = age * 2.6;
    const e0 = front + 0.6, e1 = front - 0.4;
    let env = Math.min(1, Math.max(0, (dist - e0) / (e1 - e0)));
    env = env * env * (3 - 2 * env);
    h += r.w * env * Math.sin((dist - front) * 4.2) * Math.exp(-dist * 0.22) * Math.exp(-age * 0.75);
  }
  const rr = Math.hypot(x - speaker.x, z - speaker.y);
  h += bass * 0.07 * Math.cos(rr * 8 - t * 5) * Math.exp(-rr * 0.75);
  return h;
}

export function makeWater({ segments = 256, size = 260 } = {}) {
  const geo = new THREE.PlaneGeometry(size, size, segments, segments);
  geo.rotateX(-Math.PI / 2);
  const uniforms = {
    uTime: { value: 0 }, uCalm: { value: 1 }, uBass: { value: 0 }, uTreble: { value: 0 },
    uSpeaker: { value: new THREE.Vector2() },
    uRipples: { value: Array.from({ length: MAX_RIPPLES }, () => new THREE.Vector4(0, 0, -100, 0)) },
    uSurge: { value: new THREE.Vector4(0, 0, 1.6, 0) },
    uDeep: { value: new THREE.Color('#3B78B5') }, uShallow: { value: new THREE.Color('#7DB6E2') },
    uZenith: { value: new THREE.Color('#4F93D6') }, uHorizon: { value: new THREE.Color('#E1ECF6') },
    uSunDir: { value: new THREE.Vector3(0.42, 0.075, -1).normalize() },
    uSunCol: { value: new THREE.Color(1.0, 0.935, 0.79) }, uHaze: { value: new THREE.Color(1.0, 0.95, 0.86) }, uWarm: { value: 0 }, uVivid: { value: 0 },
    uReflect: { value: null }, uResolution: { value: new THREE.Vector2(1, 1) },
    uFogNear: { value: 30 }, uFogFar: { value: 130 },
  };
  const mat = new THREE.ShaderMaterial({ vertexShader: waterVertex, fragmentShader: waterFragment, uniforms });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  return { mesh, uniforms };
}

export function makeSky(uniforms) {
  const mat = new THREE.ShaderMaterial({
    vertexShader: skyVertex, fragmentShader: skyFragment, side: THREE.BackSide, depthWrite: false,
    uniforms: { uZenith: uniforms.uZenith, uHorizon: uniforms.uHorizon, uSunDir: uniforms.uSunDir, uTime: uniforms.uTime, uSunCol: uniforms.uSunCol, uHaze: uniforms.uHaze, uWarm: uniforms.uWarm, uVivid: uniforms.uVivid },
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(300, 32, 16), mat);
  m.frustumCulled = false;
  m.renderOrder = -1;
  return m;
}
