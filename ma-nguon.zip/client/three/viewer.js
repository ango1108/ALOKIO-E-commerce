// Trình xem sản phẩm 3D: xoay/zoom có giới hạn, tự xoay chậm, đổi hoàn thiện, LED theo nhạc.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createStage, place, frame, reducedMotion } from './stage.js';
import { buildModel, applyFinish } from './models.js';
import * as audio from '../audio.js';

export function mountViewer(canvas, { model, finish, knob = 'champagne', strap = 'bo', engraving = '', autoRotate = true, interactive = true, dark = false, bloom = false, azim = -0.55, elev = 0.28, padding = 1.3, onReady } = {}) {
  const stage = createStage(canvas, { fov: 30, bloom, envOpts: dark ? { warm: 0.7, cool: 1.3 } : {}, onFrame, exposure: dark ? 0.95 : 1.0 });
  const { scene, camera, renderer } = stage;
  if (dark) { stage.ground.material.opacity = 0.35; stage.hemi.intensity = 0.25; }
  let obj = null;
  let size = new THREE.Vector3();
  let controls = null;
  let target = new THREE.Vector3();
  const rm = reducedMotion();
  let idle = 0;

  function build(opts) {
    if (obj) { scene.remove(obj); obj.traverse((o) => { if (o.isMesh) o.geometry && !o.geometry.userData?.shared; }); }
    obj = buildModel(model, opts);
    scene.add(obj);
    size = place(stage, obj);
    const f = frame(camera, size, { padding, azim, elev });
    target.set(0, f.ty, 0);
    if (controls) { controls.target.copy(target); controls.minDistance = f.dist * 0.55; controls.maxDistance = f.dist * 1.6; controls.update(); }
    // bóng đổ theo kích thước
    const k = stage.key;
    const r = Math.max(size.x, size.y, size.z);
    k.shadow.camera.left = -r * 2.5; k.shadow.camera.right = r * 2.5; k.shadow.camera.top = r * 2.5; k.shadow.camera.bottom = -r * 2.5;
    k.position.set(r * 0.7, r * 3, r * 1.4); k.shadow.camera.updateProjectionMatrix();
    stage.renderOnce();
  }
  build({ finish, knob, strap, engraving });

  if (interactive) {
    controls = new OrbitControls(camera, canvas);
  controls.cursorStyle = 'grab'; // con trỏ hình bàn tay: báo hiệu có thể kéo để xoay
    controls.target.copy(target);
    controls.enableDamping = true; controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minPolarAngle = 0.25; controls.maxPolarAngle = Math.PI / 2 - 0.04;
    controls.rotateSpeed = 0.7; controls.zoomSpeed = 0.6;
    controls.autoRotate = autoRotate && !rm; controls.autoRotateSpeed = 0.9;
    const f = frame(camera, size, { padding, azim, elev });
    controls.minDistance = f.dist * 0.55; controls.maxDistance = f.dist * 1.6;
    controls.addEventListener('start', () => { idle = 0; controls.autoRotate = false; });
    controls.addEventListener('end', () => { idle = 0.001; });
    controls.addEventListener('change', () => { if (!stage.running) stage.render(); });
    // Ngăn cuộn trang khi zoom bằng con lăn chỉ khi đang giữ Ctrl/khi canvas được focus
    controls.enableZoom = true;
    canvas.addEventListener('wheel', (e) => { if (!e.ctrlKey && !canvas.matches(':focus')) e.stopImmediatePropagation(); }, { capture: true });
    canvas.tabIndex = -1;
  }

  function onFrame(t, dt) {
    if (controls) {
      if (idle > 0) { idle += dt; if (idle > 3 && autoRotate && !rm) { controls.autoRotate = true; idle = 0; } }
      controls.update();
    } else if (autoRotate && obj) obj.rotation.y = Math.sin(t * 0.35) * 0.5;
    if (obj && obj.userData.update) obj.userData.update(t, audio.readBands(t));
  }

  stage.start();
  requestAnimationFrame(() => { canvas.parentElement.classList.add('is-3d'); onReady && onReady(); });

  return {
    stage,
    get object() { return obj; },
    setFinish(f, k) { applyFinish(obj, f, k); },
    rebuild(opts) { build({ finish, knob, strap, engraving, ...opts }); },
    setView(az, el) { const f = frame(camera, size, { padding, azim: az, elev: el ?? elev }); if (controls) { controls.target.set(0, f.ty, 0); controls.update(); } },
    snapshot(type = 'image/png') { stage.render(); return renderer.domElement.toDataURL(type); },
    dispose() { controls && controls.dispose(); stage.dispose(); },
  };
}
