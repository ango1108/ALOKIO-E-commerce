// "Sân khấu" 3D dùng chung: renderer, môi trường studio (phản chiếu), ánh sáng, bóng đổ,
// bloom tuỳ chọn, vòng lặp có tạm dừng khi khuất màn hình / tab ẩn, độ phân giải thích ứng.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import * as T from './textures.js';

export { reducedMotion, isMobile, liteMode, webglOK } from './support.js';
import { reducedMotion, isMobile } from './support.js';

// Môi trường studio: các softbox phát sáng để sơn mài, nhôm, khảm trai có phản chiếu đẹp
export function studioEnv(renderer, { warm = 1, cool = 1, dark = false } = {}) {
  const scene = new THREE.Scene();
  const room = new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), new THREE.MeshBasicMaterial({ side: THREE.BackSide, color: dark ? '#0b1220' : '#cfd8e3' }));
  scene.add(room);
  const box = (w, h, color, intensity, pos, look = [0, 0, 0]) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity), side: THREE.DoubleSide }));
    m.position.set(...pos); m.lookAt(...look); scene.add(m);
  };
  box(24, 10, '#ffffff', 5.5, [0, 18, 4]);           // softbox trên
  box(4, 22, '#ffffff', 3.8 * cool, [-16, 6, 6]);    // dải sáng trái
  box(4, 22, '#eaf2ff', 3.2 * cool, [16, 6, 2]);     // dải sáng phải (lạnh)
  box(16, 6, '#fff3df', 1.6 * warm, [0, 2, 18]);     // fill trước ấm
  box(30, 6, '#f2e6d2', 0.9 * warm, [0, -8, -10]);   // hắt sáng sàn
  box(3, 3, '#ffffff', 9, [8, 12, 14]);              // điểm highlight
  const pmrem = new THREE.PMREMGenerator(renderer);
  const env = pmrem.fromScene(scene, 0.035).texture;
  pmrem.dispose();
  return env;
}

export function createStage(canvas, opts = {}) {
  const {
    fov = 32, near = 0.1, far = 400, background = null, shadows = true, bloom = false, bloomStrength = 0.35, bloomThreshold = 1.0,
    exposure = 1.0, maxDpr = isMobile() ? 1.25 : 1.5, envOpts = {}, alpha = background == null, onFrame = () => {}, ground = true,
    groundColor = null,
  } = opts;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha, powerPreference: 'high-performance', preserveDrawingBuffer: !!opts.preserve });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = exposure;
  renderer.shadowMap.enabled = shadows;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  let dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
  renderer.setPixelRatio(dpr);
  const scene = new THREE.Scene();
  if (background) scene.background = new THREE.Color(background);
  scene.environment = studioEnv(renderer, envOpts);
  const camera = new THREE.PerspectiveCamera(fov, 1, near, far);

  // Ánh sáng: key có bóng, hemisphere fill, rim
  const key = new THREE.DirectionalLight('#fff7ec', 2.2);
  key.position.set(6, 12, 8);
  key.castShadow = shadows;
  key.shadow.mapSize.set(isMobile() ? 1024 : 2048, isMobile() ? 1024 : 2048); // điện thoại: bóng đổ nhẹ hơn một nửa bộ nhớ
  key.shadow.camera.left = -12; key.shadow.camera.right = 12; key.shadow.camera.top = 12; key.shadow.camera.bottom = -12;
  key.shadow.camera.near = 1; key.shadow.camera.far = 60;
  key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02; key.shadow.radius = 10; key.shadow.blurSamples = 16;
  scene.add(key);
  const hemi = new THREE.HemisphereLight('#f3f8ff', '#d8cfc2', 0.55);
  scene.add(hemi);
  const rim = new THREE.DirectionalLight('#dbe9ff', 1.1);
  rim.position.set(-8, 6, -10);
  scene.add(rim);

  let groundMesh = null; let contact = null;
  if (ground) {
    groundMesh = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), groundColor ? new THREE.MeshStandardMaterial({ color: groundColor, roughness: 0.9 }) : new THREE.ShadowMaterial({ opacity: 0.12 }));
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);
    contact = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: T.softShadow(), transparent: true, depthWrite: false, opacity: 0.85 }));
    contact.rotation.x = -Math.PI / 2; contact.position.y = 0.003;
    scene.add(contact);
  }

  let composer = null;
  if (bloom && !isMobile()) {
    composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    composer.addPass(new UnrealBloomPass(new THREE.Vector2(256, 256), bloomStrength, 0.6, bloomThreshold));
    composer.addPass(new OutputPass());
  }

  let lastT = performance.now();
  let running = false, visible = true, raf = 0, t = 0;
  const frameTimes = [];
  const rm = reducedMotion();

  function size() {
    const r = canvas.getBoundingClientRect();
    const w = Math.max(1, r.width), h = Math.max(1, r.height);
    renderer.setSize(w, h, false);
    if (composer) composer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  size();
  const ro = new ResizeObserver(() => { size(); if (!running) render(); });
  ro.observe(canvas);

  function render() {
    if (composer) composer.render(); else renderer.render(scene, camera);
  }

  function loop() {
    raf = requestAnimationFrame(loop);
    const nowT = performance.now(); const dt = Math.min((nowT - lastT) / 1000, 0.05); lastT = nowT;
    t += dt;
    onFrame(t, dt);
    render();
    // Độ phân giải thích ứng (trung bình 30 khung hình)
    frameTimes.push(dt);
    if (frameTimes.length >= 30) {
      const avg = frameTimes.reduce((a, b) => a + b, 0) / frameTimes.length;
      frameTimes.length = 0;
      const cap = Math.min(window.devicePixelRatio || 1, maxDpr);
      if (avg > 0.024 && dpr > cap * 0.5) { dpr = Math.max(cap * 0.5, dpr - 0.15); renderer.setPixelRatio(dpr); size(); }
      else if (avg < 0.0145 && dpr < cap) { dpr = Math.min(cap, dpr + 0.1); renderer.setPixelRatio(dpr); size(); }
      stage.fps = 1 / avg;
    }
  }

  function start() {
    if (rm) { onFrame(1.5, 0); render(); return; }
    if (running || !visible || document.hidden) return;
    running = true; lastT = performance.now(); loop();
  }
  function stop() { running = false; cancelAnimationFrame(raf); }

  const io = new IntersectionObserver((es) => {
    visible = es[es.length - 1].isIntersecting; // lấy báo cáo MỚI NHẤT (cuộn nhanh có thể dồn nhiều báo cáo một lúc)
    if (visible) start(); else stop();
  }, { rootMargin: '120px' });
  io.observe(canvas);
  const onVis = () => (document.hidden ? stop() : start());
  document.addEventListener('visibilitychange', onVis);

  const stage = {
    renderer, scene, camera, key, rim, hemi, ground: groundMesh, contact, composer, start, stop, render, size, fps: 60,
    get time() { return t; },
    get running() { return running; },
    setContact(w, d) { if (contact) contact.scale.set(w, d, 1); },
    renderOnce() { onFrame(t, 0); render(); },
    dispose() { stop(); io.disconnect(); ro.disconnect(); document.removeEventListener('visibilitychange', onVis); composer && composer.dispose && composer.dispose(); scene.environment && scene.environment.dispose(); renderer.dispose(); renderer.forceContextLoss(); },
  };
  return stage;
}

// Đặt model lên sân khấu: canh giữa, chạm đất, cập nhật bóng tiếp xúc
export function place(stage, model) {
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= box.min.y;
  stage.setContact(size.x * 1.5, size.z * 1.9);
  return size;
}

// Khung hình camera vừa vặn với vật thể
export function frame(camera, size, { padding = 1.35, elev = 0.32, azim = -0.5, target = null } = {}) {
  // Bán kính theo đường chéo mặt sàn để vật thể không bị cắt khi nhìn chéo 3/4
  const r = Math.max(Math.hypot(size.x, size.z) * 0.92, size.y * 1.15) * padding;
  const dist = r / (2 * Math.tan((camera.fov * Math.PI) / 360)) * (camera.aspect < 1 ? 1.35 / Math.max(camera.aspect, 0.55) : 1);
  const ty = target ? target.y : size.y * 0.48;
  camera.position.set(Math.sin(azim) * Math.cos(elev) * dist, ty + Math.sin(elev) * dist, Math.cos(azim) * Math.cos(elev) * dist);
  camera.lookAt(0, ty, 0);
  return { dist, ty };
}

// Kéo để xoay (chuột hoặc ngón tay): trả về object { spin, tilt } được cập nhật liên tục, có quán tính.
// touch-action: pan-y → trên điện thoại vuốt dọc vẫn cuộn trang, vuốt ngang để xoay.
export function dragSpin(el, { speed = 4, tiltSpeed = 0, clamp = Infinity, onChange, host = el } = {}) {
  const st = { spin: 0, tilt: 0, vel: 0, dragging: false };
  el.style.cursor = 'grab';
  el.style.touchAction = 'pan-y';
  let last = null;
  host.addEventListener('pointerdown', (e) => {
    if (e.button > 0 || (e.target.closest && e.target.closest('a, button, input, select, label'))) return;
    last = { x: e.clientX, y: e.clientY, t: performance.now() };
    st.dragging = true; st.vel = 0;
    try { host.setPointerCapture(e.pointerId); } catch { /* noop */ }
    el.style.cursor = 'grabbing';
  });
  host.addEventListener('pointermove', (e) => {
    if (!st.dragging || !last) return;
    const w = el.clientWidth || 1;
    const dx = (e.clientX - last.x) / w, dy = (e.clientY - last.y) / (el.clientHeight || 1);
    const now = performance.now();
    st.spin = Math.max(-clamp, Math.min(clamp, st.spin + dx * speed));
    if (tiltSpeed) st.tilt = Math.max(-0.35, Math.min(0.35, st.tilt + dy * tiltSpeed));
    st.vel = (dx * speed) / Math.max(8, now - last.t) * 16;
    last = { x: e.clientX, y: e.clientY, t: now };
    onChange && onChange(st);
  });
  const up = () => { if (!st.dragging) return; st.dragging = false; last = null; el.style.cursor = 'grab'; };
  host.addEventListener('pointerup', up);
  host.addEventListener('pointercancel', up);
  // gọi mỗi khung hình để có quán tính
  st.step = (dt = 1 / 60) => {
    if (st.dragging || Math.abs(st.vel) < 1e-4) return false;
    st.spin = Math.max(-clamp, Math.min(clamp, st.spin + st.vel));
    st.vel *= Math.pow(0.04, dt);
    onChange && onChange(st);
    return true;
  };
  return st;
}
