// Texture dựng sẵn (bản 23/11).
// Lúc build, tools/bake-textures chạy website ở chế độ window.__ALK_BAKE và lưu mọi texture vẽ bằng canvas
// thành ảnh img/tex/*.webp kèm "bản kê" (window.__ALK_TEXMAP, chèn đầu js/alokio-3d.js).
// Lúc chạy thật, alkBake(key, gen) trả về texture tạm 2×2 (màu trung bình) rồi thay bằng ảnh dựng sẵn khi tải xong,
// thay vì chạy vòng lặp vẽ canvas trên luồng chính — hết giật khi từng khung 3D xuất hiện.
import * as THREE from 'three';

function desc(t, f) {
  const c = t.image, a = document.createElement('canvas'); a.width = a.height = 1;
  const x = a.getContext('2d'); x.drawImage(c, 0, 0, 1, 1); const d = x.getImageData(0, 0, 1, 1).data;
  return { f, w: c.width, h: c.height, avg: `rgba(${d[0]},${d[1]},${d[2]},${(d[3] / 255).toFixed(3)})`, ws: t.wrapS, wt: t.wrapT,
    r: [t.repeat.x, t.repeat.y], o: [t.offset.x, t.offset.y], cs: t.colorSpace, an: t.anisotropy, fy: t.flipY, data: c.toDataURL('image/webp', 0.9) };
}
function fromBaked(d) {
  const c = document.createElement('canvas'); c.width = c.height = 2; const x = c.getContext('2d'); x.fillStyle = d.avg; x.fillRect(0, 0, 2, 2);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = d.ws; t.wrapT = d.wt; t.repeat.set(...d.r); t.offset.set(...d.o); t.colorSpace = d.cs; t.anisotropy = d.an; t.flipY = d.fy; t.needsUpdate = true;
  const im = new Image(); im.decoding = 'async'; im.src = 'img/tex/' + d.f;
  im.decode().then(() => { t.image = im; t.dispose(); t.needsUpdate = true; }) // kích thước đổi (2×2 → ảnh thật): giải phóng bản GPU cũ để three.js cấp phát lại.catch(() => {});
  return t;
}
export function alkBake(k, gen) {
  const M = window.__ALK_TEXMAP, B = window.__ALK_BAKE;
  if (!B && M && M[k]) { const e = M[k]; if (e.t) return fromBaked(e.t); const o = {}; for (const n in e.o) o[n] = fromBaked(e.o[n]); return o; }
  const t0 = performance.now(), v = gen(), ms = performance.now() - t0;
  if (B && v && typeof v === 'object' && !(k in B)) {
    const safe = k.replace(/[^a-z0-9]+/gi, '_').slice(0, 60);
    try {
      if (v.isTexture && v.image && v.image.getContext) B[k] = { ms, t: desc(v, safe + '.webp') };
      else if (!v.isTexture && !v.isMaterial && !Array.isArray(v)) {
        const ks = Object.keys(v);
        if (ks.length && ks.every((q) => v[q] && v[q].isTexture && v[q].image && v[q].image.getContext)) B[k] = { ms, o: Object.fromEntries(ks.map((q) => [q, desc(v[q], `${safe}-${q}.webp`)])) };
      }
    } catch { /* bỏ qua texture không xuất được */ }
  }
  return v;
}
