// Tách lớp chi tiết cho phần "Cuộn để mở chiếc loa" (bản 23/11).
// Viết dạng "nhà máy" nhận các lớp three.js qua tham số T, để cùng một đoạn mã
// dùng được cả trong mã nguồn (import từ 'three') lẫn trong gói js/alokio-3d.js đã nén
// (ở đó T được ghép từ các tên rút gọn). Không dùng nhựa / cao su "giả": mọi bề mặt là
// kim loại xước, mạ thiếc, mạ vàng, giấy sợi, vải lụa, đồng tráng men, sơn phủ mặt nạ PCB.
function alkTeardownFactory(T) {
  const { Mesh, Group, Phys, Box, Cyl, Circle, Torus, Lathe, Extrude, Shape, Plane, V2, V3, Color,
    CanvasTex, Repeat, SRGB, NoCS, Double, Curve, metal, canvas, rand, h2n } = T;
  const cache = new Map();
  const once = (k, f) => (cache.has(k) || cache.set(k, f()), cache.get(k));
  const tex = (c, { repeat = [1, 1], srgb = false, aniso = 8 } = {}) => {
    const t = new CanvasTex(c); t.wrapS = t.wrapT = Repeat; t.repeat.set(repeat[0], repeat[1]);
    t.anisotropy = aniso; t.colorSpace = srgb ? SRGB : NoCS; t.needsUpdate = true; return t;
  };
  const mesh = (g, m, p, r) => {
    const o = new Mesh(g, m); if (p) o.position.set(p[0], p[1], p[2]); if (r) o.rotation.set(r[0], r[1], r[2]);
    o.castShadow = o.receiveShadow = true; return o;
  };
  const noise = (ctx, w, h, n, R, cols, a = .06, sz = 3) => {
    for (let i = 0; i < n; i++) { ctx.globalAlpha = R() * a; ctx.fillStyle = cols[i % cols.length]; ctx.fillRect(R() * w, R() * h, 1 + R() * sz, 1 + R() * sz * .5); }
    ctx.globalAlpha = 1;
  };

  /* ------------------------------ Vật liệu ------------------------------ */
  const M = () => once('mats', () => {
    const steel = metal('#cfd2d6', { rough: .24, brushed: 'radial', aniso: .4 });
    const tin = metal('#c3c6c9', { rough: .36, brushed: 'linear', aniso: .3 });
    const alu = metal('#bcc0c5', { rough: .32, brushed: 'linear', aniso: .55 });
    const castAlu = new Phys({ color: '#7d8187', metalness: 1, roughness: .46, normalMap: grain(), normalScale: new V2(.35, .35), envMapIntensity: 1.15 });
    const gunmetal = metal('#6c7076', { rough: .3, brushed: 'radial', aniso: .6 });
    const chrome = new Phys({ color: '#e3e6ea', metalness: 1, roughness: .1, envMapIntensity: 1.35 });
    const brass = new Phys({ color: '#c09a52', metalness: 1, roughness: .3, envMapIntensity: 1.2 });
    const gold = new Phys({ color: '#d6ae63', metalness: 1, roughness: .22, envMapIntensity: 1.25 });
    const zinc = new Phys({ color: '#a7acb2', metalness: 1, roughness: .38, envMapIntensity: 1.1 });
    const blackSteel = new Phys({ color: '#1e1f22', metalness: .55, roughness: .34, clearcoat: .6, clearcoatRoughness: .2, normalMap: grain(), normalScale: new V2(.15, .15), envMapIntensity: 1 });
    const nickel = new Phys({ color: '#c9cbcd', metalness: 1, roughness: .34, normalMap: dimples(), normalScale: new V2(.9, .9), envMapIntensity: 1.15 });
    const ferrite = new Phys({ color: '#2c2d30', metalness: .15, roughness: .86, normalMap: grain(), normalScale: new V2(.6, .6), envMapIntensity: .6 });
    const epoxy = new Phys({ color: '#18191c', metalness: 0, roughness: .62, envMapIntensity: .55 });
    const ceramic = new Phys({ color: '#b49a72', metalness: 0, roughness: .55, envMapIntensity: .7 });
    const resistor = new Phys({ color: '#141416', metalness: 0, roughness: .48, envMapIntensity: .6 });
    const fr4 = new Phys({ color: '#5f5b43', metalness: 0, roughness: .78, envMapIntensity: .6 });
    const maskBottom = new Phys({ color: '#0d1210', metalness: 0, roughness: .45, clearcoat: .3, clearcoatRoughness: .35 });
    const copper = new Phys({ color: '#b8693f', metalness: 1, roughness: .27, clearcoat: .7, clearcoatRoughness: .12,
      normalMap: windings(), normalScale: new V2(1.1, 1.1), envMapIntensity: 1.25 });
    const paper = new Phys({ map: paperTex().map, normalMap: paperTex().normal, normalScale: new V2(.7, .7), roughness: .84,
      metalness: 0, sheen: .35, sheenColor: new Color('#857a70'), sheenRoughness: .55, side: Double, envMapIntensity: .55 });
    const surround = new Phys({ color: '#1d1d20', roughness: .5, metalness: 0, sheen: .7, sheenColor: new Color('#5e5f66'),
      sheenRoughness: .45, clearcoat: .2, clearcoatRoughness: .55, normalMap: grain(), normalScale: new V2(.25, .25), side: Double, envMapIntensity: .7 });
    const felt = new Phys({ color: '#262422', roughness: .92, metalness: 0, sheen: 1, sheenColor: new Color('#6f665d'), sheenRoughness: .6, side: Double });
    const silk = new Phys({ color: '#34302c', roughness: .5, metalness: 0, sheen: 1, sheenColor: new Color('#b3a591'), sheenRoughness: .35,
      clearcoat: .35, clearcoatRoughness: .3, envMapIntensity: .8 });
    const spider = new Phys({ color: '#c4ab72', roughness: .9, metalness: 0, sheen: .6, sheenColor: new Color('#efe0b8'), normalMap: grain(), normalScale: new V2(.5, .5), side: Double });
    const fish = new Phys({ color: '#c7a46b', roughness: .85, metalness: 0, normalMap: grain(), normalScale: new V2(.4, .4) });
    const wireRed = new Phys({ color: '#9b1f1f', roughness: .42, metalness: 0, clearcoat: .5, clearcoatRoughness: .3 });
    const wireBlack = new Phys({ color: '#141416', roughness: .42, metalness: 0, clearcoat: .5, clearcoatRoughness: .3 });
    return { blackSteel, steel, tin, alu, castAlu, gunmetal, chrome, brass, gold, zinc, nickel, ferrite, epoxy, ceramic, resistor, fr4, maskBottom,
      copper, paper, surround, felt, silk, spider, fish, wireRed, wireBlack };
  });

  function grain() {
    return once('grain', () => {
      const c = canvas(256), x = c.getContext('2d'), R = rand(5); x.fillStyle = '#808080'; x.fillRect(0, 0, 256, 256);
      noise(x, 256, 256, 6000, R, ['#ffffff', '#000000'], .35, 2); return tex(h2n(c, 2.2), { repeat: [3, 3] });
    });
  }
  function dimples() {
    return once('dimples', () => {
      const c = canvas(256), x = c.getContext('2d'); x.fillStyle = '#808080'; x.fillRect(0, 0, 256, 256);
      for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) {
        const g = x.createRadialGradient(32 + i * 64, 32 + j * 64, 1, 32 + i * 64, 32 + j * 64, 11);
        g.addColorStop(0, '#202020'); g.addColorStop(1, '#808080'); x.fillStyle = g;
        x.beginPath(); x.arc(32 + i * 64 - 9, 32 + j * 64, 9, 0, 7); x.arc(32 + i * 64 + 9, 32 + j * 64, 9, 0, 7); x.fill();
      }
      return tex(h2n(c, 3));
    });
  }
  function windings() {
    return once('wind', () => {
      const c = canvas(1024, 32), x = c.getContext('2d'), n = 150, p = 1024 / n;
      for (let i = 0; i < n; i++) {
        const g = x.createLinearGradient(i * p, 0, i * p + p, 0);
        g.addColorStop(0, '#202020'); g.addColorStop(.5, '#f0f0f0'); g.addColorStop(1, '#202020'); x.fillStyle = g; x.fillRect(i * p, 0, p, 32);
      }
      return tex(h2n(c, 4));
    });
  }
  function paperTex() {
    return once('paper', () => {
      const S = 512, a = canvas(S), b = canvas(S), x = a.getContext('2d'), y = b.getContext('2d'), R = rand(19);
      x.fillStyle = '#2b2927'; x.fillRect(0, 0, S, S); y.fillStyle = '#808080'; y.fillRect(0, 0, S, S);
      for (let i = 0; i < 5200; i++) {
        const px = R() * S, py = R() * S, an = R() * Math.PI, l = 4 + R() * 16, v = R();
        x.strokeStyle = v < .5 ? 'rgba(80,74,68,.35)' : 'rgba(14,13,12,.4)'; x.lineWidth = .6 + R() * .9;
        y.strokeStyle = v < .5 ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.35)'; y.lineWidth = x.lineWidth;
        for (const k of [x, y]) { k.beginPath(); k.moveTo(px, py); k.lineTo(px + Math.cos(an) * l, py + Math.sin(an) * l); k.stroke(); }
      }
      return { map: tex(a, { repeat: [4, 1], srgb: true }), normal: tex(h2n(b, 1.6), { repeat: [4, 1] }) };
    });
  }

  /* ------------------------------ Bo mạch khuếch đại ------------------------------ */
  const BW = 1.12, BD = .44, BT = .018;
  const L = {
    toroids: [[-.43, -.095], [-.43, .095]], heat: [-.2, 0, .2, .36], dsp: [.07, .03, .095], shield: [.3, -.085, .17, .13],
    xtal: [.175, .078], capsBig: [[.29, .12], [.385, .12]], capsMid: [[-.02, -.165], [.06, -.165], [.14, -.165]],
    usb: [.47, .2], term: [.5, -.06], standoffs: [[-.53, -.19], [.53, -.19], [-.53, .19], [.53, .19]]
  };
  const busy = () => {
    const r = [];
    L.toroids.forEach(([x, z]) => r.push([x - .09, z - .09, x + .09, z + .09]));
    r.push([L.heat[0] - L.heat[2] / 2 - .01, L.heat[1] - L.heat[3] / 2 - .01, L.heat[0] + L.heat[2] / 2 + .01, L.heat[1] + L.heat[3] / 2 + .01]);
    r.push([L.dsp[0] - .07, L.dsp[1] - .07, L.dsp[0] + .07, L.dsp[1] + .07]);
    r.push([L.shield[0] - L.shield[2] / 2 - .01, L.shield[1] - L.shield[3] / 2 - .01, L.shield[0] + L.shield[2] / 2 + .01, L.shield[1] + L.shield[3] / 2 + .01]);
    [...L.capsBig].forEach(([x, z]) => r.push([x - .05, z - .05, x + .05, z + .05]));
    L.capsMid.forEach(([x, z]) => r.push([x - .035, z - .035, x + .035, z + .035]));
    r.push([L.usb[0] - .04, L.usb[1] - .03, L.usb[0] + .04, L.usb[1] + .03], [L.term[0] - .04, L.term[1] - .05, L.term[0] + .04, L.term[1] + .05]);
    L.standoffs.forEach(([x, z]) => r.push([x - .03, z - .03, x + .03, z + .03]));
    r.push([-.08, .1, .24, .21]); // vùng chữ in lụa
    return r;
  };
  const smd = () => once('smdpos', () => {
    const R = rand(77), out = [], b = busy(), hit = (x, z, m) => b.some(q => x > q[0] - m && x < q[2] + m && z > q[1] - m && z < q[3] + m)
      || out.some(o => Math.abs(o[0] - x) < .03 && Math.abs(o[1] - z) < .022);
    for (let t = 0; t < 900 && out.length < 70; t++) {
      const x = (R() - .5) * (BW - .08), z = (R() - .5) * (BD - .06);
      if (!hit(x, z, .012)) out.push([x, z, R() < .5 ? 0 : Math.PI / 2, R() < .62 ? 'r' : 'c']);
    }
    return out;
  });

  function pcbMaps() {
    return once('pcb', () => {
      const W = matchMedia('(max-width: 767px)').matches ? 1024 : 2048, H = Math.round(W * BD / BW), R = rand(41);
      const col = canvas(W, H), hm = canvas(W, H), rm = canvas(W, H), c = col.getContext('2d'), h = hm.getContext('2d'), r = rm.getContext('2d');
      const sx = W / BW, sz = H / BD, P = (x, z) => [(x + BW / 2) * sx, (z + BD / 2) * sz];
      c.fillStyle = '#0f1513'; c.fillRect(0, 0, W, H); h.fillStyle = '#303030'; h.fillRect(0, 0, W, H);
      r.fillStyle = 'rgb(0,108,0)'; r.fillRect(0, 0, W, H); // G = độ nhám, B = kim loại
      noise(c, W, H, 9000, R, ['#2a4a3e', '#000000'], .07, 7);
      const all = [c, h, r];
      const fillRect = (x0, z0, x1, z1, cc, hh, rr) => {
        const [a, b] = P(x0, z0), [e, f] = P(x1, z1);
        if (cc) { c.fillStyle = cc; c.fillRect(a, b, e - a, f - b); } if (hh) { h.fillStyle = hh; h.fillRect(a, b, e - a, f - b); } if (rr) { r.fillStyle = rr; r.fillRect(a, b, e - a, f - b); }
      };
      // Mảng đồng phủ đất (dưới lớp mặt nạ): sáng hơn và gồ lên một chút
      fillRect(-.555, -.215, -.25, .215, '#131c18', '#3c3c3c'); fillRect(.2, .05, .555, .215, '#131c18', '#3c3c3c');
      // Đường mạch
      const trace = (pts, w) => {
        c.strokeStyle = '#1b2a23'; h.strokeStyle = '#5a5a5a';
        for (const k of [c, h]) { k.lineWidth = w * sx; k.lineJoin = k.lineCap = 'round'; k.beginPath(); pts.forEach(([x, z], i) => { const [a, b] = P(x, z); i ? k.lineTo(a, b) : k.moveTo(a, b); }); k.stroke(); }
      };
      const route = (x0, z0, x1, z1, w) => {
        const dx = x1 - x0, dz = z1 - z0, d = Math.min(Math.abs(dx), Math.abs(dz)), mx = x0 + (Math.abs(dx) - d) * Math.sign(dx);
        trace([[x0, z0], [mx, z0], [mx + d * Math.sign(dx), z0 + d * Math.sign(dz)], [x1, z1]], w);
      };
      const pts = smd();
      for (let i = 0; i < 120; i++) {
        const a = pts[Math.floor(R() * pts.length)], b = i % 3 === 0 ? [L.dsp[0] + (R() - .5) * .09, L.dsp[1] + (R() - .5) * .09] : pts[Math.floor(R() * pts.length)];
        route(a[0], a[1], b[0], b[1], R() < .15 ? .006 : .0022);
      }
      // Đường nguồn dày từ cọc pin tới tụ lớn và tới tản nhiệt
      route(L.term[0], L.term[1], L.capsBig[1][0], L.capsBig[1][1], .014); route(L.capsBig[0][0], L.capsBig[0][1], L.heat[0] + .1, .14, .012);
      route(L.heat[0] - .1, -.12, L.toroids[0][0], L.toroids[0][1], .012); route(L.heat[0] - .1, .12, L.toroids[1][0], L.toroids[1][1], .012);
      // Pad mạ vàng (ENIG)
      const pad = (x, z, w, d) => fillRect(x - w / 2, z - d / 2, x + w / 2, z + d / 2, '#c9a35c', '#6a6a6a', 'rgb(0,52,255)');
      pts.forEach(([x, z, rot]) => { const ox = rot ? 0 : .0075, oz = rot ? .0075 : 0; pad(x - ox, z - oz, .007, .007); pad(x + ox, z + oz, .007, .007); });
      for (let i = 0; i < 16; i++) { const o = -.04 + i * .0053; pad(L.dsp[0] + o, L.dsp[1] - .056, .0028, .012); pad(L.dsp[0] + o, L.dsp[1] + .056, .0028, .012); pad(L.dsp[0] - .056, L.dsp[1] + o, .012, .0028); pad(L.dsp[0] + .056, L.dsp[1] + o, .012, .0028); }
      L.capsBig.concat(L.capsMid).forEach(([x, z]) => { pad(x - .014, z, .012, .012); pad(x + .014, z, .012, .012); });
      // Via + lỗ mạ xuyên
      const via = (x, z, rr) => {
        const [a, b] = P(x, z); c.fillStyle = '#c4a05c'; c.beginPath(); c.arc(a, b, rr * sx, 0, 7); c.fill();
        c.fillStyle = '#050605'; c.beginPath(); c.arc(a, b, rr * sx * .45, 0, 7); c.fill();
        r.fillStyle = 'rgb(0,60,255)'; r.beginPath(); r.arc(a, b, rr * sx, 0, 7); r.fill();
      };
      for (let i = 0; i < 70; i++) via(-.53 + i * (1.06 / 69), -.205, .0032), via(-.53 + i * (1.06 / 69), .205, .0032);
      for (let i = 0; i < 80; i++) { const q = pts[i % pts.length]; via(q[0] + (R() - .5) * .04, q[1] + (R() - .5) * .04, .0026); }
      L.standoffs.forEach(([x, z]) => via(x, z, .022));
      // In lụa: viền linh kiện, ký hiệu, tên bo
      c.strokeStyle = '#e6e3d8'; c.fillStyle = '#e6e3d8'; c.lineWidth = .0016 * sx; r.fillStyle = 'rgb(0,175,0)';
      const box = (x, z, w, d) => { const [a, b] = P(x - w / 2, z - d / 2); c.strokeRect(a, b, w * sx, d * sz); };
      const ring = (x, z, rr) => { const [a, b] = P(x, z); c.beginPath(); c.arc(a, b, rr * sx, 0, 7); c.stroke(); };
      const txt = (s, x, z, size, align = 'center', weight = 500) => { const [a, b] = P(x, z); c.font = `${weight} ${Math.round(size * sx)}px Arial, sans-serif`; c.textAlign = align; c.textBaseline = 'middle'; c.fillText(s, a, b); };
      L.toroids.forEach(([x, z], i) => { ring(x, z, .084); txt('L' + (i + 1), x + .1, z, .016); });
      box(L.dsp[0], L.dsp[1], .13, .13); txt('U3', L.dsp[0], L.dsp[1] - .078, .015);
      box(L.shield[0], L.shield[1], L.shield[2] + .016, L.shield[3] + .016); txt('U7 · BT', L.shield[0], L.shield[1] + .085, .014);
      L.capsBig.forEach(([x, z], i) => { ring(x, z, .045); txt('C' + (12 + i), x, z - .058, .014); });
      L.capsMid.forEach(([x, z], i) => { ring(x, z, .03); txt('C' + (21 + i), x, z + .044, .012); });
      txt('J1', L.term[0], L.term[1] + .065, .014); txt('USB-C', L.usb[0] - .075, L.usb[1], .012);
      pts.forEach(([x, z], i) => { if (i % 4 === 0) txt((pts[i][3] === 'r' ? 'R' : 'C') + (30 + i), x, z - .014, .0075); });
      txt('ALOKIO', .0, .13, .032, 'left', 700); txt('HẠ LONG · AMP-D40 · REV 2.3', .0, .158, .0135, 'left');
      txt('CLASS-D 2 × 40 W   ·   DSP 32-BIT', .0, .182, .0135, 'left'); txt('+ BATT −', L.term[0] - .002, L.term[1] - .068, .012);
      txt('⚠ HOT', L.heat[0], -.205, .012);
      return { map: tex(col, { srgb: true, aniso: 12 }), normal: tex(h2n(hm, 2.6), { aniso: 12 }), rm: tex(rm, { aniso: 12 }) };
    });
  }
  function chipTex(lines, w = 256, h = 256, base = '#17181b', ink = '#8a8d92', dot = true) {
    return once('chip:' + lines.join('|') + base, () => {
      const c = canvas(w, h), x = c.getContext('2d'), R = rand(lines.join('').length);
      x.fillStyle = base; x.fillRect(0, 0, w, h); noise(x, w, h, 1400, R, ['#ffffff', '#000000'], .05, 2);
      x.fillStyle = ink; x.textAlign = 'center'; x.textBaseline = 'middle';
      lines.forEach((s, i) => { x.font = `${i ? 500 : 700} ${Math.round(h * (i ? .1 : .13))}px Arial, sans-serif`; x.fillText(s, w / 2, h * (.38 + i * .16)); });
      if (dot) { x.fillStyle = '#0c0c0d'; x.beginPath(); x.arc(w * .14, h * .14, w * .045, 0, 7); x.fill(); }
      return tex(c, { srgb: true });
    });
  }
  function shieldTex() {
    return once('shield', () => {
      const w = 512, h = 392, c = canvas(w, h), x = c.getContext('2d'), R = rand(9);
      x.fillStyle = '#c4c6c8'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < 900; i++) { x.globalAlpha = .05 + R() * .08; x.fillStyle = R() < .5 ? '#ffffff' : '#7d8084'; x.fillRect(0, R() * h, w, 1); }
      x.globalAlpha = 1; x.fillStyle = '#55585d'; x.textAlign = 'left'; x.textBaseline = 'middle';
      x.font = '700 46px Arial, sans-serif'; x.fillText('ALOKIO', 36, 82); x.font = '500 30px Arial, sans-serif';
      x.fillText('AK-BT53  ·  Bluetooth 5.3', 36, 140); x.fillText('aptX · AAC · LDAC', 36, 186); x.fillText('M/N: HL-01   S/N: 24461108', 36, 232);
      for (let j = 0; j < 12; j++) for (let i = 0; i < 12; i++) if (R() < .5 || i < 2 && j < 2) { x.fillRect(360 + i * 9, 250 + j * 9, 9, 9); }
      return tex(c, { srgb: true });
    });
  }
  function sleeveTex(label) {
    return once('sleeve:' + label, () => {
      const w = 512, h = 256, c = canvas(w, h), x = c.getContext('2d');
      x.fillStyle = '#121214'; x.fillRect(0, 0, w, h); x.fillStyle = '#c9b48a'; x.fillRect(0, 0, 70, h);
      x.fillStyle = '#121214'; for (let i = 0; i < 5; i++) x.fillRect(22, 18 + i * 50, 26, 9);
      x.save(); x.translate(250, h / 2); x.rotate(-Math.PI / 2); x.fillStyle = '#c9b48a'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.font = '700 30px Arial, sans-serif'; x.fillText('ALOKIO', 0, -36); x.font = '500 24px Arial, sans-serif'; x.fillText(label, 0, 0); x.fillText('105°C', 0, 32); x.restore();
      return tex(c, { srgb: true });
    });
  }
  function ventTex() {
    return once('vent', () => {
      const c = canvas(256), x = c.getContext('2d'); x.fillStyle = '#9a9a9a'; x.fillRect(0, 0, 256, 256);
      x.strokeStyle = '#262626'; x.lineWidth = 7; x.lineCap = 'round'; x.beginPath(); x.moveTo(128, 40); x.lineTo(128, 216); x.moveTo(40, 128); x.lineTo(216, 128); x.stroke();
      x.strokeStyle = '#d0d0d0'; x.lineWidth = 6; x.beginPath(); x.arc(128, 128, 122, 0, 7); x.stroke();
      return tex(h2n(c, 3.5));
    });
  }
  function wrapTex() {
    return once('wrap', () => {
      const w = 1024, h = 300, c = canvas(w, h), x = c.getContext('2d'), R = rand(3);
      x.fillStyle = '#c9ccd0'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < 500; i++) { x.globalAlpha = .05 + R() * .07; x.fillStyle = R() < .5 ? '#ffffff' : '#8a8e94'; x.fillRect(0, R() * h, w, 1); }
      x.globalAlpha = 1; x.fillStyle = '#183a63'; x.fillRect(0, 0, 26, h);
      x.fillStyle = '#20242a'; x.textAlign = 'left'; x.textBaseline = 'middle';
      x.font = '700 64px Arial, sans-serif'; x.fillText('ALOKIO', 60, 62); x.font = '600 34px Arial, sans-serif'; x.fillText('POWER MODULE · HL-B68', 330, 64);
      x.font = '500 30px Arial, sans-serif'; x.fillText('Li-ion 7,2 V  ·  6800 mAh  ·  49 Wh', 60, 140);
      x.fillText('Tháo lắp nhanh · Sạc USB-C PD 30 W', 60, 190);
      x.font = '400 22px Arial, sans-serif'; x.globalAlpha = .7; x.fillText('Không đốt · Không đâm thủng · Không nối tắt', 60, 246);
      x.globalAlpha = 1; for (let i = 0; i < 44; i++) x.fillRect(780 + i * 5, 150, R() < .5 ? 2 : 3, 90);
      return tex(c, { srgb: true });
    });
  }
  function etchTex(lines) {
    return once('etch:' + lines.join('|'), () => {
      const w = 2048, h = 512, c = canvas(w, h), x = c.getContext('2d');
      x.fillStyle = '#000'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle';
      lines.forEach((s, i) => { x.font = `${i ? 600 : 700} ${i ? 78 : 168}px Arial, sans-serif`; x.fillText(s, w / 2, 148 + i * 132 + (i ? 52 : 0)); });
      return tex(c);
    });
  }

  const shapesGeo = (key, rects, depth) => once(key, () => {
    const shapes = rects.map(([x, z, w, d]) => { const s = new Shape(); s.moveTo(x - w / 2, -(z - d / 2)); s.lineTo(x + w / 2, -(z - d / 2)); s.lineTo(x + w / 2, -(z + d / 2)); s.lineTo(x - w / 2, -(z + d / 2)); s.closePath(); return s; });
    const g = new Extrude(shapes, { depth, bevelEnabled: false, curveSegments: 1 }); g.rotateX(-Math.PI / 2); return g;
  });

  function board() {
    const m = M(), maps = pcbMaps(), g = new Group(), top = BT / 2;
    const face = new Phys({ map: maps.map, normalMap: maps.normal, normalScale: new V2(.8, .8), roughnessMap: maps.rm, metalnessMap: maps.rm,
      roughness: 1, metalness: 1, clearcoat: .45, clearcoatRoughness: .3, envMapIntensity: 1 });
    g.add(mesh(new Box(BW, BT, BD), [m.fr4, m.fr4, face, m.maskBottom, m.fr4, m.fr4]));
    // Cuộn cảm hình xuyến: dây đồng tráng men quấn quanh lõi
    L.toroids.forEach(([x, z]) => {
      g.add(mesh(once('tor', () => new Torus(.054, .026, 28, 120)), m.copper, [x, top + .027, z], [Math.PI / 2, 0, 0]));
      g.add(mesh(once('torc', () => new Cyl(.03, .03, .012, 32)), m.epoxy, [x, top + .006, z]));
    });
    // Tản nhiệt nhôm đùn
    const [hx, hz, hw, hd] = L.heat;
    g.add(mesh(once('hsb', () => new Box(hw, .014, hd)), m.alu, [hx, top + .007, hz]));
    for (let i = 0; i < 11; i++) g.add(mesh(once('hsf', () => new Box(.0055, .085, hd)), m.alu, [hx - hw / 2 + .006 + i * ((hw - .012) / 10), top + .014 + .0425, hz]));
    // DSP dạng QFP + chân
    const [dx, dz, ds] = L.dsp;
    g.add(mesh(new Box(ds, .011, ds), [m.epoxy, m.epoxy, new Phys({ map: chipTex(['ALOKIO', 'AK-DSP32', '2446 · TW']), roughness: .58, metalness: 0 }), m.epoxy, m.epoxy, m.epoxy], [dx, top + .0075, dz]));
    const pins = []; for (let i = 0; i < 16; i++) { const o = -.04 + i * .0053; pins.push([dx + o, dz - .051, .0024, .012], [dx + o, dz + .051, .0024, .012], [dx - .051, dz + o, .012, .0024], [dx + .051, dz + o, .012, .0024]); }
    g.add(mesh(shapesGeo('pins', pins, .003), m.tin, [0, top, 0]));
    // Hộp chắn nhiễu Bluetooth (thép mạ thiếc, chữ dập)
    const [sx2, sz2, sw, sd] = L.shield;
    g.add(mesh(new Box(sw, .017, sd), [m.tin, m.tin, new Phys({ map: shieldTex(), metalness: 1, roughness: .34, envMapIntensity: 1.15 }), m.tin, m.tin, m.tin], [sx2, top + .0085, sz2]));
    // Thạch anh
    g.add(mesh(new Box(.034, .009, .014), m.steel, [L.xtal[0], top + .0045, L.xtal[1]]));
    // Tụ hoá: vỏ in chữ + nắp nhôm khía chữ thập
    const top2 = new Phys({ color: '#d4d7da', metalness: 1, roughness: .28, normalMap: ventTex(), normalScale: new V2(1, 1), envMapIntensity: 1.2 });
    const cap = (x, z, r, hh, label) => {
      const sl = new Phys({ map: sleeveTex(label), roughness: .3, metalness: 0, clearcoat: .8, clearcoatRoughness: .15 });
      g.add(mesh(once('cap' + r + hh, () => new Cyl(r, r, hh, 40)), [sl, top2, m.epoxy], [x, top + hh / 2 + .002, z]));
      g.add(mesh(once('capr' + r, () => new Torus(r * .97, r * .06, 8, 40)), m.zinc, [x, top + hh - .006, z], [Math.PI / 2, 0, 0]));
    };
    L.capsBig.forEach(([x, z]) => cap(x, z, .04, .12, '2200 µF  35 V'));
    L.capsMid.forEach(([x, z]) => cap(x, z, .026, .07, '470 µF  25 V'));
    // Linh kiện dán: thân + hai đầu mạ thiếc
    const pts = smd(), bodies = [], ends = [], ceram = [];
    pts.forEach(([x, z, rot, k]) => {
      const lw = .016, ld = .008;
      (k === 'r' ? bodies : ceram).push(rot ? [x, z, ld, lw * .62] : [x, z, lw * .62, ld]);
      const o = lw * .4; ends.push(rot ? [x, z - o, ld, lw * .2] : [x - o, z, lw * .2, ld], rot ? [x, z + o, ld, lw * .2] : [x + o, z, lw * .2, ld]);
    });
    g.add(mesh(shapesGeo('smdR', bodies, .005), m.resistor, [0, top, 0]));
    g.add(mesh(shapesGeo('smdC', ceram, .005), m.ceramic, [0, top, 0]));
    g.add(mesh(shapesGeo('smdE', ends, .0052), m.tin, [0, top, 0]));
    // Cổng USB-C (vỏ thép) + cọc nối pin mạ vàng
    g.add(mesh(new Box(.06, .022, .05), m.steel, [L.usb[0], top + .011, L.usb[1] + .002]));
    g.add(mesh(new Box(.046, .009, .006), m.epoxy, [L.usb[0], top + .011, L.usb[1] + .025]));
    g.add(mesh(new Box(.05, .04, .08), m.epoxy, [L.term[0], top + .02, L.term[1]]));
    [-.02, .02].forEach(o => g.add(mesh(once('trm', () => new Cyl(.011, .011, .006, 20)), m.gold, [L.term[0], top + .043, L.term[1] + o])));
    // Trụ đồng + ốc inox ở bốn góc
    L.standoffs.forEach(([x, z]) => {
      g.add(mesh(once('so', () => new Cyl(.017, .017, .07, 6)), m.brass, [x, -BT / 2 - .035, z]));
      g.add(mesh(once('sh', () => new Cyl(.016, .016, .007, 28)), m.steel, [x, top + .0035, z]));
      g.add(mesh(once('shx', () => new Circle(.007, 6)), m.epoxy, [x, top + .0072, z], [-Math.PI / 2, 0, 0]));
    });
    return g;
  }

  /* ------------------------------ Khối pin ------------------------------ */
  function battery() {
    // Thanh pin dạng module: vỏ nhôm anod, trượt theo ray vào khoang pin, tiếp điểm mạ vàng ở đầu
    const m = M(), g = new Group(), LX = .74, LY = .13, LZ = .22;
    const shell = metal('#3d4148', { rough: .34, brushed: 'linear', aniso: .5 });
    g.add(mesh(T.rbox(LX, LY, LZ, .03), shell));
    // Hai nắp đầu thép sơn đen
    [-1, 1].forEach(sd => g.add(mesh(T.rbox(.02, LY + .006, LZ + .006, .012), m.blackSteel, [sd * (LX / 2 - .004), 0, 0])));
    // Ray trượt hai bên
    [-1, 1].forEach(sd => g.add(mesh(once('rail', () => new Box(LX - .06, .016, .012)), m.alu, [0, -.02, sd * (LZ / 2 + .005)])));
    // Nhãn thông số trên lưng
    const lab = new Phys({ map: wrapTex(), metalness: .35, roughness: .38, clearcoat: .5, clearcoatRoughness: .2 });
    g.add(mesh(new Plane(.5, .15), lab, [-.04, LY / 2 + .0015, 0], [-Math.PI / 2, 0, 0]));
    // Tiếp điểm mạ vàng ở đầu cắm
    for (let i = 0; i < 5; i++) g.add(mesh(once('pin', () => new Box(.008, .03, .014)), m.gold, [LX / 2 + .008, -.01, -.05 + i * .025]));
    // Chốt gài lò xo + đèn báo dung lượng
    g.add(mesh(T.rbox(.06, .012, .09, .005), m.chrome, [-LX / 2 + .07, LY / 2 + .006, 0]));
    const led = new Phys({ color: '#0b0c0d', emissive: '#7fe3b0', emissiveIntensity: 1.6, roughness: .3 });
    for (let i = 0; i < 4; i++) g.add(mesh(once('led4', () => new Cyl(.006, .006, .004, 16)), i < 3 ? led : m.epoxy, [LX / 2 - .06 - i * .022, LY / 2 + .002, .075]));
    return g;
  }

  /* ------------------------------ Khung sườn nhôm ------------------------------ */
  function chassis() {
    const m = M(), g = new Group(), W = 2.0, H = .88, rr = .08;
    const geo = once('chassis', () => {
      const s = new Shape(), x0 = -W / 2, y0 = -H / 2;
      s.moveTo(x0 + rr, y0); s.lineTo(x0 + W - rr, y0); s.quadraticCurveTo(x0 + W, y0, x0 + W, y0 + rr); s.lineTo(x0 + W, y0 + H - rr);
      s.quadraticCurveTo(x0 + W, y0 + H, x0 + W - rr, y0 + H); s.lineTo(x0 + rr, y0 + H); s.quadraticCurveTo(x0, y0 + H, x0, y0 + H - rr); s.lineTo(x0, y0 + rr); s.quadraticCurveTo(x0, y0, x0 + rr, y0);
      const hole = (x, y, r) => { const p = new Shape(); p.absarc(x, y, r, 0, Math.PI * 2, true); s.holes.push(p); };
      hole(-.56, -.05, .285); hole(.56, -.05, .285); hole(-.14, .22, .082); hole(.14, .22, .082);
      [[-.15, -.3], [.15, -.3]].forEach(([x, y]) => hole(x, y, .03));
      const gg = new Extrude(s, { depth: .03, bevelEnabled: true, bevelThickness: .006, bevelSize: .006, bevelSegments: 2, curveSegments: 56 });
      gg.translate(0, 0, -.03); return gg;
    });
    g.add(mesh(geo, m.alu));
    // Gân tăng cứng phía sau
    [-.2, .2].forEach(x => g.add(mesh(once('rib', () => new Box(.03, H - .1, .07)), m.castAlu, [x, 0, -.065])));
    // 12 ốc M3 inox lục giác chìm
    const screw = (x, y) => {
      g.add(mesh(once('scr', () => new Cyl(.021, .021, .012, 32)), m.steel, [x, y, .012], [Math.PI / 2, 0, 0]));
      g.add(mesh(once('scrh', () => new Circle(.0095, 6)), m.epoxy, [x, y, .0185]));
    };
    [-.56, .56].forEach(cx => [0, 1, 2, 3].forEach(k => { const a = Math.PI / 4 + k * Math.PI / 2; screw(cx + Math.cos(a) * .35, -.05 + Math.sin(a) * .35); }));
    [[-.92, .36], [.92, .36], [-.92, -.36], [.92, -.36]].forEach(([x, y]) => screw(x, y));
    // Chữ khắc laser
    const et = new Phys({ color: '#4a4d52', metalness: 1, roughness: .62, alphaMap: etchTex(['ALOKIO', 'HẠ LONG · HL-01', 'THIẾT KẾ & LẮP RÁP TẠI VIỆT NAM']), transparent: true, alphaTest: .35, polygonOffset: true, polygonOffsetFactor: -2 });
    g.add(mesh(new Plane(.48, .12), et, [0, -.1, .0065]));
    return g;
  }

  /* ------------------------------ Nâng cấp loa con ------------------------------ */
  function upgradeWoofer(drv, kit) {
    const m = M(), r = .3;
    drv.traverse(o => { if (!o.isMesh) return; if (o.material === kit.cone) o.material = m.paper; else if (o.material === kit.rubber) o.material = m.surround; else if (o.material === kit.deep || o.material === kit.dust || o.material === kit.plastic) o.material = m.felt; });
    const back = new Group(); back.rotation.x = Math.PI / 2;
    back.add(mesh(once('mgf', () => new Cyl(.44 * r, .44 * r, .018, 48)), m.blackSteel, [0, -.36 * r, 0]));
    back.add(mesh(once('mgc', () => new Cyl(.5 * r, .5 * r, .1 * r, 48)), m.ferrite, [0, -.36 * r - .011 - .05 * r, 0]));
    back.add(mesh(once('mgb', () => new Cyl(.44 * r, .44 * r, .018, 48)), m.blackSteel, [0, -.36 * r - .02 - .1 * r, 0]));
    back.add(mesh(once('mgp', () => new Cyl(.12 * r, .12 * r, .03, 24)), m.chrome, [0, -.36 * r - .033 - .1 * r - .004, 0]));
    const prof = []; for (let i = 0; i <= 24; i++) { const t = i / 24; prof.push(new V2((.2 + t * .42) * r, (-.3 + Math.sin(t * Math.PI * 6) * .018) * r)); }
    back.add(mesh(once('spd', () => new Lathe(prof, 64)), m.spider));
    for (let k = 0; k < 4; k++) {
      const p = new Group(); p.rotation.y = Math.PI / 4 + k * Math.PI / 2;
      const r0 = .98 * r, y0 = -.03 * r, r1 = .42 * r, y1 = -.36 * r, dr = r1 - r0, dy = y1 - y0, len = Math.hypot(dr, dy);
      p.add(mesh(once('spk', () => T.rbox(.07 * r, len, .016, .006)), m.castAlu, [(r0 + r1) / 2, (y0 + y1) / 2, 0], [0, 0, Math.atan2(-dr, dy)]));
      back.add(p);
    }
    back.add(mesh(once('bsr', () => new Torus(.43 * r, .02, 10, 48)), m.castAlu, [0, -.36 * r, 0], [Math.PI / 2, 0, 0]));
    drv.add(back);
  }
  function upgradeTweeter(tw, kit) {
    const m = M(), r = .075;
    tw.traverse(o => { if (!o.isMesh) return; if (o.material === kit.plastic || o.material === kit.trim) o.material = m.gunmetal; else if (o.material === kit.knob || o.material === kit.chrome) o.material = m.silk; });
    tw.add(mesh(once('twm', () => new Cyl(.62 * r, .62 * r, .35 * r, 40)), m.chrome, [0, 0, -.3 * r], [Math.PI / 2, 0, 0]));
    tw.add(mesh(once('twr', () => new Torus(.98 * r, .05 * r, 10, 48)), m.steel, [0, 0, .13 * r]));
  }

  /* ------------------------------ Ghép vào mô hình ------------------------------ */
  const SPEC = [
    ['Mặt vải lanh', 'Dệt kim 3D, xuyên âm 96%'],
    ['Khung nhôm champagne', 'Nhôm 6063 phay CNC, anod champagne'],
    ['2 tweeter lụa 20 mm', 'Nam châm neodymium, tới 20 kHz'],
    ['2 woofer 3"', 'Màng giấy sợi dài, 2 × 30 W'],
    ['Khung sườn nhôm', 'Nguyên tấm, 12 ốc M3 inox'],
    ['Bo mạch Class-D', '2 × 40 W · DSP 32-bit · BT 5.3'],
    ['Thanh pin module', '7,2 V · 6800 mAh · 30+ giờ'],
    ['Vỏ sơn mài', '9 lớp mài tay, chuẩn IP67']
  ];

  return function attach(model, cv) {
    const ud = model.userData, kit = ud.mats || {}, byName = n => ud.parts.find(p => p.name === n);
    const add = (obj, name, explode, internal = true) => {
      obj.name = name; obj.userData.explode = explode; obj.userData.home = obj.position.clone(); obj.userData.internal = internal;
      ud.parts.push(obj); model.add(obj); return obj;
    };
    // Bỏ bo mạch + pin kiểu cũ (trông như nhựa)
    ['Bo mạch ampli Class-D', 'Pin'].forEach(n => { const p = byName(n); if (p) { model.remove(p); ud.parts.splice(ud.parts.indexOf(p), 1); } });
    // Chân đế + màng thụ động hai bên gắn liền với vỏ, để không lơ lửng khi tách lớp
    const shell = byName('Vỏ sơn mài');
    if (shell) model.children.filter(c => !ud.parts.includes(c) && c.isMesh).forEach(c => shell.add(c));
    ud.parts.forEach(p => { if (/^Woofer/.test(p.name)) upgradeWoofer(p, kit); if (/^Tweeter/.test(p.name)) upgradeTweeter(p, kit); });
    const b = board(); b.position.set(0, -.07, -.2); add(b, 'Bo mạch khuếch đại', new V3(0, 1.05, .3));
    const bt = battery(); bt.position.set(0, -.33, -.05); add(bt, 'Khối pin', new V3(-.1, -1.0, .38));
    const ch = chassis(); ch.position.set(0, 0, .262); add(ch, 'Khung sườn nhôm', new V3(0, 0, .72));
    model.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    // Khoảng tách gọn lại để cả cụm nằm trong khung hình
    const ex = (n, x, y, z) => { const p = byName(n); if (p) p.userData.explode.set(x, y, z); };
    ex('Mặt vải lanh', 0, 0, 2.0); ex('Khung nhôm champagne', 0, 0, 1.68); ex('Vỏ sơn mài', 0, 0, -.72);
    ex('Tweeter trái', -.2, .26, 1.4); ex('Tweeter phải', .2, .26, 1.4); ex('Woofer 3" trái', -.14, -.02, 1.12); ex('Woofer 3" phải', .14, -.02, 1.12);
    ch.userData.explode.set(0, 0, .6);

    // Nhãn chú thích
    const tgt = [
      [byName('Mặt vải lanh'), new V3(-.86, .36, .01)],
      [byName('Khung nhôm champagne'), new V3(.98, .4, .02)],
      [byName('Tweeter phải'), new V3(.06, .07, .02)],
      [byName('Woofer 3" trái'), new V3(-.22, .24, .0)],
      [ch, new V3(.9, -.38, .02)],
      [b, new V3(.36, .14, .12)],
      [bt, new V3(.2, .07, .1)],
      [byName('Vỏ sơn mài'), new V3(-1.1, .45, .3)]
    ];
    const view = cv.parentElement, wrapEl = document.createElement('div');
    wrapEl.className = 'td'; wrapEl.setAttribute('aria-hidden', 'true');
    wrapEl.innerHTML = '<svg class="td__lines"></svg>' + SPEC.map((s, i) => `<i class="td__dot">${i + 1}</i><span class="td__tag"><b>${s[0]}</b><small>${s[1]}</small></span>`).join('');
    view.appendChild(wrapEl);
    const svg = wrapEl.firstChild, dots = [...wrapEl.querySelectorAll('.td__dot')], tags = [...wrapEl.querySelectorAll('.td__tag')];
    svg.innerHTML = SPEC.map(() => '<line/>').join(''); const lines = [...svg.querySelectorAll('line')];
    const v = new V3(), st = tgt.map(() => ({ x: 0, y: 0, on: false, side: 1, ly: 0, w: 0, h: 0 }));
    let sizeKey = '';
    return {
      update(cam, k, w) {
        const W = view.clientWidth, H = view.clientHeight; if (!W || !H) return;
        const show = Math.max(0, Math.min(1, (k - .3) / .22)), compact = W < 620;
        wrapEl.classList.toggle('is-compact', compact); wrapEl.style.opacity = show.toFixed(3);
        if (show <= 0) { dots.forEach(d => d.classList.remove('is-on')); tags.forEach(t => t.classList.remove('is-on')); return; }
        model.updateMatrixWorld(); cam.updateMatrixWorld();
        const key = W + 'x' + H + compact; if (key !== sizeKey) { sizeKey = key; svg.setAttribute('viewBox', `0 0 ${W} ${H}`); tags.forEach((t, i) => { st[i].w = t.offsetWidth; st[i].h = t.offsetHeight; }); }
        tgt.forEach(([obj, a], i) => {
          const s = st[i]; if (!obj) { s.on = false; return; }
          v.copy(a); obj.localToWorld(v); v.project(cam);
          s.x = (v.x * .5 + .5) * W; s.y = (-v.y * .5 + .5) * H; s.on = i <= w && v.z < 1 && s.x > 0 && s.x < W && s.y > 0 && s.y < H;
          s.side = s.x < W * .5 ? -1 : 1; s.ly = s.y;
        });
        if (!compact) for (const side of [-1, 1]) {
          const arr = st.filter(s => s.on && s.side === side).sort((p, q) => p.y - q.y), gap = 6;
          for (let i = 1; i < arr.length; i++) arr[i].ly = Math.max(arr[i].ly, arr[i - 1].ly + (arr[i - 1].h + arr[i].h) / 2 + gap);
          const last = arr[arr.length - 1]; if (last && last.ly + last.h / 2 > H - 8) { last.ly = H - 8 - last.h / 2; for (let i = arr.length - 2; i >= 0; i--) arr[i].ly = Math.min(arr[i].ly, arr[i + 1].ly - (arr[i].h + arr[i + 1].h) / 2 - gap); }
          arr.forEach(s => { s.ly = Math.max(s.h / 2 + 8, s.ly); });
        }
        st.forEach((s, i) => {
          dots[i].classList.toggle('is-on', s.on); tags[i].classList.toggle('is-on', s.on && !compact);
          dots[i].style.transform = `translate(${s.x.toFixed(1)}px,${s.y.toFixed(1)}px) translate(-50%,-50%)`;
          if (compact || !s.on) { lines[i].setAttribute('stroke-opacity', '0'); return; }
          let lx = s.side < 0 ? s.x - 46 - s.w : s.x + 46;
          lx = Math.max(6, Math.min(W - 6 - s.w, lx));
          tags[i].style.transform = `translate(${lx.toFixed(1)}px,${(s.ly - s.h / 2).toFixed(1)}px)`;
          const ex = s.side < 0 ? lx + s.w : lx;
          lines[i].setAttribute('x1', s.x.toFixed(1)); lines[i].setAttribute('y1', s.y.toFixed(1));
          lines[i].setAttribute('x2', ex.toFixed(1)); lines[i].setAttribute('y2', s.ly.toFixed(1)); lines[i].setAttribute('stroke-opacity', '1');
        });
      }
    };
  };
}
export { alkTeardownFactory };
