// "Kích thước thật" (bản 23/11): một phòng khách lớn, người cao 1,7 m (tỉ lệ người thật, mặc đồ) đứng giữa,
// các mẫu loa đặt đúng chỗ người ta hay dùng: loa nhỏ trên kệ / bàn / cạnh TV, soundbar dưới TV, loa karaoke dưới sàn.
// 1 đơn vị = 10 cm. Viết dạng nhà máy nhận lớp three.js qua T (dùng chung cho mã nguồn và gói đã nén).
function alkRoomFactory(T) {
  const { Mesh, Group, Phys, Basic, Box, Cyl, Sphere, Capsule, Lathe, Plane, V2, V3, Color, CanvasTex, Repeat, SRGB, NoCS, Double,
    Box3, createStage, buildModel, dragSpin, rbox, wood, linen, canvas, rand, h2n, metal } = T;
  const bake = T.bake || ((k, f) => f()); // dùng texture dựng sẵn (img/tex) nếu có
  const tex = (c, { repeat = [1, 1], srgb = false, aniso = 8 } = {}) => {
    const t = new CanvasTex(c); t.wrapS = t.wrapT = Repeat; t.repeat.set(repeat[0], repeat[1]); t.anisotropy = aniso; t.colorSpace = srgb ? SRGB : NoCS; t.needsUpdate = true; return t;
  };
  const mesh = (g, m, p, r, sc) => {
    const o = new Mesh(g, m); if (p) o.position.set(p[0], p[1], p[2]); if (r) o.rotation.set(r[0], r[1], r[2]); if (sc) o.scale.set(sc[0], sc[1], sc[2]);
    o.castShadow = o.receiveShadow = true; return o;
  };

  /* ---------------- Vân sàn gỗ sồi + tường + tranh + màn hình TV ---------------- */
  function floorTex() { return bake('room:floorTex', () => floorTexRaw()); }
  function floorTexRaw() {
    const W = 1024, H = 1024, c = canvas(W, H), x = c.getContext('2d'), hm = canvas(W, H), y = hm.getContext('2d'), R = rand(23);
    y.fillStyle = '#909090'; y.fillRect(0, 0, W, H);
    const rows = 8, ph = H / rows;
    for (let r = 0; r < rows; r++) {
      let px = -R() * 400;
      while (px < W) {
        const len = 380 + R() * 420, tone = 0.85 + R() * 0.25, base = [206 * tone, 170 * tone, 128 * tone];
        x.fillStyle = `rgb(${base.map(v => Math.min(255, v | 0)).join(',')})`; x.fillRect(px, r * ph, len, ph);
        for (let k = 0; k < 26; k++) {
          const yy = r * ph + R() * ph; x.strokeStyle = `rgba(${R() < .5 ? '120,84,52' : '235,205,160'},${.08 + R() * .16})`; x.lineWidth = .6 + R() * 2.2;
          x.beginPath(); for (let s = 0; s <= len; s += 24) { const d = yy + Math.sin((px + s) * .01 + k) * 2.5; s ? x.lineTo(px + s, d) : x.moveTo(px, d); } x.stroke();
        }
        x.fillStyle = 'rgba(60,40,24,.55)'; x.fillRect(px, r * ph, 2, ph); y.fillStyle = '#303030'; y.fillRect(px, r * ph, 3, ph);
        px += len;
      }
      x.fillStyle = 'rgba(60,40,24,.5)'; x.fillRect(0, r * ph, W, 2); y.fillStyle = '#303030'; y.fillRect(0, r * ph, W, 3);
    }
    return { map: tex(c, { repeat: [5, 4], srgb: true, aniso: 12 }), normal: tex(h2n(hm, 2), { repeat: [5, 4], aniso: 12 }) };
  }
  function plasterTex() { return bake('room:plasterTex', () => plasterTexRaw()); }
  function plasterTexRaw() {
    const c = canvas(256), x = c.getContext('2d'), R = rand(31); x.fillStyle = '#808080'; x.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 5000; i++) { x.globalAlpha = R() * .25; x.fillStyle = R() < .5 ? '#fff' : '#000'; x.beginPath(); x.arc(R() * 256, R() * 256, .5 + R() * 2.2, 0, 7); x.fill(); }
    return tex(h2n(c, 1.2), { repeat: [10, 4] });
  }
  function paintingTex() { return bake('room:paintingTex', () => paintingTexRaw()); }
  function paintingTexRaw() {
    const W = 1024, H = 640, c = canvas(W, H), x = c.getContext('2d'), R = rand(8);
    const sky = x.createLinearGradient(0, 0, 0, H * .55); sky.addColorStop(0, '#8fb6dc'); sky.addColorStop(1, '#f1dcc0'); x.fillStyle = sky; x.fillRect(0, 0, W, H);
    const sea = x.createLinearGradient(0, H * .55, 0, H); sea.addColorStop(0, '#5f9cc8'); sea.addColorStop(1, '#2c5e8f'); x.fillStyle = sea; x.fillRect(0, H * .55, W, H * .45);
    // núi đá vôi kiểu Hạ Long
    [[120, .55, 170, 230], [330, .55, 120, 160], [560, .55, 210, 280], [800, .55, 140, 190]].forEach(([cx, base, w, h]) => {
      x.fillStyle = 'rgba(70,96,110,.75)'; x.beginPath(); x.moveTo(cx - w / 2, H * base);
      x.bezierCurveTo(cx - w * .45, H * base - h * .7, cx - w * .2, H * base - h, cx, H * base - h); x.bezierCurveTo(cx + w * .25, H * base - h, cx + w * .4, H * base - h * .6, cx + w / 2, H * base); x.fill();
    });
    for (let i = 0; i < 900; i++) { x.globalAlpha = .05 + R() * .12; x.strokeStyle = R() < .5 ? '#ffffff' : '#1c3d5e'; x.lineWidth = 1 + R() * 4; const yy = H * (.56 + R() * .44), xx = R() * W; x.beginPath(); x.moveTo(xx, yy); x.lineTo(xx + 20 + R() * 60, yy + (R() - .5) * 3); x.stroke(); }
    x.globalAlpha = 1; return tex(c, { srgb: true });
  }
  function screenTex() { return bake('room:screenTex', () => screenTexRaw()); }
  function screenTexRaw() {
    const W = 1024, H = 576, c = canvas(W, H), x = c.getContext('2d');
    const sky = x.createLinearGradient(0, 0, 0, H * .58); sky.addColorStop(0, '#3d7cc2'); sky.addColorStop(.7, '#a9cbe8'); sky.addColorStop(1, '#f6d9a8'); x.fillStyle = sky; x.fillRect(0, 0, W, H);
    const sea = x.createLinearGradient(0, H * .58, 0, H); sea.addColorStop(0, '#46a7c4'); sea.addColorStop(1, '#14507c'); x.fillStyle = sea; x.fillRect(0, H * .58, W, H);
    const sun = x.createRadialGradient(W * .7, H * .5, 4, W * .7, H * .5, 160); sun.addColorStop(0, 'rgba(255,240,205,1)'); sun.addColorStop(1, 'rgba(255,240,205,0)'); x.fillStyle = sun; x.fillRect(0, 0, W, H);
    x.fillStyle = 'rgba(255,255,255,.92)'; x.font = '600 34px Arial, sans-serif'; x.fillText('ALOKIO · Âm Thanh Việt', 48, H - 52);
    return tex(c, { srgb: true });
  }

  /* ---------------- Người 1,7 m: tỉ lệ người thật, mặc áo thun + quần dài + giày ---------------- */
  function human() {
    const g = new Group();
    const skin = new Phys({ color: '#d7a587', roughness: .58, sheen: .35, sheenColor: new Color('#ffd9c4'), envMapIntensity: .8 });
    const shirt = linen('#eef0f2'), pants = linen('#1b2638'), hair = new Phys({ color: '#1f1915', roughness: .7, sheen: 1, sheenColor: new Color('#6b5a4c') });
    const shoe = new Phys({ color: '#f1eee8', roughness: .5, clearcoat: .25, clearcoatRoughness: .4 }), sole = new Phys({ color: '#d6cfc3', roughness: .75 });
    const belt = new Phys({ color: '#5a3a26', roughness: .5, clearcoat: .3 });
    // Chân (đáy giày y=0, đáy quần ~ y 8,4 → chân chiếm ~ 49% chiều cao)
    [-1, 1].forEach(sd => {
      const lx = sd * .92;
      g.add(mesh(new Cyl(.92, .66, 4.1, 28), pants, [lx, 6.45, 0]));
      g.add(mesh(new Sphere(.67, 20, 12), pants, [lx, 4.4, .02]));
      g.add(mesh(new Cyl(.66, .56, 3.55, 28), pants, [lx, 2.62, 0]));
      g.add(mesh(rbox(1.05, .62, 2.6, .28), shoe, [lx, .46, .42]));
      g.add(mesh(rbox(1.1, .16, 2.68, .07), sole, [lx, .08, .42]));
    });
    // Hông + thắt lưng
    g.add(mesh(new Capsule(1.66, .9, 8, 28), pants, [0, 9.2, 0], null, [1, 1, .64]));
    g.add(mesh(new Cyl(1.72, 1.72, .32, 40), belt, [0, 10.15, 0], null, [1, 1, .64]));
    // Thân áo: hình tiện (eo – ngực – vai) rồi ép dẹt chiều sâu
    const prof = [[0, 9.75], [1.72, 9.75], [1.7, 10.4], [1.66, 11.2], [1.8, 12.2], [1.98, 13.15], [2.06, 13.85], [1.88, 14.3], [1.25, 14.58], [.62, 14.7], [0, 14.72]].map(([r, y]) => new V2(r, y));
    g.add(mesh(new Lathe(prof, 48), shirt, [0, 0, 0], null, [1, 1, .6]));
    // Cổ + đầu + tóc
    g.add(mesh(new Cyl(.5, .55, 1.0, 24), skin, [0, 14.95, .02]));
    const head = mesh(new Sphere(1, 40, 28), skin, [0, 15.85, .08], null, [.86, 1.1, .96]); g.add(head);
    const hr = mesh(new Sphere(1.04, 40, 20, 0, Math.PI * 2, 0, Math.PI * .46), hair, [0, 15.96, .02], [-.42, 0, 0], [.88, 1.08, 1]); g.add(hr);
    [-1, 1].forEach(sd => g.add(mesh(new Sphere(.2, 12, 10), skin, [sd * .86, 15.8, .02], null, [.5, 1, .8])));
    // Tay: tay áo ngắn + cánh tay + cẳng tay + bàn tay, buông dọc thân
    [-1, 1].forEach(sd => {
      const a = new Group(); a.position.set(sd * 2.12, 14.0, 0); a.rotation.z = sd * .085; a.rotation.x = .04;
      a.add(mesh(new Sphere(.62, 24, 16), shirt, [0, -.05, 0], null, [1, .9, 1]));
      a.add(mesh(new Cyl(.64, .6, 1.9, 24), shirt, [0, -.9, 0]));
      a.add(mesh(new Cyl(.5, .44, 3.1, 20), skin, [0, -1.75, 0]));
      a.add(mesh(new Sphere(.44, 16, 12), skin, [0, -3.25, 0]));
      a.add(mesh(new Cyl(.44, .34, 2.9, 20), skin, [0, -4.7, .05]));
      a.add(mesh(new Sphere(.42, 20, 14), skin, [sd * -.02, -6.62, .08], null, [.62, 1.55, .9]));
      g.add(a);
    });
    return g;
  }

  /* ---------------- Nội thất ---------------- */
  function furniture() {
    const g = new Group(), wd = wood(), brass = new Phys({ color: '#c09a52', metalness: 1, roughness: .3 }), blackMetal = new Phys({ color: '#1d1e21', metalness: .7, roughness: .38 });
    const white = new Phys({ color: '#f3f0ea', roughness: .6 });
    // Kệ TV gỗ óc chó
    const tv = { x: -17, z: -12.4 };
    g.add(mesh(rbox(20, 4.2, 4.4, .14), wd, [tv.x, .7 + 2.1, tv.z]));
    [-1, 1].forEach(a => [-1, 1].forEach(b => g.add(mesh(new Cyl(.16, .12, .7, 12), brass, [tv.x + a * 9.2, .35, tv.z + b * 1.8]))));
    for (let i = 1; i < 4; i++) g.add(mesh(new Box(.06, 3.6, .05), blackMetal, [tv.x - 10 + i * 5, 2.8, tv.z + 2.21]));
    // TV 55" + chân đế
    const scr = new Phys({ color: '#05070a', roughness: .12, metalness: .2, clearcoat: 1, clearcoatRoughness: .05, emissive: '#ffffff', emissiveMap: screenTex(), emissiveIntensity: .55 });
    g.add(mesh(rbox(12.4, 7.2, .32, .06), blackMetal, [tv.x, 5.0 + .9 + 3.6, tv.z - .9]));
    g.add(mesh(new Plane(12.15, 6.95), scr, [tv.x, 5.0 + .9 + 3.6, tv.z - .9 + .165]));
    [-1, 1].forEach(sd => g.add(mesh(new Box(.25, 1.0, 1.6), blackMetal, [tv.x + sd * 5, 5.0 + .45, tv.z - .7], [.25, 0, 0])));
    // Tủ thấp bên phải + kệ treo + tranh
    const sb = { x: 17, z: -12.4 };
    g.add(mesh(rbox(16, 7.4, 4.4, .14), wd, [sb.x, .7 + 3.7, sb.z]));
    [-1, 1].forEach(a => [-1, 1].forEach(b => g.add(mesh(new Cyl(.16, .12, .7, 12), brass, [sb.x + a * 7.2, .35, sb.z + b * 1.8]))));
    g.add(mesh(new Box(.06, 6.8, .05), blackMetal, [sb.x, 4.4, sb.z + 2.21]));
    [-1, 1].forEach(sd => g.add(mesh(new Box(.12, 1.6, .2), brass, [sb.x + sd * .6, 4.6, sb.z + 2.3])));
    g.add(mesh(rbox(8, .36, 2.6, .08), wd, [11.6, 13.2, -13.75]));
    const art = new Phys({ map: paintingTex(), roughness: .85 });
    g.add(mesh(rbox(10.6, 6.8, .35, .05), new Phys({ color: '#c9b48a', metalness: 1, roughness: .35 }), [21.6, 16.2, -14.75]));
    g.add(mesh(new Plane(10, 6.2), art, [21.6, 16.2, -14.55]));
    // Bàn tròn cạnh người
    g.add(mesh(new Cyl(2.3, 2.3, .3, 48), wd, [8.4, 5.2, -4.2]));
    g.add(mesh(new Cyl(.22, .22, 5.0, 16), brass, [8.4, 2.6, -4.2]));
    g.add(mesh(new Cyl(1.3, 1.4, .18, 40), brass, [8.4, .09, -4.2]));
    // Thảm dưới chân người
    g.add(mesh(rbox(24, .1, 13, .05), linen('#d8cfc0'), [0, .05, -4.6]));
    // Ổ cắm trên tường (chi tiết thật)
    g.add(mesh(rbox(.9, .9, .1, .05), white, [-6.2, 3.1, -14.9]));
    return { g, slots: {
      bar: [tv.x, 4.9, tv.z + .9], tvLeft: [tv.x - 8, 4.9, tv.z + .2], tvRight: [tv.x + 7.6, 4.9, tv.z + .2],
      floorL: [tv.x - 15.2, 0, tv.z + 1.2], floorR: [tv.x + 11.6, 0, tv.z + .9],
      sbL: [sb.x - 4, 8.1, sb.z + .1], sbR: [sb.x + 4.4, 8.1, sb.z + .1], shelf: [11.6, 13.38, -13.75], table: [8.4, 5.35, -4.2]
    } };
  }

  return function mount(cv, items) {
    const tags = [];
    const stage = createStage(cv, { fov: 30, ground: false, onFrame: () => placeTags(), envOpts: { warm: 1.2 } });
    const { scene, camera, key } = stage;
    const room = new Group();
    // Sàn, tường, len chân tường
    const fl = floorTex();
    room.add(mesh(new Plane(90, 44), new Phys({ map: fl.map, normalMap: fl.normal, normalScale: new V2(.5, .5), roughness: .5, clearcoat: .35, clearcoatRoughness: .3 }), [0, 0, 6.5], [-Math.PI / 2, 0, 0]));
    const wall = new Phys({ color: '#efe9e0', roughness: .92, normalMap: plasterTex(), normalScale: new V2(.25, .25) });
    room.add(mesh(new Plane(90, 32), wall, [0, 16, -15]));
    [-1, 1].forEach(sd => room.add(mesh(new Plane(44, 32), wall, [sd * 45, 16, 6.5], [0, -sd * Math.PI / 2, 0])));
    room.add(mesh(new Box(90, .9, .25), new Phys({ color: '#f7f4ef', roughness: .55 }), [0, .45, -14.86]));
    const f = furniture(); room.add(f.g);
    // Người đứng giữa phòng
    const hm = human(); hm.position.set(1.6, 0, -4.6); hm.rotation.y = .08; room.add(hm);
    tags.push({ at: new V3(1.6, 18.1, -4.6), label: 'Người cao 1,7 m', size: '' });
    // Sản phẩm đặt theo vị trí sử dụng thực tế
    for (const it of items) {
      const o = buildModel(it.model, { finish: it.finish }), b = new Box3().setFromObject(o), sz = b.getSize(new V3()), s = f.slots[it.slot] || [0, 0, 0];
      o.position.set(s[0] - (b.min.x + b.max.x) / 2, s[1] - b.min.y, s[2] - (b.min.z + b.max.z) / 2);
      if (it.rot) o.rotation.y = it.rot;
      room.add(o);
      tags.push({ at: new V3(s[0], s[1] + sz.y + .5, s[2]), label: it.name, size: `${Math.round(sz.x * 10)} × ${Math.round(sz.y * 10)} cm` });
    }
    room.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    const pivot = new Group(); pivot.add(room); scene.add(pivot);
    key.position.set(-14, 34, 22); key.intensity = 2.4;
    Object.assign(key.shadow.camera, { left: -46, right: 46, top: 34, bottom: -20, near: 1, far: 120 }); key.shadow.camera.updateProjectionMatrix(); key.shadow.bias = -3e-4;
    key.target.position.set(0, 4, -6); scene.add(key.target);

    // Nhãn tên + kích thước bám theo từng mẫu
    const host = cv.parentElement, wrap = document.createElement('div'); wrap.className = 'szt'; wrap.setAttribute('aria-hidden', 'true');
    wrap.innerHTML = tags.map((t, i) => `<span class="szt__tag${i ? '' : ' szt__tag--me'}"><b>${t.label}</b>${t.size ? `<small>${t.size}</small>` : ''}</span>`).join('');
    host.appendChild(wrap); const els = [...wrap.children]; const v = new V3();
    function placeTags() {
      const W = host.clientWidth, H = host.clientHeight; if (!W) return; pivot.updateMatrixWorld(); camera.updateMatrixWorld();
      tags.forEach((t, i) => {
        v.copy(t.at); room.localToWorld(v); v.project(camera);
        els[i].style.transform = `translate(${((v.x * .5 + .5) * W).toFixed(1)}px,${((-v.y * .5 + .5) * H).toFixed(1)}px) translate(-50%,-100%)`;
      });
    }
    const fit = () => {
      const t = Math.tan(camera.fov * Math.PI / 360), span = camera.aspect < 1.6 ? 38 : 64;
      const d = Math.max((span / 2) / (t * camera.aspect), 13 / t);
      camera.position.set(0, 11, -4 + d); camera.lookAt(0, 9.4, -6);
    };
    fit();
    let raf = 0;
    const drag = dragSpin(cv, { speed: 1.6, clamp: .32, onChange: () => { pivot.rotation.y = drag.spin; stage.render(); placeTags(); } });
    const inertia = () => { if (drag.step()) raf = requestAnimationFrame(inertia); };
    cv.addEventListener('pointerup', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(inertia); });
    new ResizeObserver(() => { fit(); stage.render(); placeTags(); }).observe(cv);
    stage.renderOnce(); placeTags();
    host.querySelector('img')?.remove();
    return stage;
  };
}
export { alkRoomFactory };
