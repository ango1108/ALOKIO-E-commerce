// Các cảnh 3D phụ: tách lớp (exploded), núm vặn analog, phòng vật liệu, so kích thước.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { dragSpin, createStage, place, frame, reducedMotion, isMobile } from './stage.js';
import { buildModel, setExplode } from './models.js';
import * as M from './materials.js';
import * as audio from '../audio.js';

// ---------- Tách lớp theo cuộn trang ----------
export function mountExploded(canvas, section, steps, { model = { type: 'halong' }, finish = 'huyen' } = {}) {
  const stage = createStage(canvas, { fov: 30, onFrame });
  const obj = buildModel(model, { finish, knob: 'champagne', strap: 'bo' });
  stage.scene.add(obj);
  const size = place(stage, obj);
  const pivot = new THREE.Vector3(0, size.y * 0.5, 0);
  stage.key.position.set(5, 9, 7);
  let k = 0, kt = 0;
  const rm = reducedMotion();
  // Bộ phận bên trong ẩn khi chưa tách
  const internals = obj.userData.parts.filter((p) => p.userData.internal);
  function onScroll() {
    const r = section.getBoundingClientRect();
    const total = r.height - window.innerHeight;
    kt = total > 0 ? Math.min(1, Math.max(0, -r.top / total)) : 0.6;
  }
  if (rm) kt = 0.65;
  // Điện thoại: không tách theo cuộn trang mà theo thao tác vuốt NGAY TRONG khung loa (xem client/pages/home.js)
  else if (isMobile()) section.addEventListener('alk:explode', (e) => { kt = e.detail; });
  else { window.addEventListener('scroll', onScroll, { passive: true }); onScroll(); }
  const drag = dragSpin(canvas, { speed: 3.2 });
  function onFrame(t, dt) {
    drag.step(dt);
    k += (kt - k) * Math.min(1, dt * 5 || 1);
    const e = Math.min(1, k * 1.15);
    setExplode(obj, e * 1.0);
    internals.forEach((p) => (p.visible = e > 0.04));
    const az = -0.75 + k * 1.1 - drag.spin;
    const dist = Math.max(size.x, size.y) * 3.6 + e * 2.2;
    stage.camera.position.set(Math.sin(az) * dist, pivot.y + 1.4 + e * 0.8, Math.cos(az) * dist);
    stage.camera.lookAt(pivot.x, pivot.y + e * 0.3, pivot.z + e * 0.4);
    obj.userData.update(t, audio.readBands(t));
    const idx = Math.min(steps.length - 1, Math.floor(k * steps.length * 0.999));
    steps.forEach((s, i) => s.classList.toggle('is-on', i <= idx && k > 0.02));
  }
  stage.start();
  canvas.parentElement.querySelector('img')?.remove();
  return stage;
}

// ---------- Núm vặn analog (cận cảnh mặt trên Hội An) ----------
export function mountKnobs(canvas, sliders) {
  const stage = createStage(canvas, { fov: 26, onFrame });
  const obj = buildModel({ type: 'hifi', size: 's' }, { finish: 'ngoc-trai', knob: 'champagne' });
  stage.scene.add(obj);
  const size = place(stage, obj);
  const knobs = obj.userData.knobs.slice(0, 3);
  const map = ['volume', 'bass', 'treble'];
  const range = { volume: [0, 100], bass: [-12, 12], treble: [-12, 12] };
  const val = { volume: Math.round(audio.getVolume() * 100), bass: 0, treble: 0 }; // lấy theo âm lượng hiện tại (mặc định 15%), không tự đẩy lên to
  const cam = stage.camera;
  cam.position.set(0.9, size.y + 1.9, 2.6);
  cam.lookAt(0, size.y * 0.92, 0.25);
  const ray = new THREE.Raycaster();
  let drag = null, lastY = 0, lastTick = 0, fv = 0; // fv: giá trị liên tục (cộng dồn phần lẻ khi rê chuột từng chút)
  const toAngle = (name) => { const [a, b] = range[name]; return -((val[name] - a) / (b - a)) * Math.PI * 1.5 + Math.PI * 0.75; };
  function sync(name, from3d) {
    const i = map.indexOf(name);
    knobs[i].rotation.y = toAngle(name);
    const s = sliders.querySelector(`[data-eq="${name}"]`);
    if (s && from3d) s.value = val[name];
    const out = s && s.parentElement.querySelector('output');
    if (out) out.textContent = name === 'volume' ? val[name] : `${val[name] > 0 ? '+' : ''}${val[name]} dB`;
    audio.setEQ({ [name]: name === 'volume' ? val[name] / 100 : val[name] });
    if (!stage.running) stage.render();
  }
  map.forEach((n) => sync(n));
  canvas.style.cursor = 'grab';
  canvas.addEventListener('pointerdown', (e) => {
    const r = canvas.getBoundingClientRect();
    ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), cam);
    const hits = ray.intersectObjects(knobs, true);
    if (!hits.length) return;
    let o = hits[0].object; while (o && !o.userData.isKnob) o = o.parent;
    drag = map[knobs.indexOf(o)];
    if (!drag) return;
    fv = val[drag];
    lastY = e.clientY; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing';
    // không tự phát nhạc: khách bấm “Phát nhạc” để nghe thử
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag) {
      const r = canvas.getBoundingClientRect();
      ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), cam);
      canvas.style.cursor = ray.intersectObjects(knobs, true).length ? 'grab' : 'default';
      return;
    }
    const [a, b] = range[drag];
    const dv = ((lastY - e.clientY) / 160) * (b - a);
    lastY = e.clientY;
    fv = Math.min(b, Math.max(a, fv + dv));
    const nv = Math.round(fv);
    if (nv !== val[drag]) { val[drag] = nv; sync(drag, true); const now = performance.now(); if (now - lastTick > 40) { audio.tick(); lastTick = now; } }
  });
  canvas.addEventListener('pointerup', () => { drag = null; canvas.style.cursor = 'grab'; });
  sliders.addEventListener('input', (e) => {
    const s = e.target.closest('[data-eq]'); if (!s) return;
    val[s.dataset.eq] = Number(s.value); sync(s.dataset.eq, false); audio.tick();
  });
  function onFrame(t) { obj.userData.update(t, audio.readBands(t)); }
  stage.start();
  canvas.parentElement.querySelector('img')?.remove();
  return stage;
}

// ---------- Phòng vật liệu ----------
export function mountMaterials(canvas) {
  const stage = createStage(canvas, { fov: 28, ground: false, envOpts: { warm: 0.8, cool: 1.2, dark: true }, exposure: 1.05, onFrame });
  const { scene, camera } = stage;
  scene.remove(stage.hemi);
  const geo = new RoundedBoxGeometry(1.6, 2.1, 0.35, 8, 0.16);
  const mats = [M.lacquer('#10161F'), M.pearlMat(), M.linenMat('#DCE7F2'), M.metal('#D8C49A', { rough: 0.28 })];
  const tiles = mats.map((m, i) => {
    const mesh = new THREE.Mesh(geo, m);
    mesh.position.set((i - 1.5) * 2.05, 0, 0);
    scene.add(mesh);
    return mesh;
  });
  // vân phay tròn cho tấm nhôm
  const disk = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.12, 96), M.knurlMetal('#D8C49A'));
  disk.rotation.x = Math.PI / 2; disk.position.set(0, 0.3, 0.22); tiles[3].add(disk);
  const cap = new THREE.Mesh(new THREE.CircleGeometry(0.43, 64), M.metal('#D8C49A', { rough: 0.22 }));
  cap.position.set(0, 0.3, 0.285); tiles[3].add(cap);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.06, 16, 96), M.pearlMat());
  ring.position.set(0, 0.3, 0.2); tiles[0].add(ring);
  const spot = new THREE.PointLight('#ffffff', 22, 12, 1.6);
  scene.add(spot);
  stage.key.intensity = 1.2;
  const mobile = isMobile();
  camera.position.set(0, 0.2, mobile ? 16 : 10.5);
  camera.lookAt(0, 0.15, 0);
  const mouse = new THREE.Vector2(0.3, 0.2), tm = mouse.clone();
  canvas.parentElement.addEventListener('pointermove', (e) => {
    const r = canvas.getBoundingClientRect();
    tm.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  });
  const drag = dragSpin(canvas, { speed: 3, host: canvas.parentElement });
  function onFrame(t, dt) {
    drag.step(dt);
    mouse.lerp(tm, Math.min(1, dt * 3));
    spot.position.set(mouse.x * 5, mouse.y * 2.5 + 0.5, 3.2);
    tiles.forEach((m, i) => { m.rotation.y = Math.sin(t * 0.4 + i) * 0.28 + mouse.x * 0.15 + drag.spin; m.rotation.x = Math.sin(t * 0.3 + i * 2) * 0.08 - mouse.y * 0.08; m.position.y = Math.sin(t * 0.6 + i) * 0.06; });
  }
  stage.start();
  canvas.parentElement.querySelector('img')?.remove();
  return stage;
}

// ---------- So kích thước thật ----------
export function mountSizeCompare(canvas, items) {
  const stage = createStage(canvas, { fov: 24, onFrame: () => {} });
  const { scene, camera } = stage;
  let x = 0;
  const group = new THREE.Group();
  // người cao 1,7 m (17 đơn vị): hình nhân trừu tượng
  const human = new THREE.Group();
  const mat = new THREE.MeshPhysicalMaterial({ color: '#CFDCEB', roughness: 0.6, transparent: true, opacity: 0.85 });
  human.add(new THREE.Mesh(new THREE.CapsuleGeometry(1.6, 7.2, 8, 24), mat).translateY(9.8));
  human.add(new THREE.Mesh(new THREE.SphereGeometry(1.15, 32, 16), mat).translateY(15.7));
  [-0.8, 0.8].forEach((lx) => human.add(new THREE.Mesh(new THREE.CapsuleGeometry(0.62, 5.8, 6, 16), mat).translateX(lx).translateY(3.4)));
  group.add(human);
  x = 3.2;
  for (const it of items) {
    const o = buildModel(it.model, { finish: it.finish });
    const box = new THREE.Box3().setFromObject(o);
    const w = box.max.x - box.min.x;
    o.position.set(x + w / 2 - (box.min.x + box.max.x) / 2, -box.min.y, 0);
    group.add(o);
    x += w + 1.4;
  }
  const total = x;
  // Nội dung trải từ mép trái hình nhân (-1,6) tới mép phải mẫu cuối (total - 1,4): căn giữa đúng khoảng này
  const spanW = total + 0.2;
  group.position.x = -(total - 3) / 2;
  const pivot = new THREE.Group(); pivot.add(group); scene.add(pivot);
  stage.setContact(total * 1.2, 6);
  const k = stage.key; k.shadow.camera.left = -total; k.shadow.camera.right = total; k.shadow.camera.top = 20; k.shadow.camera.bottom = -20; k.position.set(6, 24, 14); k.shadow.camera.updateProjectionMatrix();
  const fit = () => {
    const t = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const byW = (spanW / 2) * 1.12 / (t * camera.aspect); // vừa chiều ngang (+12% lề)
    const byH = (19 / 2) * 1.2 / t; // vừa chiều cao người 1,7 m + tay kéo
    camera.position.set(0, 8.5, Math.max(byW, byH)); camera.lookAt(0, 8, 0);
  };
  fit();
  // Kéo ngang để xoay cả hàng sản phẩm (giới hạn ±40°)
  let raf = 0;
  const drag = dragSpin(canvas, { speed: 2.4, clamp: 0.7, onChange: () => { pivot.rotation.y = drag.spin; stage.render(); } });
  const inertia = () => { if (drag.step()) raf = requestAnimationFrame(inertia); };
  canvas.addEventListener('pointerup', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(inertia); });
  new ResizeObserver(() => { fit(); stage.render(); }).observe(canvas);
  stage.renderOnce();
  canvas.parentElement.querySelector('img')?.remove();
  return stage;
}
