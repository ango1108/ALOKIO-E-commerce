// Các hàm kiểm tra nhỏ (không cần three.js) – để trang chỉ tải gói 3D khi thật sự cần.
export const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export const isMobile = () => window.matchMedia('(max-width: 767px)').matches || /Mobi|Android/i.test(navigator.userAgent);
export const liteMode = () => document.documentElement.classList.contains('lite');
export function webglOK() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch { return false; }
}
