// Bản đồ Việt Nam dạng lưới điểm 2.5D (minh hoạ): cột sáng theo số đơn từng tỉnh, xung sóng khi có đơn mới realtime.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createStage } from './stage.js';

export function mountVNMap(canvas, { outline, provinces, counts }) {
  const stage = createStage(canvas, { fov: 32, ground: false, shadows: false, bloom: true, bloomStrength: 0.7, envOpts: { dark: true }, onFrame });
  const { scene, camera } = stage;
  scene.remove(stage.hemi);
  // Chiếu lon/lat → mặt phẳng
  const lon0 = 106, lat0 = 16;
  const P0 = (lon, lat) => new THREE.Vector2((lon - lon0) * 1.0, -(lat - lat0) * 1.08);
  // Căn giữa theo khung bao của đường viền để cả nước luôn nằm gọn trong khung
  const raw = outline.map(([lo, la]) => P0(lo, la));
  const bb = new THREE.Box2().setFromPoints(raw); const ctr = bb.getCenter(new THREE.Vector2()); const size = bb.getSize(new THREE.Vector2());
  const P = (lon, lat) => P0(lon, lat).sub(ctr);
  const poly = raw.map((v) => v.clone().sub(ctr));
  const root = new THREE.Group(); scene.add(root);
  const inside = (pt) => { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const a = poly[i], b = poly[j]; if ((a.y > pt.y) !== (b.y > pt.y) && pt.x < ((b.x - a.x) * (pt.y - a.y)) / (b.y - a.y) + a.x) c = !c; } return c; };
  const dots = [];
  for (let x = -size.x / 2; x <= size.x / 2; x += 0.12) for (let y = -size.y / 2; y <= size.y / 2; y += 0.12) { const pt = new THREE.Vector2(x, y); if (inside(pt)) dots.push(x, 0, y); }
  const dg = new THREE.BufferGeometry(); dg.setAttribute('position', new THREE.Float32BufferAttribute(dots, 3));
  root.add(new THREE.Points(dg, new THREE.PointsMaterial({ color: '#7FA8D6', size: 0.075, transparent: true, opacity: 0.75 })));
  const line = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(poly.map((p) => new THREE.Vector3(p.x, 0, p.y))), new THREE.LineBasicMaterial({ color: '#A9C9EC', transparent: true, opacity: 0.5 }));
  root.add(line);
  const bars = new Map();
  const max = Math.max(1, ...Object.values(counts));
  const barMat = new THREE.MeshStandardMaterial({ color: '#CFE2F6', emissive: '#6FA8E8', emissiveIntensity: 1.2, transparent: true, opacity: 0.9 });
  for (const pr of provinces) {
    const p = P(pr.lon, pr.lat);
    const n = counts[pr.code] || 0;
    const h = 0.06 + Math.sqrt(n / max) * 3.2;
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 1, 20), barMat.clone());
    m.scale.y = h; m.position.set(p.x, h / 2, p.y);
    root.add(m);
    bars.set(pr.code, { mesh: m, h, n, p });
  }
  const pulses = [];
  const ringGeo = new THREE.RingGeometry(0.9, 1, 48); ringGeo.rotateX(-Math.PI / 2);
  // Nhìn từ phía nam, nghiêng ~32°, khoảng cách đủ để thấy trọn chiều dài đất nước
  const fit = () => { const fov = THREE.MathUtils.degToRad(camera.fov); const need = Math.max(size.y * 0.92, size.x / Math.max(0.3, camera.aspect)) / 2 / Math.tan(fov / 2) * 1.08; const tz = size.y * 0.05; camera.position.set(0.6, need * 0.85, need * 0.53 + tz); camera.lookAt(0, 0, tz); };
  fit();
  const controls = new OrbitControls(camera, canvas);
  controls.cursorStyle = 'grab'; // con trỏ hình bàn tay: báo hiệu có thể kéo để xoay
  controls.enablePan = false; controls.enableDamping = true; controls.minDistance = 8; controls.maxDistance = 60; controls.maxPolarAngle = 1.2; controls.target.set(0, 0, size.y * 0.05);
  new ResizeObserver(() => { if (!controls.__touched) fit(); }).observe(canvas);
  controls.addEventListener('start', () => { controls.__touched = true; });
  canvas.addEventListener('wheel', (e) => { if (!e.ctrlKey) e.stopImmediatePropagation(); }, { capture: true });
  function onFrame(t, dt) {
    controls.update();
    root.rotation.y = Math.sin(t * 0.25) * 0.1;
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i]; p.t += dt;
      p.mesh.scale.setScalar(0.1 + p.t * 1.6); p.mesh.material.opacity = Math.max(0, 1 - p.t / 1.6);
      if (p.t > 1.6) { root.remove(p.mesh); pulses.splice(i, 1); }
    }
    for (const b of bars.values()) { b.mesh.material.emissiveIntensity += (1.2 - b.mesh.material.emissiveIntensity) * Math.min(1, dt * 1.5); }
  }
  stage.start();
  return {
    pulse(code) {
      const b = bars.get(code);
      if (!b) return;
      b.n++; b.h += 0.15; b.mesh.scale.y = b.h; b.mesh.position.y = b.h / 2; b.mesh.material.emissiveIntensity = 6;
      for (let k = 0; k < 2; k++) {
        const m = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: k ? '#FFC9BB' : '#CFE2F6', transparent: true, side: THREE.DoubleSide }));
        m.position.set(b.p.x, 0.02, b.p.y);
        root.add(m); pulses.push({ mesh: m, t: -k * 0.35 });
      }
    },
  };
}
