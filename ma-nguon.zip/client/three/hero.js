// HERO: mặt nước vô tận rung theo nhạc, loa Alokio Luxe Hạ Long nổi bập bềnh.
import * as THREE from 'three';
import { createStage, reducedMotion, isMobile, dragSpin } from './stage.js';
import { makeWater, makeSky, heightAtCPU, MAX_RIPPLES } from './water.js';
import { buildModel } from './models.js';
import * as audio from '../audio.js';

export function mountHero(canvas, { onReady } = {}) {
  const mobile = isMobile();
  const rm = reducedMotion();
  const ripples = []; // {x, y(z), z(start), w(strength)}
  let kick = 0, kickV = 0;
  const pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  let scrollK = 0;

  const stage = createStage(canvas, {
    fov: mobile ? 44 : 30, ground: false, shadows: false, exposure: 1.02, maxDpr: mobile ? 1.25 : 1.5,
    envOpts: { warm: 1.1, cool: 1.2 }, onFrame,
  });
  const { scene, camera, renderer } = stage;
  scene.remove(stage.key); // ánh sáng hero tự đặt
  // Nắng chiều thấp phía trước bên phải (cùng hướng với mặt trời trong shader) → viền sáng ấm trên loa
  const sun = new THREE.DirectionalLight('#ffd3a3', 3.0); sun.position.set(8.4, 3.2, -20); scene.add(sun);
  const front = new THREE.DirectionalLight('#eef5ff', 1.4); front.position.set(-4, 5, 10); scene.add(front);

  const { mesh: water, uniforms } = makeWater({ segments: mobile ? 140 : 256 });
  // Hoàng hôn nhẹ: mặt trời thấp hơn, nắng vàng cam dịu; trời và nước vẫn giữ tông xanh chủ đạo
  uniforms.uWarm.value = 1;
  uniforms.uSunDir.value.set(0.42, 0.05, -1).normalize();
  uniforms.uSunCol.value.setRGB(1.0, 0.82, 0.6);
  uniforms.uHaze.value.setRGB(1.0, 0.89, 0.76);
  scene.add(water);
  const sky = makeSky(uniforms);
  scene.add(sky);

  // Môi trường phản chiếu từ chính bầu trời + mặt nước → sơn mài và khảm trai ánh sắc trời pastel
  const envScene = new THREE.Scene();
  envScene.add(makeSky(uniforms));
  const pm = new THREE.PMREMGenerator(renderer);
  const skyEnv = pm.fromScene(envScene, 0.02).texture;
  pm.dispose();
  // Sơn mài cần các mảng sáng – tối rõ ràng để bóng sâu: dùng môi trường studio (softbox) cho loa,
  // còn mặt nước dùng hàm bầu trời riêng trong shader.
  scene.environmentIntensity = 1.0;
  skyEnv.dispose();

  const heroFinish = canvas.dataset.finish || 'huyen';
  const speaker = buildModel({ type: 'halong' }, { finish: heroFinish, knob: 'champagne', strap: heroFinish === 'huyen' ? 'kem' : 'bo' });
  const holder = new THREE.Group();
  holder.add(speaker);
  speaker.position.y = speaker.userData.lift - 0.07; // chìm nhẹ 7 mm dưới mặt nước
  scene.add(holder);
  // Bố cục theo tỉ lệ khung: màn ngang đặt loa bên phải tiêu đề; màn dọc (điện thoại) đặt loa phía trên tiêu đề
  const spPos = new THREE.Vector2();
  let narrow = null;
  function layoutFor(aspect) {
    const n = aspect < 0.9;
    if (n === narrow) return;
    narrow = n;
    spPos.set(n ? 0 : 3.1, n ? -2.6 : -1.6);
    holder.position.set(spPos.x, 0, spPos.y);
    uniforms.uSpeaker.value.copy(spPos);
  }
  layoutFor(camera.aspect || 1.6);

  // Ảnh phản chiếu phẳng (render loa lộn ngược qua mặt nước)
  const rt = new THREE.WebGLRenderTarget(1, 1, { samples: 0 });
  uniforms.uReflect.value = rt.texture;

  const bufSize = new THREE.Vector2();
  function resize() {
    const s = renderer.getDrawingBufferSize(bufSize);
    rt.setSize(Math.max(1, s.x >> 1), Math.max(1, s.y >> 1));
    uniforms.uResolution.value.set(s.x, s.y);
  }
  new ResizeObserver(resize).observe(canvas);
  resize();

  function addRipple(x, z, w) {
    if (ripples.length >= MAX_RIPPLES) ripples.shift();
    ripples.push({ x, y: z, z: stage.time, w });
  }

  const offBeat = audio.onBeat((b) => addRipple(spPos.x, spPos.y, 0.05 + b * 0.16));

  // Raycast con trỏ xuống mặt phẳng y = 0
  const ray = new THREE.Raycaster();
  const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  const hit = new THREE.Vector3();
  let lastMove = 0;
  function toWater(e) {
    const r = canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    return ray.ray.intersectPlane(plane, hit) ? hit : null;
  }
  const host = canvas.parentElement;
  host.addEventListener('pointermove', (e) => {
    const r = canvas.getBoundingClientRect();
    pointer.tx = ((e.clientX - r.left) / r.width) * 2 - 1;
    pointer.ty = ((e.clientY - r.top) / r.height) * 2 - 1;
    const now = performance.now();
    if (now - lastMove > 120 && !rm) { lastMove = now; const p = toWater(e); if (p && p.distanceTo(camera.position) < 40) addRipple(p.x, p.z, 0.035); }
  }, { passive: true });
  host.addEventListener('pointerdown', (e) => {
    if (e.target.closest('a, button')) return;
    const p = toWater(e);
    if (p) addRipple(p.x, p.z, 0.22);
    // "giọt nước" đẩy loa nảy lên
    const d = p ? Math.hypot(p.x - spPos.x, p.z - spPos.y) : 99;
    kickV += Math.max(0.15, 1.2 - d * 0.18);
    if (!stage.running) stage.renderOnce();
  });
  // Kéo ngang trên mặt nước để xoay chiếc loa
  const drag = dragSpin(host, { speed: 3.5 });
  const onScroll = () => { scrollK = Math.min(1, window.scrollY / (window.innerHeight * 0.9)); };
  if (!rm) window.addEventListener('scroll', onScroll, { passive: true });

  const look = new THREE.Vector3();
  let first = true;
  let tiltX = 0, tiltZ = 0;
  const lastBuf = new THREE.Vector2();
  function onFrame(t, dt) {
    // độ phân giải có thể tự giảm khi máy yếu → cập nhật ảnh phản chiếu cho khớp
    renderer.getDrawingBufferSize(lastBuf);
    if (lastBuf.x !== uniforms.uResolution.value.x || lastBuf.y !== uniforms.uResolution.value.y) resize();
    const b = audio.readBands(t);
    uniforms.uTime.value = t;
    uniforms.uBass.value = b.bass;
    uniforms.uTreble.value = b.treble;
    const ease = scrollK * scrollK * (3 - 2 * scrollK);
    uniforms.uCalm.value = 1 - ease * 0.6;
    for (let i = 0; i < MAX_RIPPLES; i++) {
      const r = ripples[i];
      uniforms.uRipples.value[i].set(r ? r.x : 0, r ? r.y : 0, r ? r.z : -100, r ? r.w : 0);
    }
    // camera: parallax nhẹ theo chuột + nâng lên khi cuộn
    pointer.x += (pointer.tx - pointer.x) * Math.min(1, dt * 2.5);
    pointer.y += (pointer.ty - pointer.y) * Math.min(1, dt * 2.5);
    layoutFor(camera.aspect);
    const base = narrow ? { x: 0, y: 2.3, z: 11.5, lx: 0, ly: -0.4, lz: 3.2 } : { x: -0.4, y: 2.1, z: 9.4, lx: 1.5, ly: 1.05, lz: -1.4 };
    camera.position.set(base.x + pointer.x * 0.35, base.y + ease * 7 - pointer.y * 0.15, base.z - ease * 3.5);
    look.set(base.lx + pointer.x * 0.15, base.ly - ease * 0.8, base.lz);
    camera.lookAt(look);
    water.position.set(camera.position.x, 0, camera.position.z - 60);
    // loa nổi: lấy độ cao & độ nghiêng mặt nước tại vị trí loa
    const h0 = heightAtCPU(spPos.x, spPos.y, t, uniforms.uCalm.value, ripples, b.bass, spPos);
    const hx = heightAtCPU(spPos.x + 0.6, spPos.y, t, uniforms.uCalm.value, ripples, b.bass, spPos);
    const hz = heightAtCPU(spPos.x, spPos.y + 0.6, t, uniforms.uCalm.value, ripples, b.bass, spPos);
    kickV -= kick * 9 * dt; kickV *= Math.pow(0.02, dt); kick += kickV * dt;
    tiltX += ((hz - h0) * 0.9 - tiltX) * Math.min(1, dt * 3);
    tiltZ += (-(hx - h0) * 0.9 - tiltZ) * Math.min(1, dt * 3);
    holder.position.y = h0 + kick * 0.35 + Math.sin(t * 0.9) * 0.015;
    holder.rotation.x = tiltX + pointer.y * 0.03;
    holder.rotation.z = tiltZ;
    drag.step(dt);
    holder.rotation.y = (narrow ? 0.5 : 0.42) + pointer.x * 0.12 + Math.sin(t * 0.25) * 0.04 + drag.spin;
    speaker.userData.update(t, b);
    // render phản chiếu
    water.visible = false; sky.visible = false;
    holder.scale.y = -1; holder.position.y = -holder.position.y;
    renderer.setRenderTarget(rt);
    renderer.setClearColor(0x000000, 0);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    holder.scale.y = 1; holder.position.y = -holder.position.y;
    water.visible = true; sky.visible = true;
    if (first) { first = false; requestAnimationFrame(() => { canvas.classList.add('is-ready'); onReady && onReady(); }); }
  }

  stage.start();
  return {
    stage,
    splash() { addRipple(spPos.x, spPos.y, 0.3); kickV += 0.8; },
    dispose() { offBeat(); stage.dispose(); },
  };
}
