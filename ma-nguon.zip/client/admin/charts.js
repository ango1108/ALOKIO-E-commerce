// Bộ biểu đồ SVG tự vẽ cho trang quản trị (không dùng thư viện).
// Tông màu: navy · xanh pastel · vàng champagne – đồng bộ với thương hiệu Alokio.
import { esc, fmt } from '../lib/core.js';

export const COLORS = ['#2B5C94', '#86AEDD', '#C9A86A', '#E8735A', '#1F7A55', '#5B6B80', '#BCD6F2', '#9C7E48'];
const money = (v) => (v >= 1e9 ? (v / 1e9).toFixed(2).replace('.', ',') + ' tỷ' : v >= 1e6 ? (v / 1e6).toFixed(v >= 1e8 ? 0 : 1).replace('.', ',') + ' tr' : new Intl.NumberFormat('vi-VN').format(Math.round(v)));
export { money };
let gid = 0;

// Đường cong mượt qua các điểm
function smooth(pts) {
  if (pts.length < 2) return '';
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += ` C${(p1[0] + (p2[0] - p0[0]) / 6).toFixed(1)},${(p1[1] + (p2[1] - p0[1]) / 6).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / 6).toFixed(1)},${(p2[1] - (p3[1] - p1[1]) / 6).toFixed(1)} ${p2[0]},${p2[1]}`;
  }
  return d;
}

// Biểu đồ nhỏ trong thẻ KPI
export function sparkline(values, { color = '#2B5C94', w = 140, h = 38 } = {}) {
  if (!values.length) return '';
  const max = Math.max(...values), min = Math.min(...values);
  const pts = values.map((v, i) => [+(i / Math.max(1, values.length - 1) * w).toFixed(1), +(h - 3 - ((v - min) / Math.max(1e-9, max - min)) * (h - 8)).toFixed(1)]);
  const id = 'sp' + ++gid;
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".28"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs><path d="${smooth(pts)} L${w},${h} L0,${h}Z" fill="url(#${id})"/><path d="${smooth(pts)}" fill="none" stroke="${color}" stroke-width="1.8" vector-effect="non-scaling-stroke"/></svg>`;
}

// Cột dọc (có nhãn dưới, tooltip)
export function bars(entries, { color = '#2B5C94', h = 220, value = money, highlightMax = true } = {}) {
  const W = 340, pl = 4, pb = 30, max = Math.max(1, ...entries.map((e) => e[1]));
  const bw = (W - pl * 2) / entries.length;
  const id = 'bg' + ++gid;
  const out = entries.map(([k, v], i) => {
    const bh = (v / max) * (h - pb - 22), x = pl + i * bw + bw * 0.18, top = h - pb - bh;
    const best = highlightMax && v === max;
    return `<g><rect x="${x.toFixed(1)}" y="${top.toFixed(1)}" width="${(bw * 0.64).toFixed(1)}" height="${bh.toFixed(1)}" rx="6" fill="${best ? `url(#${id}g)` : `url(#${id})`}"><title>${esc(k)}: ${esc(value(v))}</title></rect>${best ? `<text x="${(x + bw * 0.32).toFixed(1)}" y="${(top - 6).toFixed(1)}" text-anchor="middle" class="ch-val">${esc(value(v))}</text>` : ''}<text x="${(x + bw * 0.32).toFixed(1)}" y="${h - 9}" text-anchor="middle">${esc(k)}</text></g>`;
  }).join('');
  return `<svg class="ch ch--bars" viewBox="0 0 ${W} ${h}" role="img" aria-label="Biểu đồ cột"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}"/><stop offset="1" stop-color="${color}" stop-opacity=".45"/></linearGradient><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E4CC94"/><stop offset="1" stop-color="#B8995F"/></linearGradient></defs>${out}</svg>`;
}

// Thanh ngang xếp hạng
export function hbars(entries, { value = money, sub = null, color = '#2B5C94' } = {}) {
  const max = Math.max(1, ...entries.map((e) => e[1]));
  return `<div class="hbars">${entries.map(([k, v, c], i) => `<div class="hbar"><span class="hbar__k"><em>${i + 1}</em>${esc(k)}</span><span class="hbar__t"><i style="width:${Math.max(2, (v / max) * 100).toFixed(1)}%;${c ? `background:${c}` : i === 0 ? '' : `background:${color}`}"></i></span><b>${esc(value(v))}</b>${sub ? `<small>${esc(sub(i))}</small>` : ''}</div>`).join('')}</div>`;
}

// Vùng (area) theo giờ / theo tuần, có thể nhiều đường
export function area(labels, series, { h = 240, value = money, showEvery = 1 } = {}) {
  const W = 620, pl = 48, pb = 26, pt = 14;
  const max = Math.max(1, ...series.flatMap((s) => s.values));
  const x = (i) => pl + (i / Math.max(1, labels.length - 1)) * (W - pl - 12);
  const y = (v) => pt + (1 - v / max) * (h - pb - pt);
  let defs = '', paths = '';
  series.forEach((s, si) => {
    const id = 'ar' + ++gid;
    const pts = s.values.map((v, i) => [+x(i).toFixed(1), +y(v).toFixed(1)]);
    defs += `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity="${si ? 0.12 : 0.3}"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient>`;
    paths += `<path d="${smooth(pts)} L${pts[pts.length - 1][0]},${h - pb} L${pts[0][0]},${h - pb}Z" fill="url(#${id})"/><path d="${smooth(pts)}" fill="none" stroke="${s.color}" stroke-width="${si ? 1.6 : 2.4}" ${s.dash ? 'stroke-dasharray="5 5"' : ''} stroke-linecap="round"/>`;
    const mi = s.values.indexOf(Math.max(...s.values));
    if (!si) paths += `<circle cx="${pts[mi][0]}" cy="${pts[mi][1]}" r="5" fill="#fff" stroke="${s.color}" stroke-width="2.4"/><text class="ch-val" x="${pts[mi][0]}" y="${pts[mi][1] - 12}" text-anchor="middle">${esc(value(s.values[mi]))}</text>`;
  });
  const grid = [0, 0.5, 1].map((g) => `<line x1="${pl}" x2="${W - 12}" y1="${y(max * g)}" y2="${y(max * g)}" class="ch-grid"/><text x="${pl - 8}" y="${y(max * g) + 4}" text-anchor="end">${esc(value(max * g))}</text>`).join('');
  const lbl = labels.map((l, i) => (i % showEvery === 0 ? `<text x="${x(i)}" y="${h - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  return `<svg class="ch" viewBox="0 0 ${W} ${h}" role="img" aria-label="Biểu đồ vùng"><defs>${defs}</defs>${grid}${paths}${lbl}</svg>`;
}

// Cột chồng (tỉ trọng phương thức thanh toán theo tuần)
export function stacked(labels, rows, keys, colors, { h = 240 } = {}) {
  const W = 620, pl = 8, pb = 26, bw = (W - pl * 2) / labels.length;
  const out = rows.map((r, i) => {
    const tot = keys.reduce((a, k) => a + (r[k] || 0), 0) || 1;
    let yy = h - pb;
    return keys.map((k, ki) => { const hh = ((r[k] || 0) / tot) * (h - pb - 10); yy -= hh; return `<rect x="${(pl + i * bw + bw * 0.14).toFixed(1)}" y="${yy.toFixed(1)}" width="${(bw * 0.72).toFixed(1)}" height="${Math.max(0, hh - 1).toFixed(1)}" rx="3" fill="${colors[ki]}"><title>${esc(labels[i])} · ${esc(k)}: ${Math.round(((r[k] || 0) / tot) * 100)}%</title></rect>`; }).join('');
  }).join('');
  const lbl = labels.map((l, i) => (i % Math.ceil(labels.length / 7) === 0 ? `<text x="${(pl + i * bw + bw / 2).toFixed(1)}" y="${h - 6}" text-anchor="middle">${esc(l)}</text>` : '')).join('');
  return `<svg class="ch" viewBox="0 0 ${W} ${h}" role="img" aria-label="Biểu đồ cột chồng">${out}${lbl}</svg>`;
}

// Vòng tròn mục tiêu (gauge)
export function ring(ratio, { label = '', sub = '', expected = null } = {}) {
  const r = 78, C = 2 * Math.PI * r, k = Math.max(0, Math.min(1, ratio));
  const id = 'rg' + ++gid;
  const exp = expected != null ? (() => { const a = -Math.PI / 2 + Math.min(1, expected) * Math.PI * 2; return `<line x1="${100 + Math.cos(a) * 64}" y1="${100 + Math.sin(a) * 64}" x2="${100 + Math.cos(a) * 92}" y2="${100 + Math.sin(a) * 92}" stroke="#E8735A" stroke-width="2.5" stroke-linecap="round"><title>Tiến độ kỳ vọng theo ngày</title></line>`; })() : '';
  return `<svg class="ring" viewBox="0 0 200 200" role="img" aria-label="${esc(label)}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2B5C94"/><stop offset=".6" stop-color="#86AEDD"/><stop offset="1" stop-color="#C9A86A"/></linearGradient></defs>
  <circle cx="100" cy="100" r="${r}" fill="none" stroke="currentColor" stroke-opacity=".08" stroke-width="16"/>
  <circle cx="100" cy="100" r="${r}" fill="none" stroke="url(#${id})" stroke-width="16" stroke-linecap="round" stroke-dasharray="${(C * k).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 100 100)" class="ring__arc"/>${exp}
  <text x="100" y="98" text-anchor="middle" class="ring__v">${Math.round(ratio * 100)}%</text><text x="100" y="122" text-anchor="middle" class="ring__l">${esc(sub)}</text></svg>`;
}

// Phễu chuyển đổi
export function funnel(steps) {
  const max = steps[0][1] || 1;
  return `<div class="funnel">${steps.map(([k, v], i) => { const w = Math.max(3, (v / max) * 100); const rate = i ? ((v / (steps[i - 1][1] || 1)) * 100).toFixed(1).replace('.', ',') + '%' : ''; return `<div class="funnel__row"><span class="funnel__k">${esc(k)}</span><span class="funnel__t"><span class="funnel__bar" style="width:${w.toFixed(1)}%;--i:${i}"></span></span><b>${new Intl.NumberFormat('vi-VN').format(v)}</b><small>${rate ? '↳ ' + rate : ''}</small></div>`; }).join('')}</div>`;
}

// Donut nhiều phần
export function donut(entries, { colors = COLORS, center = '', value = money } = {}) {
  const total = entries.reduce((s, e) => s + e[1], 0) || 1;
  let a = -Math.PI / 2;
  const arcs = entries.map(([k, v], i) => {
    const a2 = a + (v / total) * Math.PI * 2, large = a2 - a > Math.PI ? 1 : 0;
    const p = (ang, r) => `${(100 + Math.cos(ang) * r).toFixed(2)},${(100 + Math.sin(ang) * r).toFixed(2)}`;
    const d = `M${p(a, 82)} A82 82 0 ${large} 1 ${p(a2 - 0.0001, 82)} L${p(a2 - 0.0001, 56)} A56 56 0 ${large} 0 ${p(a, 56)} Z`;
    a = a2;
    return `<path d="${d}" fill="${colors[i % colors.length]}" stroke="var(--surface, #fff)" stroke-width="2"><title>${esc(k)}: ${esc(value(v))}</title></path>`;
  }).join('');
  return `<div class="donut2"><svg viewBox="0 0 200 200" role="img" aria-label="Biểu đồ tròn">${arcs}<text x="100" y="98" text-anchor="middle" class="ring__v" style="font-size:22px">${esc(center || value(total))}</text><text x="100" y="118" text-anchor="middle" class="ring__l">tổng</text></svg>
  <ul class="legend2">${entries.map(([k, v], i) => `<li><i style="background:${colors[i % colors.length]}"></i><span>${esc(k)}</span><b>${Math.round((v / total) * 100)}%</b></li>`).join('')}</ul></div>`;
}

// Bảng cohort (tỉ lệ quay lại)
export function cohort(rows) {
  return `<div class="tbl-wrap"><table class="cohort"><thead><tr><th>Tháng mua đầu</th><th>Khách</th>${[1, 2, 3, 4, 5].map((k) => `<th>+${k} th</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr><th>${esc(r.label)}</th><td>${r.size}</td>${[0, 1, 2, 3, 4].map((k) => (r.row[k] == null ? '<td class="na"></td>' : `<td style="--v:${Math.min(1, r.row[k] * 3).toFixed(2)}">${(r.row[k] * 100).toFixed(1).replace('.', ',')}%</td>`)).join('')}</tr>`).join('')}</tbody></table></div>`;
}

// Mini-bar 24 giờ
export function hoursChart(hours) {
  const max = Math.max(1, ...hours);
  return `<div class="hours">${hours.map((v, h) => `<span title="${h}h: ${v} đơn" style="--v:${(v / max).toFixed(3)}"><i></i>${h % 3 === 0 ? `<em>${h}h</em>` : ''}</span>`).join('')}</div>`;
}

export { fmt };
