// Hệ thống âm thanh dùng chung (Web Audio API).
// - Menu nhạc nền (khách tự chọn ở thanh bên phải):
//   · Interstellar – Main Theme (mặc định) · Osamu Fukuzawa – Smooth Bossa Nova · Samurai Beats – Kabuki Phonk
//     (mỗi bài là một file mp3 nhúng dạng base64 trong js/nhac-*.js, chỉ tải khi được chọn phát)
//   · "Alokio Bass": nhạc ambient có bass đập, TẠO BẰNG CODE (không cần file).
// - Âm lượng & bài đang chọn được nhớ trong localStorage (alokio:volume, alokio:music).
// - Chuỗi xử lý: nhạc → EQ bass (lowshelf) → EQ treble (highshelf) → echo (delay + feedback) → master → analyser.
// - Analyser tách 3 dải bass / mid / treble, bắt nhịp bass để mặt nước tạo vòng sóng.
// - Trình duyệt chặn tự phát âm thanh → chỉ bắt đầu sau một cú chạm/nhấp của người dùng.

const listeners = new Set();
const beatListeners = new Set();
let ctx = null, master, analyser, bassEQ, trebleEQ, echoDelay, echoWet, echoFb, musicBus, reverb, reverbGain;
let playing = false, scheduler = null, nextTime = 0, step = 0, filmBus = null;
export const TRACKS = [
  { id: 'interstellar', title: 'Interstellar – Main Theme', artist: 'Hans Zimmer', file: 'js/nhac-interstellar.js' },
  { id: 'osamu', title: 'Smooth Bossa Nova', artist: 'Osamu Fukuzawa', file: 'js/nhac-osamu.js' },
  { id: 'phonk', title: 'Samurai Beats · Kabuki Phonk', artist: 'Japanese Trap', file: 'js/nhac-phonk.js' },
  { id: 'bass', title: 'Alokio Bass', artist: 'Nhạc tổng hợp · bass đập', file: null },
];
const els = {}; // id → <audio>
const loading = {};
const modeListeners = new Set();
const volListeners = new Set();
const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, v); } catch { /* noop */ } } };
let mode = TRACKS.some((t) => t.id === LS.get('alokio:music', '')) ? LS.get('alokio:music', '') : 'interstellar';
const isFile = (m = mode) => m !== 'bass';
let micStream = null, micSource = null, micGain = null, micAnalyser = null;
const freq = new Uint8Array(512);
const bands = { bass: 0, mid: 0, treble: 0, level: 0 };
let bassAvg = 0.1, lastBeat = 0;
const eqState = { bass: 0, treble: 0, echo: 0.18, volume: Math.min(1, Math.max(0, Number(LS.get('alokio:volume', '0.8')) || 0)) };

const BPM = 76;
const SPB = 60 / BPM;
// Hợp âm (Hz) – Dmaj9 · A/C# · Bm11 · Gmaj7 (tông sáng, mềm)
const CHORDS = [
  { root: 73.42, notes: [293.66, 369.99, 440.0, 554.37, 659.25] },
  { root: 69.3, notes: [277.18, 329.63, 440.0, 554.37, 659.25] },
  { root: 61.74, notes: [246.94, 293.66, 369.99, 440.0, 659.25] },
  { root: 49.0, notes: [246.94, 293.66, 369.99, 392.0, 587.33] },
];

function impulse(seconds = 3.6, decay = 2.6) {
  const rate = ctx.sampleRate, len = rate * seconds;
  const buf = ctx.createBuffer(2, len, rate);
  for (let c = 0; c < 2; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
  }
  return buf;
}

function build() {
  ctx = new (window.AudioContext || window.webkitAudioContext)();
  musicBus = ctx.createGain(); musicBus.gain.value = 1;
  filmBus = ctx.createGain(); filmBus.gain.value = 1.15; filmBus.connect(musicBus);
  bassEQ = ctx.createBiquadFilter(); bassEQ.type = 'lowshelf'; bassEQ.frequency.value = 180;
  trebleEQ = ctx.createBiquadFilter(); trebleEQ.type = 'highshelf'; trebleEQ.frequency.value = 3200;
  echoDelay = ctx.createDelay(1.5); echoDelay.delayTime.value = SPB * 0.75;
  echoFb = ctx.createGain(); echoFb.gain.value = 0.35;
  echoWet = ctx.createGain(); echoWet.gain.value = eqState.echo;
  reverb = ctx.createConvolver(); reverb.buffer = impulse();
  reverbGain = ctx.createGain(); reverbGain.gain.value = 0.5;
  master = ctx.createGain(); master.gain.value = 0;
  analyser = ctx.createAnalyser(); analyser.fftSize = 1024; analyser.smoothingTimeConstant = 0.8;
  musicBus.connect(bassEQ); bassEQ.connect(trebleEQ);
  trebleEQ.connect(master);
  trebleEQ.connect(echoDelay); echoDelay.connect(echoFb); echoFb.connect(echoDelay); echoDelay.connect(echoWet); echoWet.connect(master);
  trebleEQ.connect(reverb); reverb.connect(reverbGain); reverbGain.connect(master);
  master.connect(analyser); analyser.connect(ctx.destination);
  setEQ(eqState);
}

// ---------- Nhạc tạo bằng code ----------
function pad(time, chord, dur) {
  const filt = ctx.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.setValueAtTime(900, time); filt.frequency.linearRampToValueAtTime(1700, time + dur * 0.5); filt.frequency.linearRampToValueAtTime(1000, time + dur); filt.Q.value = 0.4;
  const g = ctx.createGain(); g.gain.setValueAtTime(0, time); g.gain.linearRampToValueAtTime(0.05, time + 1.6); g.gain.setValueAtTime(0.05, time + dur - 1.2); g.gain.linearRampToValueAtTime(0, time + dur + 0.8);
  filt.connect(g); g.connect(musicBus);
  for (const f of chord.notes.slice(0, 4)) {
    for (const det of [-6, 7]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f / 2; o.detune.value = det;
      o.connect(filt); o.start(time); o.stop(time + dur + 1);
    }
  }
}
function pluck(time, f, vel = 0.12) {
  const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = f;
  const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2;
  const g = ctx.createGain(); g.gain.setValueAtTime(0, time); g.gain.linearRampToValueAtTime(vel, time + 0.008); g.gain.exponentialRampToValueAtTime(0.0008, time + 1.4);
  const g2 = ctx.createGain(); g2.gain.value = 0.25;
  o.connect(g); o2.connect(g2); g2.connect(g); g.connect(musicBus);
  o.start(time); o2.start(time); o.stop(time + 1.5); o2.stop(time + 1.5);
}
function thump(time, f, vel = 0.9) {
  const o = ctx.createOscillator(); o.type = 'sine';
  o.frequency.setValueAtTime(f * 2.2, time); o.frequency.exponentialRampToValueAtTime(f, time + 0.12);
  const g = ctx.createGain(); g.gain.setValueAtTime(0, time); g.gain.linearRampToValueAtTime(vel * 0.55, time + 0.01); g.gain.exponentialRampToValueAtTime(0.001, time + 0.75);
  o.connect(g); g.connect(musicBus); o.start(time); o.stop(time + 0.8);
}
let noiseBuf = null;
function shaker(time, vel = 0.03) {
  if (!noiseBuf) { noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.2, ctx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
  const s = ctx.createBufferSource(); s.buffer = noiseBuf;
  const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000;
  const g = ctx.createGain(); g.gain.setValueAtTime(vel, time); g.gain.exponentialRampToValueAtTime(0.0005, time + 0.08);
  s.connect(hp); hp.connect(g); g.connect(musicBus); s.start(time); s.stop(time + 0.1);
}

// Bộ hẹn giờ nhìn trước (lookahead) — mỗi bước = 1/2 phách
function schedule() {
  while (nextTime < ctx.currentTime + 0.15) {
    const bar = Math.floor(step / 8);
    const inBar = step % 8;
    const chord = CHORDS[bar % CHORDS.length];
    if (inBar === 0) pad(nextTime, chord, SPB * 4);
    if (inBar === 0 || inBar === 4 || (inBar === 5 && bar % 2 === 1)) thump(nextTime, chord.root, inBar === 5 ? 0.6 : 0.95);
    const arp = [0, 2, 4, 1, 3, 2, 4, 1];
    if (Math.random() < (inBar % 2 ? 0.55 : 0.9)) pluck(nextTime, chord.notes[arp[inBar]] * (bar % 4 === 3 && inBar > 4 ? 2 : 1), 0.06 + Math.random() * 0.05);
    if (inBar % 2 === 1) shaker(nextTime, 0.018 + Math.random() * 0.012);
    nextTime += SPB / 2;
    step++;
  }
}

// ---------- Nhạc nền từ file mp3 (nhúng base64 → Blob, chạy được cả khi mở file:// trực tiếp) ----------
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src; s.onload = resolve; s.onerror = () => reject(new Error('Không tải được ' + src));
    document.head.appendChild(s);
  });
}
function ensureTrack(id) {
  if (els[id]) return Promise.resolve(els[id]);
  if (loading[id]) return loading[id];
  const tr = TRACKS.find((t) => t.id === id);
  loading[id] = (async () => {
    window.__ALK_TRACKS__ = window.__ALK_TRACKS__ || {};
    if (!window.__ALK_TRACKS__[id]) await loadScript(tr.file);
    const bin = atob(window.__ALK_TRACKS__[id]);
    delete window.__ALK_TRACKS__[id];
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const el = new Audio(URL.createObjectURL(new Blob([bytes], { type: 'audio/mpeg' })));
    el.loop = true;
    el.preload = 'auto';
    ctx.createMediaElementSource(el).connect(filmBus);
    els[id] = el;
    return el;
  })();
  loading[id].catch(() => { delete loading[id]; });
  return loading[id];
}

async function startSource() {
  if (isFile()) {
    const want = mode;
    try { const el = await ensureTrack(want); if (playing && mode === want) await el.play(); return; }
    catch (e) { console.warn('[alokio] Không phát được file nhạc, chuyển sang nhạc tổng hợp.', e); mode = 'bass'; modeListeners.forEach((fn) => fn(mode)); }
  }
  clearInterval(scheduler);
  nextTime = ctx.currentTime + 0.05; scheduler = setInterval(schedule, 25); schedule();
}
function stopSource(which = mode) {
  if (isFile(which)) { if (els[which]) els[which].pause(); }
  else clearInterval(scheduler);
}

export const getMode = () => mode;
export const getTrack = () => TRACKS.find((t) => t.id === mode);
export function onMode(fn) { modeListeners.add(fn); return () => modeListeners.delete(fn); }
export async function setMode(m) {
  const next = TRACKS.some((t) => t.id === m) ? m : 'interstellar';
  if (next === mode) return;
  const prev = mode;
  mode = next;
  LS.set('alokio:music', mode);
  modeListeners.forEach((fn) => fn(mode));
  if (!ctx) return;
  setEQ({});
  if (playing) { stopSource(prev); if (isFile(next) && els[next]) els[next].currentTime = 0; await startSource(); }
}

export async function play() {
  if (!ctx) build();
  if (ctx.state === 'suspended') await ctx.resume();
  if (playing) return;
  playing = true;
  emit();
  await startSource();
  if (!playing) return;
  master.gain.cancelScheduledValues(ctx.currentTime);
  master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
  master.gain.linearRampToValueAtTime(eqState.volume, ctx.currentTime + 1.5);
  try { localStorage.setItem('alokio:sound', '1'); } catch { /* noop */ }
  emit();
}

export function pause({ remember = true } = {}) {
  if (!ctx || !playing) return;
  playing = false;
  master.gain.cancelScheduledValues(ctx.currentTime);
  master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
  master.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.2);
  setTimeout(() => { if (!playing) { clearInterval(scheduler); Object.values(els).forEach((el) => el.pause()); } }, 1300);
  if (remember) try { localStorage.setItem('alokio:sound', '0'); } catch { /* noop */ }
  emit();
}

export const toggle = () => (playing ? pause() : play());
export const isPlaying = () => playing;
export const wantsSound = () => { try { return localStorage.getItem('alokio:sound') === '1'; } catch { return false; } };

export function setEQ({ bass, treble, echo, volume } = {}) {
  if (bass != null) eqState.bass = bass;
  if (treble != null) eqState.treble = treble;
  if (echo != null) eqState.echo = echo;
  if (volume != null && volume !== eqState.volume) {
    eqState.volume = Math.min(1, Math.max(0, volume));
    LS.set('alokio:volume', String(eqState.volume));
    volListeners.forEach((fn) => fn(eqState.volume));
  }
  if (!ctx) return;
  const t = ctx.currentTime;
  // Bản phim đã có sẵn không gian vang → giảm echo/reverb để giữ âm thanh trong trẻo
  const wet = isFile() ? 0.35 : 1;
  bassEQ.gain.setTargetAtTime(eqState.bass, t, 0.05);
  trebleEQ.gain.setTargetAtTime(eqState.treble, t, 0.05);
  echoWet.gain.setTargetAtTime(eqState.echo * 0.9 * wet, t, 0.05);
  echoFb.gain.setTargetAtTime((0.2 + eqState.echo * 0.45) * (isFile() ? 0.6 : 1), t, 0.05);
  reverbGain.gain.setTargetAtTime(isFile() ? 0.18 : 0.5, t, 0.05);
  if (playing) master.gain.setTargetAtTime(eqState.volume, t, 0.08);
}
export const getEQ = () => ({ ...eqState });
export const getVolume = () => eqState.volume;
export const setVolume = (v) => setEQ({ volume: v });
export function onVolume(fn) { volListeners.add(fn); return () => volListeners.delete(fn); }

// Gọi mỗi khung hình: trả về {bass, mid, treble, level} trong khoảng 0–1
export function readBands(t = performance.now() / 1000) {
  if (ctx && (playing || master.gain.value > 0.01)) {
    analyser.getByteFrequencyData(freq);
    const hz = ctx.sampleRate / analyser.fftSize;
    const avg = (a, b) => { let s = 0, n = 0; for (let i = Math.max(1, Math.floor(a / hz)); i <= Math.min(freq.length - 1, Math.ceil(b / hz)); i++) { s += freq[i]; n++; } return n ? s / n / 255 : 0; };
    const b = avg(20, 150), m = avg(150, 2000), tr = avg(2000, 8000);
    bands.bass += (b - bands.bass) * 0.35;
    bands.mid += (m - bands.mid) * 0.3;
    bands.treble += (tr * 1.6 - bands.treble) * 0.3;
    bands.level = (bands.bass + bands.mid + bands.treble) / 3;
    // bắt nhịp bass
    bassAvg += (bands.bass - bassAvg) * 0.04;
    const now = performance.now();
    if (bands.bass > bassAvg * 1.35 && bands.bass > 0.1 && now - lastBeat > 180) {
      lastBeat = now;
      beatListeners.forEach((fn) => fn(bands.bass));
    }
  } else {
    // "Thở": khi chưa bật nhạc, mặt nước vẫn sống động nhẹ nhàng
    bands.bass = 0.15 + 0.1 * Math.sin(t * 0.8);
    bands.mid = 0.1 + 0.05 * Math.sin(t * 0.5 + 1);
    bands.treble = 0.05;
    bands.level = 0.1;
  }
  return bands;
}

export function onBeat(fn) { beatListeners.add(fn); return () => beatListeners.delete(fn); }
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit() { listeners.forEach((fn) => fn(playing)); }

// ---------- Micro karaoke ----------
export async function startMic() {
  if (!ctx) build();
  if (ctx.state === 'suspended') await ctx.resume();
  micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  micSource = ctx.createMediaStreamSource(micStream);
  micGain = ctx.createGain(); micGain.gain.value = 0.9;
  micAnalyser = ctx.createAnalyser(); micAnalyser.fftSize = 512;
  micSource.connect(micAnalyser);
  micSource.connect(micGain);
  micGain.connect(echoDelay); micGain.connect(reverb); micGain.connect(master);
  if (!playing) { master.gain.setTargetAtTime(eqState.volume, ctx.currentTime, 0.1); }
  const buf = new Uint8Array(micAnalyser.fftSize);
  return () => {
    micAnalyser.getByteTimeDomainData(buf);
    let peak = 0; for (const v of buf) peak = Math.max(peak, Math.abs(v - 128) / 128);
    return peak;
  };
}
export function stopMic() {
  if (micStream) micStream.getTracks().forEach((t) => t.stop());
  try { micSource && micSource.disconnect(); micGain && micGain.disconnect(); } catch { /* noop */ }
  micStream = micSource = micGain = micAnalyser = null;
  if (!playing && master) master.gain.setTargetAtTime(0, ctx.currentTime, 0.2);
}

// Tiếng "tách" khi xoay núm / "ting" khi có đơn mới (admin)
export function tick(freqHz = 2200) {
  if (!ctx) return;
  const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = freqHz;
  const g = ctx.createGain(); g.gain.setValueAtTime(0.02, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.03);
  o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.04);
}
export function ting() {
  if (!ctx) build();
  if (ctx.state === 'suspended') ctx.resume();
  [1318.5, 1760].forEach((f, i) => {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    const g = ctx.createGain(); const t = ctx.currentTime + i * 0.12;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.18, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 1);
  });
}

document.addEventListener('visibilitychange', () => {
  if (!ctx) return;
  if (document.hidden && playing) { pause({ remember: false }); ctx.__resume = true; }
  else if (!document.hidden && ctx.__resume) { ctx.__resume = false; play(); }
});
