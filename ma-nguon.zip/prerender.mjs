// Xuất sẵn HTML đầy đủ cho từng trang (SEO + ảnh xem trước khi chia sẻ + hiện nội dung ngay khi mạng chậm).
// node prerender.mjs <thư-mục-site> <phiên-bản>
// JS (js/alokio.js) vẫn dựng lại trang sau khi tải để gắn dữ liệu riêng của người xem (giỏ hàng, đăng nhập…).
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const esbuild = (await import('/opt/npm-tools/node_modules/esbuild/lib/main.js')).default;
const ROOT = path.dirname(new URL(import.meta.url).pathname), OUT = process.argv[2], VER = process.argv[3];
const SITE = 'https://ango1108.github.io/ALOKIO-E-commerce';
// Môi trường giả cho Node: localStorage trong bộ nhớ
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k), clear: () => mem.clear() };
globalThis.window = globalThis; window.addEventListener = () => {}; window.removeEventListener = () => {};
const tmp = path.join(ROOT, '.prerender.cjs');
await esbuild.build({ entryPoints: [path.join(ROOT, 'browser/prerender-entry.js')], outfile: tmp, bundle: true, platform: 'node', format: 'cjs', logLevel: 'warning',
  define: { 'process.env.SITE_URL': JSON.stringify(SITE) } });
const MOD = (await import(pathToFileURL(tmp).href)).default; const { handle, boot, ROUTES, toFile } = MOD.default || MOD;
fs.unlinkSync(tmp);
boot();
const st = JSON.parse(mem.get('alokio:db'));
const products = st.products.filter((p) => !p.hidden).map((p) => p.slug), posts = st.posts.map((p) => p.slug);
// Ghi danh sách trang đã xuất sẵn cho gói JS (routes.js dùng để tạo liên kết)
fs.writeFileSync(path.join(ROOT, 'browser/prerendered.js'), fs.readFileSync(path.join(ROOT, 'browser/prerendered.js'), 'utf8').replace(/export const PRERENDERED = .*;/, `export const PRERENDERED = ${JSON.stringify({ product: products, post: posts })};`));

const ASSET = /(["'(\s,=])\/(img|fonts|brand|uploads|audio|css|js|vendor)\//g;
const fixAssets = (s) => s.replace(ASSET, '$1$2/');
const LOADER = fs.readFileSync(path.join(ROOT, 'browser/loader.html'), 'utf8').replace(/\n\s*/g, '').replace('__VER__', VER);
const jobs = [];
for (const [vpath, file] of ROUTES) {
  if (vpath.includes(':') || vpath.startsWith('/admin') || vpath === '/404') continue;
  jobs.push([vpath, file]);
}
for (const s of products) jobs.push(['/san-pham/' + s, `san-pham--${s}.html`]);
for (const s of posts) jobs.push(['/blog/' + s, `bai-viet--${s}.html`]);
let n = 0;
for (const [vpath, file] of jobs) {
  const res = await handle({ method: 'GET', url: vpath, body: null, cookie: '' });
  if (res.status !== 200) { console.warn('bỏ qua', vpath, res.status); continue; }
  let h = fixAssets(String(res.body)).replace(/(\shref=)(["'])(\/(?!\/|api\/)[^"']*)\2/g, (_, a, q, v) => `${a}${q}${toFile(v.replace(/&amp;/g, '&')).replace(/&/g, '&amp;')}${q}`);
  const url = `${SITE}/${file === 'index.html' ? '' : file}`;
  h = h.replace(/<link rel="canonical" href="[^"]*">/, `<link rel="canonical" href="${url}">`).replace(/<meta property="og:url" content="[^"]*">/, `<meta property="og:url" content="${url}">`)
    .replace(/<link rel="manifest"[^>]*>\n?/, '')
    .replace(/<link rel="stylesheet" href="css\/site\.css\?v=[^"]*">/, `<link rel="stylesheet" href="css/site.css?v=${VER}">`)
    .replace(/<script>window\.__ALOKIO__=[\s\S]*?<\/script>\n?/, '')
    .replace(/<script type="module" src="[^"]*"><\/script>\n?/g, '')
    .replace('<html lang="vi">', `<html lang="vi" class="${file === 'index.html' ? '' : 'pre'}">`)
    .replace(/<body([^>]*)>/, (m) => m + (file === 'index.html' ? LOADER : ''))
    .replace('</body>', `<script src="js/alokio.js?v=${VER}" defer></script>\n</body>`);
  // Ảnh xem trước khi chia sẻ: dùng bản JPG 1200×630 (Facebook, Zalo đọc tốt nhất)
  h = h.replace(/<meta property="og:image" content="([^"]*)">/, (m, u) => {
    const pm = u.match(/img\/products\/([^/]+)\.webp$/), bm = u.match(/img\/blog\/([^/]+)\.webp$/);
    const j = pm ? `img/og/${pm[1]}.jpg` : bm ? `img/og/blog-${bm[1]}.jpg` : 'img/og/og-default.jpg';
    return `<meta property="og:image" content="${SITE}/${fs.existsSync(path.join(OUT, j)) ? j : 'img/og/og-default.jpg'}">\n<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">`;
  });
  h = h.replace('<!DOCTYPE html>', `<!DOCTYPE html>\n<!-- Trang: ${vpath} — HTML xuất sẵn lúc build; js/alokio.js dựng lại với dữ liệu của người xem (localStorage) -->`);
  fs.writeFileSync(path.join(OUT, file), h); n++;
}
// Sơ đồ trang cho Google
const today = new Date().toISOString().slice(0, 10);
fs.writeFileSync(path.join(OUT, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${jobs.filter(([v]) => !/gio-hang|thanh-toan|tai-khoan|tra-cuu|yeu-thich|so-sanh|tim-kiem/.test(v)).map(([, f]) => `  <url><loc>${SITE}/${f === 'index.html' ? '' : f}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>\n`);
fs.writeFileSync(path.join(OUT, 'robots.txt'), `User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: ${SITE}/sitemap.xml\n`);
console.log('prerender xong', n, 'trang');
