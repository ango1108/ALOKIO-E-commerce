# Dựng sẵn texture 3D: chạy website ở chế độ __ALK_BAKE, thu mọi texture canvas rồi ghi img/tex/*.webp + bản kê
import asyncio, json, base64, os, re, sys
from playwright.async_api import async_playwright
OUT=sys.argv[1]  # thư mục site
MIN_MS=float(sys.argv[2]) if len(sys.argv)>2 else 5
INIT="sessionStorage.setItem('alokio:intro','1');window.__ALK_BAKE={};"
async def harvest(pg, acc):
    d=await pg.evaluate("JSON.stringify(window.__ALK_BAKE||{})")
    for k,v in json.loads(d).items():
        if k not in acc: acc[k]=v
async def main():
    acc={}
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        for vp in [{'width':1440,'height':900}]:
            ctx=await b.new_context(viewport=vp); await ctx.add_init_script(INIT)
            pg=await ctx.new_page(); pg.set_default_timeout(120000)
            await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(8000)
            H=await pg.evaluate('document.body.scrollHeight')
            for y in range(0,H,800):
                await pg.evaluate(f'scrollTo(0,{y})'); await pg.wait_for_timeout(2500)
                if await pg.evaluate("(()=>{const s=document.querySelector('[data-inside]');if(!s)return false;const r=s.getBoundingClientRect();return r.top<innerHeight&&r.bottom>0})()"):
                    for t in range(3):
                        await pg.evaluate(f"document.querySelectorAll('[data-in-tab]')[{t}].click()"); await pg.wait_for_timeout(9000)
            await harvest(pg, acc); print('index', len(acc), flush=True)
            await pg.goto('http://localhost:8765/showroom.html'); await pg.wait_for_timeout(12000)
            for i in range(24):
                await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(1800)
            await harvest(pg, acc); print('showroom', len(acc), flush=True)
            for slug in ['alokio-luxe-ha-long','alokio-luxe-hoi-an','loa-keo-alokio-al-ak18','alokio-luxe-song-huong','alokio-luxe-ho-tay']:
                await pg.goto(f'http://localhost:8765/san-pham.html?slug={slug}'); await pg.wait_for_timeout(9000)
                await harvest(pg, acc)
            print('products', len(acc), flush=True)
        await b.close()
    os.makedirs(f'{OUT}/img/tex', exist_ok=True)
    for f in os.listdir(f'{OUT}/img/tex'): os.remove(f'{OUT}/img/tex/{f}')
    man={}; total=0; n=0; skipped=0
    for k,v in sorted(acc.items()):
        if v['ms']<MIN_MS or k.startswith('t:lcd') or k.startswith('t:wm'): skipped+=1; continue
        def save(dsc):
            global_n=len(os.listdir(f'{OUT}/img/tex'))
            safe=re.sub(r'[^a-z0-9]+','-',dsc['f'].lower())[:50].strip('-')
            fn=f'{global_n:03d}-{safe}'.replace('-webp','')+'.webp'
            data=base64.b64decode(dsc['data'].split(',',1)[1]); open(f'{OUT}/img/tex/{fn}','wb').write(data)
            o={kk:vv for kk,vv in dsc.items() if kk!='data'}; o['f']=fn; return o,len(data)
        if 't' in v: o,sz=save(v['t']); man[k]={'t':o}; total+=sz
        else:
            oo={}
            for q,dsc in v['o'].items(): o,sz=save(dsc); oo[q]=o; total+=sz
            man[k]={'o':oo}
        n+=1
    json.dump(man, open('/home/claude/texmap.json','w'), ensure_ascii=False)
    print('baked',n,'keys, skipped',skipped,'size KB',total//1024)
    for k,v in sorted(acc.items(), key=lambda kv:-kv[1]['ms'])[:15]: print(round(v['ms']),k)
asyncio.run(main())
