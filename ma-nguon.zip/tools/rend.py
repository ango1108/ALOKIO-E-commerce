import sys, asyncio, base64, io, time
from playwright.async_api import async_playwright
from PIL import Image
# usage: rend.py shot W H ss [shot W H ss ...]
import json as _j
if sys.argv[1].endswith('.json'):
    jobs=_j.load(open(sys.argv[1]))
else:
    jobs=[sys.argv[i:i+4] for i in range(1,len(sys.argv),4)]
async def one(b, shot, W, H, ss, extra='', out=None):
    out = out or shot
    pg=await b.new_page(viewport={'width':800,'height':600}); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.on('console', lambda m: m.type=='error' and errs.append(m.text[:300]))
    t=time.time()
    await pg.goto(f'http://localhost:8765/_r/render.html?shot={shot}&w={W}&h={H}&ss={ss}'+extra)
    await pg.wait_for_function('window.__go', timeout=60000)
    await pg.evaluate('window.__go()')
    await pg.wait_for_function('window.__done', timeout=900000, polling=1000)
    err=await pg.evaluate('window.__err')
    if err: print(shot,'ERR',err[:800],errs[:3]); await pg.close(); return
    d=await pg.evaluate('window.__out'); im=Image.open(io.BytesIO(base64.b64decode(d.split(',')[1]))).convert('RGB')
    im=im.resize((int(W),int(H)), Image.LANCZOS); im.save(f'/home/claude/renders/{out}.png'); im.save(f'/home/claude/renders/{out}.webp', quality=88, method=6)
    print(out,'ok',round(time.time()-t),'s',errs[:2]); await pg.close()
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--disable-gpu-watchdog'])
        for j in jobs:
            try:
                await one(b,*j) if isinstance(j,list) else await one(b,j['shot'],j['W'],j['H'],j['ss'],j.get('extra',''),j.get('out'))
            except Exception as e:
                print('FAIL', j if isinstance(j,list) else j.get('out'), str(e)[:200], flush=True)
        await b.close()
asyncio.run(main())
