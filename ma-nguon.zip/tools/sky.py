import numpy as np, sys
from PIL import Image, ImageFilter
def grade(src, dst):
    im=np.asarray(Image.open(src).convert('RGB')).astype(np.float32)/255
    H,W,_=im.shape
    mx=im.max(2); mn=im.min(2); lum=im.mean(2)
    neutral=((mx-mn)<0.075)&(lum>0.62)&((im[...,2]-im[...,0])>-0.02)
    frac=neutral.mean(1)
    hz=0
    for i in range(H):
        if frac[i]<0.45 and i>H*0.05: break
        hz=i
    if hz<H*0.1: return None
    yy=np.arange(H)[:,None].astype(np.float32)
    t=np.clip(yy/hz,0,1)[...,None]
    top=np.array([0.60,0.75,0.93]); hor=np.array([0.86,0.92,0.97])
    col=top*(1-t**1.3)+hor*(t**1.3)
    target=np.clip(col*(lum/ (col.mean(2)))[...,None]*1.0,0,1)
    m=neutral.astype(np.float32)*(yy<=hz+2)
    m=np.asarray(Image.fromarray((m*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2.5))).astype(np.float32)/255*0.85
    out=im*(1-m[...,None])+target*m[...,None]
    Image.fromarray((np.clip(out,0,1)*255+.5).astype(np.uint8)).save(dst, quality=88, method=6)
    return round(hz/H,2)
for s in sys.argv[2:]:
    print(s, grade(f'{sys.argv[1]}/{s}.png', f'/home/claude/renders/g/{s.split("/")[-1]}.webp'))
