# Ảnh xem trước khi chia sẻ (1200×630 JPG): sản phẩm, bài viết, mặc định
import json, os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter
SITE=sys.argv[1]; R='/home/claude/renders'
os.makedirs(f'{SITE}/img/og', exist_ok=True)
F='/home/claude/alokio-e-commerce/fonts'
serif=lambda s: ImageFont.truetype(f'{F}/PlayfairDisplay.woff', s)
sans=lambda s: ImageFont.truetype(f'{F}/BeVietnamPro-Medium.woff', s)
def crop_wide(src, out):
    im=Image.open(src).convert('RGB'); w,h=im.size; th=int(w*630/1200)
    top=max(0,(h-th)//2); im=im.crop((0,top,w,top+th)).resize((1200,630),Image.LANCZOS); im.save(out,quality=86,optimize=True,progressive=True)
P=json.load(open('/home/claude/products.json'))
import importlib
tag={}
for p in P:
    st=f'{R}/p/{p["slug"]}.png'
    if not os.path.exists(st): continue
    im=Image.open(st).convert('RGB').resize((630,630),Image.LANCZOS)
    # nền trái lấy đúng màu phông studio ở mép trái ảnh, chuyển dần sang ảnh
    col=im.crop((0,0,12,630)).resize((1,630),Image.BOX).resize((570,630))
    bg=Image.new('RGB',(1200,630)); bg.paste(col,(0,0)); bg.paste(im,(570,0))
    edge=Image.new('L',(80,630)); ed=ImageDraw.Draw(edge)
    for x in range(80): ed.line([(x,0),(x,630)],fill=int(255*x/79))
    bg.paste(col.crop((0,0,80,630)),(570,0),Image.eval(edge,lambda v:255-v))
    d=ImageDraw.Draw(bg)
    line='ALOKIO LUXE' if p['line']=='luxe' else 'LOA KÉO KARAOKE'
    d.text((64,190),line,font=sans(22),fill='#2B5C94')
    name=p['name'].replace('Alokio Luxe ','').replace('Loa kéo Alokio ','')
    d.text((60,228),name,font=serif(76 if len(name)<12 else 60),fill='#0F2A4A')
    d.text((64,342),'Âm Thanh Việt · Alokio',font=sans(24),fill='#5b6b80')
    d.rounded_rectangle((64,400,64+250,452),radius=26,fill='#0F2A4A'); d.text((94,413),'Xem sản phẩm',font=sans(21),fill='#ffffff')
    bg.save(f'{SITE}/img/og/{p["slug"]}.jpg',quality=86,optimize=True,progressive=True)
for c in ['material','home','wave','water','bar','karaoke','knobs','battery']:
    src=f'{R}/blog-{c}.png'
    if os.path.exists(src): crop_wide(src, f'{SITE}/img/og/blog-{c}.jpg')
crop_wide(f'{R}/feat-lacquer.png', f'{SITE}/img/og/og-default.jpg')
print('og ok', len(os.listdir(f'{SITE}/img/og')))
