// Đóng gói bản HTML tĩnh: node build.mjs  →  dist/alokio-html/
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(ROOT, 'dist/alokio-html');
let esbuild;
for (const p of [process.env.ESBUILD_PATH, 'esbuild', '/opt/npm-tools/node_modules/esbuild/lib/main.js'].filter(Boolean)) {
  try { esbuild = await import(p); break; } catch { /* thử tiếp */ }
}
esbuild = esbuild.default || esbuild;

const { ROUTES } = await import('./browser/routes.js');

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

// 1) Tài nguyên tĩnh
for (const d of ['img', 'fonts', 'brand']) fs.cpSync(path.join(ROOT, 'public', d), path.join(OUT, d), { recursive: true });
fs.mkdirSync(path.join(OUT, 'css'), { recursive: true });
for (const f of ['site.css', 'admin.css']) {
  const css = fs.readFileSync(path.join(ROOT, 'public/css', f), 'utf8').replace(/url\((['"]?)\/(fonts|img|brand)\//g, 'url($1../$2/');
  fs.writeFileSync(path.join(OUT, 'css', f), css);
}

// 2) Danh sách file (thay cho fs.existsSync)
const list = [];
const walk = (dir, rel = '') => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const r = rel ? rel + '/' + e.name : e.name; if (e.isDirectory()) walk(path.join(dir, e.name), r); else list.push(r); } };
walk(OUT);
fs.writeFileSync(path.join(ROOT, 'server/files.json'), JSON.stringify(list));

// 3) Gói JavaScript (một file duy nhất, chạy được khi mở trực tiếp bằng file://)
const threePlugin = {
  name: 'three-vendor',
  setup(b) {
    b.onResolve({ filter: /^three$/ }, () => ({ path: path.join(ROOT, 'vendor/three/three.module.js') }));
    b.onResolve({ filter: /^three\/addons\// }, (a) => ({ path: path.join(ROOT, 'vendor/three/addons', a.path.replace('three/addons/', '')) }));
  },
};
const minify = !process.argv.includes('--readable');
const CLIENT = path.join(ROOT, 'client');
// Gói chính: thay import('../three/x.js') bằng __alk3d('x') → three.js nằm ở gói riêng, tải khi cần
const lazy3d = {
  name: 'lazy-3d',
  setup(b) {
    b.onLoad({ filter: /[\\/]client[\\/](pages|lib|admin)[\\/].*\.js$/ }, (a) => ({
      contents: fs.readFileSync(a.path, 'utf8').replace(/import\((['"])\.\.\/three\/(\w+)\.js\1\)/g, (_, q, n) => `__alk3d('${n}')`),
      loader: 'js',
    }));
  },
};
// Gói 3D: các module dùng chung (âm thanh, giỏ, realtime) lấy từ gói chính
const shared = {
  name: 'shared-from-main',
  setup(b) {
    const MAP = { 'audio.js': 'audio', 'lib/core.js': 'core', 'lib/cart.js': 'cart', 'lib/live.js': 'live' };
    b.onResolve({ filter: /audio\.js$|lib\/(core|cart|live)\.js$/ }, (a) => {
      const abs = path.resolve(a.resolveDir, a.path);
      const rel = path.relative(CLIENT, abs).split(path.sep).join('/');
      return MAP[rel] ? { path: MAP[rel], namespace: 'shared' } : undefined;
    });
    b.onLoad({ filter: /.*/, namespace: 'shared' }, (a) => ({ contents: `module.exports = window.__alkShared.${a.path};`, loader: 'js' }));
  },
};
const common = { bundle: true, format: 'iife', target: ['es2020'], minify, legalComments: 'none', charset: 'utf8', logLevel: 'warning' };
await esbuild.build({
  ...common, entryPoints: [path.join(ROOT, 'browser/main.js')], outfile: path.join(OUT, 'js/alokio.js'),
  banner: { js: '/* Alokio – Âm Thanh Việt · bản HTML tĩnh (đồ án môn học). Mã nguồn đọc được nằm trong ma-nguon.zip. */\nvar process = { env: {} };' },
  plugins: [lazy3d],
});
await esbuild.build({
  ...common, entryPoints: [path.join(ROOT, 'browser/three-entry.js')], outfile: path.join(OUT, 'js/alokio-3d.js'),
  banner: { js: '/* Alokio – gói 3D (three.js MIT) */' },
  plugins: [threePlugin, shared],
});
// CSS nén gọn
for (const f of ['site.css', 'admin.css']) {
  const r = await esbuild.transform(fs.readFileSync(path.join(OUT, 'css', f), 'utf8'), { loader: 'css', minify: true, legalComments: 'none' });
  fs.writeFileSync(path.join(OUT, 'css', f), r.code);
}

// 3b) Nhạc nền: mỗi bài mp3 được nhúng dạng base64 vào một file .js để chạy được cả khi mở trực tiếp (file://).
//     Các file này chỉ được tải khi người xem chọn phát bài đó.
const SONGS = { interstellar: 'Interstellar – Main Theme (Hans Zimmer)', osamu: 'Smooth Bossa Nova (Osamu Fukuzawa)', phonk: 'Samurai Beats · Kabuki Phonk (trích 5 phút)' };
for (const [id, title] of Object.entries(SONGS)) {
  const mp3 = path.join(ROOT, 'public/audio', id + '.mp3');
  if (!fs.existsSync(mp3)) continue;
  fs.writeFileSync(path.join(OUT, `js/nhac-${id}.js`), `/* Nhạc nền: ${title}. Dùng cho đồ án môn học. */\n(window.__ALK_TRACKS__=window.__ALK_TRACKS__||{})[${JSON.stringify(id)}]="` + fs.readFileSync(mp3).toString('base64') + '";\n');
}

// 4) Các trang .html (mỗi đường dẫn của website là một file)
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
// Số phiên bản gắn vào đường dẫn CSS/JS (đổi mỗi lần phát hành để trình duyệt không dùng bản cũ trong bộ nhớ đệm)
const VER = '20261121b';
const LOADER = fs.readFileSync(path.join(ROOT, 'browser/loader.html'), 'utf8').replace(/\n\s*/g, '').replace('__VER__', VER);
for (const [vpath, file, label] of ROUTES) {
  if (fs.existsSync(path.join(OUT, file))) continue;
  const admin = file.startsWith('admin') && file !== 'admin-in-don.html';
  const theme = admin
    ? `<script>try{if(localStorage.getItem('alokio:admin-theme')==='dark')document.documentElement.classList.add('dark')}catch(e){}</script>`
    : `<script>try{if(localStorage.getItem('alokio:lite')==='1')document.documentElement.classList.add('lite')}catch(e){}</script>`;
  const html = `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(label)} | Alokio – Âm Thanh Việt</title>
<!-- Trang: ${vpath} — nội dung được dựng bởi js/alokio.js từ dữ liệu giả lập (localStorage) -->
<link rel="icon" href="img/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="css/site.css?v=${VER}" media="print" onload="this.media='all'">${admin ? '\n<link rel="stylesheet" href="css/admin.css?v=${VER}" media="print" onload="this.media=\'all\'">' : ''}
<noscript><link rel="stylesheet" href="css/site.css?v=${VER}"></noscript>
${theme}
</head>
<body${admin ? ' class="adm"' : ''}>
${file === 'admin-in-don.html' ? '' : LOADER}
<noscript><style>#alk-loader{display:none}</style><p style="padding:40px;text-align:center;font-family:sans-serif">Vui lòng bật JavaScript để xem website Alokio.</p></noscript>
<script src="js/alokio.js?v=${VER}" defer></script>
</body>
</html>
`;
  fs.writeFileSync(path.join(OUT, file), html);
}
// 5) README + mã nguồn đọc được (ma-nguon.zip)
fs.copyFileSync(path.join(ROOT, 'README.dist.md'), path.join(OUT, 'README.md'));
const { execSync } = await import('node:child_process');
try { execSync(`cd "${ROOT}" && zip -qr "${path.join(OUT, 'ma-nguon.zip')}" browser client server vendor/qrcode.js vendor/qrcode-LICENSE public/css build.mjs README.dist.md -x "server/files.json"`); } catch (e) { console.warn('Không tạo được ma-nguon.zip:', e.message); }
const size = fs.statSync(path.join(OUT, 'js/alokio.js')).size;
console.log(`Xong: ${OUT}  (js/alokio.js ${(size / 1024).toFixed(0)} KB, ${ROUTES.length} đường dẫn)`);
