import { hasFile } from '../files.js';
import { html, raw, esc } from './html.js';
import { icon } from './icons.js';
import { PUBLIC } from '../paths.js';

// Logo thật: đặt file vào public/brand/alokio-logo.svg (hoặc .png). Nếu chưa có → chữ ALOKIO.
export function logoFile() {
  for (const f of ['alokio-logo.svg', 'alokio-logo.png', 'alokio-logo.webp']) {
    if (hasFile('brand', f)) return '/brand/' + f;
  }
  return null;
}

export function logo(cls = '') {
  const f = logoFile();
  if (f) return html`<img class="logo-img ${cls}" src="${f}" alt="Alokio" width="132" height="36">`;
  return html`<span class="wordmark ${cls}">ALOKIO</span>`;
}

export function siteUrl() {
  return (process.env.SITE_URL || 'http://localhost:3000').replace(/\/$/, '');
}

const NAV = [
  { href: '/bo-suu-tap/alokio-luxe', label: 'Alokio Luxe', mega: true },
  { href: '/bo-suu-tap/am-thanh-viet-karaoke', label: 'Karaoke' },
  { href: '/showroom', label: 'Showroom 3D' },
  { href: '/flash-sale', label: 'Flash sale' },
  { href: '/blog', label: 'Cẩm nang' },
  { href: '/ho-tro', label: 'Hỗ trợ' },
];

export function layout(ctx, { title, description = '', body, page = '', scripts = [], jsonld = [], canonical, noindex = false, ogImage, bodyClass = '', preload = [] }) {
  const s = ctx.state.settings;
  const url = siteUrl() + (canonical || ctx.url.pathname);
  const fullTitle = title ? `${title} | Alokio – Âm Thanh Việt` : 'Alokio – Âm Thanh Việt';
  const desc = description || 'Alokio – Âm Thanh Việt: loa bluetooth cao cấp Alokio Luxe (dòng ý tưởng) và loa kéo karaoke chính hãng. Trải nghiệm 3D, thanh toán QR động, giao toàn quốc.';
  const og = siteUrl() + (ogImage || '/img/og/og-default.webp');
  const org = {
    '@context': 'https://schema.org', '@type': 'Organization', name: 'Alokio – Âm Thanh Việt', url: siteUrl(),
    logo: siteUrl() + (logoFile() || '/img/icon-512.png'), sameAs: [s.links.facebook, s.links.tiktok, s.links.shopee],
  };
  const site = { '@context': 'https://schema.org', '@type': 'WebSite', name: 'Alokio', url: siteUrl(), potentialAction: { '@type': 'SearchAction', target: siteUrl() + '/tim-kiem?q={q}', 'query-input': 'required name=q' } };
  const ld = [org, site, ...jsonld].map((j) => `<script type="application/ld+json">${JSON.stringify(j).replace(/</g, '\\u003c')}</script>`).join('');
  const boot = { page, user: ctx.customer ? { name: ctx.customer.name, email: ctx.customer.email } : null, links: s.links };
  return '<!DOCTYPE html>' + html`
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${fullTitle}</title>
<meta name="description" content="${desc}">
<link rel="canonical" href="${url}">
${noindex ? raw('<meta name="robots" content="noindex, nofollow">') : ''}
<meta property="og:type" content="website">
<meta property="og:site_name" content="Alokio – Âm Thanh Việt">
<meta property="og:title" content="${fullTitle}">
<meta property="og:description" content="${desc}">
<meta property="og:url" content="${url}">
<meta property="og:image" content="${og}">
<meta property="og:locale" content="vi_VN">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#F7FAFD">
<link rel="icon" href="/img/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/img/icon-512.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="preload" href="/fonts/BeVietnamPro-Regular.woff" as="font" type="font/woff" crossorigin>
<link rel="preload" href="/fonts/PlayfairDisplay.woff" as="font" type="font/woff" crossorigin>
${preload.map((p) => raw(`<link rel="preload" href="${esc(p.href)}" as="${esc(p.as)}"${p.type ? ` type="${esc(p.type)}"` : ''}${p.fetchpriority ? ` fetchpriority="${p.fetchpriority}"` : ''}>`))}
<link rel="stylesheet" href="/css/site.css?v=${ctx.assetVersion}">
${raw(ld)}
<script>try{if(localStorage.getItem('alokio:lite')==='1')document.documentElement.classList.add('lite')}catch(e){}</script>
</head>
<body class="${bodyClass}" data-page="${page}">
<a class="skip" href="#main">Bỏ qua tới nội dung chính</a>
${header(ctx)}
<main id="main" tabindex="-1">${body}</main>
${footer(ctx)}
${chrome(ctx)}
<script>window.__ALOKIO__=${raw(JSON.stringify(boot).replace(/</g, '\\u003c'))}</script>
<script type="module" src="/js/site.js?v=${ctx.assetVersion}"></script>
${scripts.map((sc) => raw(`<script type="module" src="${sc}?v=${ctx.assetVersion}"></script>`))}
</body>
</html>`;
}

function header(ctx) {
  const s = ctx.state.settings;
  const luxe = ctx.state.products.filter((p) => p.line === 'luxe' && p.category !== 'phu-kien' && !p.hidden);
  const path = ctx.url.pathname;
  return html`
<header class="nav" data-nav>
  <div class="nav__pill">
    <a class="nav__brand" href="/" aria-label="Alokio – Trang chủ">${logo()}</a>
    <nav class="nav__links" aria-label="Điều hướng chính">
      <ul>
        ${NAV.map((n) => html`<li class="${n.mega ? 'has-mega' : ''}"><a href="${n.href}" ${path.startsWith(n.href) ? raw('aria-current="page"') : ''}>${n.label}</a>
          ${n.mega ? html`<div class="mega" role="group" aria-label="Các mẫu Alokio Luxe"><div class="mega__grid">${luxe.map((p) => html`<a class="mega__item" href="/san-pham/${p.slug}"><img src="${p.image}" alt="" width="120" height="120" loading="lazy" decoding="async"><span>${p.name.replace('Alokio Luxe ', '')}</span></a>`)}</div><a class="mega__all link-arrow" href="/bo-suu-tap/alokio-luxe">Xem toàn bộ bộ sưu tập ${icon('arrow', { size: 16 })}</a></div>` : ''}
        </li>`)}
      </ul>
    </nav>
    <div class="nav__actions">
      <button class="icon-btn" type="button" data-sound-toggle aria-pressed="false" title="Âm thanh: Tắt"><span class="sr-only" data-sound-label>Âm thanh: Tắt</span>${icon('mute', { cls: 'when-off' })}${icon('sound', { cls: 'when-on' })}</button>
      <button class="icon-btn" type="button" data-search-open aria-label="Tìm kiếm">${icon('search')}</button>
      <a class="icon-btn hide-sm" href="/so-sanh" aria-label="So sánh sản phẩm">${icon('compare')}<span class="badge" data-compare-count hidden>0</span></a>
      <a class="icon-btn hide-sm" href="/yeu-thich" aria-label="Danh sách yêu thích">${icon('heart')}<span class="badge" data-wish-count hidden>0</span></a>
      <a class="icon-btn hide-sm" href="${ctx.customer ? '/tai-khoan' : '/tai-khoan/dang-nhap'}" aria-label="Tài khoản">${icon('user')}</a>
      <button class="icon-btn" type="button" data-cart-open aria-label="Giỏ hàng" aria-controls="minicart">${icon('cart')}<span class="badge" data-cart-count hidden>0</span></button>
      <span class="nav__social hide-md">
        <a class="icon-btn icon-btn--sm" href="${s.links.facebook}" target="_blank" rel="noopener noreferrer" aria-label="Facebook Alokio (mở tab mới)">${icon('facebook', { size: 18 })}</a>
        <a class="icon-btn icon-btn--sm" href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer" aria-label="TikTok Shop Alokio (mở tab mới)">${icon('tiktok', { size: 18 })}</a>
        <a class="icon-btn icon-btn--sm" href="${s.links.shopee}" target="_blank" rel="noopener noreferrer" aria-label="Shopee Alokio (mở tab mới)">${icon('shopee', { size: 18 })}</a>
      </span>
      <button class="icon-btn show-md" type="button" data-drawer-open aria-label="Mở menu" aria-controls="mobile-menu" aria-expanded="false">${icon('menu')}</button>
    </div>
  </div>
</header>`;
}

function footer(ctx) {
  const s = ctx.state.settings;
  const year = new Date().getFullYear();
  return html`
<footer class="footer">
  <div class="container footer__grid">
    <div class="footer__brand">
      ${logo('logo--footer')}
      <p class="muted">Âm Thanh Việt. Loa kéo karaoke chính hãng và bộ sưu tập ý tưởng Alokio Luxe: sơn mài, khảm trai, vải lanh và nhôm champagne.</p>
      <form class="pill-form" data-newsletter novalidate>
        <label class="sr-only" for="nl-footer">Email nhận tin</label>
        <input id="nl-footer" type="email" name="email" placeholder="Email của bạn" autocomplete="email" required>
        <button class="btn btn--primary" type="submit">Nhận tin</button>
        <p class="form-msg" aria-live="polite"></p>
      </form>
    </div>
    <div>
      <h2 class="footer__title">Sản phẩm</h2>
      <ul class="footer__list">
        <li><a href="/bo-suu-tap/alokio-luxe">Alokio Luxe</a></li>
        <li><a href="/danh-muc/loa-di-dong">Loa di động</a></li>
        <li><a href="/danh-muc/loa-nghe-tai-gia">Loa nghe tại gia</a></li>
        <li><a href="/danh-muc/soundbar-rap-phim">Soundbar & rạp phim</a></li>
        <li><a href="/bo-suu-tap/am-thanh-viet-karaoke">Loa kéo karaoke</a></li>
        <li><a href="/danh-muc/phu-kien">Phụ kiện</a></li>
      </ul>
    </div>
    <div>
      <h2 class="footer__title">Hỗ trợ</h2>
      <ul class="footer__list">
        <li><a href="/tra-cuu-don-hang">Tra cứu đơn hàng</a></li>
        <li><a href="/ho-tro">Câu hỏi thường gặp</a></li>
        <li><a href="/chinh-sach/van-chuyen">Vận chuyển</a></li>
        <li><a href="/chinh-sach/doi-tra">Đổi trả</a></li>
        <li><a href="/chinh-sach/bao-hanh">Bảo hành</a></li>
        <li><a href="/chinh-sach/bao-mat">Bảo mật</a></li>
        <li><a href="/lien-he">Liên hệ</a></li>
      </ul>
    </div>
    <div>
      <h2 class="footer__title">Kênh chính thức</h2>
      <ul class="footer__list footer__social">
        <li><a href="${s.links.facebook}" target="_blank" rel="noopener noreferrer">${icon('facebook', { size: 18 })} Facebook</a></li>
        <li><a href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer">${icon('tiktok', { size: 18 })} TikTok Shop</a></li>
        <li><a href="${s.links.shopee}" target="_blank" rel="noopener noreferrer">${icon('shopee', { size: 18 })} Shopee</a></li>
      </ul>
      <button class="btn btn--soft btn--sm" type="button" data-lite-toggle aria-pressed="false">${icon('layers', { size: 16 })} <span>Chế độ nhẹ: Tắt</span></button>
    </div>
  </div>
  <div class="container footer__legal">
    <p>© ${year} Alokio – Âm Thanh Việt. Website demo phục vụ đồ án môn học. Mọi thanh toán trên website là giả lập (sandbox), không phát sinh giao dịch thật. Dòng Alokio Luxe là sản phẩm ý tưởng của đồ án. Mua loa kéo Alokio chính hãng tại các kênh chính thức.</p>
    <p><a href="/dieu-khoan">Điều khoản</a> · <a href="/chinh-sach/bao-mat">Bảo mật</a> · <a href="/admin">Quản trị</a></p>
  </div>
</footer>`;
}

function chrome(ctx) {
  const s = ctx.state.settings;
  return html`
<aside class="dock" data-rail aria-label="Âm lượng và điều hướng nhanh">
  <button class="dock__btn" type="button" data-sound-toggle aria-pressed="false" title="Âm thanh: Tắt"><span class="sr-only" data-sound-label>Âm thanh: Tắt</span>${icon('mute', { cls: 'when-off', size: 18 })}${icon('sound', { cls: 'when-on', size: 18 })}</button>
  <div class="dock__vol" data-vol role="slider" tabindex="0" aria-label="Âm lượng" aria-orientation="vertical" aria-valuemin="0" aria-valuemax="100" aria-valuenow="80" aria-valuetext="80%">
    <span class="dock__track"><span class="dock__fill" data-vol-fill></span><span class="dock__thumb" data-vol-thumb></span></span>
  </div>
  <span class="dock__pct" data-vol-pct aria-hidden="true">80</span>
  <div class="dock__music">
    <button class="dock__btn dock__note" type="button" data-music-open aria-haspopup="true" aria-expanded="false" aria-controls="music-menu" title="Chọn nhạc nền"><svg class="ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg><span class="sr-only">Chọn nhạc nền</span></button>
    <div class="dock__menu" id="music-menu" data-music-menu role="menu" aria-label="Chọn nhạc nền" hidden>
      <p class="dock__menu-title">Nhạc nền <span>· nghe thử</span></p>
      <div class="dock__list" data-music-list></div>
    </div>
  </div>
  <span class="dock__sep" aria-hidden="true"></span>
  <button class="dock__btn dock__top" type="button" data-to-top title="Lên đầu trang" aria-label="Lên đầu trang">${icon('arrow', { size: 18 })}</button>
  <span class="dock__tip" data-rail-tip role="status" aria-live="polite"></span>
</aside>
<div class="drawer" id="minicart" data-minicart role="dialog" aria-modal="true" aria-labelledby="minicart-title" hidden>
  <div class="drawer__scrim" data-close></div>
  <div class="drawer__panel" tabindex="-1">
    <div class="drawer__head"><h2 id="minicart-title">Giỏ hàng</h2><button class="icon-btn" type="button" data-close aria-label="Đóng giỏ hàng">${icon('close')}</button></div>
    <div class="drawer__body" data-minicart-body><p class="muted">Đang tải…</p></div>
    <div class="drawer__foot" data-minicart-foot></div>
  </div>
</div>
<div class="drawer drawer--left" id="mobile-menu" data-mobile-menu role="dialog" aria-modal="true" aria-label="Menu" hidden>
  <div class="drawer__scrim" data-close></div>
  <div class="drawer__panel" tabindex="-1">
    <div class="drawer__paint" data-menu-paint aria-hidden="true"></div>
    <div class="drawer__head">${logo()}<button class="icon-btn" type="button" data-close aria-label="Đóng menu">${icon('close')}</button></div>
    <nav class="drawer__body mobile-nav" aria-label="Menu di động">
      <span class="mobile-nav__eyebrow">Âm Thanh Việt · Bộ sưu tập 2026</span>
      <a href="/">Trang chủ</a>${NAV.map((n) => html`<a href="${n.href}">${n.label}</a>`)}
      <a href="/cua-hang">Tất cả sản phẩm</a><a href="/so-sanh">So sánh</a><a href="/yeu-thich">Yêu thích</a>
      <a href="${ctx.customer ? '/tai-khoan' : '/tai-khoan/dang-nhap'}">Tài khoản</a><a href="/tra-cuu-don-hang">Tra cứu đơn hàng</a>
      <div class="mobile-nav__social">
        <a href="${s.links.facebook}" target="_blank" rel="noopener noreferrer">${icon('facebook')} Facebook</a>
        <a href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer">${icon('tiktok')} TikTok Shop</a>
        <a href="${s.links.shopee}" target="_blank" rel="noopener noreferrer">${icon('shopee')} Shopee</a>
      </div>
    </nav>
  </div>
</div>
<div class="search-overlay" data-search role="dialog" aria-modal="true" aria-label="Tìm kiếm" hidden>
  <div class="search-overlay__panel">
    <form action="/tim-kiem" method="get" class="search-form" role="search">
      ${icon('search')}
      <label class="sr-only" for="q-global">Tìm sản phẩm</label>
      <input id="q-global" name="q" type="search" placeholder="Tìm loa, bộ sưu tập, bài viết…" autocomplete="off" data-search-input aria-controls="search-suggest" aria-autocomplete="list">
      <button class="icon-btn" type="button" data-close aria-label="Đóng tìm kiếm">${icon('close')}</button>
    </form>
    <ul class="search-suggest" id="search-suggest" data-search-suggest role="listbox"></ul>
  </div>
</div>
<div class="fab" data-fab>
  <div class="fab__menu" id="fab-menu" hidden>
    <a class="fab__item fab__item--fb" href="${s.links.facebook}" target="_blank" rel="noopener noreferrer">${icon('facebook')}<span>Facebook</span></a>
    <a class="fab__item fab__item--tt" href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer">${icon('tiktok')}<span>TikTok Shop</span></a>
    <a class="fab__item fab__item--sp" href="${s.links.shopee}" target="_blank" rel="noopener noreferrer">${icon('shopee')}<span>Shopee</span></a>
    <button class="fab__item fab__item--chat" type="button" data-chat-open>${icon('chat')}<span>Chat với Alokio</span></button>
  </div>
  <button class="fab__btn" type="button" data-fab-toggle aria-expanded="false" aria-controls="fab-menu" aria-label="Liên hệ Alokio">${icon('chat', { size: 24 })}</button>
</div>
<section class="chat" data-chat role="dialog" aria-label="Chat với Alokio" hidden>
  <header class="chat__head"><div><strong>Alokio</strong><span class="chat__status"><i></i> Đang trực tuyến</span></div><button class="icon-btn" type="button" data-chat-close aria-label="Đóng chat">${icon('close')}</button></header>
  <div class="chat__body" data-chat-body aria-live="polite"></div>
  <div class="chat__quick" data-chat-quick>
    <button type="button">Hạ Long còn màu Ngọc Trai không?</button><button type="button">Giao hàng mất bao lâu?</button><button type="button">Loa kéo mua ở đâu?</button>
  </div>
  <form class="chat__form" data-chat-form>
    <label class="sr-only" for="chat-input">Nhập tin nhắn</label>
    <input id="chat-input" name="text" placeholder="Nhập tin nhắn…" autocomplete="off" maxlength="500">
    <button class="btn btn--primary btn--sm" type="submit">Gửi</button>
  </form>
</section>
<div class="toasts" data-toasts aria-live="polite" aria-atomic="false"></div>
<div class="ticker" data-ticker hidden aria-live="off"></div>`;
}

export function breadcrumbs(items) {
  const ld = { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.label, item: it.href ? siteUrl() + it.href : undefined })) };
  return {
    html: html`<nav class="crumbs" aria-label="Đường dẫn"><ol>${items.map((it, i) => html`<li>${it.href && i < items.length - 1 ? html`<a href="${it.href}">${it.label}</a>` : html`<span aria-current="page">${it.label}</span>`}</li>`)}</ol></nav>`,
    ld,
  };
}
