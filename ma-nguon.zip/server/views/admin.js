// Trang quản trị: khung (sidebar + topbar) dựng sẵn, nội dung từng mục do mã giao diện gọi API giả lập & cập nhật theo thời gian thực giữa các tab.
import { html, raw, fmt, fmtDateTime, esc } from './html.js';
import { icon } from './icons.js';
import { logo } from './layout.js';
import { ROLES, can } from '../auth.js';
import { STATUS_LABEL, PAYMENT_LABEL, PAY_STATUS_LABEL } from '../commerce.js';
import { FINISHES } from '../seed/catalog.js';

const NAV = [
  ['tong-quan', '', 'Tổng quan', 'chart', 'dashboard'],
  ['phan-tich', 'phan-tich', 'Phân tích chuyên sâu', 'eye', 'dashboard'],
  ['don-hang', 'don-hang', 'Đơn hàng', 'box', 'orders'],
  ['giao-dich', 'giao-dich', 'Giao dịch', 'qr', 'payments'],
  ['san-pham', 'san-pham', 'Sản phẩm', 'cube', 'products'],
  ['kho', 'kho', 'Kho hàng', 'layers', 'inventory'],
  ['khach-hang', 'khach-hang', 'Khách hàng', 'users', 'customers'],
  ['chat', 'chat', 'Hộp thư chat', 'chat', 'chat'],
  ['ma-giam-gia', 'ma-giam-gia', 'Mã giảm giá', 'tag', '*'],
  ['flash-sale', 'flash-sale', 'Flash sale', 'zap', '*'],
  ['danh-gia', 'danh-gia', 'Đánh giá', 'sparkle', 'reviews'],
  ['noi-dung', 'noi-dung', 'Nội dung & blog', 'file', '*'],
  ['cai-dat', 'cai-dat', 'Cài đặt', 'settings', '*'],
  ['nhan-vien', 'nhan-vien', 'Nhân viên & nhật ký', 'shield', '*'],
];

function head(title, v) {
  return `<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>${esc(title)} · Quản trị Alokio</title><link rel="icon" href="/img/favicon.svg"><link rel="stylesheet" href="/css/site.css?v=${v}"><link rel="stylesheet" href="/css/admin.css?v=${v}"><script>try{if(localStorage.getItem('alokio:admin-theme')==='dark')document.documentElement.classList.add('dark')}catch(e){}</script></head>`;
}

export function loginPage(ctx) {
  const next = ctx.url.searchParams.get('next') || '/admin';
  return head('Đăng nhập', ctx.assetVersion) + html`<body class="adm-login"><main id="main" class="auth"><div style="text-align:center;margin-bottom:24px">${logo()}<p class="label" style="margin-top:12px">Trang quản trị</p></div>
  <form class="panel" data-admin-login data-next="${next}" novalidate>
    <h1 style="font-size:34px;margin:0">Đăng nhập</h1>
    <label class="field"><span>Email</span><input class="input" name="email" type="email" autocomplete="username" required value="admin@alokio.vn"></label>
    <label class="field"><span>Mật khẩu</span><input class="input" name="password" type="password" autocomplete="current-password" required></label>
    <p class="err" data-err aria-live="assertive"></p>
    <button class="btn btn--primary btn--block btn--lg" type="submit">Đăng nhập</button>
    <button class="btn btn--demo btn--block btn--lg" type="button" data-demo="admin@alokio.vn|Admin@123">Dùng tài khoản demo</button>
    <div class="demo-cred">Thử vai trò khác:
      <span class="demo-cred__btns"><button type="button" data-demo="nhanvien@alokio.vn|Staff@123">Nhân viên bán hàng</button><button type="button" data-demo="kho@alokio.vn|Kho@123">Nhân viên kho</button></span>
      <small><b>admin@alokio.vn</b> / Admin@123 · <b>nhanvien@alokio.vn</b> / Staff@123 · <b>kho@alokio.vn</b> / Kho@123</small></div>
    <a href="/" class="link-arrow">${icon('back', { size: 16 })} Về cửa hàng</a>
  </form></main>
  <script>
  __alk.paintFixed('admin-login');
  var lf=document.querySelector('[data-admin-login]');
  lf.addEventListener('submit',async(e)=>{e.preventDefault();const f=e.target;const r=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:f.email.value,password:f.password.value})});const d=await r.json();if(!r.ok){f.querySelector('[data-err]').textContent=d.error;return}__alk.go(f.dataset.next)});
  lf.querySelectorAll('[data-demo]').forEach(function(b){b.addEventListener('click',function(){var v=b.dataset.demo.split('|');lf.email.value=v[0];lf.password.value=v[1];lf.requestSubmit()})});
  </script></body></html>`;
}

export function shell(ctx, active, detail = null) {
  const u = ctx.staff;
  const items = NAV.filter((n) => can(u, n[4] === 'dashboard' ? 'dashboard' : n[4]) || n[4] === 'dashboard');
  const allowed = NAV.find((n) => n[0] === active);
  const ok = allowed && (allowed[4] === 'dashboard' || can(u, allowed[4]));
  const title = allowed ? allowed[2] : 'Quản trị';
  return head(title, ctx.assetVersion) + html`<body class="adm" data-admin="${active}" data-detail="${detail || ''}">
<a class="skip" href="#main">Bỏ qua tới nội dung chính</a>
<aside class="adm__side" data-side>
  <a class="adm__brand" href="/admin">${logo()}<span class="label">Quản trị</span></a>
  <nav aria-label="Quản trị"><ul>${items.map(([id, path, label, ic]) => html`<li><a href="/admin${path ? '/' + path : ''}" ${id === active ? raw('aria-current="page"') : ''}>${icon(ic, { size: 18 })}<span>${label}</span><b class="adm__badge" data-badge="${id}" hidden></b></a></li>`)}</ul></nav>
  <div class="adm__me"><b>${u.name}</b><span>${ROLES[u.role].label}</span></div>
</aside>
<div class="adm__main">
  <header class="adm__top">
    <button class="icon-btn adm__burger" type="button" data-side-toggle aria-label="Mở menu">${icon('menu')}</button>
    <button class="adm__search" type="button" data-cmdk>${icon('search', { size: 16 })}<span>Tìm đơn, sản phẩm, khách…</span><kbd>Ctrl K</kbd></button>
    <div class="adm__tools">
      <span class="adm__live" title="Số tab cửa hàng đang mở trên trình duyệt này"><i></i> <b data-online>0</b> đang online</span>
      ${can(u, '*') ? html`<label class="adm__sim" title="Tự tạo đơn hàng ngẫu nhiên để demo realtime"><input type="checkbox" data-sim-toggle ${ctx.state.settings.simulator.enabled ? raw('checked') : ''}> <span>Mô phỏng đơn</span></label>` : ''}
      <button class="icon-btn" type="button" data-theme aria-label="Đổi giao diện sáng/tối">${icon('moon')}</button>
      <div class="adm__bellwrap"><button class="icon-btn" type="button" data-bell aria-label="Thông báo" aria-expanded="false">${icon('bell')}<span class="badge" data-bell-n hidden>0</span></button><div class="adm__notes" data-notes hidden><p class="muted" style="padding:14px">Chưa có thông báo mới.</p></div></div>
      <a class="icon-btn" href="/" target="_blank" rel="noopener" aria-label="Mở cửa hàng">${icon('external')}</a>
      <button class="icon-btn" type="button" data-logout aria-label="Đăng xuất">${icon('logout')}</button>
    </div>
  </header>
  <main id="main" class="adm__content" tabindex="-1" data-content>
    ${ok ? html`<p class="muted">Đang tải…</p>` : html`<div class="panel"><h1>Không có quyền truy cập</h1><p class="muted">Tài khoản ${ROLES[u.role].label} không được phép mở mục này.</p><a class="btn btn--primary" href="/admin">Về tổng quan</a></div>`}
  </main>
</div>
<div class="adm__cmdk" data-cmdk-box role="dialog" aria-modal="true" aria-label="Tìm kiếm nhanh" hidden><div class="adm__cmdk-panel"><input class="input" placeholder="Nhập mã đơn, tên khách, sản phẩm…" data-cmdk-input aria-label="Tìm kiếm"><ul data-cmdk-list role="listbox"></ul></div></div>
<div class="toasts" data-toasts aria-live="polite"></div>
<div class="modal" data-modal role="dialog" aria-modal="true" hidden><div class="drawer__scrim" data-close></div><div class="modal__panel drawer__panel" tabindex="-1" data-modal-panel></div></div>
<script type="module" src="/js/admin.js?v=${ctx.assetVersion}"></script>
</body></html>`;
}

export function invoice(ctx, code, kind) {
  const o = ctx.state.orders.find((x) => x.code === code);
  if (!o) return 'Không tìm thấy đơn hàng';
  const label = kind === 'giao-hang' ? 'PHIẾU GIAO HÀNG' : 'HOÁ ĐƠN BÁN HÀNG (DEMO)';
  const qr = `/tra-cuu-don-hang?ma=${o.code}`;
  return `<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>${label} ${esc(o.code)}</title><link rel="stylesheet" href="/css/site.css"><style>body{background:#fff;padding:40px;font-size:15px}.inv{max-width:820px;margin:auto}.inv table{width:100%;border-collapse:collapse;margin:20px 0}.inv th,.inv td{border-bottom:1px solid #ddd;padding:10px;text-align:left}.inv h1{font-size:30px}.r{text-align:right}@media print{.np{display:none}}</style></head><body><div class="inv">
<div class="row"><div>${String(logo())}<p class="muted" style="margin:6px 0 0">Alokio – Âm Thanh Việt · Website demo đồ án</p></div><div class="r"><h1 style="margin:0">${label}</h1><p>Số: <b>${esc(o.code)}</b><br>${esc(fmtDateTime(o.createdAt))}</p></div></div>
<div class="row" style="align-items:flex-start;margin-top:24px"><div><p class="label">Người nhận</p><p><b>${esc(o.address.name)}</b> · ${esc(o.contact.phone)}<br>${esc(o.address.street)}, ${esc(o.address.ward)}, ${esc(o.address.provinceName)}</p></div><div class="r"><p class="label">Thanh toán</p><p>${esc(PAYMENT_LABEL[o.payment.method])}<br>${esc(PAY_STATUS_LABEL[o.payment.status])}</p></div></div>
<table><thead><tr><th>Sản phẩm</th><th>Màu</th><th class="r">SL</th><th class="r">Đơn giá</th><th class="r">Thành tiền</th></tr></thead><tbody>${o.items.map((l) => `<tr><td>${esc(l.name)}${l.options?.engraving ? `<br><small>Khắc: ${esc(l.options.engraving)}</small>` : ''}</td><td>${esc(FINISHES[l.finish]?.name || l.finish)}</td><td class="r">${l.qty}</td><td class="r">${esc(fmt(l.price))}</td><td class="r">${esc(fmt(l.total))}</td></tr>`).join('')}</tbody></table>
<div style="margin-left:auto;max-width:320px"><div class="row"><span>Tạm tính</span><span>${esc(fmt(o.subtotal))}</span></div>${o.discount ? `<div class="row"><span>Giảm giá</span><span>−${esc(fmt(o.discount))}</span></div>` : ''}<div class="row"><span>Vận chuyển</span><span>${esc(fmt(o.shippingFee))}</span></div><div class="row row--total"><span>Tổng</span><span>${esc(fmt(o.total))}</span></div>${kind === 'giao-hang' && o.payment.method === 'cod' ? `<div class="row row--total"><span>Thu hộ (COD)</span><span>${esc(fmt(o.total - (o.payment.deposit || 0)))}</span></div>` : ''}</div>
${kind === 'giao-hang' ? `<p class="label" style="margin-top:30px">Quét để tra cứu đơn</p><div id="qr" style="width:140px"></div><p class="muted">${esc(qr)}</p>` : ''}
<p class="muted" style="margin-top:40px;font-size:13px">Chứng từ demo phục vụ đồ án môn học, không có giá trị pháp lý.</p>
<p class="np"><button class="btn btn--primary" onclick="print()">In</button></p></div>
${kind === 'giao-hang' ? `<script>window.__INVOICE_QR__=__alk.abs(${JSON.stringify(qr)})</script><script type="module" src="/js/admin.js"></script>` : ''}
</body></html>`;
}

export const ORDER_LABELS = STATUS_LABEL;
