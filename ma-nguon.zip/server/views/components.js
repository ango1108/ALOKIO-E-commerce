import { html, raw, fmt, stars } from './html.js';
import { icon } from './icons.js';
import { FINISHES } from '../seed/catalog.js';
import { activeFlash } from '../commerce.js';

export function priceHTML(state, p) {
  const fl = activeFlash(state, p.id);
  if (fl) return html`<span class="price price--flash">${fmt(fl.item.price)}</span><span class="price--old">${fmt(p.price)}</span>`;
  if (p.compareAt) return html`<span class="price">${fmt(p.price)}</span><span class="price--old">${fmt(p.compareAt)}</span>`;
  return html`<span class="price">${fmt(p.price)}</span>`;
}

export function productCard(state, p, { lazy = true, reveal = true } = {}) {
  const fl = activeFlash(state, p.id);
  const out = Object.values(p.stock).every((v) => v <= 0);
  return html`
<article class="pcard pcard--${p.line} ${reveal ? 'reveal' : ''}">
  <a class="pcard__media" href="/san-pham/${p.slug}" tabindex="-1" aria-hidden="true">
    <img src="${p.image}" alt="" width="600" height="600" ${lazy ? raw('loading="lazy" decoding="async"') : ''}>
  </a>
  <div class="pcard__tags">
    ${p.isConcept ? html`<span class="tag tag--concept">Alokio Luxe</span>` : html`<span class="tag tag--real">Chính hãng</span>`}
    ${fl ? html`<span class="tag tag--flash">${icon('zap', { size: 12 })} Flash sale</span>` : ''}
    ${out ? html`<span class="tag">Hết hàng</span>` : ''}
  </div>
  <button class="icon-btn pcard__wish" type="button" data-wish="${p.id}" aria-pressed="false" aria-label="Yêu thích ${p.name}">${icon('heart', { size: 18 })}</button>
  <div class="pcard__body">
    <a class="pcard__name" href="/san-pham/${p.slug}">${p.name}</a>
    <p class="pcard__sub">${p.tagline}</p>
    ${p.reviewCount ? html`<div class="rating">${stars(p.rating)} <span>${String(p.rating).replace('.', ',')} (${p.reviewCount})</span></div>` : ''}
    <div class="pcard__foot">
      <div>${priceHTML(state, p)}</div>
      <div class="swatches" aria-label="Màu: ${p.finishes.map((f) => FINISHES[f]?.name).join(', ')}">${p.finishes.map((f) => html`<span class="swatch" style="background:${FINISHES[f]?.hex}" title="${FINISHES[f]?.name}"></span>`)}</div>
    </div>
    <button class="btn btn--soft btn--sm pcard__add" type="button" data-add="${p.id}" data-finish="${p.finishes[0]}" data-name="${p.name}" ${out ? raw('disabled') : ''}>${icon('cart', { size: 16 })} ${out ? 'Hết hàng' : 'Thêm vào giỏ'}</button>
  </div>
</article>`;
}

export function channelButtons(s, { size = '' } = {}) {
  return html`<div class="channel-btns">
    <a class="btn btn--shopee ${size}" href="${s.links.shopee}" target="_blank" rel="noopener noreferrer">${icon('shopee', { size: 18 })} Mua trên Shopee</a>
    <a class="btn btn--tiktok ${size}" href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer">${icon('tiktok', { size: 18 })} TikTok Shop</a>
    <a class="btn btn--facebook ${size}" href="${s.links.facebook}" target="_blank" rel="noopener noreferrer">${icon('facebook', { size: 18 })} Facebook</a>
  </div>`;
}

export function productJsonLd(state, p, url) {
  const fl = activeFlash(state, p.id);
  const inStock = Object.values(p.stock).some((v) => v > 0);
  return {
    '@context': 'https://schema.org', '@type': 'Product', name: p.name, description: p.description[0], sku: p.id,
    image: [url + p.image], brand: { '@type': 'Brand', name: 'Alokio' }, category: p.category,
    offers: { '@type': 'Offer', priceCurrency: 'VND', price: fl ? fl.item.price : p.price, availability: inStock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', url: url + '/san-pham/' + p.slug },
    ...(p.reviewCount ? { aggregateRating: { '@type': 'AggregateRating', ratingValue: p.rating, reviewCount: p.reviewCount } } : {}),
  };
}
