// Các trang cửa hàng (render phía server → HTML đầy đủ cho SEO; JS chỉ tăng cường trải nghiệm).
import { hasFile } from '../files.js';
import { html, raw, fmt, fmtDate, fmtDateTime, stars, md, headings, esc } from './html.js';
import { icon } from './icons.js';
import { layout, breadcrumbs, siteUrl, logo } from './layout.js';
import { productCard, priceHTML, channelButtons, productJsonLd } from './components.js';
import { FINISHES, KNOBS, STRAPS, ENGRAVING_PRICE, GIFTBOX_PRICE } from '../seed/catalog.js';
import { PROVINCES, WARDS } from '../seed/places.js';
import { activeFlash, STATUS_LABEL, PAYMENT_LABEL, PAY_STATUS_LABEL } from '../commerce.js';
import { WALLETS } from '../payments.js';
import { PUBLIC } from '../paths.js';

const visible = (st) => st.products.filter((p) => !p.hidden);
const hasImg = (rel) => hasFile(rel);
const norm = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').toLowerCase();

// =====================================================================
// SHOWROOM 3D
// =====================================================================
export function showroom(ctx) {
  const st = ctx.state;
  const items = visible(st).filter((p) => p.category !== 'phu-kien');
  const luxe = items.filter((p) => p.line === 'luxe');
  const kar = items.filter((p) => p.line === 'karaoke').slice(0, 4);
  const list = [...luxe, ...kar];
  const data = list.map((p) => ({ id: p.id, slug: p.slug, name: p.name, line: p.line, model: p.model, finish: p.finishes[0], price: p.price, tagline: p.tagline, highlights: p.highlights, image: p.image }));
  const body = html`
<section class="showroom" data-showroom aria-labelledby="sr-h">
  <img src="/img/showroom-poster.webp" alt="" width="1600" height="900" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" data-sr-poster>
  <div class="showroom__intro"><span class="eyebrow">Showroom 3D</span><h1 id="sr-h">Gallery <em>trên vịnh</em>.</h1><p class="muted">Kéo để nhìn quanh · phím ← → để đi tới mẫu kế tiếp · nhấp vào loa để bật thử.</p></div>
  <div class="srzoom" role="group" aria-label="Phóng to, thu nhỏ để nhìn gần hoặc xa">
    <button type="button" data-sr-zin aria-label="Phóng to (nhìn gần)">${icon('plus', { size: 16 })}</button>
    <input type="range" min="0" max="100" step="1" value="57" aria-label="Mức phóng" data-sr-zr>
    <button type="button" data-sr-zout aria-label="Thu nhỏ (nhìn xa)">${icon('minus', { size: 16 })}</button>
    <span>Zoom</span>
  </div>
  <aside class="showroom__card glass" data-sr-card aria-live="polite">
    <button class="showroom__min" type="button" data-sr-min aria-expanded="true" aria-label="Thu gọn thông tin để xem loa"><span class="showroom__min-less">${icon('minus', { size: 16 })}</span><span class="showroom__min-more">${icon('plus', { size: 16 })}</span></button>
    <span class="tag" data-sr-tag>Alokio Luxe</span>
    <h2 data-sr-name>${list[0].name}</h2>
    <p class="muted" data-sr-tagline>${list[0].tagline}</p>
    <ul class="stage__specs" data-sr-specs>${list[0].highlights.map((h) => html`<li>${h}</li>`)}</ul>
    <div class="stage__price" data-sr-price>${fmt(list[0].price)}</div>
    <div class="stage__ctas"><button class="btn btn--primary" type="button" data-sr-add>${icon('cart', { size: 18 })} Thêm vào giỏ</button><a class="btn btn--ghost" data-sr-link href="/san-pham/${list[0].slug}">Xem chi tiết</a></div>
  </aside>
  <div class="showroom__ui">
    <div class="showroom__bar">
      <button class="showroom__arrow" type="button" data-sr-step="-1" aria-label="Mẫu trước">${icon('back', { size: 18 })}</button>
      <nav class="showroom__list" aria-label="Danh sách mẫu trong showroom" data-sr-list>
        ${list.map((p, i) => html`<button type="button" data-sr-go="${i}" aria-current="${i === 0}">${p.name.replace('Alokio Luxe ', '').replace('Loa kéo Alokio ', '')}</button>`)}
      </nav>
      <button class="showroom__arrow" type="button" data-sr-step="1" aria-label="Mẫu kế tiếp">${icon('arrow', { size: 18 })}</button>
    </div>
    <p class="showroom__help"><span class="hide-sm">← → chuyển mẫu · Enter để bật thử · kéo chuột để xoay · + / − hoặc thanh bên trái để zoom</span><span class="show-sm">Vuốt ngang để đổi mẫu · chạm vào loa để bật thử</span></p>
  </div>
</section>
<script type="application/json" id="sr-data">${raw(JSON.stringify(data).replace(/</g, '\\u003c'))}</script>`;
  return layout(ctx, { title: 'Showroom 3D – Gallery trên vịnh', page: 'showroom', body, scripts: ['/js/showroom.js'], description: 'Dạo quanh showroom 3D của Alokio: các mẫu loa Alokio Luxe và loa kéo karaoke trưng bày trên bục sơn mài nổi trên mặt nước. Bật thử và thêm vào giỏ ngay trong không gian 3D.' });
}

// =====================================================================
// DANH SÁCH SẢN PHẨM (cửa hàng / danh mục / bộ sưu tập / flash / tìm kiếm)
// =====================================================================
const SORTS = [['noi-bat', 'Nổi bật'], ['ban-chay', 'Bán chạy'], ['gia-tang', 'Giá tăng dần'], ['gia-giam', 'Giá giảm dần'], ['moi-nhat', 'Mới nhất'], ['danh-gia', 'Đánh giá cao']];
const PRICE_RANGES = [['', 'Tất cả mức giá'], ['0-3000000', 'Dưới 3 triệu'], ['3000000-6000000', '3 – 6 triệu'], ['6000000-10000000', '6 – 10 triệu'], ['10000000-99999999', 'Trên 10 triệu']];
const FEATURES = [['chong-nuoc', 'Chống nước IP67+', (p) => p.specs.some(([, v]) => /IP6[78]/.test(v))], ['wifi', 'Wi-Fi / AirPlay', (p) => p.specs.some(([, v]) => /Wi-Fi/.test(v))], ['karaoke', 'Có micro karaoke', (p) => p.mics > 0 || /micro\/guitar/.test(p.specs.map((s) => s[1]).join(' '))], ['pin', 'Pin trên 15 giờ', (p) => p.specs.some(([k, v]) => /Pin|Thời lượng/.test(k) && /(1[5-9]|[2-9]\d)\+? giờ/.test(v))], ['hdmi', 'HDMI cho TV', (p) => p.specs.some(([, v]) => /HDMI/.test(v))]];

function listing(ctx, { title, h1, intro, base, preset = {}, crumbs, page = 'shop', canonical, jsonld = [] }) {
  const st = ctx.state;
  const q = ctx.url.searchParams;
  const f = {
    line: preset.line || q.get('dong') || '', cat: preset.cat || q.get('danh-muc') || '', price: q.get('gia') || '', finish: q.get('mau') || '',
    feat: q.getAll('tinh-nang'), sort: q.get('sap-xep') || 'noi-bat', q: preset.q ?? q.get('q') ?? '', page: Math.max(1, Number(q.get('trang') || 1)),
  };
  let list = visible(st);
  if (preset.flash) list = list.filter((p) => activeFlash(st, p.id));
  if (f.line) list = list.filter((p) => p.line === f.line);
  if (f.cat) list = list.filter((p) => p.category === f.cat);
  if (f.finish) list = list.filter((p) => p.finishes.includes(f.finish));
  if (f.price) { const [a, b] = f.price.split('-').map(Number); list = list.filter((p) => p.price >= a && p.price <= b); }
  for (const id of f.feat) { const ff = FEATURES.find((x) => x[0] === id); if (ff) list = list.filter(ff[2]); }
  if (f.q) { const t = norm(f.q); list = list.filter((p) => norm(`${p.name} ${p.tagline} ${p.highlights.join(' ')} ${p.category}`).includes(t)); }
  const sorters = { 'noi-bat': (a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || (a.line === 'luxe' ? -1 : 1) - (b.line === 'luxe' ? -1 : 1), 'ban-chay': (a, b) => b.sold - a.sold, 'gia-tang': (a, b) => a.price - b.price, 'gia-giam': (a, b) => b.price - a.price, 'moi-nhat': (a, b) => b.createdAt - a.createdAt, 'danh-gia': (a, b) => b.rating - a.rating };
  list = [...list].sort(sorters[f.sort] || sorters['noi-bat']);
  const per = 12, pages = Math.max(1, Math.ceil(list.length / per));
  const shown = list.slice((f.page - 1) * per, f.page * per);
  const qs = (over) => { const u = new URLSearchParams(ctx.url.search); for (const [k, v] of Object.entries(over)) { if (v === '' || v == null) u.delete(k); else u.set(k, v); } const s = u.toString(); return s ? `${base}?${s}` : base; };
  const bc = breadcrumbs(crumbs);
  const body = html`
<div class="container page-head">
  ${bc.html}
  <h1>${h1}</h1>
  ${intro ? html`<p class="lede">${intro}</p>` : ''}
</div>
<div class="container shop">
  <form class="filters glass" method="get" action="${base}" data-filters aria-label="Bộ lọc sản phẩm">
    ${f.q ? html`<input type="hidden" name="q" value="${f.q}">` : ''}
    ${preset.line ? '' : html`<fieldset><legend>Dòng sản phẩm</legend>
      ${[['', 'Tất cả'], ['luxe', 'Alokio Luxe'], ['karaoke', 'Loa kéo karaoke']].map(([v, l]) => html`<label class="check"><input type="radio" name="dong" value="${v}" ${f.line === v ? raw('checked') : ''}> ${l}</label>`)}</fieldset>`}
    ${preset.cat ? '' : html`<fieldset><legend>Danh mục</legend><select class="select" name="danh-muc" aria-label="Danh mục"><option value="">Tất cả danh mục</option>${st.categories.map((c) => html`<option value="${c.slug}" ${f.cat === c.slug ? raw('selected') : ''}>${c.name}</option>`)}</select></fieldset>`}
    <fieldset><legend>Khoảng giá</legend>${PRICE_RANGES.map(([v, l]) => html`<label class="check"><input type="radio" name="gia" value="${v}" ${f.price === v ? raw('checked') : ''}> ${l}</label>`)}</fieldset>
    <fieldset><legend>Màu hoàn thiện</legend><div class="finish-opts">${Object.values(FINISHES).map((x) => html`<label class="finish-opt" title="${x.name}"><input type="radio" name="mau" value="${x.id}" ${f.finish === x.id ? raw('checked') : ''} aria-label="${x.name}"><span style="background:${x.hex}"></span></label>`)}</div>${f.finish ? html`<a href="${qs({ mau: '' })}" style="font-size:13px">Bỏ chọn màu</a>` : ''}</fieldset>
    <fieldset><legend>Tính năng</legend>${FEATURES.map(([v, l]) => html`<label class="check"><input type="checkbox" name="tinh-nang" value="${v}" ${f.feat.includes(v) ? raw('checked') : ''}> ${l}</label>`)}</fieldset>
    <input type="hidden" name="sap-xep" value="${f.sort}">
    <noscript><button class="btn btn--primary btn--sm" type="submit">Áp dụng</button></noscript>
    <a class="btn btn--soft btn--sm" href="${base}">Xoá bộ lọc</a>
  </form>
  <div>
    <div class="toolbar">
      <p class="muted" style="margin:0" aria-live="polite"><b>${list.length}</b> sản phẩm${f.q ? html` cho “${f.q}”` : ''}</p>
      <div style="display:flex;gap:8px;align-items:center">
        <button class="btn btn--soft btn--sm filter-toggle" type="button" data-filter-toggle aria-expanded="false">${icon('filter', { size: 16 })} Bộ lọc</button>
        <label class="sr-only" for="sort">Sắp xếp</label>
        <select class="select" id="sort" data-sort>${SORTS.map(([v, l]) => html`<option value="${v}" ${f.sort === v ? raw('selected') : ''}>${l}</option>`)}</select>
      </div>
    </div>
    ${shown.length ? html`<div class="grid" data-grid>${shown.map((p) => productCard(st, p))}</div>` : html`<div class="empty panel">${icon('search', { size: 44 })}<p>Không tìm thấy sản phẩm phù hợp với bộ lọc.</p><a class="btn btn--primary btn--sm" href="${base}">Xoá bộ lọc</a></div>`}
    ${pages > 1 ? html`<nav class="pager" aria-label="Phân trang">${Array.from({ length: pages }, (_, i) => i + 1).map((n) => (n === f.page ? html`<span aria-current="page">${n}</span>` : html`<a href="${qs({ trang: n })}">${n}</a>`))}</nav>` : ''}
  </div>
</div>`;
  const itemList = { '@context': 'https://schema.org', '@type': 'ItemList', itemListElement: shown.map((p, i) => ({ '@type': 'ListItem', position: i + 1, url: siteUrl() + '/san-pham/' + p.slug, name: p.name })) };
  return layout(ctx, { title, page, body, scripts: ['/js/shop.js'], description: intro, canonical: canonical || base, jsonld: [bc.ld, itemList, ...jsonld] });
}

export const shop = (ctx) => listing(ctx, { title: 'Cửa hàng', h1: 'Cửa hàng', intro: 'Toàn bộ loa Alokio: bộ sưu tập cao cấp Alokio Luxe và loa kéo karaoke chính hãng.', base: '/cua-hang', crumbs: [{ label: 'Trang chủ', href: '/' }, { label: 'Cửa hàng' }] });
export function category(ctx) {
  const c = ctx.state.categories.find((x) => x.slug === ctx.params.slug);
  if (!c) return notFound(ctx);
  return listing(ctx, { title: c.name, h1: c.name, intro: c.desc, base: '/danh-muc/' + c.slug, preset: { cat: c.slug }, crumbs: [{ label: 'Trang chủ', href: '/' }, { label: 'Cửa hàng', href: '/cua-hang' }, { label: c.name }] });
}
export function collection(ctx) {
  const c = ctx.state.collections.find((x) => x.slug === ctx.params.slug);
  if (!c) return notFound(ctx);
  if (c.line === 'luxe') return luxeCollection(ctx, c);
  const st = ctx.state;
  const out = listing(ctx, { title: c.name, h1: c.name, intro: c.desc, base: '/bo-suu-tap/' + c.slug, preset: { line: c.line }, crumbs: [{ label: 'Trang chủ', href: '/' }, { label: c.name }] });
  return out.replace('<div class="container shop">', `<div class="container" style="margin:-10px auto 30px">${channelButtons(st.settings)}</div><div class="container shop">`);
}
function luxeCollection(ctx, c) {
  const st = ctx.state;
  const chapters = [['loa-di-dong', 'Chương I · Di động', 'Mang mặt hồ theo bên mình.'], ['loa-nghe-tai-gia', 'Chương II · Tại gia', 'Những chiếc tủ âm thanh cho căn phòng.'], ['loa-thong-minh', 'Chương III · Thông minh', 'Lặng lẽ, kết nối, tinh tế.'], ['soundbar-rap-phim', 'Chương IV · Rạp phim', 'Dòng sông âm thanh dưới màn hình.'], ['loa-party-karaoke', 'Chương V · Tiệc', 'Bữa tiệc sang trọng, kéo đi bằng một tay.'], ['phu-kien', 'Phụ lục · Phụ kiện', 'Da thật, gỗ óc chó, nhôm.']];
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Alokio Luxe' }]);
  const body = html`
<div class="container page-head">${bc.html}<span class="eyebrow">Bộ sưu tập · Sang trọng kiểu Việt</span><h1>Alokio <em style="font-style:italic;color:var(--primary)">Luxe</em></h1><p class="lede">${c.desc}</p>
  <div class="note" style="margin-top:18px;max-width:760px">${icon('sparkle', { size: 18 })}<span>Alokio Luxe đưa chất âm Alokio vào dòng loa bluetooth cao cấp: mỗi chiếc được hoàn thiện thủ công từ sơn mài nhiều lớp, khảm trai và nhôm phay champagne, rồi kiểm tra âm học từng chiếc trước khi xuất xưởng.</span></div>
</div>
${chapters.map(([cat, t, sub]) => {
  const items = visible(st).filter((p) => p.line === 'luxe' && p.category === cat);
  if (!items.length) return '';
  return html`<section class="section--tight container" aria-label="${t}"><div class="section__head"><div><span class="eyebrow reveal">${t}</span><h2 class="h3 reveal">${sub}</h2></div></div><div class="grid">${items.map((p) => productCard(st, p))}</div></section>`;
})}
<div style="height:60px"></div>`;
  return layout(ctx, { title: 'Bộ sưu tập Alokio Luxe', page: 'collection', body, scripts: ['/js/shop.js'], description: c.desc, jsonld: [bc.ld] });
}
export function flashSale(ctx) {
  const st = ctx.state;
  const now = Date.now();
  const f = st.flashSales.find((x) => x.enabled && now >= x.startsAt && now <= x.endsAt);
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Flash sale' }]);
  const body = html`
<div class="container page-head">${bc.html}<span class="eyebrow">${icon('zap', { size: 14 })} Flash sale</span><h1>${f ? f.name : 'Flash sale'}</h1>
${f ? html`<p class="lede">Kết thúc sau <b data-flash-end="${f.endsAt}" class="countdown" style="font-size:22px">--:--:--</b> · Số lượng có hạn, cập nhật realtime.</p>` : html`<p class="lede">Hiện chưa có chương trình flash sale. Quay lại sau nhé!</p>`}</div>
<div class="container" style="padding-bottom:80px">
  ${f ? html`<div class="grid">${f.items.map((it) => { const p = st.products.find((x) => x.id === it.productId); if (!p || p.hidden) return ''; const pct = Math.round((it.sold / it.quota) * 100); return html`<div>${productCard(st, p)}<div style="padding:10px 6px" data-flash-item="${p.id}"><div class="freeship__bar" style="height:8px"><i style="width:${pct}%;background:linear-gradient(90deg,#F2A38F,#C9472B)"></i></div><small class="muted">Đã bán ${it.sold}/${it.quota} · còn ${it.quota - it.sold} suất</small></div></div>`; })}</div>` : html`<a class="btn btn--primary" href="/cua-hang">Vào cửa hàng</a>`}
</div>`;
  return layout(ctx, { title: 'Flash sale', page: 'flash', body, scripts: ['/js/shop.js'], description: 'Flash sale Alokio: giảm giá có thời hạn cho loa Alokio Luxe và loa kéo karaoke, số lượng cập nhật realtime.', jsonld: [bc.ld] });
}
export const search = (ctx) => listing(ctx, { title: `Tìm kiếm “${ctx.url.searchParams.get('q') || ''}”`, h1: 'Kết quả tìm kiếm', intro: '', base: '/tim-kiem', crumbs: [{ label: 'Trang chủ', href: '/' }, { label: 'Tìm kiếm' }], page: 'search' });

// =====================================================================
// CHI TIẾT SẢN PHẨM
// =====================================================================
export function product(ctx) {
  const st = ctx.state;
  const p = st.products.find((x) => x.slug === ctx.params.slug && !x.hidden);
  if (!p) return notFound(ctx);
  const s = st.settings;
  const cat = st.categories.find((c) => c.slug === p.category);
  const reviews = st.reviews.filter((r) => r.productId === p.id && r.status === 'approved');
  const related = visible(st).filter((x) => x.id !== p.id && (x.category === p.category || x.line === p.line)).sort((a, b) => (a.category === p.category ? -1 : 1)).slice(0, 4);
  const fl = activeFlash(st, p.id);
  const isLuxe = p.line === 'luxe';
  const gallery = [p.image, `/img/products/${p.slug}-2.webp`, ...p.finishes.slice(1).map((f) => `/img/products/${p.slug}--${f}.webp`)].filter((src) => hasImg(src));
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: isLuxe ? 'Alokio Luxe' : 'Loa kéo karaoke', href: isLuxe ? '/bo-suu-tap/alokio-luxe' : '/bo-suu-tap/am-thanh-viet-karaoke' }, { label: cat?.name || '', href: '/danh-muc/' + p.category }, { label: p.name }]);
  const faqLd = p.faq.length ? { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: p.faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) } : null;
  const data = { id: p.id, slug: p.slug, name: p.name, line: p.line, model: p.model, finishes: p.finishes, stock: p.stock, price: p.price, flashPrice: fl ? fl.item.price : null, knobs: p.knobs, straps: p.straps, engraving: p.engraving, engravingPrice: ENGRAVING_PRICE, giftboxPrice: GIFTBOX_PRICE, image: p.image, finishNames: Object.fromEntries(p.finishes.map((f) => [f, FINISHES[f].name])), liveViewers: s.liveViewers };
  const body = html`
<div class="container" style="padding-top:28px">${bc.html}</div>
<div class="container pdp">
  <div class="pdp__view">
    <div class="viewer ${isLuxe ? '' : 'viewer--karaoke'}" data-viewer>
      <img src="${p.image}" alt="${p.name} – ${FINISHES[p.finishes[0]].name}" width="900" height="860" fetchpriority="high" data-viewer-img>
      <div class="viewer__tools">
        <span class="chip" aria-hidden="true">${icon('cube', { size: 16 })} Kéo để xoay · Ctrl + cuộn để phóng to</span>
        <span style="display:flex;flex-wrap:wrap;gap:6px">
          <button class="chip" type="button" data-explode aria-pressed="false">${icon('layers', { size: 16 })} Xem cấu tạo</button>
          <button class="chip" type="button" data-listen>${icon('play', { size: 14 })} Nghe thử</button>
        </span>
      </div>
    </div>
    ${gallery.length > 1 ? html`<div class="gallery" role="group" aria-label="Ảnh sản phẩm">${gallery.slice(0, 4).map((src, i) => html`<button type="button" data-gallery="${src}" aria-pressed="${i === 0}" aria-label="Ảnh ${i + 1}"><img src="${src}" alt="" width="200" height="200" loading="lazy"></button>`)}</div>` : ''}
  </div>
  <div class="pdp__info">
    <div style="display:flex;gap:8px;flex-wrap:wrap">${isLuxe ? html`<span class="tag tag--concept">Alokio Luxe · Sang trọng kiểu Việt</span>` : html`<span class="tag tag--real">Loa kéo chính hãng Alokio</span>`}${fl ? html`<span class="tag tag--flash">${icon('zap', { size: 12 })} Flash sale</span>` : ''}</div>
    <h1>${p.name}</h1>
    <p class="pdp__tagline">${p.tagline}</p>
    <div class="pdp__meta">
      ${p.reviewCount ? html`<a href="#danh-gia" style="color:inherit;text-decoration:none">${stars(p.rating)} ${String(p.rating).replace('.', ',')} · ${p.reviewCount} đánh giá</a>` : ''}
      <span>Đã bán ${p.sold}</span>
      ${s.liveViewers ? html`<span class="live-dot" data-viewers>Đang có <b data-viewers-n>1</b> người xem</span>` : ''}
    </div>
    <div class="pdp__price" data-price>${priceHTML(st, p)}</div>
    ${fl ? html`<p style="font-size:14px;color:#93301B;margin:0">Flash sale kết thúc sau <b data-flash-end="${fl.sale.endsAt}">--:--:--</b> · còn ${fl.item.quota - fl.item.sold} suất</p>` : ''}
    <form class="atelier glass" id="atelier" data-atelier>
      <div class="atelier__title"><span class="label">${isLuxe ? 'Atelier · Tuỳ biến' : 'Lựa chọn'}</span><span class="muted" style="font-size:13px" data-stock-label data-stock-for="${p.id}"></span></div>
      <fieldset class="opt-group" style="border:0;padding:0;margin:0"><legend style="font-size:14px;font-weight:500;margin-bottom:10px">Hoàn thiện: <em data-finish-name style="font-style:normal;color:var(--muted)">${FINISHES[p.finishes[0]].name}</em></legend>
        <div class="finish-opts">${p.finishes.map((f, i) => html`<label class="finish-opt" title="${FINISHES[f].name} — ${FINISHES[f].note}"><input type="radio" name="finish" value="${f}" ${i === 0 ? raw('checked') : ''} ${(p.stock[f] ?? 0) <= 0 ? raw('data-oos="1"') : ''} aria-label="${FINISHES[f].name}${(p.stock[f] ?? 0) <= 0 ? ' (hết hàng)' : ''}"><span style="background:${FINISHES[f].hex}"></span></label>`)}</div>
      </fieldset>
      ${p.knobs ? html`<fieldset class="opt-group" style="border:0;padding:0;margin:0"><legend style="font-size:14px;font-weight:500;margin-bottom:10px">Núm vặn &amp; khung</legend><div class="finish-opts">${KNOBS.map((k, i) => html`<label class="finish-opt" title="${k.name}"><input type="radio" name="knob" value="${k.id}" ${i === 0 ? raw('checked') : ''} aria-label="${k.name}"><span style="background:radial-gradient(circle at 35% 30%,#fff,${k.hex} 55%,#8a7a5c)"></span></label>`)}</div></fieldset>` : ''}
      ${p.straps ? html`<fieldset class="opt-group" style="border:0;padding:0;margin:0"><legend style="font-size:14px;font-weight:500;margin-bottom:10px">Quai da</legend><div class="finish-opts">${STRAPS.map((k, i) => html`<label class="finish-opt" title="${k.name}"><input type="radio" name="strap" value="${k.id}" ${i === 0 ? raw('checked') : ''} aria-label="${k.name}"><span style="background:${k.hex}"></span></label>`)}</div></fieldset>` : ''}
      ${p.engraving ? html`<label class="field"><span>Khắc tên trên nhôm <em class="muted" style="font-style:normal;font-weight:300">(+${fmt(ENGRAVING_PRICE)}, tối đa 18 ký tự)</em></span><input class="input" name="engraving" maxlength="18" placeholder="Ví dụ: Minh Anh" autocomplete="off"></label>` : ''}
      ${isLuxe ? html`<label class="check"><input type="checkbox" name="giftbox"> Hộp quà sơn mài (+${fmt(GIFTBOX_PRICE)})</label>` : ''}
    </form>
    <div class="pdp__buy">
      <div class="qty"><button type="button" data-q="-1" aria-label="Giảm số lượng">${icon('minus', { size: 16 })}</button><input value="1" inputmode="numeric" aria-label="Số lượng" data-qty><button type="button" data-q="1" aria-label="Tăng số lượng">${icon('plus', { size: 16 })}</button></div>
      <button class="btn btn--primary btn--lg" type="button" data-buy="cart">${icon('cart', { size: 18 })} Thêm vào giỏ</button>
      <button class="btn btn--dark btn--lg" type="button" data-buy="now">Mua ngay</button>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn--soft btn--sm" type="button" data-wish="${p.id}" aria-pressed="false">${icon('heart', { size: 16 })} Yêu thích</button>
      <button class="btn btn--soft btn--sm" type="button" data-compare="${p.id}" aria-pressed="false">${icon('compare', { size: 16 })} So sánh</button>
      <button class="btn btn--soft btn--sm" type="button" data-restock hidden>${icon('bell', { size: 16 })} Báo khi có hàng</button>
    </div>
    ${p.links === 'official' ? html`<div style="margin-top:22px"><p class="label" style="margin-bottom:10px">Cũng có bán tại kênh chính thức</p>${channelButtons(s, { size: 'btn--sm' })}</div>` : ''}
    <ul class="perks">
      <li>${icon('truck')} Giao toàn quốc · miễn phí cho đơn từ ${fmt(s.shipping.freeThreshold)}</li>
      <li>${icon('shield')} ${p.warranty}</li>
      <li>${icon('qr')} Thanh toán COD, VietQR, ví điện tử QR động, thẻ, trả góp 0%</li>
    </ul>
    ${p.note ? html`<p class="note ${isLuxe ? '' : 'note--info'}">${icon(isLuxe ? 'sparkle' : 'file', { size: 18 })}<span>${p.note}</span></p>` : ''}
  </div>
</div>
<div class="container pdp-tabs">
  <div class="acc">
    <details open><summary>Câu chuyện sản phẩm</summary><div class="acc__body prose">${p.description.map((d) => html`<p>${d}</p>`)}<p><b>Điểm nổi bật:</b> ${p.highlights.join(' · ')}.</p></div></details>
    <details open><summary>Thông số kỹ thuật</summary><div class="acc__body"><table class="specs"><tbody>${p.specs.map(([k, v]) => html`<tr><th scope="row">${k}</th><td>${v}</td></tr>`)}<tr><th scope="row">Khối lượng</th><td>${String(p.weightKg).replace('.', ',')} kg</td></tr></tbody></table>${p.needsVerify ? html`<p class="muted" style="font-size:13px;margin-top:10px">* Thông số tham khảo từ đại lý, có thể khác với lô hàng hiện tại.</p>` : ''}</div></details>
    <details><summary>Trong hộp có gì</summary><div class="acc__body"><ul>${p.inBox.map((i) => html`<li>${i}</li>`)}</ul></div></details>
    ${p.faq.length ? html`<details><summary>Câu hỏi thường gặp</summary><div class="acc__body faq">${p.faq.map(([q, a]) => html`<details><summary>${q}</summary><p>${a}</p></details>`)}</div></details>` : ''}
    <details id="danh-gia" open><summary>Đánh giá (${reviews.length})</summary><div class="acc__body">
      ${reviews.length ? html`<div class="row" style="margin-bottom:10px"><div><span style="font:400 44px var(--serif)">${String(p.rating).replace('.', ',')}</span> ${stars(p.rating)}</div>
        <div role="group" aria-label="Lọc theo số sao" style="display:flex;gap:6px;flex-wrap:wrap">${[0, 5, 4, 3].map((n) => html`<button class="chip" type="button" data-star-filter="${n}" aria-pressed="${n === 0}">${n ? `${n} sao` : 'Tất cả'}</button>`)}</div></div>` : ''}
      <div data-reviews>${reviews.map((r) => html`<article class="review" data-stars="${r.stars}"><div class="review__head"><span><b style="color:var(--ink)">${r.name}</b> · ${stars(r.stars)}</span><span>${fmtDate(r.createdAt)}</span></div><p>${r.text}</p>${r.reply ? html`<div class="review__reply"><b>Alokio phản hồi:</b> ${r.reply}</div>` : ''}</article>`)}</div>
      <form class="panel" style="margin-top:24px;display:grid;gap:12px" data-review-form novalidate>
        <h3 style="margin:0">Viết đánh giá</h3>
        <fieldset style="border:0;padding:0;margin:0"><legend style="font-size:14px;font-weight:500">Số sao</legend><div style="display:flex;flex-wrap:wrap;gap:6px">${[1, 2, 3, 4, 5].map((n) => html`<label class="chip"><input type="radio" name="stars" value="${n}" ${n === 5 ? raw('checked') : ''}> ${n} ★</label>`)}</div></fieldset>
        <label class="field"><span>Tên của bạn</span><input class="input" name="name" required maxlength="60" autocomplete="name"></label>
        <label class="field"><span>Nội dung</span><textarea class="textarea" name="text" required minlength="10" maxlength="800"></textarea></label>
        <p class="err" data-review-msg aria-live="polite"></p>
        <button class="btn btn--primary" type="submit">Gửi đánh giá</button>
      </form>
    </div></details>
  </div>
</div>
${related.length ? html`<section class="section--tight container" aria-labelledby="rel-h"><div class="section__head"><h2 class="h3" id="rel-h">Có thể bạn cũng thích</h2></div><div class="grid">${related.map((x) => productCard(st, x))}</div></section>` : ''}
<section class="section--tight container" aria-labelledby="rv-h" data-recent hidden><h2 class="h3" id="rv-h">Bạn vừa xem</h2><div class="grid" data-recent-grid></div></section>
<div class="sticky-buy" data-sticky-buy><div style="flex:1;min-width:0"><b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${p.name}</b><span data-sticky-price>${priceHTML(st, p)}</span></div><button class="btn btn--primary" type="button" data-buy="cart">Thêm vào giỏ</button></div>
<script type="application/json" id="product-data">${raw(JSON.stringify(data).replace(/</g, '\\u003c'))}</script>`;
  return layout(ctx, {
    title: p.name, page: 'product', body, scripts: ['/js/product.js'],
    description: `${p.name} – ${p.tagline} ${p.highlights.join(', ')}. ${isLuxe ? 'Bộ sưu tập cao cấp Alokio Luxe.' : 'Loa kéo karaoke chính hãng Alokio.'}`,
    jsonld: [bc.ld, productJsonLd(st, p, siteUrl()), ...(faqLd ? [faqLd] : [])], ogImage: p.image,
    preload: [{ href: p.image, as: 'image', fetchpriority: 'high' }],
  });
}

// =====================================================================
// SO SÁNH / YÊU THÍCH (dữ liệu nằm ở trình duyệt → render bằng JS, có khung SSR)
// =====================================================================
export function compare(ctx) {
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'So sánh' }]);
  const body = html`<div class="container page-head">${bc.html}<h1>So sánh sản phẩm</h1><p class="lede">Chọn tối đa 4 sản phẩm để so sánh. Các dòng khác nhau được tô nền nhẹ.</p></div>
<div class="container" style="padding-bottom:80px"><label class="check" style="margin-bottom:16px"><input type="checkbox" data-only-diff> Chỉ hiện điểm khác nhau</label><div class="cmp panel" data-compare-table><p class="muted">Đang tải…</p></div></div>`;
  return layout(ctx, { title: 'So sánh sản phẩm', page: 'compare', body, scripts: ['/js/shop.js'], noindex: true });
}
export function wishlist(ctx) {
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Yêu thích' }]);
  const body = html`<div class="container page-head">${bc.html}<h1>Danh sách yêu thích</h1></div><div class="container" style="padding-bottom:80px"><div class="grid" data-wish-grid><p class="muted">Đang tải…</p></div></div>`;
  return layout(ctx, { title: 'Yêu thích', page: 'wishlist', body, scripts: ['/js/shop.js'], noindex: true });
}

// =====================================================================
// GIỎ HÀNG & THANH TOÁN
// =====================================================================
export function cartPage(ctx) {
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Giỏ hàng' }]);
  const body = html`<div class="container page-head">${bc.html}<h1>Giỏ hàng</h1></div>
<div class="container two-col">
  <div><div class="panel" data-cart-lines><p class="muted">Đang tải giỏ hàng…</p></div>
    <div class="panel" data-cart-suggest hidden><h2 class="h3">Thường mua kèm</h2><div class="rail" data-suggest-grid></div></div></div>
  <aside class="panel summary" aria-label="Tóm tắt đơn hàng">
    <h2>Tóm tắt</h2>
    <div data-cart-freeship></div>
    <form class="pill-form" data-coupon style="margin:16px 0" novalidate><label class="sr-only" for="coupon">Mã giảm giá</label><input id="coupon" name="code" placeholder="Mã giảm giá (VD: ALOKIO10)" autocomplete="off"><button class="btn btn--soft btn--sm" type="submit">Áp dụng</button><p class="form-msg" aria-live="polite"></p></form>
    <div style="margin-top:28px" data-cart-totals></div>
    <a class="btn btn--primary btn--block btn--lg" href="/thanh-toan" data-to-checkout style="margin-top:16px">Tiến hành thanh toán ${icon('arrow', { size: 18 })}</a>
    <p class="muted" style="font-size:13px;margin-top:12px">Mã thử nghiệm: <b>ALOKIO10</b>, <b>LUXE500</b>, <b>HATHAYLAM</b>, <b>FREESHIP</b>.</p>
  </aside>
</div>`;
  return layout(ctx, { title: 'Giỏ hàng', page: 'cart', body, scripts: ['/js/cart.js'], noindex: true });
}

export function checkout(ctx) {
  const st = ctx.state;
  const s = st.settings;
  const c = ctx.customer;
  const addr = c?.addresses?.[0];
  const wallets = WALLETS.filter((w) => s.payments.wallets.includes(w.id));
  const body = html`
<div class="container page-head" style="padding-bottom:20px"><h1 style="font-size:clamp(36px,4.6vw,60px)">Thanh toán</h1>
  <ol class="steps" aria-label="Các bước thanh toán" data-steps><li aria-current="step" data-step-i="1"><b>1</b> Thông tin</li><li data-step-i="2"><b>2</b> Vận chuyển</li><li data-step-i="3"><b>3</b> Thanh toán</li></ol>
</div>
<form class="container two-col" data-checkout novalidate>
  <div>
    <section class="panel" data-step="1" aria-labelledby="s1">
      <h2 id="s1">Thông tin nhận hàng</h2>
      ${c ? html`<p class="muted">Xin chào <b>${c.name}</b>! Thông tin đã được điền sẵn từ tài khoản.</p>` : html`<p class="muted">Mua không cần tài khoản, hoặc <a href="/tai-khoan/dang-nhap?next=/thanh-toan">đăng nhập</a> để điền nhanh.</p>`}
      <div class="form-grid">
        <label class="field"><span>Họ và tên *</span><input class="input" name="name" autocomplete="name" required value="${c?.name || ''}"><small class="err" data-err="name"></small></label>
        <label class="field"><span>Số điện thoại *</span><input class="input" name="phone" inputmode="tel" autocomplete="tel" required value="${c?.phone || ''}" placeholder="09xxxxxxxx"><small class="err" data-err="phone"></small></label>
        <label class="field full"><span>Email (nhận xác nhận đơn)</span><input class="input" name="email" type="email" autocomplete="email" value="${c?.email || ''}"><small class="err" data-err="email"></small></label>
        <label class="field"><span>Tỉnh / Thành phố *</span><select class="select" name="province" required autocomplete="address-level1"><option value="">— Chọn tỉnh/thành (34) —</option>${PROVINCES.slice().sort((a, b) => a.name.localeCompare(b.name, 'vi')).map((pr) => html`<option value="${pr.code}" ${addr?.province === pr.code ? raw('selected') : ''}>${pr.name}</option>`)}</select><small class="err" data-err="province"></small></label>
        <label class="field"><span>Phường / Xã / Đặc khu *</span><input class="input" name="ward" list="ward-list" required autocomplete="address-level2" value="${addr?.ward || ''}"><datalist id="ward-list"></datalist><small class="err" data-err="ward"></small></label>
        <label class="field full"><span>Số nhà, tên đường *</span><input class="input" name="street" required autocomplete="street-address" value="${addr?.street || ''}"><small class="err" data-err="street"></small></label>
        <label class="field full"><span>Ghi chú</span><input class="input" name="note" maxlength="300" placeholder="Ví dụ: giao giờ hành chính"></label>
      </div>
      <p class="muted" style="font-size:13px;margin-top:12px">Địa chỉ theo địa giới hành chính mới 2 cấp (tỉnh – xã), không còn quận/huyện.</p>
      <button class="btn btn--primary" type="button" data-next="2" style="margin-top:12px">Tiếp tục ${icon('arrow', { size: 18 })}</button>
    </section>
    <section class="panel" data-step="2" aria-labelledby="s2" hidden>
      <h2 id="s2">Vận chuyển</h2>
      <div class="pay-opts">
        <label class="choice"><input type="radio" name="shipping" value="standard" checked><span><span class="choice__title">${icon('truck', { size: 18 })} Giao tiêu chuẩn (2–5 ngày)</span><span class="choice__desc">Phí theo khối lượng; miễn phí cho đơn từ ${fmt(s.shipping.freeThreshold)}.</span></span></label>
        <label class="choice"><input type="radio" name="shipping" value="express"><span><span class="choice__title">${icon('zap', { size: 18 })} Hoả tốc 2 giờ — ${fmt(s.shipping.express)}</span><span class="choice__desc">Hà Nội & TP.HCM.</span></span></label>
        <label class="choice"><input type="radio" name="shipping" value="pickup"><span><span class="choice__title">${icon('home', { size: 18 })} Nhận tại showroom — miễn phí</span><span class="choice__desc">Nghe thử trước khi nhận.</span></span></label>
      </div>
      <div style="display:flex;gap:10px;margin-top:16px"><button class="btn btn--ghost" type="button" data-prev="1">${icon('back', { size: 18 })} Quay lại</button><button class="btn btn--primary" type="button" data-next="3">Tiếp tục ${icon('arrow', { size: 18 })}</button></div>
    </section>
    <section class="panel" data-step="3" aria-labelledby="s3" hidden>
      <h2 id="s3">Phương thức thanh toán</h2>
      <p class="note note--info" style="margin-bottom:16px">${icon('shield', { size: 18 })}<span>Môi trường sandbox: không có tiền thật được chuyển. QR động được tạo riêng cho từng đơn hàng.</span></p>
      <div class="pay-opts" role="radiogroup" aria-label="Phương thức thanh toán">
        ${s.payments.wallet ? html`<label class="choice"><input type="radio" name="method" value="wallet" checked><span style="flex:1"><span class="choice__title">${icon('wallet', { size: 18 })} Ví điện tử — QR động</span><span class="choice__desc">Quét mã bằng điện thoại, xác nhận là máy tính tự cập nhật ngay.</span>
          <span class="wallets" role="radiogroup" aria-label="Chọn ví">${wallets.map((w, i) => html`<label class="wallet-chip"><input type="radio" name="wallet" value="${w.id}" ${i === 0 ? raw('checked') : ''}><span>${w.name}</span></label>`)}</span><small class="err" data-err="wallet"></small></span></label>` : ''}
        ${s.payments.vietqr ? html`<label class="choice"><input type="radio" name="method" value="vietqr" ${s.payments.wallet ? '' : raw('checked')}><span><span class="choice__title">${icon('qr', { size: 18 })} Chuyển khoản — VietQR động</span><span class="choice__desc">Mã QR chuẩn NAPAS kèm sẵn số tiền và nội dung chuyển khoản.</span></span></label>` : ''}
        ${s.payments.card ? html`<label class="choice"><input type="radio" name="method" value="card"><span><span class="choice__title">${icon('card', { size: 18 })} Thẻ ATM nội địa / Visa / Mastercard / JCB</span><span class="choice__desc">Xác thực OTP (sandbox). Không lưu số thẻ.</span></span></label>` : ''}
        ${s.payments.installment ? html`<label class="choice"><input type="radio" name="method" value="installment"><span style="flex:1"><span class="choice__title">${icon('clock', { size: 18 })} Trả góp 0% qua thẻ</span><span class="choice__desc">Phí chuyển đổi 0 ₫.</span>
          <span class="wallets" role="radiogroup" aria-label="Kỳ hạn">${[3, 6, 9, 12].map((m, i) => html`<label class="wallet-chip"><input type="radio" name="installment" value="${m}" ${i === 1 ? raw('checked') : ''}><span>${m} tháng · <span data-inst="${m}">—</span>/th</span></label>`)}</span></span></label>` : ''}
        ${s.payments.cod ? html`<label class="choice"><input type="radio" name="method" value="cod"><span style="flex:1"><span class="choice__title">${icon('cash', { size: 18 })} Thanh toán khi nhận hàng (COD)</span><span class="choice__desc">Kiểm tra hàng trước khi trả tiền.</span>
          <label class="check" data-deposit-wrap hidden style="margin-top:10px;font-size:14px"><input type="checkbox" name="deposit"> Đặt cọc ${s.payments.depositPercent}% qua VietQR để giữ hàng (đơn từ ${fmt(s.payments.depositMin)})</label></span></label>` : ''}
      </div>
      <small class="err" data-err="method"></small>
      <div style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap"><button class="btn btn--ghost" type="button" data-prev="2">${icon('back', { size: 18 })} Quay lại</button><button class="btn btn--primary btn--lg" type="submit" data-place>Đặt hàng</button></div>
      <p class="err" data-form-err aria-live="assertive"></p>
    </section>
  </div>
  <aside class="panel summary" aria-label="Tóm tắt đơn hàng">
    <h2>Đơn hàng</h2>
    <div data-co-lines><p class="muted">Đang tải…</p></div>
    <div class="pill-form" style="margin:14px 0" data-co-coupon><label class="sr-only" for="co-coupon">Mã giảm giá</label><input id="co-coupon" placeholder="Mã giảm giá" autocomplete="off"><button class="btn btn--soft btn--sm" type="button">Áp dụng</button><p class="form-msg" aria-live="polite"></p></div>
    <div style="margin-top:26px" data-co-totals></div>
  </aside>
</form>`;
  return layout(ctx, { title: 'Thanh toán', page: 'checkout', body, scripts: ['/js/checkout.js'], noindex: true });
}

export function payPage(ctx) {
  const st = ctx.state;
  const o = st.orders.find((x) => x.code === ctx.params.code);
  if (!o) return notFound(ctx);
  const pay = st.payments.find((p) => p.id === o.payment.sessionId);
  const wallet = WALLETS.find((w) => w.id === o.payment.wallet);
  const isCard = pay && (pay.method === 'card' || pay.method === 'installment');
  const body = html`
<div class="container page-head" style="padding-bottom:20px"><span class="eyebrow">Đơn ${o.code}</span><h1 style="font-size:clamp(34px,4.4vw,58px)">${isCard ? 'Thanh toán bằng thẻ' : pay?.method === 'deposit' ? 'Đặt cọc qua VietQR' : pay?.method === 'vietqr' ? 'Chuyển khoản VietQR' : `Thanh toán qua ${wallet ? wallet.name : 'ví điện tử'}`}</h1></div>
<div class="container two-col" data-pay data-code="${o.code}" data-pay-id="${pay ? pay.id : ''}" data-method="${pay ? pay.method : ''}">
  <div class="panel">
    ${!pay ? html`<p>Đơn hàng không cần thanh toán trực tuyến.</p><a class="btn btn--primary" href="/dat-hang-thanh-cong/${o.code}">Xem đơn hàng</a>` : isCard ? html`
      <form class="stack" data-card-form novalidate style="max-width:460px">
        ${pay.method === 'installment' ? html`<p class="note note--info">Trả góp ${o.payment.installment?.months || 6} tháng · khoảng <b>${fmt(Math.ceil(o.total / (o.payment.installment?.months || 6) / 1000) * 1000)}</b>/tháng · phí chuyển đổi 0 ₫.</p>` : ''}
        <label class="field"><span>Số thẻ</span><input class="input" name="number" inputmode="numeric" autocomplete="cc-number" placeholder="4111 1111 1111 1111" maxlength="23"><small class="err" data-err="number"></small></label>
        <div class="form-grid"><label class="field"><span>Hết hạn (MM/YY)</span><input class="input" name="exp" inputmode="numeric" autocomplete="cc-exp" placeholder="12/28" maxlength="5"><small class="err" data-err="exp"></small></label><label class="field"><span>CVC</span><input class="input" name="cvc" inputmode="numeric" autocomplete="cc-csc" placeholder="123" maxlength="4"><small class="err" data-err="cvc"></small></label></div>
        <label class="field"><span>Tên in trên thẻ</span><input class="input" name="holder" autocomplete="cc-name" placeholder="NGUYEN VAN A"><small class="err" data-err="holder"></small></label>
        <div data-otp hidden class="stack"><p class="note note--info">${icon('shield', { size: 18 })}<span>Ngân hàng (sandbox) đã gửi OTP. <b>OTP demo: 123456</b></span></p><label class="field"><span>Mã OTP</span><input class="input" name="otp" inputmode="numeric" maxlength="6" autocomplete="one-time-code"><small class="err" data-err="otp"></small></label></div>
        <p class="err" data-card-err aria-live="assertive"></p>
        <button class="btn btn--primary btn--lg" type="submit" data-card-submit>Thanh toán ${fmt(pay.amount)}</button>
        <details class="faq"><summary>Thẻ thử nghiệm</summary><p>4111 1111 1111 1111 (Visa – thành công) · 5555 5555 5555 4444 (Mastercard – thành công) · 9704 0000 0000 0018 (NAPAS – thành công) · 4000 0000 0000 0002 (bị từ chối). Hạn bất kỳ trong tương lai, CVC 3 số bất kỳ.</p></details>
      </form>` : html`
      <div class="qr-wrap">
        <div class="qr-card" data-qr-card>
          <div class="qr-card__img" data-qr><span class="muted">Đang tạo mã…</span></div>
          <span class="qr-card__scan" aria-hidden="true"></span>
          <p style="margin:12px 0 0;font-weight:500">${pay.method === 'wallet' ? `Mở app ${wallet ? wallet.name : 'ví'} → Quét mã` : 'Mở app ngân hàng → Quét mã'}</p>
        </div>
        <div class="stack">
          <span class="pay-status" data-pay-status data-s="${pay.status}" role="status">${PAY_STATUS_LABEL[pay.status] || pay.status}</span>
          <p style="margin:0">Số tiền: <b style="font-size:26px;font-weight:500">${fmt(pay.amount)}</b></p>
          <p style="margin:0" class="muted">Mã QR hết hạn sau <b class="countdown" style="font-size:20px;color:var(--ink)" data-countdown>--:--</b></p>
          ${pay.method !== 'wallet' ? html`<dl class="kv" data-bank></dl>` : ''}
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn btn--primary" href="#" data-sim target="_blank" rel="noopener">${icon('phone', { size: 18 })} Mô phỏng quét mã</a>
            <a class="btn btn--ghost show-sm-only" href="#" data-app>${icon('wallet', { size: 18 })} Mở ứng dụng ví</a>
            <button class="btn btn--soft" type="button" data-renew hidden>${icon('refresh', { size: 18 })} Tạo mã mới</button>
          </div>
          <p class="muted" style="font-size:13.5px" data-lan-hint>Cổng thanh toán giả lập: bấm “Mô phỏng quét mã” để mở trang xác nhận như khi quét bằng app. Trang sẽ tự chuyển khi thanh toán thành công.</p>
        </div>
      </div>`}
  </div>
  <aside class="panel summary">
    <h2>Đơn ${o.code}</h2>
    ${o.items.map((l) => html`<div class="row" style="font-size:15px;padding:6px 0"><span>${l.name} × ${l.qty}</span><span>${fmt(l.total)}</span></div>`)}
    <div class="row row--total"><span>Tổng cộng</span><span>${fmt(o.total)}</span></div>
    ${o.payment.deposit ? html`<div class="row"><span>Đặt cọc</span><span>${fmt(o.payment.deposit)}</span></div><div class="row"><span>Còn lại (COD)</span><span>${fmt(o.total - o.payment.deposit)}</span></div>` : ''}
    <a class="btn btn--ghost btn--block" style="margin-top:16px" href="/dat-hang-thanh-cong/${o.code}">Thanh toán sau</a>
  </aside>
</div>`;
  return layout(ctx, { title: 'Thanh toán đơn ' + o.code, page: 'pay', body, scripts: ['/js/pay.js'], noindex: true });
}

export function sandbox(ctx) {
  const st = ctx.state;
  const p = st.payments.find((x) => x.id === ctx.params.id);
  const sig = ctx.url.searchParams.get('sig');
  const ok = p && sig === p.sig;
  const o = ok ? st.orders.find((x) => x.code === p.orderCode) : null;
  const wallet = ok ? WALLETS.find((w) => w.id === p.wallet) : null;
  const methodName = !ok ? '' : p.method === 'wallet' ? wallet?.name || 'Ví điện tử' : p.method === 'deposit' ? 'Đặt cọc qua chuyển khoản' : 'Chuyển khoản ngân hàng';
  const body = `<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Cổng thanh toán Sandbox</title><link rel="stylesheet" href="/css/site.css?v=${ctx.assetVersion}"></head><body style="background:#F2F5F9">
<div class="sandbox-banner">MÔI TRƯỜNG THỬ NGHIỆM — KHÔNG CÓ TIỀN THẬT</div>
<main class="sandbox" id="main">
  ${ok ? `<div class="panel" style="text-align:center" data-sandbox data-id="${esc(p.id)}" data-sig="${esc(sig)}">
    <p class="label">Cổng thanh toán Sandbox · ${esc(methodName)}</p>
    <p style="margin:16px 0 0" class="muted">Thanh toán cho</p>
    <h1 style="font-size:30px;margin:4px 0">Alokio – Âm Thanh Việt</h1>
    <p class="sandbox__amount">${esc(fmt(p.amount))}</p>
    <p class="muted">Đơn hàng <b>${esc(o.code)}</b> · ${o.items.length} sản phẩm</p>
    <div data-sb-state><p class="pay-status" data-s="${esc(p.status)}">${esc(PAY_STATUS_LABEL[p.status] || p.status)}</p></div>
    <div style="display:grid;gap:10px;margin-top:20px" data-sb-actions>
      <button class="btn btn--primary btn--lg btn--block" type="button" data-sb="confirm">Xác nhận thanh toán</button>
      <button class="btn btn--ghost btn--block" type="button" data-sb="reject">Từ chối</button>
    </div>
    <p class="muted" style="font-size:13px;margin-top:18px">Đây là trang giả lập của đồ án, không phải ứng dụng ví hay ngân hàng thật. Không nhập mật khẩu hay thông tin tài khoản thật ở bất kỳ đâu.</p>
  </div>` : `<div class="panel"><h1 style="font-size:28px">Mã thanh toán không hợp lệ</h1><p class="muted">Liên kết đã hết hạn hoặc sai chữ ký.</p></div>`}
</main>
<script type="module" src="/js/sandbox.js?v=${ctx.assetVersion}"></script></body></html>`;
  return body;
}

export function success(ctx) {
  const st = ctx.state;
  const o = st.orders.find((x) => x.code === ctx.params.code);
  if (!o) return notFound(ctx);
  const s = st.settings;
  const body = html`
<div class="container" style="padding:30px 0 80px">
  <div class="success-hero" data-success-3d data-model='${raw(JSON.stringify((st.products.find((p) => p.id === o.items[0]?.productId) || st.products[0]).model))}' data-finish="${o.items[0]?.finish || 'ngoc-trai'}"></div>
  <div class="two-col" style="margin-top:30px">
    <div>
      <span class="eyebrow">Đặt hàng thành công</span>
      <h1 style="font-size:clamp(36px,5vw,64px)">Cảm ơn bạn, <em style="color:var(--primary)">${o.contact.name.split(' ').pop()}</em>!</h1>
      <p class="lede">Mã đơn hàng của bạn là <b style="color:var(--ink)">${o.code}</b>. Trạng thái được cập nhật realtime bên dưới.</p>
      <div class="panel" style="margin-top:20px"><h2 class="h3">Tình trạng đơn</h2><ol class="timeline" data-timeline data-code="${o.code}">${raw(timelineHTML(o))}</ol>
        <p style="margin:0">Thanh toán: <span class="st st--${o.payment.status}" data-paystatus>${PAY_STATUS_LABEL[o.payment.status]}</span> · ${PAYMENT_LABEL[o.payment.method]}</p>
        ${o.payment.status === 'pending' && o.payment.sessionId ? html`<a class="btn btn--primary btn--sm" style="margin-top:14px" href="/thanh-toan/${o.code}">Tiếp tục thanh toán</a>` : ''}
      </div>
      <div class="panel"><h2 class="h3">Theo dõi Alokio</h2><p class="muted">Nhận ưu đãi và video hướng dẫn sử dụng loa trên các kênh chính thức.</p>${channelButtons(s, { size: 'btn--sm' })}</div>
    </div>
    <aside class="panel summary">
      <h2>Chi tiết</h2>
      ${o.items.map((l) => html`<div class="row" style="font-size:15px;padding:6px 0"><span>${l.name} × ${l.qty}<br><small class="muted">${FINISHES[l.finish]?.name || ''}${l.options?.engraving ? ` · Khắc “${l.options.engraving}”` : ''}</small></span><span>${fmt(l.total)}</span></div>`)}
      <div class="row"><span>Tạm tính</span><span>${fmt(o.subtotal)}</span></div>
      ${o.discount ? html`<div class="row"><span>Giảm giá ${o.coupon ? `(${o.coupon})` : ''}</span><span>−${fmt(o.discount)}</span></div>` : ''}
      <div class="row"><span>Vận chuyển</span><span>${o.shippingFee ? fmt(o.shippingFee) : 'Miễn phí'}</span></div>
      <div class="row row--total"><span>Tổng</span><span>${fmt(o.total)}</span></div>
      <p class="muted" style="font-size:14px;margin-top:14px">Giao tới: ${o.address.name}, ${o.address.street}, ${o.address.ward}, ${o.address.provinceName}</p>
      <a class="btn btn--ghost btn--block" href="/tra-cuu-don-hang?ma=${o.code}">Tra cứu đơn hàng</a>
      <a class="btn btn--soft btn--block" style="margin-top:8px" href="/cua-hang">Tiếp tục mua sắm</a>
    </aside>
  </div>
</div>`;
  return layout(ctx, { title: 'Đặt hàng thành công', page: 'success', body, scripts: ['/js/misc.js'], noindex: true });
}

function timelineHTML(o) {
  const steps = ['pending', 'confirmed', 'packing', 'shipping', 'completed'];
  if (['cancelled', 'returned'].includes(o.status)) {
    return o.timeline.map((t) => `<li class="is-done"><b>${esc(STATUS_LABEL[t.status])}</b><small>${esc(fmtDateTime(t.at))}${t.note ? ' · ' + esc(t.note) : ''}</small></li>`).join('');
  }
  const cur = steps.indexOf(o.status);
  return steps.map((s, i) => {
    const t = o.timeline.find((x) => x.status === s);
    return `<li class="${i <= cur ? 'is-done' : ''} ${i === cur ? 'is-current' : ''}"><b>${esc(STATUS_LABEL[s])}</b><small>${t ? esc(fmtDateTime(t.at)) : 'Chưa diễn ra'}</small></li>`;
  }).join('');
}
export { timelineHTML };

export function track(ctx) {
  const st = ctx.state;
  const code = ctx.url.searchParams.get('ma') || '';
  const o = code ? st.orders.find((x) => x.code === code) : null;
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Tra cứu đơn hàng' }]);
  const body = html`<div class="container page-head">${bc.html}<h1>Tra cứu đơn hàng</h1><p class="lede">Nhập mã đơn và số điện thoại đặt hàng. Trạng thái cập nhật realtime khi Alokio xử lý đơn.</p></div>
<div class="container two-col">
  <form class="panel stack" data-track novalidate>
    <label class="field"><span>Mã đơn hàng</span><input class="input" name="code" required placeholder="AL-261120-1234" value="${code}"></label>
    <label class="field"><span>Số điện thoại</span><input class="input" name="phone" required inputmode="tel" placeholder="09xxxxxxxx"></label>
    <p class="err" data-track-err aria-live="polite"></p>
    <button class="btn btn--primary" type="submit">Tra cứu</button>
  </form>
  <div class="panel" data-track-result ${o ? '' : raw('hidden')}>${o ? html`<h2 class="h3">Đơn ${o.code}</h2><ol class="timeline" data-timeline data-code="${o.code}">${raw(timelineHTML(o))}</ol>` : ''}</div>
</div>`;
  return layout(ctx, { title: 'Tra cứu đơn hàng', page: 'track', body, scripts: ['/js/misc.js'], description: 'Tra cứu tình trạng đơn hàng Alokio bằng mã đơn và số điện thoại.' });
}

// =====================================================================
// TÀI KHOẢN
// =====================================================================
function authPage(ctx, mode) {
  const next = ctx.url.searchParams.get('next') || '/tai-khoan';
  const titles = { login: 'Đăng nhập', register: 'Tạo tài khoản', forgot: 'Quên mật khẩu' };
  const body = html`<div class="container auth"><h1 style="font-size:46px;text-align:center">${titles[mode]}</h1>
  <form class="panel" data-auth="${mode}" data-next="${next}" novalidate>
    ${mode === 'register' ? html`<label class="field"><span>Họ và tên</span><input class="input" name="name" autocomplete="name" required><small class="err" data-err="name"></small></label><label class="field"><span>Số điện thoại</span><input class="input" name="phone" inputmode="tel" autocomplete="tel" required><small class="err" data-err="phone"></small></label>` : ''}
    <label class="field"><span>Email</span><input class="input" name="email" type="email" autocomplete="email" required><small class="err" data-err="email"></small></label>
    ${mode !== 'forgot' ? html`<label class="field"><span>Mật khẩu</span><input class="input" name="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}" required><small class="err" data-err="password"></small></label>` : ''}
    <p class="err" data-form-err aria-live="assertive"></p>
    <button class="btn btn--primary btn--block btn--lg" type="submit">${mode === 'login' ? 'Đăng nhập' : mode === 'register' ? 'Tạo tài khoản' : 'Gửi liên kết đặt lại'}</button>
    ${mode === 'login' ? html`<button class="btn btn--demo btn--block" type="button" data-demo="khach@alokio.vn|Alokio@123">Dùng tài khoản demo</button><p class="demo-cred">Tài khoản demo: <b>khach@alokio.vn</b> / <b>Alokio@123</b></p><p style="text-align:center;margin:0"><a href="/tai-khoan/quen-mat-khau">Quên mật khẩu?</a> · <a href="/tai-khoan/dang-ky">Tạo tài khoản</a></p>` : html`<p style="text-align:center;margin:0"><a href="/tai-khoan/dang-nhap">Đã có tài khoản? Đăng nhập</a></p>`}
  </form></div>
${mode === 'login' ? html`<a class="staff-door" href="/admin/dang-nhap" title="Đăng nhập trang quản trị" aria-label="Đăng nhập trang quản trị">${icon('shield', { size: 16 })}<span>Quản trị</span></a>` : ''}`;
  return layout(ctx, { title: titles[mode], page: 'auth', body, scripts: ['/js/account.js'], noindex: true });
}
export const login = (ctx) => authPage(ctx, 'login');
export const register = (ctx) => authPage(ctx, 'register');
export const forgot = (ctx) => authPage(ctx, 'forgot');

export function account(ctx) {
  const c = ctx.customer;
  if (!c) return authPage(ctx, 'login');
  const st = ctx.state;
  const orders = st.orders.filter((o) => o.customerId === c.id);
  const addr = c.addresses[0];
  const spent = orders.filter((o) => o.status !== 'cancelled').reduce((s, o) => s + o.total, 0);
  const body = html`<div class="container page-head"><span class="eyebrow">Tài khoản</span><h1>Xin chào, ${c.name.split(' ').pop()}</h1></div>
<div class="container acct">
  <nav aria-label="Tài khoản"><a href="#tong-quan" aria-current="page">Tổng quan</a><a href="#don-hang">Đơn hàng của tôi</a><a href="#dia-chi">Sổ địa chỉ</a><a href="/yeu-thich">Yêu thích</a><a href="#ho-so">Thông tin & mật khẩu</a><a href="#" data-logout>Đăng xuất</a></nav>
  <div class="stack">
    <section class="panel" id="tong-quan"><div class="stats" style="grid-template-columns:repeat(3,1fr);margin:0"><div class="stat"><b>${orders.length}</b><span>Đơn hàng</span></div><div class="stat"><b style="font-size:28px">${fmt(spent)}</b><span>Đã chi tiêu</span></div><div class="stat"><b>${spent >= 15e6 ? 'VIP' : orders.length >= 2 ? 'Thân thiết' : 'Mới'}</b><span>Hạng thành viên</span></div></div></section>
    <section class="panel" id="don-hang"><h2 class="h3">Đơn hàng của tôi</h2>
      ${orders.length ? html`<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Mã đơn</th><th>Ngày</th><th>Sản phẩm</th><th>Tổng</th><th>Trạng thái</th></tr></thead><tbody data-my-orders>${orders.map((o) => html`<tr data-code="${o.code}"><td><a href="/tai-khoan/don-hang/${o.code}">${o.code}</a></td><td>${fmtDate(o.createdAt)}</td><td>${o.items[0]?.name}${o.items.length > 1 ? ` +${o.items.length - 1}` : ''}</td><td>${fmt(o.total)}</td><td><span class="st st--${o.status}" data-st>${STATUS_LABEL[o.status]}</span></td></tr>`)}</tbody></table></div>` : html`<p class="muted">Bạn chưa có đơn hàng nào.</p>`}
    </section>
    <form class="panel" id="dia-chi" data-profile novalidate><h2 class="h3">Sổ địa chỉ</h2>
      <div class="form-grid">
        <label class="field"><span>Tỉnh / Thành phố</span><select class="select" name="province"><option value="">— Chọn —</option>${PROVINCES.slice().sort((a, b) => a.name.localeCompare(b.name, 'vi')).map((pr) => html`<option value="${pr.code}" ${addr?.province === pr.code ? raw('selected') : ''}>${pr.name}</option>`)}</select></label>
        <label class="field"><span>Phường / Xã</span><input class="input" name="ward" value="${addr?.ward || ''}"></label>
        <label class="field full"><span>Số nhà, đường</span><input class="input" name="street" value="${addr?.street || ''}"></label>
      </div><button class="btn btn--primary btn--sm" type="submit" style="margin-top:12px">Lưu địa chỉ</button><span class="muted" data-profile-msg style="margin-left:10px" aria-live="polite"></span>
    </form>
    <form class="panel" id="ho-so" data-password novalidate><h2 class="h3">Thông tin & mật khẩu</h2>
      <div class="form-grid"><label class="field"><span>Họ tên</span><input class="input" name="name" value="${c.name}"></label><label class="field"><span>Số điện thoại</span><input class="input" name="phone" value="${c.phone}"></label>
      <label class="field"><span>Mật khẩu hiện tại</span><input class="input" type="password" name="oldPassword" autocomplete="current-password"><small class="err" data-err="oldPassword"></small></label><label class="field"><span>Mật khẩu mới</span><input class="input" type="password" name="newPassword" autocomplete="new-password"><small class="err" data-err="newPassword"></small></label></div>
      <button class="btn btn--primary btn--sm" type="submit" style="margin-top:12px">Lưu thay đổi</button><span class="muted" data-pw-msg style="margin-left:10px" aria-live="polite"></span>
    </form>
  </div>
</div>`;
  return layout(ctx, { title: 'Tài khoản', page: 'account', body, scripts: ['/js/account.js'], noindex: true });
}
export function accountOrder(ctx) {
  const c = ctx.customer;
  if (!c) return authPage(ctx, 'login');
  const o = ctx.state.orders.find((x) => x.code === ctx.params.code && x.customerId === c.id);
  if (!o) return notFound(ctx);
  const body = html`<div class="container page-head"><a class="link-arrow" href="/tai-khoan#don-hang">${icon('back', { size: 16 })} Đơn hàng của tôi</a><h1>Đơn ${o.code}</h1><p class="muted">Đặt lúc ${fmtDateTime(o.createdAt)}</p></div>
<div class="container two-col"><div class="panel"><h2 class="h3">Tình trạng</h2><ol class="timeline" data-timeline data-code="${o.code}">${raw(timelineHTML(o))}</ol>
  ${o.status === 'pending' ? html`<button class="btn btn--ghost" type="button" data-cancel-order="${o.code}">Huỷ đơn hàng</button>` : ''}</div>
  <aside class="panel summary"><h2>Sản phẩm</h2>${o.items.map((l) => html`<div class="row" style="font-size:15px;padding:6px 0"><span>${l.name} × ${l.qty}<br><small class="muted">${FINISHES[l.finish]?.name || ''}</small></span><span>${fmt(l.total)}</span></div>`)}<div class="row row--total"><span>Tổng</span><span>${fmt(o.total)}</span></div><p class="muted">Thanh toán: ${PAYMENT_LABEL[o.payment.method]} · <span class="st st--${o.payment.status}">${PAY_STATUS_LABEL[o.payment.status]}</span></p></aside></div>`;
  return layout(ctx, { title: 'Đơn ' + o.code, page: 'account', body, scripts: ['/js/account.js', '/js/misc.js'], noindex: true });
}

// =====================================================================
// BLOG & TRANG NỘI DUNG
// =====================================================================
export function blog(ctx) {
  const st = ctx.state;
  const posts = [...st.posts].sort((a, b) => b.publishedAt - a.publishedAt);
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Cẩm nang' }]);
  const body = html`<div class="container page-head">${bc.html}<span class="eyebrow">Cẩm nang âm thanh</span><h1>Đọc trước khi <em style="color:var(--primary)">nghe</em>.</h1></div>
<div class="container" style="padding-bottom:80px"><div class="posts">${posts.map((p) => html`<a class="post-card reveal" href="/blog/${p.slug}"><div class="post-card__img"><img src="/img/blog/${p.cover}.webp" alt="" width="800" height="500" loading="lazy"></div><div class="post-card__body"><span class="label">${p.tags.join(' · ')} · ${fmtDate(p.publishedAt)}</span><h2 class="h3" style="margin:8px 0">${p.title}</h2><p>${p.excerpt}</p></div></a>`)}</div></div>`;
  return layout(ctx, { title: 'Cẩm nang âm thanh', page: 'blog', body, description: 'Cẩm nang âm thanh của Alokio: chọn loa bluetooth cao cấp, loa kéo karaoke, chỉnh echo bass, bảo quản ắc quy và hơn thế nữa.', jsonld: [bc.ld] });
}
export function post(ctx) {
  const st = ctx.state;
  const p = st.posts.find((x) => x.slug === ctx.params.slug);
  if (!p) return notFound(ctx);
  const words = p.body.split(/\s+/).length;
  const toc = headings(p.body);
  const prods = (p.products || []).map((id) => st.products.find((x) => x.id === id)).filter((x) => x && !x.hidden);
  const others = st.posts.filter((x) => x.id !== p.id).slice(0, 3);
  const bc = breadcrumbs([{ label: 'Trang chủ', href: '/' }, { label: 'Cẩm nang', href: '/blog' }, { label: p.title }]);
  const ld = { '@context': 'https://schema.org', '@type': 'Article', headline: p.title, description: p.excerpt, datePublished: new Date(p.publishedAt).toISOString(), author: { '@type': 'Organization', name: p.author }, publisher: { '@type': 'Organization', name: 'Alokio' }, image: siteUrl() + `/img/blog/${p.cover}.webp`, mainEntityOfPage: siteUrl() + '/blog/' + p.slug };
  const body = html`<div class="container page-head">${bc.html}<span class="eyebrow">${p.tags.join(' · ')}</span><h1 style="max-width:20ch">${p.title}</h1><p class="muted">${fmtDate(p.publishedAt)} · ${Math.max(1, Math.round(words / 220))} phút đọc · ${p.author}</p></div>
<div class="container"><img src="/img/blog/${p.cover}.webp" alt="" width="1600" height="700" style="width:100%;aspect-ratio:16/7;object-fit:cover;border-radius:32px;margin-bottom:50px"></div>
<div class="container article">
  <nav class="toc" aria-label="Mục lục"><p class="label">Mục lục</p>${toc.map((t) => html`<a href="#${t.id}">${t.title}</a>`)}</nav>
  <article class="prose">${md(p.body)}
    ${prods.length ? html`<div class="panel" style="margin-top:40px"><p class="label">Sản phẩm trong bài</p><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr))">${prods.map((x) => productCard(st, x, { reveal: false }))}</div></div>` : ''}
  </article>
</div>
<section class="section--tight container"><h2 class="h3">Bài viết liên quan</h2><div class="posts">${others.map((o) => html`<a class="post-card" href="/blog/${o.slug}"><div class="post-card__img"><img src="/img/blog/${o.cover}.webp" alt="" width="800" height="500" loading="lazy"></div><div class="post-card__body"><h3>${o.title}</h3><p>${o.excerpt}</p></div></a>`)}</div></section>`;
  return layout(ctx, { title: p.title, page: 'post', body, description: p.excerpt, jsonld: [bc.ld, ld], ogImage: `/img/blog/${p.cover}.webp` });
}

export function about(ctx) {
  const s = ctx.state.settings;
  const body = html`<div class="container page-head"><span class="eyebrow">Giới thiệu</span><h1>Âm Thanh <em style="color:var(--primary)">Việt</em>.</h1><p class="lede">Alokio là thương hiệu loa kéo karaoke tại Việt Nam, được biết đến với các mẫu loa thùng gỗ bass 3–5 tấc, tích hợp ampli và ắc quy, kèm micro không dây cho những cuộc vui ở mọi nơi.</p></div>
<div class="container two-col"><div class="prose"><h2>Alokio Luxe</h2><p>Bên cạnh dòng loa kéo karaoke quen thuộc, Alokio ra mắt bộ sưu tập <b>Alokio Luxe</b>: loa bluetooth cao cấp mang ngôn ngữ thiết kế “Sang trọng kiểu Việt” với sơn mài, khảm trai, vải lanh và nhôm champagne.</p><p>Mỗi mẫu lấy cảm hứng từ một cảnh sắc Việt Nam: Giọt, Sóng, Hạ Long, Hội An, Huế, Tràng An… để chiếc loa vừa là thiết bị âm thanh, vừa là món đồ trưng bày trong nhà.</p><h2>Kênh chính thức</h2><p>Mua loa kéo Alokio chính hãng tại các kênh dưới đây.</p>${channelButtons(s)}</div>
<aside class="panel"><img src="/img/products/alokio-luxe-ha-long--huyen.webp" alt="Alokio Luxe Hạ Long màu Huyền" width="600" height="600" loading="lazy"></aside></div>`;
  return layout(ctx, { title: 'Giới thiệu', page: 'about', body, description: 'Giới thiệu Alokio – Âm Thanh Việt: loa kéo karaoke chính hãng và bộ sưu tập cao cấp Alokio Luxe.' });
}
export function contact(ctx) {
  const s = ctx.state.settings;
  const luxe = ctx.state.products.filter((p) => p.line === 'luxe' && p.category !== 'phu-kien');
  const body = html`<div class="container page-head"><span class="eyebrow">Liên hệ</span><h1>Nói chuyện với Alokio</h1><p class="lede">Chat trực tiếp (góc phải màn hình), nhắn qua các kênh chính thức hoặc đặt lịch nghe thử tại showroom.</p></div>
<div class="container two-col">
  <form class="panel stack" id="dat-lich" data-appointment novalidate><h2 class="h3">Đặt lịch nghe thử</h2>
    <div class="form-grid"><label class="field"><span>Họ tên *</span><input class="input" name="name" required autocomplete="name"></label><label class="field"><span>Số điện thoại *</span><input class="input" name="phone" required inputmode="tel" autocomplete="tel"></label>
    <label class="field"><span>Ngày</span><input class="input" type="date" name="date"></label><label class="field"><span>Mẫu muốn nghe</span><select class="select" name="product">${luxe.map((p) => html`<option>${p.name}</option>`)}<option>Loa kéo karaoke</option></select></label>
    <label class="field full"><span>Ghi chú</span><textarea class="textarea" name="note"></textarea></label></div>
    <p class="err" data-appt-msg aria-live="polite"></p><button class="btn btn--primary" type="submit">Đặt lịch</button></form>
  <aside class="panel stack"><h2 class="h3">Kênh chính thức</h2>${channelButtons(s)}<p class="muted">Hotline: ${s.hotline}<br>Email: ${s.email}</p><button class="btn btn--dark" type="button" data-chat-open>${icon('chat', { size: 18 })} Chat ngay</button></aside>
</div>`;
  return layout(ctx, { title: 'Liên hệ', page: 'contact', body, scripts: ['/js/misc.js'], description: 'Liên hệ Alokio: chat trực tiếp, Facebook, TikTok Shop, Shopee chính thức và đặt lịch nghe thử.' });
}
const FAQS = [
  ['Thanh toán trên website có mất tiền thật không?', 'Không. Mọi phương thức (VietQR, ví điện tử, thẻ, trả góp) đều được hỗ trợ, kể cả trả góp 0% qua thẻ.'],
  ['Mua loa kéo Alokio chính hãng ở đâu?', 'Tại Shopee, TikTok Shop và Facebook chính thức của Alokio (nút ở đầu trang, chân trang và bong bóng liên hệ).'],
  ['Phí vận chuyển tính thế nào?', 'Theo khối lượng: dưới 5 kg 30.000 ₫, 5–15 kg 80.000 ₫, trên 15 kg 150.000 ₫; miễn phí cho đơn từ 3.000.000 ₫. Hoả tốc 2 giờ 99.000 ₫.'],
  ['Tôi có thể đổi trả không?', 'Đổi trả trong 30 ngày nếu sản phẩm lỗi kỹ thuật hoặc chưa qua sử dụng (chính sách mẫu).'],
  ['Địa chỉ giao hàng có cần quận/huyện không?', 'Không. Website dùng địa giới hành chính mới 2 cấp (tỉnh – xã) với 34 tỉnh/thành.'],
];
export function support(ctx) {
  const ld = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: FAQS.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) };
  const body = html`<div class="container page-head"><span class="eyebrow">Hỗ trợ</span><h1>Câu hỏi thường gặp</h1></div>
<div class="container two-col"><div class="panel faq">${FAQS.map(([q, a]) => html`<details><summary>${q}</summary><p>${a}</p></details>`)}</div>
<aside class="panel stack"><h2 class="h3">Cần thêm trợ giúp?</h2><a class="btn btn--ghost" href="/tra-cuu-don-hang">Tra cứu đơn hàng</a><a class="btn btn--ghost" href="/chinh-sach/van-chuyen">Chính sách vận chuyển</a><a class="btn btn--ghost" href="/chinh-sach/doi-tra">Đổi trả</a><button class="btn btn--dark" type="button" data-chat-open>Chat với Alokio</button></aside></div>`;
  return layout(ctx, { title: 'Hỗ trợ – Câu hỏi thường gặp', page: 'support', body, jsonld: [ld], description: 'Câu hỏi thường gặp khi mua loa tại Alokio: vận chuyển, đổi trả, thanh toán, Alokio Luxe.' });
}
const POLICIES = {
  'doi-tra': ['Chính sách đổi trả', ['Đổi trả trong 30 ngày kể từ khi nhận hàng nếu sản phẩm lỗi kỹ thuật do nhà sản xuất.', 'Sản phẩm đổi trả cần còn đầy đủ phụ kiện, hộp và hoá đơn.', 'Phụ kiện (micro, remote) không áp dụng bảo hành theo chính sách của dòng loa kéo.']],
  'bao-hanh': ['Chính sách bảo hành', ['Alokio Luxe: bảo hành 24 tháng, đổi mới trong 30 ngày nếu lỗi do nhà sản xuất.', 'Loa kéo karaoke: bảo hành loa 12 tháng, ắc quy 6 tháng; phụ kiện không bảo hành (tham khảo đại lý).', 'Bảo hành không áp dụng cho hư hỏng do rơi vỡ, vào nước quá mức chuẩn IP hoặc tự ý sửa chữa.']],
  'van-chuyen': ['Chính sách vận chuyển', ['Giao toàn quốc theo địa giới hành chính mới (34 tỉnh/thành, 2 cấp).', 'Phí theo khối lượng: dưới 5 kg 30.000 ₫; 5–15 kg 80.000 ₫; trên 15 kg 150.000 ₫.', 'Miễn phí giao tiêu chuẩn cho đơn từ 3.000.000 ₫. Hoả tốc 2 giờ tại Hà Nội & TP.HCM: 99.000 ₫.']],
  'bao-mat': ['Chính sách bảo mật', ['Alokio chỉ dùng thông tin bạn cung cấp để xử lý đơn hàng, giao hàng và chăm sóc sau bán.', 'Không lưu số thẻ thanh toán; giao dịch được xử lý qua cổng thanh toán.', 'Micro (thử hát karaoke) chỉ dùng cục bộ trên trình duyệt, không ghi âm, không gửi đi.']],
  'dieu-khoan': ['Điều khoản sử dụng', ['Tên và logo Alokio thuộc về thương hiệu Alokio.', 'Giá và tình trạng hàng có thể thay đổi; đơn hàng được xác nhận khi Alokio liên hệ hoặc khi thanh toán thành công.', 'Khi đặt hàng, bạn đồng ý với chính sách vận chuyển, đổi trả và bảo hành của Alokio.']],
};
export function policy(ctx) {
  const p = POLICIES[ctx.params.slug];
  if (!p) return notFound(ctx);
  const body = html`<div class="container page-head"><span class="eyebrow">Chính sách</span><h1>${p[0]}</h1></div><div class="container prose" style="padding-bottom:80px">${p[1].map((x) => html`<p>${x}</p>`)}</div>`;
  return layout(ctx, { title: p[0], page: 'policy', body, description: p[1][0] });
}

export function notFound(ctx) {
  const body = html`<section class="nf" data-nf><div class="container"><span class="eyebrow">Lỗi 404</span><h1 class="display">Giọt nước <em>lạc đường</em>.</h1><p class="lede mx-auto">Trang bạn tìm không tồn tại hoặc đã được chuyển đi.</p>
  <form action="/tim-kiem" class="pill-form mx-auto" style="margin-top:24px" role="search"><label class="sr-only" for="q404">Tìm kiếm</label><input id="q404" name="q" placeholder="Tìm sản phẩm…"><button class="btn btn--primary" type="submit">Tìm</button></form>
  <p style="margin-top:28px"><a class="btn btn--ghost" href="/cua-hang">Về cửa hàng</a> <a class="btn btn--soft" href="/">Trang chủ</a></p></div></section>`;
  return Object.assign(new String(layout(ctx, { title: 'Không tìm thấy trang', page: '404', body, scripts: ['/js/misc.js'], noindex: true })), { status: 404 });
}

export function studio(ctx) {
  return `<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Studio render</title><link rel="stylesheet" href="/css/site.css"><style>html,body{margin:0;background:transparent}#c{width:100vw;height:100vh;display:block}</style></head><body><canvas id="c"></canvas><script>window.__PRODUCTS__=${JSON.stringify(ctx.state.products.map((p) => ({ id: p.id, slug: p.slug, model: p.model, finishes: p.finishes })))}</script><script type="module" src="/js/studio.js?v=${ctx.assetVersion}"></script></body></html>`;
}
