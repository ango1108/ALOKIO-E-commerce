import { html, raw, fmt, stars } from './html.js';
import { icon } from './icons.js';
import { layout } from './layout.js';
import { productCard, priceHTML, channelButtons } from './components.js';

const TABS = [
  { id: 'di-dong', label: 'Di động', cats: ['loa-di-dong'], hero: 'p-halong' },
  { id: 'tai-gia', label: 'Tại gia', cats: ['loa-nghe-tai-gia'], hero: 'p-hoian' },
  { id: 'rap-phim', label: 'Thông minh & Rạp phim', cats: ['loa-thong-minh', 'soundbar-rap-phim'], hero: 'p-songhuong' },
  { id: 'tiec', label: 'Tiệc', cats: ['loa-party-karaoke'], hero: 'p-lehoi', luxeOnly: true },
];

export function homePage(ctx) {
  const st = ctx.state;
  const s = st.settings;
  const P = (id) => st.products.find((p) => p.id === id);
  const visible = st.products.filter((p) => !p.hidden);
  const luxe = visible.filter((p) => p.line === 'luxe' && p.category !== 'phu-kien');
  const karaoke = visible.filter((p) => p.line === 'karaoke' && p.category !== 'phu-kien');
  const hero = P(s.heroProduct) || P('p-halong');
  const reviews = st.reviews.filter((r) => r.status === 'approved' && r.stars === 5 && r.text.length > 60).slice(0, 3);
  const posts = [...st.posts].sort((a, b) => b.publishedAt - a.publishedAt).slice(0, 3);
  const words = ['Âm', 'thanh', 'Việt,', 'lan', 'trên', 'mặt', 'nước.'];
  const tabData = TABS.map((t) => {
    const items = luxe.filter((p) => t.cats.includes(p.category));
    const h = P(t.hero) || items[0];
    return { ...t, items, hero: h };
  });

  const body = html`
<section class="hero" data-hero aria-labelledby="hero-title">
  <div class="hero__fallback" aria-hidden="true"></div>
  <img class="hero__poster" src="/img/hero-poster.webp" alt="" width="1920" height="1080" fetchpriority="high" decoding="async" aria-hidden="true">
  <canvas class="hero__canvas" data-hero-canvas aria-hidden="true"></canvas>
  <div class="hero__rays" aria-hidden="true"><i></i><i></i><b></b></div>
  <div class="hero__scrim" aria-hidden="true"></div>
  <div class="hero__copy">
    <span class="eyebrow fade-up" style="--d:150ms">Alokio Luxe · Hạ Long · Stereo 360°</span>
    <h1 class="display" id="hero-title">${raw(words.map((w, i) => `<span class="w"><span style="--i:${i}">${i >= 5 ? `<em>${w}</em>` : w}</span></span>`).join(' '))}</h1>
    <p class="hero__sub fade-up">Sơn mài, khảm trai và 80 W âm thanh stereo 360° — chiếc loa đủ đẹp để trưng bày, đủ bền để mang ra biển.</p>
    <div class="hero__ctas fade-up" style="--d:1000ms">
      <a class="btn btn--primary btn--lg" href="/san-pham/${hero.slug}">Đặt ${hero.name.replace('Alokio Luxe ', 'Alokio ')}</a>
      <a class="btn btn--ghost btn--lg" href="/showroom">${icon('cube', { size: 18 })} Vào phòng trưng bày 3D</a>
      <a class="link-arrow" href="/cua-hang">Khám phá cửa hàng ${icon('arrow', { size: 16 })}</a>
    </div>
    <p class="hero__badge fade-up" style="--d:1150ms">${stars(hero.rating || 5)} <b>${String(hero.rating || 5).replace('.', ',')}/5</b> · ${hero.reviewCount} đánh giá · ${priceHTML(st, hero)}</p>
  </div>
  <button class="audio-hint" type="button" data-audio-hint>${raw('<span class="bars" aria-hidden="true"><i></i><i></i><i></i><i></i></span>')} Bật âm thanh để mặt nước rung theo nhạc</button>
  <p class="hero__hint" aria-hidden="true">Chạm vào mặt nước — sóng sẽ lan theo bạn <i></i></p>
</section>

<section class="section" aria-labelledby="mf-title">
  <div class="container">
    <span class="eyebrow reveal">Sang trọng kiểu Việt</span>
    <h2 class="manifesto reveal" id="mf-title">Một chiếc loa nên đẹp cả khi <em>tắt nhạc</em>, và hay đến mức bạn không muốn tắt.</h2>
    <div class="cards3">
      <article class="feature glass reveal">
        <div class="feature__art"><img src="/img/feat-lacquer.webp" alt="Cận cảnh bề mặt sơn mài và vòng khảm trai" width="800" height="400" loading="lazy"></div>
        <span class="label">01 · Chế tác</span><h3>Sơn mài &amp; khảm trai</h3>
        <p>Nhiều lớp sơn mài mài tay cho độ bóng sâu như mặt hồ; viền khảm trai đổi sắc theo từng góc nhìn.</p>
      </article>
      <article class="feature glass reveal">
        <div class="feature__art"><img src="/img/feat-sound.webp" alt="Bên trong loa: woofer và tweeter" width="800" height="400" loading="lazy"></div>
        <span class="label">02 · Âm thanh</span><h3>Lấp đầy căn phòng</h3>
        <p>Stereo 360° trên dòng di động, tới 150 W ba đường tiếng trên dòng tại gia — bass chắc, giọng hát ấm.</p>
      </article>
      <article class="feature glass reveal">
        <div class="feature__art"><img src="/img/feat-water.webp" alt="Loa nổi trên mặt nước" width="800" height="400" loading="lazy"></div>
        <span class="label">03 · Bền bỉ</span><h3>Sinh ra cho mặt nước</h3>
        <p>Chuẩn IP67, thiết kế nổi trên nước, pin hơn 30 giờ và có thể thay được — đồng hành nhiều năm.</p>
      </article>
    </div>
  </div>
</section>

<section class="section section--mist" id="bo-suu-tap" aria-labelledby="col-title">
  <div class="container">
    <div class="section__head">
      <div><span class="eyebrow reveal">Bộ sưu tập Alokio Luxe</span><h2 class="h2 reveal" id="col-title">Mỗi mẫu loa, một <em>cảnh sắc</em> Việt.</h2></div>
      <div class="tabs reveal" role="tablist" aria-label="Nhóm sản phẩm">
        ${tabData.map((t, i) => html`<button class="tab" role="tab" id="tab-${t.id}" aria-controls="panel-${t.id}" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}" data-tab="${t.id}">${t.label}</button>`)}
      </div>
    </div>
    ${tabData.map((t, i) => html`
    <div class="tabpanel" role="tabpanel" id="panel-${t.id}" aria-labelledby="tab-${t.id}" ${i ? raw('hidden') : ''} data-panel="${t.id}">
      <div class="stage">
        <div class="stage__view" data-stage-view data-model='${raw(JSON.stringify(t.hero.model))}' data-finish="${t.hero.finishes[0]}">
          <img class="stage__img" src="${t.hero.image}" alt="${t.hero.name}" width="900" height="780" loading="lazy">
          <span class="view-hint">Kéo để xoay 360°</span>
        </div>
        <div class="stage__info">
          <span class="tag tag--concept">Bộ sưu tập cao cấp</span>
          <h3>${t.hero.name}</h3>
          <p class="stage__tagline">${t.hero.tagline}</p>
          <ul class="stage__specs">${t.hero.highlights.map((h) => html`<li>${h}</li>`)}</ul>
          <div class="stage__price">${priceHTML(st, t.hero)}</div>
          <div class="stage__ctas">
            <a class="btn btn--primary" href="/san-pham/${t.hero.slug}#atelier">${icon('sparkle', { size: 18 })} Tuỳ biến tại Atelier</a>
            <button class="btn btn--ghost" type="button" data-add="${t.hero.id}" data-finish="${t.hero.finishes[0]}" data-name="${t.hero.name}">${icon('cart', { size: 18 })} Thêm vào giỏ</button>
          </div>
        </div>
      </div>
      <div class="rail" style="margin-top:40px">${t.items.map((p) => productCard(st, p, { reveal: false }))}</div>
    </div>`)}
  </div>
</section>

<section class="section dark-band" aria-labelledby="mat-title">
  <div class="container">
    <div class="section__head">
      <div><span class="eyebrow reveal">Phòng vật liệu</span><h2 class="h2 reveal" id="mat-title">Bốn chất liệu, <em>một tinh thần</em>.</h2></div>
      <p class="lede reveal">Rê chuột để ánh đèn studio quét qua bề mặt: ánh trai đổi màu, sơn mài sâu thẳm, vải lanh mềm và nhôm phay champagne.</p>
    </div>
    <div class="matroom reveal" data-matroom>
      <img src="/img/matroom.webp" alt="Bốn mẫu vật liệu: sơn mài, khảm trai, vải lanh, nhôm champagne" width="1600" height="700" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">
      <div class="matroom__labels">
        <div><h3>Sơn mài</h3><p>Nhiều lớp, mài tay, bóng sâu như mặt hồ.</p></div>
        <div><h3>Khảm trai</h3><p>Mảnh xà cừ ghép tay, đổi sắc theo góc nhìn.</p></div>
        <div><h3>Vải lanh</h3><p>Dệt kim, cho âm thanh đi xuyên mà vẫn mềm mắt.</p></div>
        <div><h3>Nhôm champagne</h3><p>Phay CNC, vân xước tròn trên mỗi núm vặn.</p></div>
      </div>
    </div>
  </div>
</section>

<section class="exploded" data-exploded aria-labelledby="ex-title">
  <div class="container exploded__sticky">
    <div class="exploded__view" data-exploded-view><img src="/img/products/alokio-luxe-ha-long.webp" alt="Alokio Luxe Hạ Long" width="900" height="900" loading="lazy" style="position:absolute;inset:0;margin:auto;max-height:80%;object-fit:contain"></div>
    <div class="exploded__copy">
      <span class="eyebrow">Bên trong Hạ Long</span>
      <h2 class="h2" id="ex-title"><span data-ex-verb>Cuộn</span> để <em>mở</em> chiếc loa.</h2>
      <ol class="exploded__steps" data-exploded-steps>
        <li><b>Mặt vải lanh</b><span>Dệt kim, trong suốt với âm thanh.</span></li>
        <li><b>Khung nhôm champagne</b><span>Phay CNC nguyên khối, logo dập chìm.</span></li>
        <li><b>2 woofer 3" + 2 tweeter 0,6"</b><span>80 W, stereo 360°, 45 Hz – 20 kHz.</span></li>
        <li><b>Bo mạch ampli Class-D</b><span>4 kênh, tiết kiệm năng lượng.</span></li>
        <li><b>Pin thay được</b><span>30+ giờ, sạc 20 phút nghe 5 giờ.</span></li>
        <li><b>Vỏ sơn mài &amp; quai da</b><span>IP67, nổi trên mặt nước.</span></li>
      </ol>
      <div class="stats">
        <div class="stat"><b data-count="80" data-suffix=" W">0</b><span>Công suất · Hạ Long</span></div>
        <div class="stat"><b data-count="30" data-suffix="+ giờ">0</b><span>Pin · Hạ Long</span></div>
        <div class="stat"><b data-count="150" data-suffix=" W">0</b><span>Công suất · Tràng An</span></div>
        <div class="stat"><b data-count="67" data-suffix="">0</b><span>Chuẩn IP · Giọt, Sóng, Hạ Long</span></div>
      </div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="kn-title">
  <div class="container knobs">
    <div class="knobs__view reveal" data-knobs-view>
      <img src="/img/products/alokio-luxe-hoi-an.webp" alt="Núm vặn analog champagne của Alokio Luxe Hội An" width="900" height="600" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;padding:6%">
    </div>
    <div class="reveal">
      <span class="eyebrow">Vặn thử</span>
      <h2 class="h2" id="kn-title">Chạm vào <em>âm thanh</em>.</h2>
      <p class="lede">Chọn một bài, bấm phát rồi kéo trực tiếp các núm champagne của Hội An (hoặc dùng thanh trượt) để nghe âm thanh thay đổi ngay lập tức.</p>
      <div class="knob-sliders" data-knob-sliders>
        <div class="knob-slider"><label for="k-vol">Volume</label><input id="k-vol" type="range" min="0" max="100" value="15" data-eq="volume"><output for="k-vol">15</output></div>
        <div class="knob-slider"><label for="k-bass">Bass</label><input id="k-bass" type="range" min="-12" max="12" value="0" data-eq="bass"><output for="k-bass">0 dB</output></div>
        <div class="knob-slider"><label for="k-treble">Treble</label><input id="k-treble" type="range" min="-12" max="12" value="0" data-eq="treble"><output for="k-treble">0 dB</output></div>
      </div>
      <div class="kplayer" data-kplayer>
        <div class="kplayer__head"><button class="kplayer__play" type="button" data-kp-toggle aria-pressed="false" aria-label="Phát nhạc để nghe thử"><span class="kp-play">${icon('play', { size: 18 })}</span><span class="kp-pause" aria-hidden="true"><i></i><i></i></span></button>
          <div class="kplayer__now"><small data-kp-state>Chọn bài để nghe thử</small><b data-kp-title>Interstellar – Main Theme</b></div>
          <span class="eqbars" aria-hidden="true"><i></i><i></i><i></i><i></i></span></div>
        <div class="kplayer__list" role="radiogroup" aria-label="Chọn nhạc nghe thử" data-kp-list></div>
      </div>
      <a class="btn btn--ghost" href="/san-pham/alokio-luxe-hoi-an" style="margin-top:14px">Xem Hội An</a>
    </div>
  </div>
</section>

<section class="section section--tight" aria-labelledby="sr-title">
  <div class="container">
    <a class="showroom-teaser glass reveal" href="/showroom" style="display:grid;grid-template-columns:1.4fr 1fr;align-items:center;gap:30px;padding:16px;text-decoration:none;color:inherit;border-radius:32px">
      <img src="/img/showroom-poster.webp" alt="Phòng trưng bày 3D trên mặt vịnh" width="1400" height="700" loading="lazy" style="width:100%;border-radius:22px;aspect-ratio:2/1;object-fit:cover">
      <div style="padding:10px 20px">
        <span class="eyebrow">Showroom 3D</span>
        <h2 class="h2" id="sr-title" style="font-size:clamp(32px,3.6vw,52px)">Gallery <em>trên vịnh</em>.</h2>
        <p class="muted">Dạo quanh các bục sơn mài nổi trên mặt nước, bật thử từng chiếc loa và thêm vào giỏ ngay trong không gian 3D.</p>
        <span class="btn btn--dark">${icon('cube', { size: 18 })} Vào phòng trưng bày</span>
      </div>
    </a>
  </div>
</section>

<section class="section section--tight" aria-labelledby="sz-title">
  <div class="container">
    <div class="section__head"><div><span class="eyebrow reveal">Đặt vào không gian của bạn</span><h2 class="h2 reveal" id="sz-title">Kích thước <em>thật</em>.</h2></div><p class="lede reveal">So sánh các mẫu với chiều cao người 1,7 m để hình dung chính xác trước khi đặt mua.</p></div>
    <div class="sizecmp reveal" data-sizecmp>
      <img src="/img/sizecmp.webp" alt="So sánh kích thước các mẫu loa với người cao 1,7 m" width="1600" height="720" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">
    </div>
  </div>
</section>

<section class="section karaoke" id="karaoke" aria-labelledby="ka-title">
  <div class="container karaoke__grid">
    <div class="karaoke__view reveal" data-karaoke-view data-model='${raw(JSON.stringify(P('k-ak18').model))}'>
      <img src="/img/products/loa-keo-alokio-al-ak18.webp" alt="Loa kéo Alokio AL-AK18" width="800" height="840" loading="lazy" style="padding:8%">
    </div>
    <div class="reveal">
      <span class="eyebrow">Âm Thanh Việt · Karaoke · Hàng thật</span>
      <h2 class="h2" id="ka-title">Hát là phê, <em>kéo là đi</em>.</h2>
      <p class="lede">Loa kéo karaoke chính hãng Alokio: thùng gỗ, bass tới 5 tấc, ampli và ắc quy tích hợp, kèm 2 micro không dây. Mua tại các kênh chính thức của Alokio.</p>
      <div class="karaoke__cards">${karaoke.filter((p) => p.featured || ['k-gd18', 'k-r95'].includes(p.id)).slice(0, 4).map((p) => html`<a class="kcard" href="/san-pham/${p.slug}"><img src="${p.image}" alt="" width="64" height="64" loading="lazy"><span><b>${p.name.replace('Loa kéo Alokio ', '')}</b><small>${p.highlights[0]} · ${fmt(p.price)}</small></span></a>`)}</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:18px">
        <button class="btn btn--primary" type="button" data-karaoke-mic>${icon('mic', { size: 18 })} Thử hát karaoke</button>
        <a class="btn btn--ghost" style="color:#fff;border-color:rgba(255,255,255,.3);background:rgba(255,255,255,.06)" href="/bo-suu-tap/am-thanh-viet-karaoke">Xem tất cả loa kéo</a>
      </div>
      <p class="muted" style="font-size:14px" data-mic-note>Cần quyền micro, nên dùng tai nghe để tránh hú. Giọng hát chỉ phát qua loa của bạn, không ghi âm, không gửi đi đâu.</p>
      <div class="mic-meter" aria-hidden="true"><i data-mic-level></i></div>
      <div style="margin-top:22px">${channelButtons(s)}</div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="ch-title">
  <div class="container">
    <div class="section__head"><div><span class="eyebrow reveal">Kênh chính thức</span><h2 class="h2 reveal" id="ch-title">Tìm Alokio <em>ở khắp nơi</em>.</h2></div></div>
    <div class="channels">
      <a class="channel reveal" href="${s.links.facebook}" target="_blank" rel="noopener noreferrer"><span class="channel__ico" style="background:#1877F2">${icon('facebook', { size: 28 })}</span><h3>Facebook</h3><p>Tin mới, livestream và tư vấn trực tiếp từ Alokio.</p><span class="link-arrow">Mở Facebook ${icon('external', { size: 16 })}</span></a>
      <a class="channel reveal" href="${s.links.tiktok}" target="_blank" rel="noopener noreferrer"><span class="channel__ico" style="background:#111">${icon('tiktok', { size: 28 })}</span><h3>TikTok Shop</h3><p>“Loa Kéo Alokio – Âm Thanh Việt”: video thực tế và ưu đãi live.</p><span class="link-arrow">Mở TikTok Shop ${icon('external', { size: 16 })}</span></a>
      <a class="channel reveal" href="${s.links.shopee}" target="_blank" rel="noopener noreferrer"><span class="channel__ico" style="background:#EE4D2D">${icon('shopee', { size: 28 })}</span><h3>Shopee</h3><p>Gian hàng chính thức, mã giảm giá và giao nhanh toàn quốc.</p><span class="link-arrow">Mở Shopee ${icon('external', { size: 16 })}</span></a>
    </div>
  </div>
</section>

<section class="section section--mist" aria-labelledby="rv-title">
  <div class="container">
    <div class="section__head"><div><span class="eyebrow reveal">Người nghe nói gì</span><h2 class="h2 reveal" id="rv-title">Đẹp hơn ảnh, <em>hay hơn mong đợi</em>.</h2></div><p class="muted reveal">Cảm nhận thật từ những người đã mang Alokio về nhà.</p></div>
    <div class="quotes">${reviews.map((r) => { const p = P(r.productId); return html`<figure class="quote glass reveal"><blockquote>“${r.text}”</blockquote><figcaption>${stars(r.stars)} · ${r.name} · ${p ? p.name : ''}</figcaption></figure>`; })}</div>
  </div>
</section>

<section class="section" aria-labelledby="bl-title">
  <div class="container">
    <div class="section__head"><div><span class="eyebrow reveal">Cẩm nang âm thanh</span><h2 class="h2 reveal" id="bl-title">Đọc trước khi <em>nghe</em>.</h2></div><a class="link-arrow reveal" href="/blog">Tất cả bài viết ${icon('arrow', { size: 16 })}</a></div>
    <div class="posts">${posts.map((p) => html`<a class="post-card reveal" href="/blog/${p.slug}"><div class="post-card__img"><img src="/img/blog/${p.cover}.webp" alt="" width="800" height="500" loading="lazy"></div><div class="post-card__body"><span class="label">${p.tags[0]}</span><h3>${p.title}</h3><p>${p.excerpt}</p></div></a>`)}</div>
  </div>
</section>

<section class="cta" aria-labelledby="cta-title">
  <div class="container">
    <h2 class="display reveal" id="cta-title">Chọn chiếc loa <em>của riêng bạn.</em></h2>
    <div class="cta__btns reveal">
      <a class="btn btn--primary btn--lg" href="/cua-hang">Vào cửa hàng ${icon('arrow', { size: 18 })}</a>
      <a class="btn btn--ghost btn--lg" href="/lien-he#dat-lich">Đặt lịch nghe thử tại showroom</a>
    </div>
    <form class="pill-form reveal" data-newsletter novalidate>
      <label class="sr-only" for="nl-cta">Email nhận tin</label>
      <input id="nl-cta" type="email" name="email" placeholder="Nhận tin về bộ sưu tập mới" autocomplete="email" required>
      <button class="btn btn--primary" type="submit">Đăng ký</button>
      <p class="form-msg" aria-live="polite"></p>
    </form>
  </div>
</section>

<section class="section--tight" aria-label="Cam kết của Alokio">
  <div class="container promise">
    <div class="reveal">${icon('shield', { size: 26 })}<span>Bảo hành Luxe 24 tháng</span></div>
    <div class="reveal">${icon('truck', { size: 26 })}<span>Giao hoả tốc 2 giờ</span></div>
    <div class="reveal">${icon('refresh', { size: 26 })}<span>Đổi trả trong 30 ngày</span></div>
    <div class="reveal">${icon('card', { size: 26 })}<span>Trả góp 0%</span></div>
  </div>
</section>`;

  return layout(ctx, {
    title: '', page: 'home', body, scripts: ['/js/home.js'],
    description: 'Alokio – Âm Thanh Việt. Bộ sưu tập loa bluetooth cao cấp Alokio Luxe (sơn mài, khảm trai, nhôm champagne) và loa kéo karaoke chính hãng. Trải nghiệm 3D, thanh toán QR động.',
    preload: [{ href: '/img/hero-poster.webp', as: 'image', fetchpriority: 'high' }],
    ogImage: '/img/og/og-default.webp',
  });
}
