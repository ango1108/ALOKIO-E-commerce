// Template HTML an toàn: mọi giá trị chèn vào đều được escape, trừ khi đã là Safe.
export class Safe {
  constructor(s) { this.s = s; }
  toString() { return this.s; }
}
export const raw = (s) => new Safe(String(s ?? ''));

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function render(v) {
  if (v == null || v === false) return '';
  if (v instanceof Safe) return v.s;
  if (Array.isArray(v)) return v.map(render).join('');
  return esc(v);
}

export function html(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i++) out += render(values[i]) + strings[i + 1];
  return new Safe(out);
}

export const fmt = (n) => new Intl.NumberFormat('vi-VN').format(Math.round(n || 0)) + ' ₫';
export const fmtDate = (t) => new Date(t).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
export const fmtDateTime = (t) => new Date(t).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });

export function stars(n) {
  const full = Math.round(n);
  return html`<span class="stars" role="img" aria-label="${n} trên 5 sao">${'★'.repeat(full)}<span class="stars__off">${'★'.repeat(5 - full)}</span></span>`;
}

// Markdown tối giản cho blog
export function md(text) {
  const blocks = String(text).trim().split(/\n{2,}/);
  return raw(blocks.map((b) => {
    if (b.startsWith('## ')) {
      const t = b.slice(3).trim();
      const id = slugify(t);
      return `<h2 id="${id}">${esc(t)}</h2>`;
    }
    if (/^- /m.test(b) && b.split('\n').every((l) => l.startsWith('- '))) {
      return '<ul>' + b.split('\n').map((l) => `<li>${esc(l.slice(2))}</li>`).join('') + '</ul>';
    }
    return `<p>${esc(b).replace(/\n/g, '<br>')}</p>`;
  }).join('\n'));
}

export function headings(text) {
  return String(text).split('\n').filter((l) => l.startsWith('## ')).map((l) => ({ id: slugify(l.slice(3).trim()), title: l.slice(3).trim() }));
}

export function slugify(s) {
  return String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}
