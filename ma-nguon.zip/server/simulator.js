// Bộ mô phỏng đơn hàng: khi đang mở trang quản trị, cứ 20–50 giây lại có một đơn hàng giả
// "nhảy" vào (kèm tiếng ting). Chỉ một tab admin chạy bộ mô phỏng tại một thời điểm.
import { db } from './db.js';
import { createOrder, setPaymentStatus } from './services.js';
import { makeName, makePhone, makeAddress } from './seed/index.js';
import { WARDS } from './seed/places.js';

let timer = null;

export function startSimulator() {
  stopSimulator();
  const s = db().settings.simulator;
  if (!s.enabled || !globalThis.__alkSimLeader) return;
  const delay = (s.minSec + Math.random() * Math.max(0, s.maxSec - s.minSec)) * 1000;
  timer = setTimeout(() => { try { simulateOrder(); } catch (e) { console.error('[sim]', e); } startSimulator(); }, delay);
}

export function stopSimulator() {
  clearTimeout(timer);
  timer = null;
}

export function simulateOrder() {
  const st = db();
  const r = Math.random;
  const pool = st.products.filter((p) => !p.hidden && p.category !== 'phu-kien' && Object.values(p.stock).some((v) => v > 1));
  if (!pool.length) return null;
  const luxe = pool.filter((p) => p.line === 'luxe');
  const main = (r() < 0.7 && luxe.length ? luxe : pool)[Math.floor(r() * (r() < 0.7 && luxe.length ? luxe.length : pool.length))] || pool[0];
  const finish = main.finishes.find((f) => main.stock[f] > 1) || main.finishes[0];
  const name = makeName(r);
  const address = makeAddress(r);
  if (!WARDS[address.province]) address.ward = address.ward || 'Phường Trung Tâm';
  const methods = st.settings.payments;
  const choices = ['wallet', 'vietqr', 'cod', 'card'].filter((m) => methods[m]);
  const method = choices[Math.floor(r() * choices.length)] || 'cod';
  const res = createOrder({
    items: [{ productId: main.id, finish, qty: 1, options: {} }],
    contact: { name, phone: makePhone(r), email: '' },
    address: { name, phone: '', province: address.province, ward: address.ward, street: address.street },
    shippingMethod: r() < 0.2 ? 'express' : 'standard',
    payment: { method, wallet: method === 'wallet' ? methods.wallets[Math.floor(r() * methods.wallets.length)] : null },
    source: 'sim',
  });
  if (res.payment && r() < 0.85) {
    setTimeout(() => { try { setPaymentStatus(res.payment, 'paid', 'Bộ mô phỏng'); } catch { /* noop */ } }, 4000 + r() * 8000);
  }
  return res.order;
}
