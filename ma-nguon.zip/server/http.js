// Router tối giản + các hàm trả kết quả. Ở bản HTML tĩnh, "máy chủ" chạy ngay trong trình duyệt:
// mỗi yêu cầu là một object { status, headers, body } thay cho phản hồi HTTP thật.
export class Router {
  constructor() { this.routes = []; }
  add(method, pattern, handler) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/\/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '/([^/]+)'; }) + '/?$');
    this.routes.push({ method, re, keys, handler });
  }
  get(p, h) { this.add('GET', p, h); }
  post(p, h) { this.add('POST', p, h); }
  put(p, h) { this.add('PUT', p, h); }
  del(p, h) { this.add('DELETE', p, h); }
  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method !== method && !(method === 'HEAD' && r.method === 'GET')) continue;
      const m = r.re.exec(pathname);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
        return { handler: r.handler, params };
      }
    }
    return null;
  }
}

export function send(req, res, status, body, type = 'text/html; charset=utf-8', extra = {}) {
  res.status = status;
  res.type = type;
  res.body = String(body);
  Object.assign(res.headers, extra);
}

export function json(req, res, status, data, extra = {}) {
  send(req, res, status, JSON.stringify(data), 'application/json; charset=utf-8', extra);
}

export function redirect(res, to, cookies = []) {
  res.status = 303;
  res.headers.Location = to;
  if (cookies.length) res.headers['Set-Cookie'] = cookies;
}

export async function readBody(req) {
  return req.body && typeof req.body === 'object' ? req.body : {};
}
