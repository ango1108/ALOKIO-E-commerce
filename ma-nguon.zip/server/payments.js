// Thanh toán sandbox.
// 1) VietQR động: tự dựng chuỗi chuẩn EMVCo/NAPAS (TLV + CRC16-CCITT).
// 2) Phiên thanh toán ví điện tử: id ngẫu nhiên + chữ ký HMAC + hạn dùng.
//    QR chứa đường dẫn tới trang sandbox (sandbox.html) của chính website.
import { sign, randomHex } from './auth.js';

// ---------- CRC16-CCITT (False): poly 0x1021, init 0xFFFF ----------
export function crc16(str) {
  let crc = 0xffff;
  const bytes = new TextEncoder().encode(str);
  for (const b of bytes) {
    crc ^= b << 8;
    for (let i = 0; i < 8; i++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

const tlv = (id, value) => `${id}${String(value.length).padStart(2, '0')}${value}`;

// Bỏ dấu tiếng Việt cho nội dung chuyển khoản (app ngân hàng chỉ nhận ASCII)
export function asciiFold(s) {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').replace(/[^A-Za-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
}

/**
 * Dựng payload VietQR động.
 * @param {{bin:string, account:string, amount:number, content:string}} p
 */
export function buildVietQR({ bin, account, amount, content }) {
  const beneficiary = tlv('00', bin) + tlv('01', account);
  const merchant = tlv('00', 'A000000727') + tlv('01', beneficiary) + tlv('02', 'QRIBFTTA');
  const addl = tlv('08', asciiFold(content).slice(0, 50));
  let s = '';
  s += tlv('00', '01'); // Payload format
  s += tlv('01', '12'); // 12 = QR động (dùng 1 lần, có số tiền)
  s += tlv('38', merchant);
  s += tlv('53', '704'); // VND
  s += tlv('54', String(Math.round(amount)));
  s += tlv('58', 'VN');
  s += tlv('62', addl);
  s += '6304';
  return s + crc16(s);
}

// Đọc lại TLV (dùng cho kiểm thử)
export function parseTLV(s) {
  const out = {};
  let i = 0;
  while (i < s.length) {
    const id = s.slice(i, i + 2);
    const len = Number(s.slice(i + 2, i + 4));
    out[id] = s.slice(i + 4, i + 4 + len);
    i += 4 + len;
  }
  return out;
}

export function newPaymentId() {
  return 'PAY' + randomHex(6).toUpperCase();
}

export function paymentSig(id, amount) {
  return sign(`pay:${id}:${amount}`).slice(0, 16);
}

export function lanAddress() {
  return null; // bản tĩnh không có máy chủ LAN
}

// Luhn cho thẻ (sandbox)
export function luhn(num) {
  const d = String(num).replace(/\D/g, '');
  if (d.length < 12) return false;
  let sum = 0;
  let alt = false;
  for (let i = d.length - 1; i >= 0; i--) {
    let n = Number(d[i]);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    alt = !alt;
  }
  return sum % 10 === 0;
}

export const TEST_CARDS = {
  '4111111111111111': { ok: true, brand: 'Visa', type: 'intl' },
  '5555555555554444': { ok: true, brand: 'Mastercard', type: 'intl' },
  '4000000000000002': { ok: false, brand: 'Visa', type: 'intl', reason: 'Thẻ bị ngân hàng phát hành từ chối (thẻ thử nghiệm).' },
  '9704000000000018': { ok: true, brand: 'NAPAS', type: 'domestic' },
};

export const WALLETS = [
  { id: 'momo', name: 'MoMo' },
  { id: 'zalopay', name: 'ZaloPay' },
  { id: 'shopeepay', name: 'ShopeePay' },
  { id: 'vnpay', name: 'VNPAY-QR' },
  { id: 'viettelmoney', name: 'Viettel Money' },
];
