// Kênh sự kiện "realtime" giả lập trong trình duyệt.
// publish() → gửi tới các trang đang mở trong tab hiện tại và (qua localStorage) tới các tab khác.
const EVT_KEY = 'alokio:evt';
const PRES_KEY = 'alokio:presence';
const listeners = new Set();
let seq = 0;

export function publish(type, data = {}) {
  const evt = { id: Date.now() * 1000 + (++seq % 1000), type, data, at: Date.now() };
  deliver(evt);
  try { localStorage.setItem(EVT_KEY, JSON.stringify(evt)); } catch { /* noop */ }
}

function deliver(evt) { for (const fn of listeners) { try { fn(evt); } catch (e) { console.error(e); } } }

export function onEvent(fn) { listeners.add(fn); return () => listeners.delete(fn); }

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key !== EVT_KEY || !e.newValue) return;
    try { deliver(JSON.parse(e.newValue)); } catch { /* noop */ }
  });
}

// Đếm số tab đang mở (mỗi tab tự báo danh 10 giây/lần)
export function presence() {
  let list = {};
  try { list = JSON.parse(localStorage.getItem(PRES_KEY) || '{}'); } catch { /* noop */ }
  const now = Date.now();
  const pages = {};
  let shop = 0, admins = 0;
  for (const v of Object.values(list)) {
    if (now - v.t > 25000) continue;
    if (v.scope === 'admin') { admins++; continue; }
    shop++;
    if (v.page) pages[v.page] = (pages[v.page] || 0) + 1;
  }
  return { online: Math.max(1, shop), admins, pages };
}

export function heartbeat(id, info) {
  let list = {};
  try { list = JSON.parse(localStorage.getItem(PRES_KEY) || '{}'); } catch { /* noop */ }
  const now = Date.now();
  for (const [k, v] of Object.entries(list)) if (now - v.t > 25000) delete list[k];
  if (info) list[id] = { ...info, t: now }; else delete list[id];
  try { localStorage.setItem(PRES_KEY, JSON.stringify(list)); } catch { /* noop */ }
}

export function attach() { /* không dùng ở bản tĩnh */ }
