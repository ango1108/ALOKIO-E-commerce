// Nghiệp vụ: tạo đơn, cập nhật trạng thái, phiên thanh toán. Mọi thay đổi đều phát sự kiện realtime.
import { db, save } from './db.js';
import { publish } from './bus.js';
import { priceCart, orderCode, canTransition, STATUS_LABEL, activeFlash, fmt, maskName } from './commerce.js';
import { newPaymentId, paymentSig } from './payments.js';
import { PROVINCES } from './seed/places.js';

export function log(user, action) {
  const s = db();
  s.activity.unshift({ at: Date.now(), user: user || 'Hệ thống', action });
  s.activity.length = Math.min(s.activity.length, 400);
}

export function publicOrder(o) {
  return {
    code: o.code, createdAt: o.createdAt, status: o.status, statusLabel: STATUS_LABEL[o.status],
    total: o.total, items: o.items.map((i) => ({ name: i.name, qty: i.qty, finish: i.finish })),
    province: o.address.provinceName, name: maskName(o.contact.name),
  };
}

/**
 * Tạo đơn hàng. input = { items, contact, address, shippingMethod, coupon, payment:{method, wallet, deposit}, note, customerId, source }
 */
export function createOrder(input) {
  const s = db();
  const priced = priceCart(s, input.items, { coupon: input.coupon, shipping: input.shippingMethod, deposit: input.payment?.deposit });
  if (!priced.lines.length) return { error: 'Giỏ hàng trống.' };
  const stockErr = priced.errors.find((e) => e.includes('chỉ còn'));
  if (stockErr) return { error: stockErr };
  const method = input.payment?.method || 'cod';
  if (!s.settings.payments[method]) return { error: 'Phương thức thanh toán đang tạm tắt.' };
  if (method === 'wallet' && !s.settings.payments.wallets.includes(input.payment.wallet)) return { error: 'Vui lòng chọn ví điện tử.' };
  const prov = PROVINCES.find((p) => p.code === input.address.province);
  if (!prov) return { error: 'Tỉnh/thành không hợp lệ.' };

  let code;
  do { code = orderCode(); } while (s.orders.some((o) => o.code === code));
  const now = Date.now();
  const deposit = method === 'cod' && input.payment?.deposit && priced.total >= s.settings.payments.depositMin;
  const order = {
    code, createdAt: now, updatedAt: now, source: input.source || 'web', customerId: input.customerId || null,
    contact: input.contact, address: { ...input.address, provinceName: prov.name },
    items: priced.lines.map(({ stock, ...l }) => l),
    subtotal: priced.subtotal, discount: priced.discount, shippingFee: priced.shipping, total: priced.total,
    coupon: priced.coupon, shippingMethod: input.shippingMethod || 'standard',
    payment: {
      method, wallet: input.payment?.wallet || null, status: method === 'cod' ? (deposit ? 'pending' : 'cod') : 'pending',
      deposit: deposit ? priced.depositAmount : 0, installment: input.payment?.installment || null, paidAt: null,
    },
    status: 'pending', timeline: [{ status: 'pending', at: now, note: 'Đơn hàng được tạo' }], note: input.note || '', internalNotes: [],
  };
  // Trừ tồn kho, cập nhật flash sale & mã giảm giá
  for (const l of order.items) {
    const p = s.products.find((x) => x.id === l.productId);
    p.stock[l.finish] = Math.max(0, (p.stock[l.finish] || 0) - l.qty);
    p.sold += l.qty;
    const fl = activeFlash(s, p.id);
    if (fl && l.flash) fl.item.sold = Math.min(fl.item.quota, fl.item.sold + l.qty);
    publish('stock.changed', { productId: p.id, stock: p.stock, sold: p.sold });
    if (Object.values(p.stock).some((v) => v <= 3)) publish('admin.lowstock', { productId: p.id, name: p.name, stock: p.stock });
  }
  if (order.coupon) { const c = s.coupons.find((x) => x.code === order.coupon); if (c) c.used++; }
  s.orders.unshift(order);

  let payment = null;
  if (method !== 'cod' || deposit) payment = createPaymentSession(order, deposit ? 'deposit' : method);
  // Khách hàng
  if (!order.customerId) {
    let c = s.customers.find((x) => x.phone === order.contact.phone);
    if (!c) {
      c = { id: 'c-' + now.toString(36), name: order.contact.name, phone: order.contact.phone, email: order.contact.email || '', pass: null, addresses: [{ id: 'a1', ...order.address, default: true }], createdAt: now, note: '', wishlist: [] };
      s.customers.push(c);
    }
    order.customerId = c.id;
  }
  log(order.source === 'sim' ? 'Bộ mô phỏng' : 'Khách hàng', `Tạo đơn ${code} · ${fmt(order.total)}`);
  save();
  publish('order.created', { order: publicOrder(order), full: adminOrderSummary(order), lat: prov.lat, lon: prov.lon });
  publish('admin.order.created', { code, total: order.total, name: order.contact.name, province: prov.name, source: order.source });
  return { order, payment };
}

export function adminOrderSummary(o) {
  return { code: o.code, createdAt: o.createdAt, status: o.status, total: o.total, name: o.contact.name, phone: o.contact.phone, province: o.address.provinceName, method: o.payment.method, payStatus: o.payment.status, items: o.items.length, source: o.source };
}

export function createPaymentSession(order, method) {
  const s = db();
  const amount = method === 'deposit' ? order.payment.deposit : order.total;
  const id = newPaymentId();
  const now = Date.now();
  const pay = {
    id, orderCode: order.code, method, wallet: order.payment.wallet, amount, status: 'pending',
    createdAt: now, updatedAt: now, expiresAt: now + s.settings.payments.qrMinutes * 60000, sig: paymentSig(id, amount),
  };
  s.payments.unshift(pay);
  order.payment.sessionId = id;
  save();
  publish('payment.updated', paymentPublic(pay));
  return pay;
}

export function paymentPublic(p) {
  return { id: p.id, orderCode: p.orderCode, method: p.method, wallet: p.wallet, amount: p.amount, status: p.status, expiresAt: p.expiresAt, updatedAt: p.updatedAt };
}

export function setPaymentStatus(pay, status, by = 'Sandbox') {
  const s = db();
  const order = s.orders.find((o) => o.code === pay.orderCode);
  if (!order) return { error: 'Không tìm thấy đơn hàng.' };
  if (['paid', 'refunded'].includes(pay.status) && status !== 'refunded') return { error: 'Phiên thanh toán đã hoàn tất.' };
  if (status === 'paid' && Date.now() > pay.expiresAt) { pay.status = 'expired'; save(); publish('payment.updated', paymentPublic(pay)); return { error: 'Mã QR đã hết hạn.' }; }
  pay.status = status;
  pay.updatedAt = Date.now();
  if (status === 'paid') {
    order.payment.status = pay.method === 'deposit' ? 'deposit' : 'paid';
    order.payment.paidAt = Date.now();
    if (order.status === 'pending') {
      order.status = 'confirmed';
      order.timeline.push({ status: 'confirmed', at: Date.now(), note: pay.method === 'deposit' ? 'Đã nhận tiền đặt cọc' : 'Đã thanh toán' });
    }
  } else if (status === 'failed') order.payment.status = 'failed';
  else if (status === 'refunded') order.payment.status = 'refunded';
  order.updatedAt = Date.now();
  log(by, `Thanh toán ${pay.id} (${order.code}) → ${status}`);
  save();
  publish('payment.updated', paymentPublic(pay));
  publish('order.updated', { order: publicOrder(order), full: adminOrderSummary(order) });
  if (status === 'paid') publish('admin.payment.paid', { code: order.code, amount: pay.amount, method: pay.method, wallet: pay.wallet });
  return { ok: true };
}

export function updateOrderStatus(code, to, by, note = '') {
  const s = db();
  const o = s.orders.find((x) => x.code === code);
  if (!o) return { error: 'Không tìm thấy đơn hàng.' };
  if (o.status === to) return { ok: true, order: o };
  if (!canTransition(o.status, to)) return { error: `Không thể chuyển từ "${STATUS_LABEL[o.status]}" sang "${STATUS_LABEL[to]}".` };
  o.status = to;
  o.updatedAt = Date.now();
  o.timeline.push({ status: to, at: Date.now(), note });
  if (to === 'completed' && o.payment.method === 'cod') o.payment.status = 'paid';
  if (to === 'cancelled') {
    for (const l of o.items) { const p = s.products.find((x) => x.id === l.productId); if (p) { p.stock[l.finish] = (p.stock[l.finish] || 0) + l.qty; p.sold = Math.max(0, p.sold - l.qty); publish('stock.changed', { productId: p.id, stock: p.stock, sold: p.sold }); } }
    if (o.payment.status === 'paid') o.payment.status = 'refunded';
  }
  log(by, `Đơn ${code}: ${STATUS_LABEL[to]}${note ? ' · ' + note : ''}`);
  save();
  publish('order.updated', { order: publicOrder(o), full: adminOrderSummary(o) });
  return { ok: true, order: o };
}

// Hết hạn các phiên QR cũ
export function sweepExpired() {
  const s = db();
  const now = Date.now();
  for (const p of s.payments) {
    if ((p.status === 'pending' || p.status === 'scanned') && now > p.expiresAt) {
      p.status = 'expired'; p.updatedAt = now;
      publish('payment.updated', paymentPublic(p));
    }
  }
}
