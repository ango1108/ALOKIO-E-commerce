// Kho dữ liệu giả lập lưu trong localStorage của trình duyệt (thay cho database).
// - Toàn bộ dữ liệu là một object JSON, lưu dưới khoá "alokio:db".
// - Mở nhiều tab cùng lúc: tab nào ghi thì các tab khác tự nạp lại (sự kiện "storage").
// - Xoá dữ liệu trình duyệt hoặc bấm "Khôi phục dữ liệu demo" trong admin → tạo lại dữ liệu mẫu.
export const SCHEMA_VERSION = 6;
const KEY = 'alokio:db';

let state = null;
let stale = false;
let pending = false;

function read() {
  try {
    const raw = localStorage.getItem(KEY);
    const s = raw ? JSON.parse(raw) : null;
    return s && s.version === SCHEMA_VERSION ? s : null;
  } catch { return null; }
}

function write() {
  pending = false;
  try { localStorage.setItem(KEY, JSON.stringify(state)); }
  catch (e) { console.warn('[alokio] Bộ nhớ trình duyệt đầy, không lưu được dữ liệu.', e); }
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => { if (e.key === KEY || e.key === null) stale = true; });
}

export function load(seedFn) {
  state = read();
  if (!state) { state = seedFn(); state.version = SCHEMA_VERSION; write(); }
  return state;
}

export function db() {
  if (stale) { stale = false; const s = read(); if (s) state = s; }
  return state;
}

// Gom các lần ghi trong cùng một thao tác rồi ghi một lần.
export function save() {
  if (pending) return;
  pending = true;
  queueMicrotask(write);
}

export function flushSync() { write(); }

export function reset(seedFn) {
  state = seedFn();
  state.version = SCHEMA_VERSION;
  write();
  return state;
}

export function dataDir() { return ''; }
