// 34 đơn vị hành chính cấp tỉnh (từ 01/7/2025: 28 tỉnh + 6 thành phố), mô hình 2 cấp tỉnh – xã.
// Toạ độ là toạ độ gần đúng của trung tâm hành chính (dùng cho bản đồ minh hoạ trong admin).
export const PROVINCES = [
  { code: 'HNI', name: 'Hà Nội', city: true, lat: 21.03, lon: 105.85, w: 9 },
  { code: 'HPG', name: 'Hải Phòng', city: true, lat: 20.86, lon: 106.68, w: 4 },
  { code: 'HUE', name: 'Huế', city: true, lat: 16.46, lon: 107.59, w: 2 },
  { code: 'DNG', name: 'Đà Nẵng', city: true, lat: 16.05, lon: 108.2, w: 4 },
  { code: 'HCM', name: 'TP. Hồ Chí Minh', city: true, lat: 10.78, lon: 106.7, w: 12 },
  { code: 'CTO', name: 'Cần Thơ', city: true, lat: 10.03, lon: 105.78, w: 3 },
  { code: 'LCU', name: 'Lai Châu', lat: 22.4, lon: 103.45, w: 0.4 },
  { code: 'DBN', name: 'Điện Biên', lat: 21.39, lon: 103.02, w: 0.4 },
  { code: 'SLA', name: 'Sơn La', lat: 21.33, lon: 103.91, w: 0.6 },
  { code: 'LSN', name: 'Lạng Sơn', lat: 21.85, lon: 106.76, w: 0.6 },
  { code: 'CBG', name: 'Cao Bằng', lat: 22.67, lon: 106.26, w: 0.4 },
  { code: 'QNH', name: 'Quảng Ninh', lat: 20.95, lon: 107.08, w: 1.5 },
  { code: 'THA', name: 'Thanh Hoá', lat: 19.8, lon: 105.77, w: 1.8 },
  { code: 'NAN', name: 'Nghệ An', lat: 18.68, lon: 105.68, w: 1.8 },
  { code: 'HTH', name: 'Hà Tĩnh', lat: 18.34, lon: 105.9, w: 0.8 },
  { code: 'TQG', name: 'Tuyên Quang', lat: 21.82, lon: 105.21, w: 0.6 },
  { code: 'LCI', name: 'Lào Cai', lat: 22.48, lon: 103.97, w: 0.7 },
  { code: 'TNN', name: 'Thái Nguyên', lat: 21.59, lon: 105.85, w: 1 },
  { code: 'PTO', name: 'Phú Thọ', lat: 21.32, lon: 105.4, w: 1.2 },
  { code: 'BNH', name: 'Bắc Ninh', lat: 21.19, lon: 106.07, w: 1.6 },
  { code: 'HYN', name: 'Hưng Yên', lat: 20.65, lon: 106.05, w: 1.2 },
  { code: 'NBH', name: 'Ninh Bình', lat: 20.25, lon: 105.97, w: 1.2 },
  { code: 'QTI', name: 'Quảng Trị', lat: 16.75, lon: 107.19, w: 0.7 },
  { code: 'QNI', name: 'Quảng Ngãi', lat: 15.12, lon: 108.8, w: 0.9 },
  { code: 'GLA', name: 'Gia Lai', lat: 13.98, lon: 108.0, w: 0.9 },
  { code: 'KHA', name: 'Khánh Hoà', lat: 12.24, lon: 109.19, w: 1.4 },
  { code: 'LDG', name: 'Lâm Đồng', lat: 11.94, lon: 108.44, w: 1.3 },
  { code: 'DLK', name: 'Đắk Lắk', lat: 12.67, lon: 108.04, w: 0.9 },
  { code: 'DNI', name: 'Đồng Nai', lat: 10.95, lon: 106.82, w: 2.2 },
  { code: 'TNH', name: 'Tây Ninh', lat: 11.31, lon: 106.1, w: 1 },
  { code: 'VLG', name: 'Vĩnh Long', lat: 10.25, lon: 105.97, w: 1 },
  { code: 'DTP', name: 'Đồng Tháp', lat: 10.46, lon: 105.63, w: 1 },
  { code: 'CMU', name: 'Cà Mau', lat: 9.18, lon: 105.15, w: 0.7 },
  { code: 'AGG', name: 'An Giang', lat: 10.38, lon: 105.43, w: 1 },
];

// Phường/xã mẫu (tên minh hoạ) cho các thành phố lớn; tỉnh khác người dùng nhập tay.
export const WARDS = {
  HNI: ['Phường Hoàn Kiếm', 'Phường Ba Đình', 'Phường Tây Hồ', 'Phường Cầu Giấy', 'Phường Đống Đa', 'Phường Hai Bà Trưng', 'Phường Long Biên', 'Xã Gia Lâm'],
  HCM: ['Phường Sài Gòn', 'Phường Bến Thành', 'Phường Tân Định', 'Phường Thảo Điền', 'Phường An Khánh', 'Phường Bình Thạnh', 'Phường Phú Nhuận', 'Xã Củ Chi'],
  DNG: ['Phường Hải Châu', 'Phường Thanh Khê', 'Phường Sơn Trà', 'Phường Ngũ Hành Sơn', 'Phường Liên Chiểu', 'Phường Cẩm Lệ'],
  CTO: ['Phường Ninh Kiều', 'Phường Cái Khế', 'Phường Bình Thủy', 'Phường Cái Răng'],
};

// Đường viền Việt Nam giản lược (lon, lat) để vẽ bản đồ minh hoạ dạng lưới điểm.
export const VN_OUTLINE = [
  [102.14, 22.4], [102.6, 22.75], [103.3, 22.8], [104.0, 22.52], [104.8, 22.85], [105.5, 23.2], [106.2, 22.98], [106.7, 22.85],
  [106.6, 22.4], [107.35, 21.6], [108.0, 21.55], [107.6, 21.25], [107.0, 20.9], [106.6, 20.4], [106.1, 19.95], [105.85, 19.5],
  [105.7, 18.9], [106.4, 18.2], [106.6, 17.6], [107.2, 16.9], [108.0, 16.3], [108.45, 15.6], [108.9, 15.1], [109.2, 14.0],
  [109.3, 13.2], [109.2, 12.3], [109.25, 11.7], [108.8, 11.15], [108.2, 10.9], [107.5, 10.5], [106.75, 10.4], [106.6, 9.8],
  [106.0, 9.3], [105.2, 8.6], [104.75, 8.75], [104.85, 9.5], [104.9, 10.2], [104.5, 10.45], [105.1, 10.9], [106.1, 11.2],
  [106.4, 11.7], [107.4, 12.2], [107.55, 12.9], [107.5, 13.8], [107.4, 14.6], [107.55, 15.4], [107.25, 15.9], [106.6, 16.4],
  [106.3, 17.0], [105.6, 17.9], [105.1, 18.4], [104.5, 18.9], [103.9, 19.3], [104.1, 19.7], [104.6, 20.0], [104.4, 20.4],
  [103.75, 20.7], [103.3, 20.8], [102.9, 21.3], [102.6, 21.6], [102.2, 21.9],
];
