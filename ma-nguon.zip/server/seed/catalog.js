// Dữ liệu sản phẩm mẫu.
// - line "luxe": dòng Alokio Luxe — sản phẩm Ý TƯỞNG của đồ án (isConcept: true).
//   Thông số bám theo các mẫu loa bluetooth cao cấp thật cùng phân khúc (2022–2025).
// - line "karaoke": các mẫu loa kéo THẬT của Alokio, thông số/giá tổng hợp từ đại lý
//   (chủ yếu đời 2018–2020) → needsVerify: true, chủ shop cập nhật lại trong admin.

export const FINISHES = {
  'ngoc-trai': { id: 'ngoc-trai', name: 'Ngọc Trai', hex: '#EFE7DA', note: 'Sơn mài ngà, viền khảm trai' },
  'suong-som': { id: 'suong-som', name: 'Sương Sớm', hex: '#BCD3EA', note: 'Sơn mài xanh pastel' },
  huyen: { id: 'huyen', name: 'Huyền', hex: '#141A24', note: 'Sơn mài đen ánh xanh' },
  'oc-cho': { id: 'oc-cho', name: 'Óc Chó', hex: '#6A4630', note: 'Gỗ óc chó phủ dầu' },
  'go-den': { id: 'go-den', name: 'Gỗ sơn đen', hex: '#1C1C1E', note: 'Thùng gỗ sơn chống trầy' },
};

export const KNOBS = [
  { id: 'champagne', name: 'Champagne', hex: '#C9B48A' },
  { id: 'bac', name: 'Bạc satin', hex: '#C8CCD2' },
];
export const STRAPS = [
  { id: 'bo', name: 'Da bò nâu', hex: '#8A5A3B' },
  { id: 'kem', name: 'Da kem', hex: '#E6D7BF' },
  { id: 'den', name: 'Da đen', hex: '#22201F' },
];

export const CATEGORIES = [
  { slug: 'loa-di-dong', name: 'Loa di động', desc: 'Loa bluetooth di động cao cấp: chống nước IP67, pin dài, âm thanh stereo 360° trong thân sơn mài và khảm trai.' },
  { slug: 'loa-nghe-tai-gia', name: 'Loa nghe tại gia', desc: 'Loa bluetooth tại gia với núm vặn analog champagne, mặt vải lanh và âm thanh lấp đầy căn phòng.' },
  { slug: 'loa-thong-minh', name: 'Loa thông minh', desc: 'Loa Wi-Fi thông minh: AirPlay 2, multiroom, ghép stereo, micro far-field.' },
  { slug: 'soundbar-rap-phim', name: 'Soundbar & rạp phim', desc: 'Soundbar Dolby Atmos và loa siêu trầm không dây cho rạp phim tại gia.' },
  { slug: 'loa-party-karaoke', name: 'Loa party & karaoke', desc: 'Loa kéo karaoke Alokio chính hãng và loa party cao cấp: bass 3–5 tấc, micro không dây, ắc quy.' },
  { slug: 'phu-kien', name: 'Phụ kiện', desc: 'Túi da, quai da, chân đế gỗ, micro, ắc quy và phụ kiện chính hãng.' },
];

export const COLLECTIONS = [
  { slug: 'alokio-luxe', name: 'Alokio Luxe', line: 'luxe', desc: 'Bộ sưu tập loa bluetooth cao cấp “Sang trọng kiểu Việt”: sơn mài, khảm trai, vải lanh và nhôm champagne. Dòng sản phẩm ý tưởng của đồ án.' },
  { slug: 'am-thanh-viet-karaoke', name: 'Âm Thanh Việt – Karaoke', line: 'karaoke', desc: 'Loa kéo karaoke chính hãng Alokio: thùng gỗ, bass 3–5 tấc, tích hợp ampli + ắc quy, kèm micro không dây.' },
];

const LUXE_WARRANTY = 'Bảo hành 24 tháng';
const LUXE_NOTE = 'Alokio Luxe là dòng sản phẩm ý tưởng trong khuôn khổ đồ án, chưa được Alokio bán ra.';

const luxe = (p) => ({
  line: 'luxe',
  isConcept: true,
  needsVerify: false,
  knobs: ['champagne', 'bac'],
  straps: null,
  engraving: true,
  warranty: LUXE_WARRANTY,
  note: LUXE_NOTE,
  links: null,
  ...p,
});

const KARAOKE_COMMON_SPECS = [
  ['Micro', '2 micro không dây UHF (sạc)'],
  ['Kết nối', 'Bluetooth (10–15 m), USB, thẻ SD, AUX'],
  ['Cổng', '2 jack micro + 1 jack guitar 6,5 mm, kết nối loa ngoài'],
  ['Thời lượng', '5–8 giờ'],
  ['Thời gian sạc', '3–7 giờ'],
  ['Nguồn', 'AC 220 V / ắc quy 12 V'],
  ['Điều khiển', 'Remote + núm vặn MIC, ECHO, BASS, TREBLE'],
  ['Bảo hành', 'Loa 12 tháng, ắc quy 6 tháng, phụ kiện không bảo hành'],
];

const karaoke = (p) => ({
  line: 'karaoke',
  isConcept: false,
  needsVerify: true,
  knobs: null,
  straps: null,
  engraving: false,
  finishes: ['go-den'],
  warranty: 'Bảo hành loa 12 tháng',
  note: 'Thông số và giá tham khảo từ đại lý, có thể đã thay đổi — vui lòng xem giá mới nhất tại kênh chính thức.',
  links: 'official',
  category: 'loa-party-karaoke',
  ...p,
});

export const PRODUCTS = [
  // ===================== ALOKIO LUXE · DI ĐỘNG =====================
  luxe({
    id: 'p-giot', slug: 'alokio-luxe-giot', name: 'Alokio Luxe Giọt', category: 'loa-di-dong',
    tagline: 'Một giọt âm thanh, vừa trong lòng bàn tay.',
    price: 2490000, finishes: ['ngoc-trai', 'suong-som', 'huyen'], straps: ['bo', 'kem', 'den'],
    model: { type: 'pebble' }, weightKg: 0.36, featured: true,
    highlights: ['10 W · 75 Hz–20 kHz', 'IP67 · nổi trên nước', 'Pin 18+ giờ'],
    specs: [
      ['Loa', '1 driver toàn dải 2" + 2 màng cộng hưởng thụ động'], ['Công suất', '10 W'], ['Dải tần', '75 Hz – 20 kHz'],
      ['Kết nối', 'Bluetooth 5.3 LE, Auracast, multipoint'], ['Chống nước', 'IP67 (ngâm 1 m / 30 phút)'],
      ['Pin', '18+ giờ · sạc nhanh 20 phút = 5 giờ · sạc đầy 2,5 giờ'], ['Micro', 'Có, đàm thoại rảnh tay'],
      ['Kích thước', '100 × 100 × 44 mm'], ['Trọng lượng', '0,36 kg'], ['Chất liệu', 'Sơn mài, lưới nhôm hoạ tiết sóng, quai da thật'],
    ],
    inBox: ['Loa Alokio Luxe Giọt', 'Quai da thật', 'Cáp USB-C bọc dù', 'Hộp quà sơn mài mini'],
    description: [
      'Giọt là chiếc loa nhỏ nhất của Alokio Luxe, được tạo hình như một viên sỏi dưới đáy suối: dẹt, mềm, vừa khít trong lòng bàn tay. Mặt trước là lưới nhôm đục lỗ theo hoạ tiết sóng nước, viền sơn mài nhiều lớp óng như mặt hồ buổi sớm.',
      'Bên trong, driver toàn dải 2 inch kết hợp hai màng cộng hưởng thụ động cho tiếng bass chắc bất ngờ so với kích thước. Kết nối Bluetooth 5.3 LE, Auracast và multipoint giúp bạn ghép nhiều loa hoặc chuyển nhanh giữa điện thoại và máy tính.',
      'Chuẩn IP67 cùng phần đế nhẹ giúp Giọt nổi được trên mặt nước. Quai da thật có thể thay đổi màu theo phong cách của bạn.',
    ],
    faq: [['Giọt có nổi trên nước không?', 'Có. Giọt đạt IP67 và có khối lượng phân bố để nổi trên mặt nước (thiết kế ý tưởng).'], ['Có ghép đôi stereo được không?', 'Có, qua Auracast bạn có thể ghép hai chiếc Giọt hoặc nhiều loa Alokio Luxe.'], ['Sạc bằng gì?', 'Cổng USB-C, sạc nhanh 20 phút cho 5 giờ nghe.']],
  }),
  luxe({
    id: 'p-song', slug: 'alokio-luxe-song', name: 'Alokio Luxe Sóng', category: 'loa-di-dong',
    tagline: 'Stereo 360°, lan toả như con sóng.',
    price: 4290000, finishes: ['ngoc-trai', 'suong-som', 'huyen', 'oc-cho'],
    model: { type: 'wave' }, weightKg: 0.68, featured: true,
    highlights: ['Stereo 360°', 'Pin 32+ giờ', 'IP67'],
    specs: [
      ['Loa', '2 driver toàn dải 10 W + 2 màng cộng hưởng thụ động'], ['Âm thanh', 'Stereo 360°'], ['Kết nối', 'Bluetooth 5.3 LE, Auracast'],
      ['Chống nước', 'IP67'], ['Pin', '32+ giờ · sạc nhanh 20 phút = 6 giờ · sạc đầy 2 giờ'], ['Micro', 'Có'],
      ['Kích thước', '160 × 68 × 77 mm'], ['Trọng lượng', '0,68 kg'], ['Chất liệu', 'Lưới nhôm ôm 3 mặt, dải sơn mài trên đỉnh'],
    ],
    inBox: ['Loa Alokio Luxe Sóng', 'Cáp USB-C bọc dù', 'Túi vải lanh'],
    description: [
      'Sóng mang âm thanh stereo 360° vào một thân máy nhỏ gọn: lưới nhôm ôm trọn ba mặt, dải sơn mài chạy dọc trên đỉnh như vệt nắng trên mặt biển.',
      'Hai driver 10 W cùng hai màng cộng hưởng thụ động lan toả âm thanh đều quanh loa, phù hợp cho buổi dã ngoại hay góc làm việc. Pin hơn 32 giờ là đủ cho cả một chuyến đi cuối tuần.',
      'Chuẩn IP67 chống bụi, chống nước; bạn có thể mang Sóng ra bãi biển mà không phải lo lắng.',
    ],
    faq: [['Sóng có chống nước không?', 'Có, chuẩn IP67.'], ['Pin dùng được bao lâu?', 'Hơn 32 giờ ở mức âm lượng trung bình.'], ['Có ứng dụng điều khiển không?', 'Ứng dụng Alokio (ý tưởng) cho phép chỉnh EQ và ghép loa.']],
  }),
  luxe({
    id: 'p-halong', slug: 'alokio-luxe-ha-long', name: 'Alokio Luxe Hạ Long', category: 'loa-di-dong',
    tagline: 'Đủ đẹp để trưng bày, đủ bền để mang ra biển.',
    price: 7990000, finishes: ['ngoc-trai', 'suong-som', 'huyen'], straps: ['bo', 'kem', 'den'],
    model: { type: 'halong' }, weightKg: 1.8, featured: true, hero: true,
    highlights: ['80 W stereo 360°', 'Pin 30+ giờ, thay được', 'IP67 · nổi trên nước'],
    specs: [
      ['Loa', '2 woofer 3" + 2 tweeter 0,6"'], ['Công suất', '2 × 30 W + 2 × 10 W = 80 W'], ['Dải tần', '45 Hz – 20 kHz'],
      ['Âm thanh', 'Stereo 360°'], ['Kết nối', 'Bluetooth 5.3 LE, multipoint, AUX 3,5 mm'], ['Chống nước', 'IP67 · thiết kế nổi trên mặt nước'],
      ['Pin', '30+ giờ · pin thay được · sạc 20 phút = 5 giờ'], ['Tính năng', 'Sạc ngược cho điện thoại, micro đàm thoại'],
      ['Điều khiển', 'Núm đa hướng champagne viền khảm trai'], ['Kích thước', '230 × 98 × 110 mm'], ['Trọng lượng', '1,8 kg'],
    ],
    inBox: ['Loa Alokio Luxe Hạ Long', 'Quai da thật', 'Cáp USB-C bọc dù', 'Hộp quà sơn mài'],
    description: [
      'Hạ Long là biểu tượng của Alokio Luxe: thân máy phủ sơn mài nhiều lớp, mặt trước vải lanh dệt kim, khung nhôm phay champagne và vòng khảm trai óng ánh quanh núm điều khiển. Mỗi góc nhìn lại cho một sắc trai khác nhau, như mặt vịnh đổi màu theo nắng.',
      'Bốn driver gồm hai woofer 3 inch và hai tweeter 0,6 inch, tổng công suất 80 W, tạo âm trường stereo 360° lấp đầy căn phòng hay cả một bãi cát. Pin hơn 30 giờ có thể thay được, giúp chiếc loa đi cùng bạn nhiều năm.',
      'Chuẩn IP67 và thiết kế nổi trên mặt nước (ý tưởng): bạn có thể thả Hạ Long trôi trên hồ bơi trong khi nhạc vẫn vang.',
    ],
    faq: [['Pin thay được nghĩa là sao?', 'Bạn có thể tự thay pin Hạ Long bằng pin chính hãng (phụ kiện L15) mà không cần mang đi bảo hành.'], ['Hạ Long có sạc cho điện thoại được không?', 'Có, qua cổng USB-C.'], ['Khắc tên được không?', 'Có, tuỳ chọn khắc tên trên tấm nhôm tại Atelier.']],
  }),
  // ===================== ALOKIO LUXE · TẠI GIA =====================
  luxe({
    id: 'p-hoian', slug: 'alokio-luxe-hoi-an', name: 'Alokio Luxe Hội An', category: 'loa-nghe-tai-gia',
    tagline: 'Ánh đèn lồng cho căn phòng nhỏ.',
    price: 6990000, finishes: ['ngoc-trai', 'suong-som', 'oc-cho'],
    model: { type: 'hifi', size: 's' }, weightKg: 2.85, featured: true,
    highlights: ['60 W · 45 Hz–20 kHz', 'Núm analog champagne', 'Bluetooth 5.3 + AUX'],
    specs: [
      ['Loa', '1 woofer 4" + 2 tweeter 0,75" xoè hai bên'], ['Công suất', '60 W'], ['Dải tần', '45 Hz – 20 kHz'], ['Áp suất âm tối đa', '95 dB SPL @ 1 m'],
      ['Kết nối', 'Bluetooth 5.3, AUX 3,5 mm'], ['Điều khiển', 'Núm VOLUME · BASS · TREBLE nhôm champagne'],
      ['Kích thước', '260 × 170 × 150 mm'], ['Trọng lượng', '2,85 kg'], ['Chất liệu', 'Mặt vải lanh, hông sơn mài hoặc gỗ óc chó'],
    ],
    inBox: ['Loa Alokio Luxe Hội An', 'Dây nguồn bọc vải', 'Sách hướng dẫn in trên giấy dó'],
    description: [
      'Hội An là chiếc loa tại gia nhỏ nhất của Alokio Luxe, dáng tủ hi-fi cổ điển thu gọn, đủ nhỏ để đặt trên kệ sách mà vẫn đủ ấm để lấp đầy phòng khách.',
      'Ba núm vặn analog bằng nhôm phay champagne cho phép chỉnh âm lượng, bass và treble bằng tay, từng nấc chắc chắn như núm của một chiếc máy ảnh cơ. Hai tweeter xoè sang hai bên mở rộng sân khấu âm thanh.',
      'Mặt vải lanh dệt kim, hai bên ốp sơn mài hoặc gỗ óc chó phủ dầu, tạo cảm giác như một món đồ nội thất hơn là một thiết bị điện tử.',
    ],
    faq: [['Có kết nối TV được không?', 'Hội An có cổng AUX 3,5 mm; nếu cần HDMI hãy chọn Tràng An.'], ['Có pin không?', 'Không, Hội An dùng nguồn điện.'], ['Ghép đôi stereo?', 'Có thể ghép 2 chiếc qua ứng dụng (ý tưởng).']],
  }),
  luxe({
    id: 'p-hue', slug: 'alokio-luxe-hue', name: 'Alokio Luxe Huế', category: 'loa-nghe-tai-gia',
    tagline: 'Trầm mặc, sâu lắng như sông Hương.',
    price: 9490000, finishes: ['ngoc-trai', 'huyen', 'oc-cho'],
    model: { type: 'hifi', size: 'm' }, weightKg: 4.3,
    highlights: ['80 W', 'RCA + AUX', 'Núm analog'],
    specs: [
      ['Loa', '1 woofer + 2 tweeter'], ['Công suất', '80 W'], ['Kết nối', 'Bluetooth 5.3, RCA, AUX 3,5 mm'],
      ['Điều khiển', 'Núm VOLUME · BASS · TREBLE · SOURCE'], ['Kích thước', '350 × 203 × 188 mm'], ['Trọng lượng', '4,3 kg'],
      ['Chất liệu', 'Mặt vải lanh, hông sơn mài'],
    ],
    inBox: ['Loa Alokio Luxe Huế', 'Dây nguồn bọc vải', 'Cáp RCA'],
    description: [
      'Huế là chiếc loa tại gia cỡ vừa: tiếng bass dày, trung âm ấm áp, cổng RCA để nối với mâm đĩa than hay đầu CD.',
      'Dải nhôm champagne trên đỉnh gồm bốn núm vặn và một công tắc gạt, giữ đúng tinh thần điều khiển bằng tay của dòng Luxe.',
      'Hông loa phủ sơn mài Huyền hoặc Ngọc Trai, mài thủ công qua nhiều lớp để có độ bóng sâu.',
    ],
    faq: [['Có nối được mâm đĩa than không?', 'Có, qua cổng RCA (mâm cần có pre-amp phono).'], ['Phù hợp phòng bao nhiêu m²?', 'Khoảng 15–30 m².'], ['Có Wi-Fi không?', 'Không, Huế dùng Bluetooth và cổng có dây.']],
  }),
  luxe({
    id: 'p-trangan', slug: 'alokio-luxe-trang-an', name: 'Alokio Luxe Tràng An', category: 'loa-nghe-tai-gia',
    tagline: 'Ba đường tiếng, một không gian rộng mở.',
    price: 13990000, finishes: ['huyen', 'oc-cho'],
    model: { type: 'hifi', size: 'l' }, weightKg: 7.45,
    highlights: ['150 W · 3 đường tiếng', '35 Hz–20 kHz', 'HDMI ARC cho TV'],
    specs: [
      ['Loa', '1 woofer 6" + 2 mid 2" + 2 tweeter 0,75"'], ['Công suất', '150 W'], ['Dải tần', '35 Hz – 20 kHz'],
      ['Kết nối', 'Bluetooth 5.3, HDMI ARC, RCA, AUX'], ['Kích thước', '400 × 317 × 203 mm'], ['Trọng lượng', '7,45 kg'],
      ['Chất liệu', 'Mặt vải lanh, hông gỗ óc chó hoặc sơn mài'],
    ],
    inBox: ['Loa Alokio Luxe Tràng An', 'Dây nguồn', 'Cáp HDMI'],
    description: [
      'Tràng An là chiếc loa tại gia lớn nhất: hệ ba đường tiếng với woofer 6 inch, hai loa mid và hai tweeter, công suất 150 W, đủ sức làm rung cả một phòng khách rộng.',
      'Cổng HDMI ARC biến Tràng An thành trung tâm âm thanh cho TV, còn cổng RCA dành cho những người yêu đĩa than.',
      'Hai bên ốp gỗ óc chó hoặc sơn mài Huyền, mặt trước vải lanh, dải nhôm champagne với năm núm vặn trên đỉnh.',
    ],
    faq: [['Dùng cho TV được không?', 'Có, qua HDMI ARC.'], ['Phòng bao nhiêu m² là hợp?', 'Từ 25 m² trở lên.'], ['Có điều khiển từ xa?', 'Dùng remote TV qua HDMI ARC hoặc ứng dụng (ý tưởng).']],
  }),
  // ===================== ALOKIO LUXE · THÔNG MINH & RẠP PHIM =====================
  luxe({
    id: 'p-hotay', slug: 'alokio-luxe-ho-tay', name: 'Alokio Luxe Hồ Tây', category: 'loa-thong-minh',
    tagline: 'Thông minh, tĩnh lặng như mặt hồ.',
    price: 7490000, finishes: ['ngoc-trai', 'suong-som'],
    model: { type: 'stone' }, weightKg: 2.0,
    highlights: ['Wi-Fi 6 · AirPlay 2', 'Multiroom', 'Micro far-field'],
    specs: [
      ['Loa', '2 tweeter 16 mm đặt chéo + 1 mid-woofer 90 mm'], ['Ampli', '3 ampli Class-D'], ['Dải tần', '45 Hz – 20 kHz'],
      ['Kết nối', 'Wi-Fi 6, Bluetooth, AirPlay 2, USB-C line-in'], ['Tính năng', 'Multiroom, ghép stereo, tự tinh chỉnh theo phòng'],
      ['Micro', 'Far-field + công tắc ngắt micro'], ['Kích thước', '183 × 120 × 131 mm'], ['Trọng lượng', '2,0 kg'],
    ],
    inBox: ['Loa Alokio Luxe Hồ Tây', 'Dây nguồn'],
    description: [
      'Hồ Tây là chiếc loa thông minh dáng hòn cuội, bọc vải lanh, với vòng cảm ứng nhôm champagne trên đỉnh: chạm để phát, xoay để chỉnh âm lượng.',
      'Wi-Fi 6, AirPlay 2 và multiroom cho phép phát cùng lúc ở nhiều phòng; ghép hai chiếc để có âm thanh stereo.',
      'Micro far-field nhận lệnh từ xa, kèm công tắc ngắt micro vật lý để bảo vệ sự riêng tư.',
    ],
    faq: [['Cần Wi-Fi không?', 'Cần Wi-Fi để dùng đầy đủ tính năng; Bluetooth vẫn hoạt động khi không có Wi-Fi.'], ['Có ghép với Sông Hương làm loa sau?', 'Có (ý tưởng).'], ['Có tắt micro được không?', 'Có công tắc vật lý.']],
  }),
  luxe({
    id: 'p-songhuong', slug: 'alokio-luxe-song-huong', name: 'Alokio Luxe Sông Hương', category: 'soundbar-rap-phim',
    tagline: 'Dòng sông âm thanh dưới màn hình.',
    price: 12490000, finishes: ['ngoc-trai', 'huyen'],
    model: { type: 'bar' }, weightKg: 2.8,
    highlights: ['Dolby Atmos (ảo hoá)', 'HDMI eARC', '5 ampli Class-D'],
    specs: [
      ['Loa', '1 tweeter trung tâm + 4 mid-woofer elip'], ['Ampli', '5 ampli Class-D'], ['Âm thanh', 'Dolby Atmos (ảo hoá)'],
      ['Kết nối', 'HDMI eARC, Wi-Fi, AirPlay 2'], ['Kích thước', '651 × 69 × 100 mm'], ['Trọng lượng', '2,8 kg'],
    ],
    inBox: ['Soundbar Alokio Luxe Sông Hương', 'Cáp HDMI', 'Dây nguồn'],
    description: [
      'Sông Hương là soundbar thon dài, lưới nhôm đục lỗ theo hoạ tiết sóng nước, đặt dưới TV như một nét kẻ tinh tế.',
      'Năm ampli Class-D và năm driver tạo âm trường Dolby Atmos ảo hoá, lời thoại rõ ràng, hiệu ứng lan toả khắp phòng.',
      'Kết hợp Sơn Đoòng để có tiếng bass sâu như hang động.',
    ],
    faq: [['Cần TV có cổng gì?', 'HDMI ARC/eARC.'], ['Có treo tường được không?', 'Có, dùng giá treo L14.'], ['Ghép loa siêu trầm?', 'Có, với Alokio Luxe Sơn Đoòng.']],
  }),
  luxe({
    id: 'p-sondoong', slug: 'alokio-luxe-son-doong', name: 'Alokio Luxe Sơn Đoòng', category: 'soundbar-rap-phim',
    tagline: 'Tiếng trầm sâu như hang động lớn nhất thế giới.',
    price: 9990000, finishes: ['ngoc-trai', 'huyen'],
    model: { type: 'cube' }, weightKg: 8.5,
    highlights: ['2 driver 6,5" triệt rung', 'Xuống ~30 Hz', 'Không dây'],
    specs: [
      ['Loa', '2 driver 6,5" đặt đối xứng triệt rung'], ['Dải tần thấp', '~30 Hz'], ['Kết nối', 'Wi-Fi với Sông Hương'],
      ['Kích thước', '300 × 300 × 300 mm'], ['Trọng lượng', '8,5 kg'], ['Chất liệu', 'Khối sơn mài nguyên khối'],
    ],
    inBox: ['Loa siêu trầm Alokio Luxe Sơn Đoòng', 'Dây nguồn'],
    description: [
      'Sơn Đoòng là khối lập phương sơn mài nguyên khối, bên trong hai driver 6,5 inch đặt đối xứng để triệt tiêu rung động: bass sâu nhưng thân loa không rung.',
      'Kết nối không dây với Sông Hương, đặt ở bất cứ đâu trong phòng.',
      'Bề mặt sơn mài mài tay phản chiếu ánh sáng như vách đá ướt trong hang.',
    ],
    faq: [['Dùng riêng được không?', 'Sơn Đoòng được thiết kế đi cùng Sông Hương.'], ['Có rung sàn không?', 'Driver đối xứng triệt rung nên thân loa gần như đứng yên.'], ['Cần dây tín hiệu?', 'Không, kết nối Wi-Fi.']],
  }),
  // ===================== ALOKIO LUXE · TIỆC =====================
  luxe({
    id: 'p-lehoi', slug: 'alokio-luxe-le-hoi', name: 'Alokio Luxe Lễ Hội', category: 'loa-party-karaoke',
    tagline: 'Bữa tiệc sang trọng, mang đi bằng một tay kéo.',
    price: 11990000, finishes: ['huyen', 'oc-cho'],
    model: { type: 'tower' }, weightKg: 16.5,
    highlights: ['240 W', 'Pin tháo rời 18 giờ', 'Vòng LED champagne'],
    specs: [
      ['Loa', '2 woofer 6,5" + 2 tweeter 1"'], ['Công suất', '240 W'], ['Dải tần', '40 Hz – 20 kHz'],
      ['Kết nối', 'Bluetooth 5.4, Auracast'], ['Pin', 'Tháo rời 68 Wh, tới 18 giờ, sạc 3 giờ'], ['Chống nước', 'IPX4'],
      ['Cổng', '2 cổng micro/guitar 6,35 mm'], ['Đèn', 'Vòng LED champagne chạy theo nhạc'], ['Trọng lượng', '16,5 kg'],
    ],
    inBox: ['Loa Alokio Luxe Lễ Hội', 'Pin tháo rời', 'Dây nguồn'],
    description: [
      'Lễ Hội là loa party của dòng Luxe: mặt vải lanh, hông gỗ óc chó, hai vòng LED champagne quanh woofer chạy theo nhịp nhạc.',
      'Công suất 240 W, pin tháo rời 68 Wh cho 18 giờ, tay kéo nhôm và bánh xe êm giúp mang bữa tiệc đi khắp nơi.',
      'Hai cổng micro/guitar cho những đêm hát hò cùng bạn bè, cầu nối giữa Luxe và dòng karaoke Âm Thanh Việt.',
    ],
    faq: [['Có micro kèm theo không?', 'Không kèm, có thể mua thêm bộ micro không dây.'], ['Đi mưa được không?', 'Chuẩn IPX4 chống nước bắn.'], ['Thay pin được không?', 'Có, pin tháo rời.']],
  }),
  // ===================== ALOKIO LUXE · PHỤ KIỆN =====================
  luxe({ id: 'p-acc-tui', slug: 'tui-da-alokio-luxe', name: 'Túi da Alokio Luxe', category: 'phu-kien', tagline: 'Da thật, may tay, cho Giọt và Sóng.', price: 890000, finishes: ['oc-cho', 'huyen'], model: { type: 'acc', kind: 'bag' }, engraving: true, knobs: null, weightKg: 0.2, highlights: ['Da bò thật', 'Vừa Giọt & Sóng', 'Khắc tên miễn phí'], specs: [['Chất liệu', 'Da bò thuộc thực vật'], ['Tương thích', 'Alokio Luxe Giọt, Sóng']], inBox: ['Túi da'], description: ['Túi da may tay, lót vải lanh, bảo vệ loa khỏi trầy xước khi di chuyển.'], faq: [] }),
  luxe({ id: 'p-acc-quai', slug: 'quai-da-alokio-luxe', name: 'Quai da thay thế', category: 'phu-kien', tagline: 'Đổi màu quai, đổi phong cách.', price: 490000, finishes: ['oc-cho'], straps: ['bo', 'kem', 'den'], model: { type: 'acc', kind: 'strap' }, engraving: false, knobs: null, weightKg: 0.08, highlights: ['3 màu da', 'Khoá nhôm champagne', 'Giọt & Hạ Long'], specs: [['Chất liệu', 'Da bò thật, khoá nhôm'], ['Tương thích', 'Giọt, Hạ Long']], inBox: ['Quai da'], description: ['Quai da thật với khoá nhôm champagne, thay trong 10 giây.'], faq: [] }),
  luxe({ id: 'p-acc-chande', slug: 'chan-de-go-oc-cho', name: 'Chân đế gỗ óc chó', category: 'phu-kien', tagline: 'Nâng loa lên đúng tầm tai.', price: 1290000, finishes: ['oc-cho'], model: { type: 'acc', kind: 'stand' }, engraving: false, knobs: null, weightKg: 3.2, highlights: ['Gỗ óc chó nguyên khối', 'Cho Hội An & Huế', 'Chân cao su chống rung'], specs: [['Chất liệu', 'Gỗ óc chó phủ dầu'], ['Tương thích', 'Hội An, Huế']], inBox: ['Chân đế', 'Đệm chống rung'], description: ['Chân đế gỗ óc chó nguyên khối, nâng loa lên tầm tai và tách loa khỏi mặt bàn để bass sạch hơn.'], faq: [] }),
  luxe({ id: 'p-acc-treo', slug: 'gia-treo-song-huong', name: 'Giá treo tường Sông Hương', category: 'phu-kien', tagline: 'Treo sát tường, gọn như một nét kẻ.', price: 590000, finishes: ['huyen'], model: { type: 'acc', kind: 'mount' }, engraving: false, knobs: null, weightKg: 0.6, highlights: ['Nhôm sơn tĩnh điện', 'Cho Sông Hương', 'Lắp đặt 15 phút'], specs: [['Chất liệu', 'Nhôm'], ['Tương thích', 'Sông Hương']], inBox: ['Giá treo', 'Ốc vít'], description: ['Giá treo nhôm giữ soundbar sát tường, che kín dây cáp.'], faq: [] }),
  luxe({ id: 'p-acc-pin', slug: 'pin-thay-the-ha-long', name: 'Pin thay thế Hạ Long', category: 'phu-kien', tagline: 'Thêm 30 giờ nhạc trong túi.', price: 990000, finishes: ['huyen'], model: { type: 'acc', kind: 'battery' }, engraving: false, knobs: null, weightKg: 0.3, highlights: ['30+ giờ', 'Thay trong 1 phút', 'Chính hãng'], specs: [['Loại', 'Li-ion'], ['Tương thích', 'Hạ Long']], inBox: ['Pin'], description: ['Pin chính hãng cho Hạ Long, thay nhanh mà không cần dụng cụ.'], faq: [] }),

  // ===================== ÂM THANH VIỆT – KARAOKE (LOA KÉO THẬT) =====================
  karaoke({ id: 'k-ak18', slug: 'loa-keo-alokio-al-ak18', name: 'Loa kéo Alokio AL-AK18', tagline: 'Bass 5 tấc, 3 đường tiếng, đỉnh 900 W.', price: 7500000, model: { type: 'trolley', bass: 5, style: 'ak' }, featured: true, weightKg: 30, bassSize: 5, mics: 2, highlights: ['Bass 5 tấc', 'Đỉnh 900 W', '3 đơn vị loa'], specs: [['Loa', 'Bass 5 tấc + mid + treble'], ['Công suất', 'Đỉnh 900 W'], ['Thùng', 'Gỗ ép'], ['Ra mắt', '10/2019'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote', 'Dây sạc'], description: ['AL-AK18 là mẫu loa kéo 5 tấc thay thế cho Alokio AL18 đời trước, dùng 3 đơn vị loa (bass, mid, treble) trong thùng gỗ ép.', 'Công suất đỉnh 900 W, phù hợp hát karaoke gia đình, tiệc ngoài trời và sự kiện nhỏ.'], faq: [['Có kèm micro không?', 'Có, 2 micro không dây.'], ['Mua chính hãng ở đâu?', 'Tại Shopee, TikTok Shop hoặc Facebook chính thức của Alokio.']] }),
  karaoke({ id: 'k-gd18', slug: 'loa-keo-alokio-wml-gd18', name: 'Loa kéo Alokio WML-GD18', tagline: 'Bass 5 tấc, tối đa 800 W.', price: 7900000, model: { type: 'trolley', bass: 5, style: 'gd' }, weightKg: 30, bassSize: 5, mics: 2, highlights: ['Bass 5 tấc', '800 W', 'Sự kiện lớn'], specs: [['Loa', 'Bass 5 tấc'], ['Công suất', 'Tối đa 800 W'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['WML-GD18 là loa kéo bass 5 tấc công suất tối đa 800 W, cho âm thanh mạnh mẽ cho những buổi tiệc đông người.'], faq: [] }),
  karaoke({ id: 'k-bt18', slug: 'loa-keo-alokio-wml-bt18', name: 'Loa kéo Alokio WML-BT18', tagline: 'Bass 5 tấc, RMS 200 W.', price: 6990000, model: { type: 'trolley', bass: 5, style: 'bt' }, weightKg: 29, bassSize: 5, mics: 2, highlights: ['Bass 5 tấc', 'Tối đa 800 W', 'RMS 200 W'], specs: [['Loa', 'Bass 5 tấc (5,5 tấc theo một số đại lý)'], ['Công suất', 'Tối đa 800 W, RMS 200 W'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['WML-BT18 là loa kéo karaoke bass 5 tấc với công suất RMS 200 W.'], faq: [] }),
  karaoke({ id: 'k-bp18', slug: 'loa-keo-alokio-wml-bp18', name: 'Loa kéo Alokio WML-BP18', tagline: 'Loa gỗ 5 tấc, đỉnh 800 W.', price: 6690000, model: { type: 'trolley', bass: 5, style: 'bp' }, weightKg: 29, bassSize: 5, mics: 2, highlights: ['Thùng gỗ', 'Bass 5 tấc', 'Đỉnh 800 W'], specs: [['Loa', 'Bass 5 tấc'], ['Công suất', 'Đỉnh 800 W'], ['Thùng', 'Gỗ'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['WML-BP18 dùng thùng gỗ, bass 5 tấc, phù hợp karaoke, phát nhạc và diễn thuyết.'], faq: [] }),
  karaoke({ id: 'k-vip98', slug: 'loa-keo-alokio-al-vip98', name: 'Loa kéo Alokio AL-VIP98', tagline: 'Bass 4 tấc, thế hệ 2020.', price: 6900000, model: { type: 'trolley', bass: 4, style: 'vip' }, weightKg: 25, bassSize: 4, mics: 2, highlights: ['Bass 4 tấc', 'Tối đa 800 W', 'Đời 2020'], specs: [['Loa', 'Bass 4 tấc'], ['Công suất', 'Tối đa 800 W, RMS 150 W'], ['Đời', '2020'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-VIP98 là loa karaoke thế hệ 2020, bass 4 tấc, công suất tối đa 800 W.'], faq: [] }),
  karaoke({ id: 'k-g95', slug: 'loa-keo-alokio-al-g95', name: 'Loa kéo Alokio AL-G95', tagline: 'Bass 4 tấc gỗ dày, 550 W.', price: 4679000, model: { type: 'trolley', bass: 4, style: 'g95' }, featured: true, weightKg: 25, bassSize: 4, mics: 2, highlights: ['Bass 4 tấc gỗ dày', '550 W', 'Bluetooth 10–15 m'], specs: [['Loa', 'Bass 4 tấc gỗ dày'], ['Công suất', '550 W'], ['Trọng lượng', '~25 kg'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-G95 là loa kéo di động hát karaoke công suất lớn, bass 4 tấc, tích hợp ắc quy và 2 micro không dây; dùng được trong nhà lẫn ngoài trời.'], faq: [] }),
  karaoke({ id: 'k-r95', slug: 'loa-keo-alokio-al-r95', name: 'Loa kéo Alokio AL-R95', tagline: 'Thùng gỗ cao cấp, mặt sơn tĩnh điện.', price: 5400000, model: { type: 'trolley', bass: 4, style: 'r95' }, weightKg: 25, bassSize: 4, mics: 2, highlights: ['Thùng gỗ', '500 W', 'Mặt sơn tĩnh điện'], specs: [['Loa', 'Bass 4 tấc gỗ'], ['Công suất', '500 W'], ['Thùng', 'Gỗ, mặt trước sơn tĩnh điện'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-R95 là dòng loa kéo karaoke cao cấp của Alokio với thùng gỗ hiện đại, mặt trước sơn tĩnh điện chống trầy.'], faq: [] }),
  karaoke({ id: 'k-vb71', slug: 'loa-keo-alokio-al-vb71', name: 'Loa kéo Alokio AL-VB71', tagline: 'Gỗ ép + ABS, cá tính.', price: 4790000, model: { type: 'trolley', bass: 4, style: 'vb71' }, weightKg: 24, bassSize: 4, mics: 2, highlights: ['500 W', 'Gỗ ép + ABS', '3 cổng micro/nhạc cụ'], specs: [['Loa', 'Bass 4 tấc'], ['Công suất', '500 W'], ['Thùng', 'Gỗ ép + nhựa ABS'], ['Mặt trước', 'Nhựa xám + lưới kim loại sơn tĩnh điện đen'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-VB71 kết hợp gỗ ép và nhựa ABS, mặt trước phối nhựa xám với lưới kim loại sơn tĩnh điện đen, 4 bánh xe và nhiều tay nắm.'], faq: [] }),
  karaoke({ id: 'k-nb95', slug: 'loa-keo-alokio-wml-nb95', name: 'Loa kéo Alokio WML-NB95', tagline: 'Bass 4 tấc, 550 W.', price: 4799000, model: { type: 'trolley', bass: 4, style: 'nb' }, weightKg: 25, bassSize: 4, mics: 2, highlights: ['Bass 4 tấc', '550 W', 'Karaoke gia đình'], specs: [['Loa', 'Bass 4 tấc'], ['Công suất', '550 W'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['WML-NB95 là loa kéo bass 4 tấc, công suất 550 W, phù hợp mọi nhu cầu giải trí.'], faq: [] }),
  karaoke({ id: 'k-vb1', slug: 'loa-keo-alokio-vb-1', name: 'Loa kéo Alokio VB-1', tagline: 'Nhỏ gọn, thùng gỗ, 400 W.', price: 4200000, compareAt: 5000000, model: { type: 'trolley', bass: 4, style: 'vb1' }, weightKg: 22, bassSize: 4, mics: 2, highlights: ['Thùng gỗ', '400 W', 'Bass 4 tấc'], specs: [['Loa', 'Bass 4 tấc'], ['Công suất', '400 W'], ['Thời lượng', '3–6 giờ'], ...KARAOKE_COMMON_SPECS.filter((s) => s[0] !== 'Thời lượng')], inBox: ['Loa kéo', '2 micro không dây', 'Remote', 'Dây sạc'], description: ['VB-1 có thiết kế nhỏ gọn, thùng gỗ, bass 4 tấc, công suất 400 W, tích hợp bình ắc quy, đi kèm bộ micro không dây.'], faq: [] }),
  karaoke({ id: 'k-t12', slug: 'loa-keo-alokio-al-t12', name: 'Loa kéo Alokio AL-T12', tagline: 'Bass 4 tấc, giá tốt.', price: 3799000, model: { type: 'trolley', bass: 4, style: 't12' }, weightKg: 20, bassSize: 4, mics: 2, highlights: ['Bass 4 tấc', '350 W', 'Giá tốt'], specs: [['Loa', 'Bass 4 tấc'], ['Công suất', '350 W'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-T12 là mẫu 4 tấc chất lượng cao với giá dễ tiếp cận.'], faq: [] }),
  karaoke({ id: 'k-vip12', slug: 'loa-keo-alokio-al-vip12', name: 'Loa kéo Alokio AL-VIP12', tagline: 'Bass 3 tấc, tầm trung.', price: 3990000, model: { type: 'trolley', bass: 3, style: 'vip' }, weightKg: 15, bassSize: 3, mics: 2, highlights: ['Bass 3 tấc', 'Nhỏ gọn', 'Tầm trung'], specs: [['Loa', 'Bass 3 tấc'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa kéo', '2 micro không dây', 'Remote'], description: ['AL-VIP12 là loa karaoke di động tầm trung, bass 3 tấc, gọn nhẹ cho căn hộ.'], faq: [] }),
  karaoke({ id: 'k-k35', slug: 'loa-vali-keo-alokio-wml-k35', name: 'Loa vali kéo Alokio WML-K35', tagline: 'Dáng vali, đỉnh 400 W.', price: 4400000, model: { type: 'trolley', bass: 3, style: 'vali' }, weightKg: 16, bassSize: 3, mics: 2, highlights: ['Dáng vali', 'Đỉnh 400 W', 'Vỏ gỗ'], specs: [['Kiểu dáng', 'Loa vali kéo'], ['Công suất', 'Đỉnh 400 W'], ['Thùng', 'Gỗ'], ...KARAOKE_COMMON_SPECS], inBox: ['Loa vali kéo', '2 micro không dây'], description: ['WML-K35 là loa vali kéo vỏ gỗ thế hệ mới, tích hợp ampli + bình điện + tay kéo và bánh xe, kèm 2 micro không dây.'], faq: [] }),
  karaoke({ id: 'k-acc-mic', slug: 'bo-micro-khong-day-uhf', name: 'Bộ 2 micro không dây UHF', category: 'phu-kien', tagline: 'Micro thay thế cho loa kéo.', price: 690000, model: { type: 'acc', kind: 'mic' }, weightKg: 0.5, needsVerify: true, highlights: ['UHF', 'Pin sạc', '2 micro'], specs: [['Loại', 'UHF, pin sạc']], inBox: ['2 micro', 'Đầu thu'], description: ['Bộ micro không dây thay thế cho loa kéo Alokio (giá giả định).'], faq: [] }),
  karaoke({ id: 'k-acc-acquy', slug: 'binh-ac-quy-12v', name: 'Bình ắc quy thay thế 12 V', category: 'phu-kien', tagline: 'Hồi sinh thời lượng cho loa kéo.', price: 590000, model: { type: 'acc', kind: 'battery' }, weightKg: 3, highlights: ['12 V', 'Thay dễ', 'Bảo hành 6 tháng'], specs: [['Điện áp', '12 V']], inBox: ['Bình ắc quy'], description: ['Bình ắc quy thay thế cho loa kéo (giá giả định).'], faq: [] }),
  karaoke({ id: 'k-acc-ao', slug: 'ao-trum-chong-bui-loa-keo', name: 'Áo trùm chống bụi, chống nước', category: 'phu-kien', tagline: 'Che mưa nắng cho loa kéo.', price: 250000, model: { type: 'acc', kind: 'cover' }, weightKg: 0.3, highlights: ['Chống nước', 'Nhiều cỡ', 'Gấp gọn'], specs: [['Chất liệu', 'Vải dù chống nước']], inBox: ['Áo trùm'], description: ['Áo trùm bảo vệ loa kéo khỏi bụi và mưa (giá giả định).'], faq: [] }),
  karaoke({ id: 'k-acc-remote', slug: 'remote-loa-keo-alokio', name: 'Remote thay thế', category: 'phu-kien', tagline: 'Điều khiển từ xa cho loa kéo.', price: 120000, model: { type: 'acc', kind: 'remote' }, weightKg: 0.05, highlights: ['Hồng ngoại', 'Pin AAA', 'Nhỏ gọn'], specs: [['Loại', 'Hồng ngoại']], inBox: ['Remote'], description: ['Remote thay thế cho loa kéo Alokio (giá giả định).'], faq: [] }),
];

export const ENGRAVING_PRICE = 250000;
export const GIFTBOX_PRICE = 150000;
