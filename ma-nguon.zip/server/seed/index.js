// Tạo toàn bộ dữ liệu demo (chạy lần đầu hoặc khi bấm "Khôi phục dữ liệu demo").
import { PRODUCTS, CATEGORIES, COLLECTIONS } from './catalog.js';
import { PROVINCES, WARDS } from './places.js';
import { POSTS } from './posts.js';
import { hashPassword } from '../auth.js';
import { orderCode, priceCart } from '../commerce.js';

export function rng(seed = 20261120) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const HO = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Huỳnh', 'Phan', 'Vũ', 'Võ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý'];
const DEM = ['Văn', 'Thị', 'Minh', 'Thanh', 'Ngọc', 'Hoàng', 'Quốc', 'Gia', 'Bảo', 'Thu', 'Đức', 'Hải', 'Khánh', 'Anh'];
const TEN = ['An', 'Bình', 'Châu', 'Dũng', 'Giang', 'Hà', 'Hạnh', 'Huy', 'Khoa', 'Lan', 'Linh', 'Long', 'Mai', 'Nam', 'Nga', 'Phúc', 'Quân', 'Quỳnh', 'Sơn', 'Tâm', 'Thảo', 'Trang', 'Trí', 'Tú', 'Uyên', 'Vy', 'Yến', 'Đạt', 'Hiếu', 'Nhi'];
const STREETS = ['Lê Lợi', 'Nguyễn Huệ', 'Trần Phú', 'Hai Bà Trưng', 'Lý Thường Kiệt', 'Điện Biên Phủ', 'Hùng Vương', 'Nguyễn Trãi', 'Phan Chu Trinh', 'Quang Trung', 'Bạch Đằng', 'Lê Duẩn'];
const REVIEW_TEXT = {
  luxe: [
    'Đẹp hơn ảnh rất nhiều, ánh khảm trai đổi màu theo góc nhìn. Đặt ở phòng khách ai cũng hỏi.',
    'Âm thanh ấm, bass chắc mà không ù. Núm vặn champagne cầm rất đầm tay.',
    'Đóng gói như hộp trang sức, mở ra thấy sang ngay. Pin dùng cả tuần mới sạc.',
    'Mình mang ra hồ bơi thả trôi thật, nhạc vẫn rất rõ. Quá đã!',
    'Màu Sương Sớm nhẹ nhàng, hợp phòng ngủ tông trắng. Kết nối nhanh.',
    'Giá cao nhưng xứng đáng, hoàn thiện không chê vào đâu được.',
    'Treble hơi sáng lúc đầu, chỉnh núm một chút là vừa tai. Rất hài lòng.',
  ],
  karaoke: [
    'Loa hát hay, bass đánh chắc, micro hút giọng. Cả xóm qua hát chung.',
    'Giao nhanh, đóng gói kỹ. Ắc quy dùng được cả buổi tối.',
    'Thùng gỗ chắc chắn, kéo đi lại dễ. Giá hợp lý trong tầm tiền.',
    'Chỉnh echo vừa phải là hát rất mượt, không bị hú.',
    'Dùng cho quán cà phê nhỏ rất ổn, âm lượng dư dả.',
  ],
};

const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
function weighted(r, items, wKey = 'w') {
  const total = items.reduce((s, i) => s + i[wKey], 0);
  let x = r() * total;
  for (const i of items) { x -= i[wKey]; if (x <= 0) return i; }
  return items[items.length - 1];
}

export function makeName(r) {
  return `${pick(r, HO)} ${pick(r, DEM)} ${pick(r, TEN)}`;
}
export function makePhone(r) {
  return '0' + pick(r, ['90', '91', '93', '94', '96', '97', '98', '86', '88', '70', '77', '79', '83', '85']) + String(Math.floor(r() * 1e7)).padStart(7, '0');
}
export function makeAddress(r) {
  const prov = weighted(r, PROVINCES);
  const wards = WARDS[prov.code];
  const ward = wards ? pick(r, wards) : `Phường ${pick(r, ['Trung Tâm', 'Đông', 'Tây', 'Nam', 'Bắc', 'An Phú', 'Tân Hoà'])}`;
  return { province: prov.code, provinceName: prov.name, ward, street: `${Math.floor(r() * 300) + 1} ${pick(r, STREETS)}` };
}

export const DEFAULT_SETTINGS = {
  storeName: 'Alokio – Âm Thanh Việt',
  hotline: '1900 0000 (demo)',
  email: 'hello@alokio.vn (demo)',
  announcement: 'Miễn phí giao hàng cho đơn từ 3.000.000 ₫ · Giao hoả tốc 2 giờ tại Hà Nội & TP.HCM (giả lập)',
  links: {
    facebook: 'https://www.facebook.com/share/18ggn741qM/?mibextid=wwXIfr',
    tiktok: 'https://vt.tiktok.com/ZS9PFAnTEY29m-8tE0D/',
    shopee: 'https://vn.shp.ee/1Eokhik4',
  },
  shipping: {
    tiers: [{ maxKg: 5, fee: 30000 }, { maxKg: 15, fee: 80000 }, { maxKg: 9999, fee: 150000 }],
    freeThreshold: 3000000,
    express: 99000,
  },
  payments: {
    cod: true, vietqr: true, wallet: true, card: true, installment: true,
    depositPercent: 10, depositMin: 5000000, qrMinutes: 10,
    wallets: ['momo', 'zalopay', 'shopeepay', 'vnpay', 'viettelmoney'],
    autoConfirmSec: 0,
  },
  vietqr: { bin: '970436', account: '0000000000', accountName: 'ALOKIO DEMO SANDBOX', bankName: 'Ngân hàng (demo)' },
  simulator: { enabled: true, minSec: 20, maxSec: 50 },
  recentTicker: true,
  liveViewers: true,
  heroProduct: 'p-halong',
};

export function generate(seed = 20261120, now = Date.now()) {
  const r = rng(seed);
  const DAY = 864e5;

  // ---------- Sản phẩm (gắn tồn kho, đã bán, ảnh) ----------
  const products = PRODUCTS.map((p, i) => {
    const stock = {};
    for (const f of p.finishes) stock[f] = Math.floor(r() * 36) + (p.line === 'karaoke' ? 4 : 6);
    if (p.id === 'p-trangan') stock['oc-cho'] = 3; // demo cảnh báo tồn kho thấp
    // price = giá bán hiện tại; compareAt = giá gốc (gạch ngang) nếu có
    return {
      ...p,
      compareAt: p.compareAt || null,
      stock,
      sold: 0,
      rating: 0,
      reviewCount: 0,
      hidden: false,
      createdAt: now - (200 - i * 3) * DAY,
      image: `/img/products/${p.slug}.webp`,
    };
  });

  // ---------- Người dùng ----------
  const users = [
    { id: 'u-admin', email: 'admin@alokio.vn', name: 'Quản trị Alokio', role: 'admin', pass: hashPassword('Admin@123') },
    { id: 'u-sales', email: 'nhanvien@alokio.vn', name: 'Nhân viên bán hàng', role: 'sales', pass: hashPassword('Staff@123') },
    { id: 'u-kho', email: 'kho@alokio.vn', name: 'Nhân viên kho', role: 'warehouse', pass: hashPassword('Kho@123') },
  ];

  // ---------- Khách hàng ----------
  const customers = [];
  const demoCustomer = {
    id: 'c-demo', name: 'Nguyễn Minh Khách', email: 'khach@alokio.vn', phone: '0901234567', pass: hashPassword('Alokio@123'),
    addresses: [{ id: 'a1', name: 'Nguyễn Minh Khách', phone: '0901234567', province: 'HCM', provinceName: 'TP. Hồ Chí Minh', ward: 'Phường Thảo Điền', street: '12 Quốc Hương', default: true }],
    createdAt: now - 120 * DAY, note: '', wishlist: ['p-hoian', 'p-trangan'],
  };
  customers.push(demoCustomer);
  for (let i = 0; i < 460; i++) {
    const name = makeName(r);
    const addr = makeAddress(r);
    customers.push({
      id: `c-${i + 1}`, name, phone: makePhone(r), email: `khach${i + 1}@example.com`, pass: null,
      addresses: [{ id: 'a1', name, phone: '', ...addr, default: true }], createdAt: now - Math.floor(r() * 200) * DAY, note: '', wishlist: [],
    });
  }

  // ---------- Đơn hàng ----------
  const state = { products, settings: structuredClone(DEFAULT_SETTINGS), coupons: [], flashSales: [] };
  const orders = [];
  const payments = [];
  const luxe = products.filter((p) => p.line === 'luxe' && p.category !== 'phu-kien');
  const kar = products.filter((p) => p.line === 'karaoke' && p.category !== 'phu-kien');
  const accs = products.filter((p) => p.category === 'phu-kien');
  const usedCodes = new Set();
  const N = 760;
  for (let i = 0; i < N; i++) {
    // Ngày đặt: 180 ngày, tăng trưởng dần về gần đây, có đỉnh vào các ngày đôi (9/9, 10/10, 11/11…)
    let t = now - Math.pow(r(), 1.3) * 180 * DAY;
    if (r() < 0.12) {
      const d = new Date(now - Math.floor(r() * 170) * DAY);
      const m = d.getMonth() + 1;
      d.setDate(Math.min(m, 28)); d.setHours(20 + Math.floor(r() * 3), Math.floor(r() * 60));
      if (d.getTime() < now) t = d.getTime();
    }
    const hourBias = [9, 10, 11, 12, 13, 19, 20, 21, 22, 23];
    const d = new Date(t);
    d.setHours(r() < 0.7 ? pick(r, hourBias) : Math.floor(r() * 24), Math.floor(r() * 60));
    if (d.getTime() < now - 60000) t = d.getTime();
    t = Math.min(t, now - 60000);
    // Phân bố thực tế: phần lớn khách mua 1 lần, một nhóm nhỏ khách thân thiết/VIP mua nhiều lần
    const customer = r() < 0.03 ? demoCustomer : customers[Math.floor(Math.pow(r(), 2.2) * customers.length)];
    const items = [];
    const main = r() < 0.68 ? pick(r, luxe) : pick(r, kar);
    items.push({ productId: main.id, finish: pick(r, main.finishes), qty: r() < 0.9 ? 1 : 2, options: main.engraving && r() < 0.2 ? { engraving: customer.name.split(' ').pop() } : {} });
    if (r() < 0.3) { const a = pick(r, accs); items.push({ productId: a.id, finish: a.finishes[0], qty: 1, options: {} }); }
    const priced = priceCart(state, items, { shipping: r() < 0.15 ? 'express' : 'standard' });
    const age = (now - t) / DAY;
    let status;
    if (age > 10) status = r() < 0.86 ? 'completed' : r() < 0.6 ? 'cancelled' : 'returned';
    else if (age > 4) status = pick(r, ['completed', 'completed', 'shipping', 'shipping', 'cancelled']);
    else if (age > 1.5) status = pick(r, ['shipping', 'packing', 'confirmed', 'completed']);
    else status = pick(r, ['pending', 'pending', 'confirmed', 'packing']);
    const method = weighted(r, [{ id: 'wallet', w: 30 }, { id: 'vietqr', w: 24 }, { id: 'cod', w: 28 }, { id: 'card', w: 12 }, { id: 'installment', w: 6 }]).id;
    const wallet = method === 'wallet' ? pick(r, ['momo', 'zalopay', 'shopeepay', 'vnpay', 'viettelmoney']) : null;
    let payStatus = method === 'cod' ? (status === 'completed' ? 'paid' : 'cod') : status === 'pending' && r() < 0.4 ? 'pending' : 'paid';
    if (status === 'cancelled' && method !== 'cod') payStatus = r() < 0.5 ? 'refunded' : 'failed';
    let code;
    do { code = orderCode(new Date(t), r); } while (usedCodes.has(code));
    usedCodes.add(code);
    const addr = customer.addresses[0];
    const timeline = buildTimeline(status, t, r);
    const order = {
      code, createdAt: t, updatedAt: timeline[timeline.length - 1].at, source: 'seed',
      customerId: customer.id,
      contact: { name: customer.name, phone: customer.phone, email: customer.email },
      address: { ...addr, name: customer.name, phone: customer.phone },
      items: priced.lines.map(({ stock, ...l }) => l), subtotal: priced.subtotal, discount: priced.discount, shippingFee: priced.shipping, total: priced.total,
      coupon: null, shippingMethod: priced.shipping === 99000 ? 'express' : 'standard',
      payment: { method, wallet, status: payStatus, paidAt: payStatus === 'paid' ? t + 120000 : null },
      status, timeline, note: '', internalNotes: [],
    };
    orders.push(order);
    if (method !== 'cod') {
      payments.push({ id: `PAYS${String(i).padStart(5, '0')}`, orderCode: code, method, wallet, amount: order.total, status: payStatus === 'refunded' ? 'refunded' : payStatus === 'paid' ? 'paid' : payStatus, createdAt: t, updatedAt: t + 120000, expiresAt: t + 600000 });
    }
    if (status !== 'cancelled') for (const l of order.items) { const p = products.find((x) => x.id === l.productId); p.sold += l.qty; }
  }
  orders.sort((a, b) => b.createdAt - a.createdAt);

  // ---------- Đánh giá ----------
  const reviews = [];
  for (const p of products) {
    if (p.category === 'phu-kien' && r() < 0.5) continue;
    const n = 3 + Math.floor(r() * 6);
    for (let i = 0; i < n; i++) {
      const stars = r() < 0.72 ? 5 : r() < 0.8 ? 4 : 3;
      reviews.push({
        id: `rv-${p.id}-${i}`, productId: p.id, name: makeName(r), stars, text: pick(r, REVIEW_TEXT[p.line]),
        createdAt: now - Math.floor(r() * 150) * DAY, status: 'approved', reply: i === 0 ? 'Cảm ơn anh/chị đã tin chọn Alokio!' : '', sample: true,
      });
    }
    const mine = reviews.filter((x) => x.productId === p.id);
    p.reviewCount = mine.length;
    p.rating = mine.length ? Math.round((mine.reduce((s, x) => s + x.stars, 0) / mine.length) * 10) / 10 : 0;
  }

  // ---------- Chat mẫu ----------
  const chats = [
    { id: 'ch-1', name: 'Trần Thu Hà', phone: '', status: 'open', unread: 1, createdAt: now - 3600e3, messages: [
      { from: 'customer', text: 'Shop ơi, Hạ Long màu Ngọc Trai còn hàng không ạ?', at: now - 3600e3 },
      { from: 'bot', text: 'Chào bạn! Nhân viên Alokio sẽ trả lời trong ít phút nữa nhé.', at: now - 3599e3 },
    ] },
    { id: 'ch-2', name: 'Lê Quốc Huy', phone: '0912345678', status: 'resolved', unread: 0, createdAt: now - 86400e3, messages: [
      { from: 'customer', text: 'Loa kéo AL-G95 có giao Cần Thơ không shop?', at: now - 86400e3 },
      { from: 'staff', text: 'Dạ có ạ, giao toàn quốc, phí theo khối lượng. Anh có thể mua tại Shopee hoặc TikTok Shop chính thức của Alokio nhé.', at: now - 86000e3 },
      { from: 'customer', text: 'Cảm ơn shop!', at: now - 85900e3 },
    ] },
  ];

  // ---------- Mã giảm giá & flash sale ----------
  const coupons = [
    { code: 'ALOKIO10', type: 'percent', value: 10, max: 500000, minOrder: 0, line: null, limit: 500, used: 132, enabled: true, expiresAt: now + 60 * DAY, desc: 'Giảm 10%, tối đa 500.000 ₫' },
    { code: 'LUXE500', type: 'fixed', value: 500000, minOrder: 6000000, line: 'luxe', limit: 200, used: 41, enabled: true, expiresAt: now + 45 * DAY, desc: 'Giảm 500.000 ₫ cho đơn Alokio Luxe từ 6.000.000 ₫' },
    { code: 'HATHAYLAM', type: 'fixed', value: 300000, minOrder: 5000000, line: 'karaoke', limit: 200, used: 27, enabled: true, expiresAt: now + 30 * DAY, desc: 'Giảm 300.000 ₫ cho loa kéo từ 5.000.000 ₫' },
    { code: 'FREESHIP', type: 'freeship', value: 0, minOrder: 0, line: null, limit: 1000, used: 380, enabled: true, expiresAt: now + 90 * DAY, desc: 'Miễn phí vận chuyển tiêu chuẩn' },
  ];
  const flashSales = [
    { id: 'fs-1', name: 'Flash sale cuối tuần', enabled: true, startsAt: now - 6 * 3600e3, endsAt: now + 2 * DAY + 5 * 3600e3, items: [
      { productId: 'p-giot', price: 1990000, quota: 60, sold: 41 },
      { productId: 'p-song', price: 3690000, quota: 40, sold: 18 },
      { productId: 'k-vb1', price: 3890000, quota: 25, sold: 19 },
      { productId: 'p-acc-tui', price: 690000, quota: 50, sold: 12 },
    ] },
  ];

  const activity = [
    { at: now - 7200e3, user: 'Quản trị Alokio', action: 'Khởi tạo dữ liệu demo' },
  ];

  return {
    createdAt: now,
    settings: structuredClone(DEFAULT_SETTINGS),
    categories: CATEGORIES, collections: COLLECTIONS,
    products, users, customers, orders, payments, reviews, chats, coupons, flashSales,
    posts: POSTS.map((p, i) => ({ ...p, id: `post-${i + 1}`, publishedAt: now - p.days * DAY, author: 'Alokio Studio' })),
    activity, newsletter: [], appointments: [], restockRequests: [], inventoryLog: [],
  };
}

export function buildTimeline(status, t, r = Math.random) {
  const steps = ['pending', 'confirmed', 'packing', 'shipping', 'completed'];
  const tl = [{ status: 'pending', at: t, note: 'Đơn hàng được tạo' }];
  if (status === 'pending') return tl;
  const target = status === 'cancelled' ? 1 + Math.floor(r() * 2) : status === 'returned' ? 5 : steps.indexOf(status) + 1;
  let at = t;
  for (let i = 1; i < Math.min(target, 5); i++) {
    at += (0.2 + r()) * (i === 3 ? 30 : 6) * 3600e3;
    tl.push({ status: steps[i], at, note: '' });
  }
  if (status === 'cancelled') tl.push({ status: 'cancelled', at: at + 3600e3, note: 'Khách yêu cầu huỷ' });
  if (status === 'returned') tl.push({ status: 'returned', at: at + 2 * 864e5, note: 'Khách đổi trả' });
  return tl;
}
