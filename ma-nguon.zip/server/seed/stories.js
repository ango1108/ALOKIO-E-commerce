// Câu chuyện thương hiệu cho từng mẫu loa (hiện phía trên phần mô tả chi tiết ở trang sản phẩm).
// Nội dung sáng tác cho đồ án: kể vì sao mẫu loa mang tên ấy, hoạ tiết nói lên điều gì.
export const STORIES = {
  'p-giot': {
    kicker: 'Vì sao là Giọt?',
    title: 'Một giọt sương, giữ trọn buổi sớm.',
    paras: [
      'Ở những làng ven sông miền Bắc, người ta bảo buổi sáng đẹp nhất không phải lúc mặt trời lên, mà là khoảnh khắc ngay trước đó: khi giọt sương còn đọng trên đầu lá lúa, tròn và trong đến mức soi được cả bầu trời. Giọt được vẽ từ chính hình ảnh ấy. Đó là một khối âm thanh nhỏ, tròn trịa, nằm gọn trong lòng bàn tay mà vẫn chứa đủ cả một buổi sớm.',
      'Viền ngọc trai quanh mặt loa được ghép từ những mảnh trai mài mỏng như cánh chuồn, nên khi xoay dưới nắng, sắc màu chuyển từ hồng sang xanh như mặt nước lúc rạng đông. Chiếc quai hình hạt sương được may tay từ một dải da liền, không một đường nối, để bạn treo Giọt lên cành cây, mép thuyền hay quai ba lô mà không lo tuột.',
      'Chúng tôi làm Giọt nổi được trên mặt nước. Lý do không phải để khoe chuẩn IP67, mà vì một giọt nước thì phải thuộc về nước.',
    ],
    motifs: [['Viền khảm trai', 'Ánh rạng đông đổi màu theo góc nhìn'], ['Quai hạt sương', 'Da liền một dải, may tay'], ['Lưới vải lanh', 'Mặt ruộng lúa nhìn từ trên cao']],
    quote: 'Nhỏ như một giọt sương, nhưng đủ để cả buổi sáng có nhạc.',
  },
  'p-song': {
    kicker: 'Vì sao là Sóng?',
    title: 'Âm thanh không đi thẳng, âm thanh lan ra.',
    paras: [
      'Ai từng đứng trên bờ biển Quy Nhơn lúc chiều xuống sẽ nhớ cách con sóng không đổ ập vào một chỗ, mà trải dài và lan đều lên cả bờ cát. Sóng ra đời từ cảm giác đó. Chúng tôi muốn một chiếc loa không có "mặt trước": ngồi ở đâu quanh nó, bạn cũng nghe trọn vẹn như nhau.',
      'Tấm lưới nhôm ôm ba mặt được dập hoạ tiết sóng lượn, mỗi lỗ thoát âm hơi lệch nhau một chút như vệt bọt biển trên cát. Dải sơn mài phía trên là đường chân trời, và năm núm điều khiển xếp hàng như năm cánh buồm nhỏ đang ra khơi.',
      'Sóng hợp với những buổi tối ngồi quây quần: trên chiếu, trên boong thuyền, trên bãi cỏ, nơi không ai phải ngồi ở "vị trí tốt nhất".',
    ],
    motifs: [['Lưới nhôm dập sóng', 'Vệt bọt biển trên cát ướt'], ['Dải sơn mài', 'Đường chân trời lúc hoàng hôn'], ['Năm núm vặn', 'Năm cánh buồm ra khơi']],
    quote: 'Không có ghế đẹp nhất, chỉ có một vòng tròn bạn bè.',
  },
  'p-halong': {
    kicker: 'Vì sao là Hạ Long?',
    title: 'Ngàn hòn đảo, một mặt nước lặng.',
    paras: [
      'Truyền thuyết kể rằng rồng mẹ đã nhả ngọc xuống vịnh để giữ yên bờ cõi, và những viên ngọc ấy hoá thành ngàn hòn đảo đá vôi. Hạ Long là chiếc loa chúng tôi làm để giữ một điều khác: sự yên tĩnh đẹp đẽ khi nhạc tắt. Thân loa phủ chín lớp sơn mài, mỗi lớp mài tay rồi mới phủ lớp tiếp, để màu Huyền sâu như mặt vịnh lúc chạng vạng, còn màu Ngọc Trai ấm như sương sớm trên núi đá.',
      'Vòng khảm trai quanh núm âm lượng chính là "viên ngọc của rồng". Mỗi lần bạn vặn, ánh trai lại chuyển động như mặt trời trượt trên mặt nước. Khung nhôm champagne phay xước bao quanh mặt vải lanh như mép thuyền gỗ, còn chiếc quai da thật mềm dần theo năm tháng, giống mái chèo bóng lên vì tay người.',
      'Hạ Long kháng nước IP67 và nổi được. Chúng tôi muốn nó không chỉ đứng trên kệ mà còn được ra biển, lên thuyền và đi cùng bạn qua những chuyến đi dài.',
    ],
    motifs: [['Vòng khảm trai', 'Viên ngọc rồng mẹ nhả xuống vịnh'], ['Chín lớp sơn mài', 'Mặt vịnh lúc chạng vạng'], ['Khung nhôm champagne', 'Mép thuyền gỗ bóng nắng']],
    quote: 'Đủ đẹp để trưng bày, đủ bền để mang ra biển.',
  },
  'p-hoian': {
    kicker: 'Vì sao là Hội An?',
    title: 'Ánh đèn lồng cho một căn phòng nhỏ.',
    paras: [
      'Đêm rằm ở phố cổ, khi điện tắt và đèn lồng được thắp, cả con phố bỗng chậm lại. Người ta nói nhỏ hơn và đi chậm hơn. Hội An được làm cho những căn phòng muốn có cảm giác ấy: một góc đọc sách, một bàn làm việc gỗ hay một phòng ngủ có cửa sổ nhìn ra mưa.',
      'Mặt lưới dệt màu ngà như giấy dó căng trên khung đèn lồng. Hai bên hông là gỗ óc chó thật, vân chạy dọc như những thanh gỗ cửa nhà cổ đã sậm màu theo năm tháng. Ba núm vặn analog bằng nhôm champagne có độ nặng tay và tiếng "tách" rất khẽ ở mỗi nấc, vì chúng tôi tin những thứ đẹp nhất nên được chạm vào, không chỉ để nhìn.',
      'Âm thanh của Hội An ấm và tròn. Nó không ồn ào để lấp đầy căn phòng, mà vừa đủ để căn phòng có hồn.',
    ],
    motifs: [['Lưới dệt màu ngà', 'Giấy dó trên khung đèn lồng'], ['Hông gỗ óc chó', 'Cánh cửa nhà cổ sậm màu năm tháng'], ['Ba núm analog', 'Tiếng "tách" khẽ ở mỗi nấc']],
    quote: 'Chậm lại một chút, như phố cổ đêm rằm.',
  },
  'p-hue': {
    kicker: 'Vì sao là Huế?',
    title: 'Trầm mặc như một khúc ca Huế.',
    paras: [
      'Huế dạy người ta cách nghe những điều không nói thành lời: tiếng mái chèo trên sông Hương, tiếng chuông chùa Thiên Mụ vọng qua sương, hay một câu hò mái nhì kéo dài như hơi thở. Chiếc loa mang tên Huế được chỉnh âm cho đúng tinh thần ấy. Dải trầm có chiều sâu nhưng không lấn át, còn giọng hát được đặt ra phía trước, rõ và mềm.',
      'Mặt trước có một đường chỉ vàng mảnh chạy ngang, lấy cảm hứng từ đường viền trên áo dài Nhật Bình của cung đình xưa. Gỗ óc chó và sơn mài màu Huyền gợi nhắc những bức hoành phi sơn son thếp vàng trong các phủ đệ, được tiết chế lại cho hợp với một phòng khách hiện đại.',
      'Huế có cổng RCA và AUX dành cho những ai còn giữ mâm đĩa than của ông bà. Chúng tôi nghĩ những bản thu cũ xứng đáng được phát qua một chiếc loa biết lắng nghe.',
    ],
    motifs: [['Đường chỉ vàng', 'Viền áo Nhật Bình cung đình'], ['Sơn Huyền & gỗ óc chó', 'Hoành phi sơn son thếp vàng'], ['Cổng RCA', 'Dành cho mâm đĩa than của ông bà']],
    quote: 'Có những bản nhạc chỉ hay khi được nghe thật chậm.',
  },
  'p-trangan': {
    kicker: 'Vì sao là Tràng An?',
    title: 'Ba đường tiếng, như ba tầng núi nước.',
    paras: [
      'Chèo thuyền qua Tràng An, bạn sẽ thấy cảnh vật luôn có ba tầng: mặt nước gần sát mạn thuyền, những dãy núi đá ở giữa và bầu trời phía trên vách núi. Chiếc loa lớn nhất dòng tại gia của chúng tôi cũng có ba tầng như vậy. Woofer giữ phần trầm sâu như mặt nước, dải trung là núi đá vững chãi, còn tweeter lụa ở trên cùng thoáng như bầu trời.',
      'Ba núm vặn trên đỉnh xếp thành hàng như ba con thuyền nối đuôi nhau qua hang. Mặt lưới tối màu có một khe sáng mảnh ở chân, giống cửa hang mở ra phía ánh sáng. Tràng An có cổng HDMI ARC, vì những bộ phim đáng xem nhất cũng xứng đáng được nghe trọn ba tầng âm thanh.',
      'Đây là chiếc loa dành cho những không gian rộng, nơi âm nhạc cần chỗ để thở.',
    ],
    motifs: [['Ba đường tiếng', 'Mặt nước, núi đá và bầu trời'], ['Ba núm trên đỉnh', 'Ba con thuyền nối đuôi qua hang'], ['Khe sáng dưới chân', 'Cửa hang mở ra ánh sáng']],
    quote: 'Âm nhạc cũng cần chỗ để thở.',
  },
  'p-hotay': {
    kicker: 'Vì sao là Hồ Tây?',
    title: 'Tĩnh lặng như mặt hồ lúc sáu giờ chiều.',
    paras: [
      'Hà Nội ồn ào cả ngày, nhưng có một khoảnh khắc thành phố như nín thở: khi mặt trời lặn xuống Hồ Tây, mặt nước phẳng như gương và tiếng xe dường như lùi ra xa. Hồ Tây là chiếc loa thông minh được làm cho khoảnh khắc ấy. Nó lắng nghe bạn từ bên kia căn phòng bằng micro far-field, nhưng chỉ lên tiếng khi được gọi.',
      'Đỉnh loa là một mặt sơn mài phẳng tuyệt đối. Khi bạn chạm vào, một vòng sáng lan ra chầm chậm như gợn nước khi cánh sen khẽ lay. Thân loa bọc vải màu Sương Sớm, thứ màu xanh xám của sương trên mặt hồ lúc bình minh, đã được chúng tôi pha đi pha lại hàng chục lần cho đúng.',
      'Hồ Tây kết nối Wi-Fi 6, AirPlay 2 và phát đa phòng. Nhưng điều chúng tôi tự hào nhất là nó biết im lặng.',
    ],
    motifs: [['Đỉnh sơn mài phẳng', 'Mặt hồ phẳng như gương lúc hoàng hôn'], ['Vòng sáng gợn nước', 'Cánh sen khẽ lay trên mặt hồ'], ['Vải Sương Sớm', 'Sương xanh xám lúc bình minh']],
    quote: 'Một chiếc loa thông minh biết khi nào nên im lặng.',
  },
  'p-songhuong': {
    kicker: 'Vì sao là Sông Hương?',
    title: 'Một dòng sông chảy ngang dưới màn hình.',
    paras: [
      'Sông Hương không chảy xiết. Nó trôi dài, êm, và mang theo cả thành phố trên mặt nước. Chúng tôi muốn chiếc soundbar của mình cũng như vậy: một dải dài và mảnh nằm dưới TV, không chắn màn hình, không đòi ai chú ý, nhưng mở ra cả một không gian âm thanh quanh người xem.',
      'Lưới nhôm phía trước được dập theo nhịp sóng lăn tăn, mỏng dần về hai đầu như dòng sông khuất sau khúc quanh. Năm ampli Class-D bên trong là năm "mái chèo": mỗi chiếc đẩy một kênh âm thanh, phối hợp với nhau để giọng nói rõ ràng ở giữa còn tiếng mưa, tiếng gió lan ra hai bên phòng.',
      'Sông Hương nối với TV bằng một sợi cáp HDMI eARC duy nhất. Bạn chỉ cần một chiếc điều khiển, và cả buổi tối trôi đi êm như sông.',
    ],
    motifs: [['Lưới nhôm gợn sóng', 'Mặt sông lăn tăn buổi chiều'], ['Thân dài mỏng dần', 'Dòng sông khuất sau khúc quanh'], ['Năm ampli', 'Năm mái chèo cùng nhịp']],
    quote: 'Êm như sông, rộng như rạp chiếu.',
  },
  'p-sondoong': {
    kicker: 'Vì sao là Sơn Đoòng?',
    title: 'Tiếng trầm từ lòng hang động lớn nhất thế giới.',
    paras: [
      'Người đầu tiên tìm thấy hang Sơn Đoòng không nhìn thấy nó trước, mà nghe thấy nó trước: tiếng gió và tiếng sông ngầm vang lên từ một khe đá giữa rừng. Âm thanh ấy không lớn, nhưng sâu tới mức cảm nhận được bằng lồng ngực. Loa siêu trầm Sơn Đoòng được làm để mang cảm giác đó về phòng khách.',
      'Hai driver 6,5 inch đặt đối xứng, triệt rung lẫn nhau, nên tiếng trầm xuống tới khoảng 30 Hz mà thùng loa vẫn đứng im trên sàn. Mặt trước sơn mài có những vân loang tự nhiên do chúng tôi để lớp sơn tự chảy trước khi mài, nên không có hai chiếc Sơn Đoòng nào giống hệt nhau, cũng như không có hai vách đá nào giống nhau.',
      'Sơn Đoòng kết nối không dây với Sông Hương. Đặt nó ở góc phòng, quên nó đi, rồi để những thước phim hành động nhắc bạn nhớ rằng nó đang ở đó.',
    ],
    motifs: [['Vân sơn loang', 'Vách đá không lặp lại'], ['Hai driver đối xứng', 'Hai vách hang giữ yên tiếng vọng'], ['Khe thoát hơi', 'Khe đá nơi gió hang thổi ra']],
    quote: 'Thứ âm thanh bạn nghe bằng lồng ngực.',
  },
  'p-lehoi': {
    kicker: 'Vì sao là Lễ Hội?',
    title: 'Đêm hội làng, gói gọn trong một tay kéo.',
    paras: [
      'Ở làng quê Việt, đêm hội là lúc cả làng ra sân đình: trống chèo, đèn kéo quân và tiếng hát vọng qua những rặng tre. Lễ Hội là chiếc loa tiệc của dòng Luxe, được làm để mang tinh thần đó tới sân thượng, bãi cỏ hay phòng khách đông người, nhưng vẫn giữ sự chỉn chu của một món đồ đẹp.',
      'Vòng LED champagne quanh loa bass xoay chậm theo nhịp nhạc như chiếc đèn kéo quân. Hai bên hông là gỗ óc chó nguyên tấm, phần dưới sơn mài Huyền sâu như sân đình về khuya. Tay kéo bằng nhôm được thiết kế để một người kéo đi nhẹ nhàng mà không cần nhờ ai.',
      'Pin tháo rời 18 giờ, công suất 240 W, hai cổng micro. Hội có thể kéo dài tới sáng, và Lễ Hội vẫn còn hát.',
    ],
    motifs: [['Vòng LED champagne', 'Đèn kéo quân xoay theo nhịp'], ['Hông gỗ óc chó', 'Cột đình gỗ lim lên nước'], ['Tay kéo nhôm', 'Một người kéo, cả xóm vui']],
    quote: 'Hội có thể kéo dài tới sáng, và loa vẫn còn hát.',
  },
  karaoke: {
    kicker: 'Câu chuyện loa kéo Alokio',
    title: 'Tiếng hát của cả xóm.',
    paras: [
      'Ở Việt Nam, chiếc loa kéo không chỉ là một thiết bị. Nó có mặt ở đám cưới đầu ngõ, buổi liên hoan cuối năm của tổ dân phố, sinh nhật ở sân thượng và những tối cuối tuần cả nhà quây quần hát với nhau. Alokio làm loa kéo với một tâm niệm rất đơn giản: lúc mọi người cần cất tiếng hát, chiếc loa phải luôn sẵn sàng.',
      'Thùng gỗ dày giữ tiếng bass chắc mà không rè. Lưới thép sơn tĩnh điện chịu được những lần va quẹt khi kéo qua bậc cửa. Hai micro không dây UHF được chỉnh để giọng hát nghe ấm và ít hú, kể cả khi người cầm micro không quen hát.',
      'Mỗi chiếc loa kéo Alokio đều đi kèm bộ micro, remote và tờ hướng dẫn chỉnh echo, bass, treble viết bằng ngôn ngữ dễ hiểu, vì niềm vui ca hát không nên phụ thuộc vào việc bạn rành kỹ thuật tới đâu.',
    ],
    motifs: [['Thùng gỗ dày', 'Bass chắc, không rè'], ['Lưới thép sơn tĩnh điện', 'Bền qua những bậc cửa'], ['Micro UHF', 'Giọng ấm, ít hú']],
    quote: 'Lúc mọi người cần hát, loa phải luôn sẵn sàng.',
  },
};
