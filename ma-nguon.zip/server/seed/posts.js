// Bài viết blog mẫu (Markdown đơn giản: "## " là tiêu đề mục, dòng trống tách đoạn, "- " là gạch đầu dòng,
// "![chú thích](/img/...)" là ảnh minh hoạ). Nội dung sáng tác cho đồ án.
export const POSTS = [
  {
    slug: 'cau-chuyen-son-mai-va-kham-trai',
    title: 'Câu chuyện sơn mài và khảm trai trên Alokio Luxe',
    excerpt: 'Vì sao một chiếc loa bluetooth lại cần đến hai chất liệu thủ công lâu đời nhất của Việt Nam?',
    cover: 'material', tags: ['Alokio Luxe', 'Chất liệu'], products: ['p-halong', 'p-hoian'], days: 4,
    body: `Khi bắt đầu phác thảo Alokio Luxe, câu hỏi đầu tiên không phải là "bao nhiêu watt" mà là "chiếc loa này sẽ trông thế nào khi tắt nhạc". Một chiếc loa tốt nằm trong phòng bạn cả ngày, nhưng thời gian phát nhạc chỉ chiếm vài giờ. Phần còn lại, nó là một món đồ trang trí. Vì thế chúng tôi muốn mỗi chiếc loa trước hết phải là một vật đẹp, đáng để đặt ở chỗ dễ nhìn nhất trong nhà.

![Hạ Long Ngọc Trai: viền nhôm champagne phay xước ôm lấy mặt vải lanh dệt kim.](/img/blog/material-1.webp)

Câu trả lời mà đội thiết kế tìm được nằm ngay trong những món đồ quen thuộc của người Việt: chiếc tráp sơn mài bà cất giấy tờ, bức tranh khảm trai treo ở phòng khách nhà ông, chiếc hộp đựng trầu bóng lên vì tay người. Đó là những chất liệu được làm chậm, dùng lâu và càng cũ càng đẹp, đúng điều chúng tôi muốn cho một chiếc loa.

## Sơn mài: chiều sâu của bóng tối

Sơn mài truyền thống được phủ nhiều lớp, mỗi lớp khô rồi lại mài, cho đến khi bề mặt có chiều sâu như nhìn xuống mặt hồ lúc chạng vạng. Ánh sáng không dừng ở lớp ngoài cùng mà đi xuyên vào trong rồi phản lại, nên màu đen của sơn mài không phẳng mà "sâu". Đứng gần sẽ thấy bóng mình in mờ trong đó.

Trên Alokio Luxe, chúng tôi giữ tinh thần ấy cho phần thân loa. Mỗi chiếc được phủ chín lớp, mài tay giữa các lớp bằng giấy nhám mịn dần và đánh bóng hoàn thiện bằng tay. Một chiếc Hạ Long đi qua khoảng năm ngày ở xưởng sơn trước khi được lắp linh kiện.

- **Huyền** là đen ánh xanh, gợi mặt vịnh lúc trời sắp tối.
- **Ngọc Trai** là trắng ngà ấm, như lớp sương sớm trên núi đá vôi.
- **Sương Sớm** là xanh pastel nhạt, màu của bầu trời ngay trước bình minh.

Vì lớp sơn được mài tay nên không có hai chiếc loa nào phản chiếu ánh sáng giống hệt nhau. Chúng tôi coi đó là chữ ký của người thợ chứ không phải lỗi sản xuất.

## Khảm trai: ánh sáng đổi màu theo góc nhìn

Xà cừ là lớp trong cùng của vỏ trai. Khi được cắt mỏng và ghép lại, nó tạo ra thứ ánh sáng đổi màu kỳ lạ: nhìn thẳng thấy trắng bạc, nghiêng đi một chút thấy hồng, nghiêng thêm lại thấy xanh lục. Hiện tượng này đến từ cấu trúc nhiều lớp siêu mỏng trong vỏ trai, thứ mà sơn hay mực in đều không làm lại được.

Trên Hạ Long, vòng khảm trai bao quanh núm âm lượng gồm khoảng ba mươi mảnh nhỏ, ghép tay trên một vòng nhôm rồi phủ lớp sơn trong để bảo vệ. Trên Giọt, viền trai ôm quanh mặt loa như một khung tranh nhỏ. Mỗi lần bạn vặn núm hay xoay chiếc loa, ánh trai lại chuyển động như mặt trời trượt trên mặt nước.

## Vải lanh và nhôm champagne: hai vai phụ không thể thiếu

Một chiếc loa không chỉ có vỏ. Mặt trước cần cho âm thanh đi qua nên chúng tôi dùng vải lanh dệt kim. Sợi lanh có độ cứng vừa phải giữ được form phẳng, còn kiểu dệt kim cho độ thoáng khoảng 96%, gần như không làm suy hao tiếng treble. Màu vải được nhuộm để hợp với từng màu sơn chứ không dùng chung một màu xám.

Viền quanh mặt vải là nhôm 6063 phay CNC từ khối nguyên, sau đó anod màu champagne. Bề mặt được để vân xước rất mảnh theo một chiều để bắt sáng khi bạn nhìn nghiêng. Các núm vặn cũng làm bằng nhôm đặc nên có độ nặng tay và tiếng "tách" rõ ở mỗi nấc.

![Núm vặn champagne trên Hội An Óc Chó, vân gỗ thật chạy dọc hai bên hông.](/img/blog/material-2.webp)

## Gỗ óc chó cho dòng loa tại gia

Với dòng loa đặt trong nhà như Hội An, Huế và Tràng An, chúng tôi thêm một chất liệu nữa là gỗ óc chó. Gỗ được xẻ thành tấm dày, sấy kỹ để không cong vênh, rồi hoàn thiện bằng dầu thay vì sơn phủ dày. Nhờ vậy bạn vẫn sờ được vân gỗ thật, và theo thời gian gỗ sẽ sậm lại một chút, như cánh cửa nhà cổ đã lên màu năm tháng.

## Vì sao không dùng nhựa giả da?

Nhựa giả gỗ hay sơn giả da có thể rẻ hơn nhiều và trông "gần giống" trong ảnh. Nhưng sau hai năm, nhựa ngả màu, lớp in bong ra, còn chất liệu thật thì ngược lại, càng dùng càng đẹp. Một chiếc loa Alokio Luxe được thiết kế để dùng ít nhất mười năm. Pin có thể thay, linh kiện có thể sửa, và bề mặt thì càng sờ càng bóng.

## Chăm sóc bề mặt sơn mài và khảm trai

- Lau bụi bằng khăn sợi mềm hơi ẩm, sau đó lau khô. Không dùng cồn hay nước tẩy rửa.
- Tránh để loa dưới nắng gắt nhiều giờ liền vì tia UV có thể làm màu Ngọc Trai ngả vàng nhẹ.
- Nếu có vết xước nhỏ trên lớp sơn, xưởng Alokio nhận đánh bóng lại miễn phí trong thời gian bảo hành.

Chúng tôi tin rằng đồ vật tốt nhất là đồ vật mà bạn muốn giữ lâu. Sơn mài và khảm trai đã chứng minh điều đó qua nhiều thế hệ, và Alokio Luxe chỉ đơn giản là mời hai chất liệu ấy bước vào một vật dụng hiện đại.`,
  },
  {
    slug: 'chon-loa-bluetooth-cao-cap-cho-phong-khach',
    title: 'Chọn loa bluetooth cao cấp cho phòng khách: 5 điều cần biết',
    excerpt: 'Diện tích phòng, công suất, kết nối TV và cả… màu sắc. Hướng dẫn chọn loa tại gia không hối tiếc.',
    cover: 'home', tags: ['Tư vấn', 'Loa tại gia'], products: ['p-hoian', 'p-hue', 'p-trangan'], days: 9,
    body: `Chọn loa cho phòng khách khác với chọn loa mang đi chơi. Chiếc loa sẽ đứng một chỗ nhiều năm, phải hợp với nội thất, phát được cả nhạc lẫn âm thanh TV, và quan trọng nhất là nghe dễ chịu trong chính căn phòng của bạn chứ không phải trong phòng thử của cửa hàng. Dưới đây là năm điều chúng tôi thường hỏi khách trước khi tư vấn.

![Hội An đặt trên tủ gỗ óc chó, đủ lấp đầy phòng khách 20–25 m².](/img/blog/home-1.webp)

## 1. Diện tích phòng quyết định công suất

Một lỗi phổ biến là mua loa công suất quá lớn rồi chỉ dám mở ở mức 10%. Ở mức âm lượng thấp, nhiều loa lớn nghe mỏng và thiếu chi tiết vì driver chưa được "đánh thức". Ngược lại, loa quá nhỏ cho phòng lớn phải mở hết cỡ và bắt đầu méo tiếng.

- **Phòng ngủ, góc làm việc, phòng dưới 15 m²:** Hội An (40 W) là đủ, kể cả khi mở to.
- **Phòng khách 15–30 m²:** Huế (80 W) cho dải trầm sâu hơn mà vẫn gọn.
- **Phòng khách trên 30 m², phòng thông tầng hoặc liền bếp:** Tràng An (150 W, ba đường tiếng), hoặc một cặp Huế ghép stereo.

Một mẹo nhỏ: nếu nhà bạn có trần cao hay nhiều kính, hãy chọn lên một nấc vì âm thanh sẽ "tản" nhiều hơn.

## 2. Vị trí đặt loa quan trọng không kém bản thân chiếc loa

Cùng một chiếc loa, đặt sai chỗ có thể mất một nửa chất lượng. Một vài nguyên tắc đơn giản:

- Đặt loa cách tường sau khoảng 15–30 cm. Áp sát tường làm bass bị dày và ù; ra xa quá thì bass mỏng.
- Tránh nhét loa vào hộc tủ kín vì âm thanh sẽ bị dội lại trong hộc.
- Tweeter (loa treble) nên ngang tầm tai khi bạn ngồi sofa, thường khoảng 90–110 cm tính từ sàn.
- Nếu dùng cặp stereo, hai loa và vị trí ngồi nên tạo thành một tam giác gần đều.

## 3. Kết nối: Bluetooth là chưa đủ

Bluetooth rất tiện để phát nhạc từ điện thoại, nhưng phòng khách thường còn có TV, máy chơi game và đôi khi cả mâm đĩa than. Hãy kiểm tra trước những cổng bạn cần.

- **Bluetooth 5.3 với AAC/aptX:** phát nhạc trực tiếp từ điện thoại với chất lượng tốt.
- **Wi-Fi và AirPlay 2:** phát nhạc không nén, không bị ngắt khi có cuộc gọi, phát được nhiều phòng cùng lúc.
- **HDMI ARC:** dùng chung remote TV, âm thanh phim đồng bộ hình. Tràng An có cổng này.
- **RCA/AUX:** cho mâm đĩa than hay máy CD. Huế có sẵn ngõ RCA.

## 4. Màu sắc và chất liệu phải hợp với nhà bạn

Loa phòng khách là đồ nội thất. Một chiếc loa đen bóng có thể rất đẹp ở cửa hàng nhưng lại "lạc quẻ" trong căn hộ tông gỗ sáng. Một vài gợi ý phối màu:

- Nội thất gỗ sáng, tường trắng: Ngọc Trai hoặc Sương Sớm.
- Nội thất gỗ trầm, kệ óc chó: phiên bản Óc Chó cho cảm giác liền mạch.
- Phong cách tối giản, nhiều kim loại và đá: Huyền tạo điểm nhấn sâu.

![Tràng An màu Huyền cạnh cửa sổ: cặp loa stereo cho phòng khách lớn.](/img/blog/home-2.webp)

## 5. Nghe thử bằng bài hát của chính bạn

Cuối cùng, đừng tin hoàn toàn vào thông số. Hãy mang theo ba bài bạn nghe nhiều nhất: một bài có giọng hát mộc, một bài nhiều bass và một bài nhạc không lời. Giọng hát cho biết dải trung có tự nhiên không, bài nhiều bass cho biết loa có ù hay không, còn nhạc không lời cho biết loa tách nhạc cụ rõ đến đâu.

Nếu chưa tiện đến cửa hàng, bạn có thể dùng mục "Chạm vào âm thanh" trên trang chủ Alokio để tự vặn bass và treble, hoặc vào Showroom 3D để xem kích thước thật của từng mẫu đặt cạnh nhau.

## Tóm tắt nhanh

- Chọn công suất theo diện tích phòng, đừng chọn theo con số lớn nhất.
- Đặt loa cách tường, tweeter ngang tầm tai.
- Liệt kê thiết bị cần kết nối trước khi mua.
- Chọn màu theo nội thất, không theo ảnh quảng cáo.
- Nghe thử bằng nhạc của chính bạn.

## Câu hỏi thường gặp

**Có nên mua một loa lớn hay hai loa nhỏ ghép stereo?** Nếu bạn ngồi chủ yếu ở sofa trước TV, một cặp stereo cho hình ảnh âm thanh rộng và rõ hướng hơn. Nếu nhạc chỉ để làm nền khi nấu ăn, tiếp khách, một loa lớn đặt ở góc phòng sẽ phủ đều hơn.

**Loa bluetooth có thay được dàn âm thanh không?** Với nhu cầu nghe nhạc và xem phim trong căn hộ, một chiếc loa tại gia tốt hoàn toàn đủ. Dàn âm thanh rời chỉ thực sự khác biệt khi bạn có phòng nghe riêng và muốn tự phối ghép từng thiết bị.

**Mở loa cả ngày có hại không?** Không. Loa Alokio có chế độ chờ tiết kiệm điện và tự tắt sau một khoảng thời gian không phát nhạc, bạn có thể chỉnh thời gian này trong ứng dụng.`,
  },
  {
    slug: 'stereo-360-la-gi',
    title: 'Stereo 360° là gì và vì sao nó quan trọng với loa di động?',
    excerpt: 'Ngồi ở đâu quanh loa cũng nghe rõ: bí mật nằm ở cách bố trí driver.',
    cover: 'wave', tags: ['Công nghệ'], products: ['p-song', 'p-halong'], days: 15,
    body: `Hãy nhớ lại một buổi dã ngoại: mọi người ngồi thành vòng tròn trên bãi cỏ, chiếc loa đặt ở giữa. Người ngồi phía trước loa nghe rõ mồn một, còn người ngồi phía sau chỉ nghe thấy tiếng bass ì ầm và giọng hát như vọng từ phòng bên. Stereo 360° ra đời để giải quyết đúng tình huống đó.

![Sóng nằm trên khăn tắm, nắng chiều phản chiếu trên lưới nhôm ôm ba mặt.](/img/blog/wave-1.webp)

## Vì sao loa thường có "mặt trước"?

Âm trầm có bước sóng dài nên lan đều ra mọi hướng. Âm cao (treble) thì ngược lại: bước sóng ngắn, phát ra theo một chùm hẹp phía trước driver. Phần lớn chi tiết của giọng hát, tiếng cymbal hay tiếng gảy dây đàn nằm ở dải này. Vì thế khi đứng sau một chiếc loa thông thường, bạn vẫn nghe bass nhưng mất gần hết sự trong trẻo.

## Stereo 360° hoạt động như thế nào?

Thay vì đặt tất cả driver hướng về một phía, loa 360° bố trí chúng xoay quanh thân loa. Trên Alokio Luxe Sóng, bốn driver toàn dải được đặt lệch nhau 90°, kết hợp với một màng bass thụ động ở đáy. Một bộ xử lý tín hiệu số (DSP) sẽ:

- Chia tín hiệu trái và phải cho các driver sao cho ở bất kỳ vị trí nào bạn cũng nghe được cả hai kênh, thay vì người bên trái chỉ nghe kênh trái.
- Bù pha giữa các driver để chúng không triệt tiêu nhau ở những điểm giao thoa.
- Điều chỉnh âm sắc theo mức âm lượng, giữ bass đầy đặn ngay cả khi mở nhỏ.

Kết quả là âm thanh giống một "bong bóng" bao quanh chiếc loa, và ai ngồi ở đâu cũng nghe gần như nhau.

## Lưới nhôm ôm ba mặt không chỉ để đẹp

Tấm lưới trên Sóng được dập hoạ tiết sóng lượn với hàng nghìn lỗ thoát âm nhỏ. Kích thước và mật độ lỗ được tính sao cho lưới gần như "trong suốt" với âm thanh, đồng thời đủ cứng để bảo vệ driver khi bạn ném loa vào ba lô. Lưới nhôm cũng tản nhiệt tốt hơn vải, rất hợp với những buổi chơi ngoài trời dưới nắng.

## Khi nào nên chọn loa 360°?

- **Dã ngoại, cắm trại, tiệc ngoài trời:** mọi người ngồi quanh loa thay vì trước mặt nó.
- **Bàn ăn, bàn cà phê:** đặt loa giữa bàn, ai cũng nghe như nhau.
- **Phòng nhỏ có nhiều góc:** âm thanh dội đều khắp phòng thay vì dồn về một phía.

Ngược lại, nếu bạn chủ yếu ngồi một chỗ trước loa, chẳng hạn bàn làm việc hay trước TV, thì loa có hướng phát rõ ràng như Hạ Long hay Hội An lại cho hình ảnh âm thanh (soundstage) rộng và chính xác hơn.

![Hạ Long trên bãi cát: kháng nước IP67, chịu được cát và hơi muối.](/img/blog/wave-2.webp)

## Hạ Long: lựa chọn ở giữa

Hạ Long không phải loa 360° hoàn toàn, nhưng có hai cổng thoát âm bên hông và một chế độ "Vòng tròn" trong ứng dụng Alokio. Ở chế độ này, DSP mở rộng góc phát của dải trung, phù hợp khi bạn đặt loa ở giữa nhóm bạn. Khi về nhà, bạn chuyển lại chế độ "Phòng khách" để có âm thanh stereo tập trung.

## Mẹo đặt loa 360° để nghe hay nhất

- Đặt loa ở giữa không gian, cách xa tường ít nhất nửa mét.
- Kê loa cao hơn mặt đất một chút, ví dụ trên ghế đẩu hay hộp gỗ, để âm thanh không bị cỏ và cát "nuốt".
- Ngoài trời không có tường để dội bass, hãy bật chế độ Outdoor để DSP bù thêm dải trầm.
- Khi ghép hai loa Sóng, hãy đặt chúng cách nhau 2–3 mét. Âm thanh sẽ lan rộng hơn mà không bị lệch kênh.

Stereo 360° không phải là phép màu, mà là cách bố trí driver thông minh cộng với xử lý số cẩn thận. Nhưng với những buổi tối quây quần, nó tạo ra khác biệt rất lớn: không còn ai phải ngồi ở "chỗ dở".

## Câu hỏi thường gặp

**Loa 360° có nghe stereo thật không?** Có, nhưng theo cách khác loa truyền thống. Thay vì tách trái phải rõ rệt cho một người ngồi giữa, nó trộn hai kênh sao cho ai cũng nghe đủ, kèm một chút độ rộng nhờ DSP. Nếu muốn stereo tách bạch, hãy ghép hai loa Sóng ở chế độ Trái/Phải.

**Đặt loa 360° sát tường được không?** Được, nhưng một nửa âm thanh sẽ dội vào tường. Khi đó hãy bật chế độ "Sát tường" trong ứng dụng để DSP giảm bớt dải trầm và hướng thêm năng lượng ra phía trước.

**Pin có hao nhanh hơn vì nhiều driver?** Không đáng kể. Các driver nhỏ dùng chung một ampli hiệu suất cao, và Sóng vẫn đạt khoảng 18 giờ nghe ở mức âm lượng vừa phải.`,
  },
  {
    slug: 'ip67-va-chiec-loa-noi-tren-mat-nuoc',
    title: 'IP67 và chiếc loa nổi trên mặt nước',
    excerpt: 'IP67 khác IP68 thế nào, và tại sao chúng tôi muốn Hạ Long nổi được.',
    cover: 'water', tags: ['Công nghệ', 'Alokio Luxe'], products: ['p-giot', 'p-halong'], days: 21,
    body: `Trên hộp của rất nhiều thiết bị điện tử có dòng chữ "IP67" hay "IP68". Nhiều người hiểu đó là "chống nước" và dừng ở đó. Thực ra hai chữ số ấy nói lên khá nhiều điều, và hiểu đúng sẽ giúp bạn dùng loa yên tâm hơn ở bãi biển hay bể bơi.

![Giọt ở mép nước: đủ nhẹ để nổi, đủ kín để không sợ sóng đánh.](/img/blog/water-1.webp)

## IP là gì?

IP (Ingress Protection) là tiêu chuẩn quốc tế IEC 60529 đánh giá khả năng chống bụi và chống nước của vỏ thiết bị. Mã gồm hai chữ số:

- **Chữ số thứ nhất (0–6)** là mức chống vật thể rắn và bụi. Số 6 nghĩa là kín bụi hoàn toàn, bụi mịn không lọt vào được.
- **Chữ số thứ hai (0–9)** là mức chống nước. Số 4 chịu được nước bắn, số 7 chịu được ngâm nước tạm thời, số 8 chịu được ngâm lâu hơn theo điều kiện nhà sản xuất công bố.

## IP67 cụ thể là gì?

Một thiết bị đạt IP67 được thử nghiệm ngâm ở độ sâu tới 1 mét trong 30 phút mà nước không lọt vào gây hư hại. Đồng thời nó kín bụi hoàn toàn, nên cát mịn ở bãi biển cũng không chui được vào trong. Với một chiếc loa mang ra ngoài trời, đây là mức bảo vệ rất thực tế: rơi xuống hồ bơi, bị sóng đánh hay dính mưa đều không sao.

## Vậy IP68 có tốt hơn?

IP68 nghĩa là chịu được ngâm sâu hơn hoặc lâu hơn 1 mét/30 phút, nhưng con số cụ thể do nhà sản xuất tự công bố, ví dụ 1,5 mét trong 30 phút hay 2 mét trong 1 giờ. Với loa, khác biệt này hiếm khi có ý nghĩa vì hiếm ai thả loa xuống đáy hồ sâu. Điều quan trọng hơn là loa có nổi hay không, để khi rơi xuống nước bạn có thể vớt lên ngay.

## Vì sao chúng tôi muốn Hạ Long và Giọt nổi được?

Một chiếc loa chìm xuống đáy hồ bơi sâu 2 mét, dù đạt IP68, vẫn là một trải nghiệm tồi: bạn phải lặn xuống tìm, và trong lúc đó nước có thể đã làm hỏng thứ gì khác. Một chiếc loa nổi thì chỉ cần với tay là xong.

Để nổi được, tổng khối lượng của loa phải nhỏ hơn khối lượng nước mà nó chiếm chỗ. Đội kỹ thuật đã phải:

- Dùng khung sườn nhôm mỏng thay cho thép.
- Thiết kế khoang khí kín phía sau driver, đóng vai trò như phao.
- Đặt pin và bo mạch ở nửa dưới để loa luôn nổi thẳng, mặt loa hướng lên trời.

Giọt nhỏ và nhẹ nên nổi rất dễ. Hạ Long nặng hơn nhưng vẫn nổi được, với khoảng một phần ba thân chìm dưới nước như một chiếc thuyền nhỏ.

![Hạ Long trên thành hồ bơi đá travertine, quai da kem chống thấm.](/img/blog/water-2.webp)

## Những điều IP67 không bảo vệ

Chống nước không có nghĩa là "dùng thế nào cũng được". Hãy lưu ý:

- **Nước biển và nước hồ bơi có muối, clo.** Sau khi dùng, hãy rửa loa bằng nước sạch và để khô tự nhiên.
- **Đừng sạc khi cổng USB-C còn ướt.** Lắc nhẹ cho nước thoát ra rồi đợi khô hẳn, thường khoảng 30 phút.
- **Nước nóng và hơi nước** (phòng xông hơi, bồn nước nóng) không nằm trong phạm vi thử nghiệm IP.
- **Va đập mạnh** có thể làm hở gioăng. Nếu loa từng bị rơi mạnh, hãy mang đến Alokio kiểm tra miễn phí.

## Âm thanh khi loa bị ướt

Khi có nước đọng trên màng loa, tiếng sẽ hơi rè và nhỏ đi. Ứng dụng Alokio có chức năng "Đẩy nước": loa phát một tần số thấp đặc biệt trong 20 giây để rung nước ra khỏi lưới. Bạn sẽ thấy những giọt nước nhỏ bắn ra, và âm thanh trở lại bình thường.

IP67 cộng với khả năng nổi là sự kết hợp mà chúng tôi thấy thực tế nhất cho một chiếc loa đi biển. Nó không chỉ giúp loa sống sót qua tai nạn, mà còn cho bạn sự yên tâm để thực sự mang nó ra gần nước.

## Câu hỏi thường gặp

**Có thể mang loa vào phòng tắm không?** Có. Hơi nước bình thường trong phòng tắm không ảnh hưởng tới loa đạt IP67, miễn là bạn không đặt loa ngay dưới vòi nước nóng.

**Loa có hát được khi đang nổi trên nước không?** Có. Bluetooth vẫn kết nối ổn trong vòng vài mét. Âm thanh sẽ nhỏ hơn một chút vì một phần thân loa chìm dưới nước, nhưng vẫn đủ nghe khi bạn ở gần.

**Gioăng chống nước có bền mãi không?** Gioăng cao su sẽ lão hoá dần theo thời gian, nhất là khi tiếp xúc nhiều với clo và nắng. Alokio khuyên kiểm tra lại gioăng sau mỗi hai năm, và dịch vụ này miễn phí cho loa còn bảo hành.`,
  },
  {
    slug: 'ghep-loa-tai-gia-voi-tv-qua-hdmi-arc',
    title: 'Ghép loa tại gia với TV qua HDMI ARC trong 3 bước',
    excerpt: 'Một sợi cáp, một remote, âm thanh rạp phim cho phòng khách.',
    cover: 'bar', tags: ['Hướng dẫn'], products: ['p-trangan', 'p-songhuong'], days: 28,
    body: `Loa tích hợp trên TV ngày càng mỏng, và âm thanh cũng mỏng theo. Giọng nói trong phim lẫn vào nhạc nền, tiếng nổ thì nghe như ai đó đập bàn. Cách đơn giản nhất để cải thiện là nối TV với một chiếc loa ngoài qua cổng HDMI ARC. Chỉ cần một sợi cáp, bạn vẫn dùng một remote cho cả hai thiết bị.

![Sông Hương dưới TV: dải loa dài 65 cm, cao chưa tới 7 cm, không che màn hình.](/img/blog/bar-1.webp)

## ARC và eARC là gì?

ARC (Audio Return Channel) cho phép tín hiệu âm thanh đi "ngược" từ TV ra loa trên cùng một sợi cáp HDMI. Mọi nguồn phát cắm vào TV như ứng dụng Netflix, YouTube, đầu thu hay máy chơi game đều được đưa âm thanh ra loa mà không cần thêm dây.

eARC là phiên bản nâng cấp, băng thông lớn hơn nhiều, truyền được âm thanh không nén và các định dạng đa kênh. Sông Hương hỗ trợ eARC, còn Tràng An hỗ trợ ARC. Với nhu cầu xem phim và nghe nhạc trong phòng khách, cả hai đều cho chất lượng rất tốt.

## Bước 1: Tìm đúng cổng và cắm cáp

- Trên TV, tìm cổng HDMI có ghi chữ **ARC** hoặc **eARC**. Thường chỉ có một cổng như vậy.
- Trên loa Alokio, cắm vào cổng **HDMI ARC** ở mặt sau.
- Dùng cáp HDMI loại High Speed trở lên. Với eARC, nên dùng cáp Ultra High Speed để ổn định nhất.

Nếu TV đời cũ không có cổng ARC, bạn vẫn có thể dùng cổng quang (Optical). Chất lượng tương đương ARC, chỉ là không dùng chung remote được.

## Bước 2: Bật chức năng điều khiển HDMI (CEC)

CEC là tính năng cho phép các thiết bị HDMI "nói chuyện" với nhau: bật TV thì loa tự bật, vặn âm lượng trên remote TV thì loa nhận lệnh. Mỗi hãng TV gọi tính năng này bằng một tên riêng:

- Samsung: **Anynet+**
- LG: **SIMPLINK**
- Sony: **BRAVIA Sync**
- Các TV Android/Google TV khác: thường nằm trong mục **HDMI-CEC** hoặc **Điều khiển thiết bị**.

Hãy vào phần Cài đặt của TV, tìm mục kết nối hoặc thiết bị ngoài, rồi bật tính năng này lên.

## Bước 3: Chọn loa ngoài làm đầu ra âm thanh

Trong cài đặt âm thanh của TV, chọn đầu ra là **Bộ thu HDMI**, **Loa ngoài**, hoặc **HDMI ARC** tuỳ hãng. Lúc này loa Alokio sẽ hiện "TV" trên màn hình nhỏ hoặc đèn báo chuyển sang màu trắng.

Nếu TV có tuỳ chọn định dạng âm thanh số, chọn **Tự động** hoặc **Bitstream**. Loa sẽ tự giải mã định dạng phù hợp.

![Buổi tối xem phim: một thanh loa thay cả dàn âm thanh vòm.](/img/blog/bar-2.webp)

## Tinh chỉnh để xem phim hay hơn

- **Chế độ Thoại (Voice):** tăng rõ giọng nói, rất hữu ích với phim truyền hình và tin tức.
- **Chế độ Đêm (Night):** thu hẹp khoảng chênh giữa tiếng nhỏ và tiếng lớn, để bạn nghe rõ lời thoại mà không làm phiền người đang ngủ.
- **Đồng bộ tiếng hình:** nếu thấy khẩu hình lệch tiếng, chỉnh mục AV Sync trong ứng dụng Alokio, mỗi nấc 10 ms.
- **Thêm loa siêu trầm:** ghép Sơn Đoòng không dây với Sông Hương để có dải trầm xuống sâu khi xem phim hành động.

## Xử lý sự cố thường gặp

- **Không có tiếng:** kiểm tra lại đầu ra âm thanh trên TV, rồi rút cáp ra cắm lại khi cả hai thiết bị đang bật.
- **Remote TV không chỉnh được âm lượng loa:** tắt CEC trên TV, khởi động lại, rồi bật lại.
- **Tiếng bị ngắt quãng:** thử một sợi cáp khác. Cáp HDMI kém chất lượng là nguyên nhân phổ biến nhất.

Chỉ ba bước, và từ tối nay bộ phim bạn yêu thích sẽ nghe khác hẳn.

## Câu hỏi thường gặp

**Có cần cấu hình gì trên đầu thu hay máy chơi game không?** Thường là không. Chỉ cần các thiết bị này cắm vào TV, TV sẽ chuyển âm thanh của chúng ra loa qua ARC. Nếu cắm máy chơi game trực tiếp vào loa thì cần chọn đúng nguồn vào trên loa.

**Dùng Bluetooth nối TV với loa có được không?** Được, nhưng Bluetooth có độ trễ cao hơn và dễ lệch tiếng hình khi xem phim. HDMI ARC vẫn là lựa chọn ổn định nhất, đặc biệt với các cảnh hội thoại cần khớp khẩu hình.

**Một TV có ghép được hai loa Alokio cùng lúc không?** Có. Bạn nối Sông Hương qua HDMI ARC, sau đó ghép không dây thêm Sơn Đoòng làm loa siêu trầm, hoặc hai loa Hội An làm loa sau trong ứng dụng Alokio.`,
  },
  {
    slug: 'cach-chon-loa-keo-3-4-hay-5-tac',
    title: 'Cách chọn loa kéo 3, 4 hay 5 tấc cho đúng nhu cầu',
    excerpt: '"Tấc" là gì, và vì sao loa kéo 5 tấc không phải lúc nào cũng tốt hơn.',
    cover: 'karaoke', tags: ['Karaoke', 'Tư vấn'], products: ['k-ak18', 'k-g95', 'k-vip12'], days: 6,
    body: `Đi mua loa kéo, câu đầu tiên người bán thường hỏi là "anh chị lấy loại mấy tấc?". Nhiều người nghĩ cứ số càng lớn thì càng hay, nên mua ngay loại 5 tấc to nhất. Nhưng sau vài tuần lại thấy loa quá nặng để kéo đi, quá to cho phòng khách, và tiếng bass dội làm hàng xóm sang gõ cửa. Bài viết này giúp bạn chọn đúng ngay từ đầu.

![AL-AK18 trên sân hiên: bass 5 tấc, họng kèn treble và hai micro không dây.](/img/blog/karaoke-1.webp)

## "Tấc" là gì?

"Tấc" là đơn vị đo truyền thống, một tấc bằng 10 cm. Khi nói "loa kéo 4 tấc", người ta muốn nói đường kính củ loa bass vào khoảng 40 cm, tương đương 15 inch. Loa 5 tấc có củ bass khoảng 50 cm, còn 3 tấc khoảng 30 cm.

Củ bass càng lớn thì đẩy được càng nhiều không khí, nên tiếng trầm càng sâu và mạnh. Nhưng đi kèm là thùng loa to hơn, nặng hơn và cần ampli khoẻ hơn.

## Loa kéo 3 tấc: gọn nhẹ, linh hoạt

- **Phù hợp:** phòng khách nhỏ, phòng trọ, căn hộ chung cư, mang đi dã ngoại bằng xe máy.
- **Ưu điểm:** nhẹ (thường dưới 12 kg), pin lâu, tiếng gọn không làm phiền hàng xóm.
- **Hạn chế:** bass không sâu, không đủ cho sân rộng hay đám đông trên 30 người.

## Loa kéo 4 tấc: lựa chọn cân bằng nhất

- **Phù hợp:** phòng khách gia đình, sân nhà, tiệc sinh nhật 20–50 người, quán cà phê nhỏ.
- **Ưu điểm:** bass đủ dày để hát nhạc trẻ và bolero đều hay, vẫn kéo đi được bằng một người.
- **Gợi ý:** AL-G95 với thùng gỗ dày và bass 4 tấc là mẫu bán chạy nhất của Alokio, vì nó vừa với hầu hết gia đình Việt.

## Loa kéo 5 tấc: cho không gian lớn

- **Phù hợp:** sân rộng, đám cưới nhỏ, sự kiện ngoài trời, hội trường, quán karaoke bình dân.
- **Ưu điểm:** bass rất mạnh, công suất lớn, phủ được không gian rộng.
- **Hạn chế:** nặng (thường trên 25 kg), cần ắc quy dung lượng lớn, và trong phòng kín dưới 20 m² dễ bị ù tiếng.

AL-AK18 là mẫu 5 tấc của Alokio, dùng ba đường tiếng với họng kèn treble riêng, nên dù bass mạnh nhưng giọng hát vẫn sáng và rõ.

## Đừng chỉ nhìn kích thước bass

Hai chiếc loa cùng 4 tấc có thể nghe khác nhau hoàn toàn. Hãy để ý thêm:

- **Chất liệu thùng:** thùng gỗ dày cho tiếng chắc và ít rè hơn thùng nhựa.
- **Số đường tiếng:** loa có treble riêng (hai hoặc ba đường tiếng) cho giọng hát rõ hơn loa toàn dải.
- **Micro đi kèm:** micro UHF ít nhiễu và ít hú hơn micro VHF giá rẻ.
- **Ắc quy:** dung lượng bao nhiêu Ah và có thay riêng được không.
- **Bánh xe và tay kéo:** bánh cao su to, tay kéo nhôm chắc chắn sẽ giúp bạn đỡ vất vả mỗi lần di chuyển.

![Bộ micro UHF đi kèm, tay cầm nặng tay, lưới thép chống hú.](/img/blog/karaoke-2.webp)

## Bảng chọn nhanh

- **Phòng dưới 15 m², ít người:** 3 tấc.
- **Phòng khách 15–30 m², gia đình 5–15 người:** 4 tấc.
- **Sân nhà, tiệc 20–50 người:** 4 tấc công suất lớn, hoặc 5 tấc.
- **Ngoài trời, trên 50 người:** 5 tấc, ưu tiên ba đường tiếng.

## Lời khuyên cuối cùng

Hãy nghĩ về nơi bạn dùng loa nhiều nhất chứ không phải dịp lớn nhất trong năm. Nếu chín tối trong mười tối bạn hát trong phòng khách, loa 4 tấc sẽ làm bạn hài lòng hơn một chiếc 5 tấc chỉ thực sự toả sáng vào đám cưới mỗi năm một lần. Còn nếu vẫn phân vân, hãy dùng mục "Kích thước thật" trên trang chủ để xem từng mẫu đặt cạnh người cao 1,7 m trong một phòng khách thật.

## Câu hỏi thường gặp

**Loa kéo có dùng để nghe nhạc thường ngày được không?** Được, nhưng hãy giảm bass nhạc xuống một chút khi mở trong nhà. Loa kéo được chỉnh âm để phục vụ giọng hát và không gian rộng, nên ở âm lượng nhỏ trong phòng kín đôi khi sẽ dư trầm.

**Loa 5 tấc có tốn pin hơn nhiều không?** Có. Củ bass lớn cần nhiều năng lượng hơn, nên các mẫu 5 tấc thường đi kèm ắc quy dung lượng lớn. Trong điều kiện hát gia đình, AL-AK18 vẫn đạt khoảng 5–7 giờ mỗi lần sạc.

**Có nên mua thêm micro thứ ba?** Nếu nhà bạn hay hát song ca kèm bè, một micro dự phòng rất tiện. Bộ micro UHF Alokio dùng tần số riêng nên không bị nhiễu chéo với micro đi kèm loa.`,
  },
  {
    slug: 'chinh-echo-bass-de-hat-karaoke-hay',
    title: 'Chỉnh echo, bass để hát karaoke hay hơn',
    excerpt: 'Ba núm vặn quan trọng nhất trên loa kéo và cách vặn chúng.',
    cover: 'knobs', tags: ['Karaoke', 'Hướng dẫn'], products: ['k-ak18', 'k-vb71'], days: 12,
    body: `Cùng một chiếc loa kéo, có người hát nghe như ca sĩ, có người hát nghe như đang gọi điện trong nhà tắm. Phần lớn khác biệt không nằm ở giọng mà nằm ở cách vặn mấy núm trên bảng điều khiển. Bài viết này giải thích từng núm, và đưa ra một cấu hình khởi đầu mà bạn có thể áp dụng ngay tối nay.

![Cận cảnh bảng điều khiển: màn hình, núm echo, bass, treble trên mặt trên loa kéo.](/img/blog/knobs-1.webp)

## Hiểu bảng điều khiển trước khi vặn

Trên loa kéo Alokio thường có hai nhóm núm:

- **Nhóm nhạc (Music):** chỉnh âm lượng, bass và treble của nhạc nền.
- **Nhóm micro (Mic):** chỉnh âm lượng, bass, treble và echo của giọng hát.

Một lỗi phổ biến là chỉnh bass nhạc nhưng quên rằng giọng hát có núm bass riêng. Hãy luôn kiểm tra mình đang vặn núm của nhóm nào.

## Echo: gia vị cho giọng hát

Echo tạo cảm giác giọng hát có không gian, như đang đứng trên sân khấu. Một chút echo làm giọng dày và mượt hơn, che bớt những chỗ hụt hơi. Quá nhiều echo thì giọng bị nhoè, chữ này chồng lên chữ kia.

- **Nhạc chậm, bolero, ballad:** echo khoảng 40–50%, độ trễ (delay) dài.
- **Nhạc trẻ, pop:** echo khoảng 25–35%, độ trễ trung bình.
- **Nhạc nhanh, rap:** echo dưới 20% hoặc tắt hẳn để giữ rõ chữ.

Nếu loa có núm **Repeat**, đó là số lần tiếng vọng lặp lại. Để repeat thấp với nhạc nhanh và cao hơn với nhạc chậm.

## Bass micro: ấm nhưng đừng ù

Bass micro làm giọng ấm và dày, đặc biệt hữu ích với giọng nữ hoặc giọng mỏng. Nhưng micro đặt gần miệng vốn đã có hiệu ứng tăng trầm (proximity effect), nên vặn bass micro quá cao sẽ khiến giọng ù như hát qua chăn.

Hãy bắt đầu ở mức giữa (12 giờ trên mặt núm), hát thử một câu, rồi giảm dần đến khi giọng vừa ấm vừa rõ chữ.

## Treble micro: độ sáng của giọng

Treble quyết định giọng hát có "sáng" và nổi lên trên nhạc nền hay không. Thiếu treble, giọng chìm. Thừa treble, giọng chói, tiếng "s" và "x" rít lên và dễ gây hú.

- Giọng nam trầm: tăng treble nhẹ, khoảng 1–2 giờ trên mặt núm.
- Giọng nữ cao: giữ treble ở giữa hoặc giảm nhẹ.

## Cấu hình khởi đầu cho phòng khách

- Âm lượng nhạc: 40%. Âm lượng micro: cao hơn nhạc một chút.
- Bass nhạc: 1 giờ. Treble nhạc: 12 giờ.
- Bass micro: 11 giờ. Treble micro: 12–1 giờ.
- Echo: 35%. Repeat: 30%.

Từ cấu hình này, hãy hát thử điệp khúc một bài quen thuộc và điều chỉnh từng núm một, mỗi lần chỉ vặn một núm.

![Mặt trước loa kéo: lưới thép sơn tĩnh điện, viền đèn LED đổi màu theo nhạc.](/img/blog/knobs-2.webp)

## Chống hú: vị trí quan trọng hơn núm vặn

Tiếng hú (feedback) xảy ra khi micro thu lại chính âm thanh phát ra từ loa, khuếch đại lên, rồi lại thu vào, tạo thành vòng lặp. Để tránh hú:

- Không chĩa micro vào mặt loa, và đứng ở phía trước hoặc bên cạnh loa thay vì phía trước mặt loa.
- Giữ khoảng cách ít nhất 1–2 mét giữa người hát và loa.
- Nếu hú ở tiếng cao, giảm treble micro. Nếu hú ở tiếng trầm, giảm bass micro.
- Cầm micro ở thân, không bịt lưới micro bằng tay.

## Thử ngay trên website

Ở chương "Bên trong Alokio" trên trang chủ, tab "Âm thanh" cho bạn vặn thử bass và treble trên một chiếc loa 3D và nghe thay đổi ngay lập tức. Đó là cách nhanh nhất để "luyện tai" trước khi cầm micro thật. Chúc bạn những buổi hát thật vui.

## Câu hỏi thường gặp

**Vì sao giọng mình nghe hay trên loa nhà bạn nhưng dở trên loa nhà mình?** Thường là do echo và treble đang để rất khác nhau, hoặc phòng nhà bạn có nhiều đồ vải hấp thụ âm hơn. Hãy ghi lại cấu hình bạn thấy hay rồi áp dụng lại trên loa của mình.

**Có nên tắt hẳn echo không?** Với nhạc nhanh hoặc khi muốn luyện giọng, tắt echo giúp nghe rõ lỗi để sửa. Còn khi hát vui cùng gia đình, một chút echo sẽ làm mọi người tự tin hơn nhiều.

**Micro có cần chỉnh riêng cho từng người?** Nếu có thể, hãy dành micro 1 cho giọng nam và micro 2 cho giọng nữ, mỗi micro chỉnh bass và treble riêng. Như vậy không ai phải vặn lại núm mỗi khi chuyền micro.`,
  },
  {
    slug: 'bao-quan-ac-quy-loa-keo-dung-cach',
    title: 'Bảo quản ắc quy loa kéo đúng cách',
    excerpt: 'Ắc quy là bộ phận dễ hỏng nhất của loa kéo. Vài thói quen nhỏ giúp kéo dài tuổi thọ.',
    cover: 'battery', tags: ['Karaoke', 'Bảo quản'], products: ['k-acc-acquy', 'k-g95'], days: 18,
    body: `Khi một chiếc loa kéo "yếu dần", hát được nửa buổi đã tắt, thì phần lớn nguyên nhân không nằm ở ampli hay củ loa mà nằm ở ắc quy. Tin tốt là ắc quy hỏng chủ yếu do thói quen sử dụng, và chỉ cần thay đổi vài điều nhỏ là có thể kéo dài tuổi thọ thêm một đến hai năm.

![Bình ắc quy 12 V thay thế: nhỏ gọn, cực đồng, có quai xách.](/img/blog/battery-1.webp)

## Ắc quy trong loa kéo là loại gì?

Phần lớn loa kéo, kể cả các mẫu của Alokio, dùng ắc quy axit-chì kín khí loại 12 V (thường gọi là ắc quy khô hay AGM), dung lượng từ 7 đến 20 Ah tuỳ mẫu. Loại này rẻ, chịu được dòng xả lớn khi bass đánh mạnh, nhưng có một điểm yếu: rất "ghét" bị để cạn.

## Thói quen 1: Sạc đầy ngay sau khi dùng

Khi ắc quy axit-chì nằm ở trạng thái cạn, các tinh thể sunfat chì bắt đầu cứng lại trên bản cực (gọi là hiện tượng sunfat hoá). Càng để lâu, tinh thể càng cứng và càng khó sạc lại, dung lượng giảm vĩnh viễn.

Vì vậy, quy tắc quan trọng nhất là: **dùng xong là sạc**, kể cả khi đã khuya. Hãy cắm sạc trước khi đi ngủ, sáng hôm sau rút ra.

## Thói quen 2: Đừng xả quá cạn

Đừng hát đến khi loa tự tắt. Khi đèn báo pin chuyển sang đỏ hoặc nghe tiếng bắt đầu méo ở đoạn bass mạnh, đó là lúc nên cắm sạc hoặc dừng lại. Việc xả cạn thường xuyên có thể khiến số chu kỳ sạc của ắc quy giảm đi một nửa.

## Thói quen 3: Sạc định kỳ khi không dùng

Ắc quy tự xả chậm ngay cả khi loa tắt. Nếu bạn cất loa vài tháng, chẳng hạn chỉ dùng dịp Tết, hãy:

- Sạc đầy trước khi cất.
- Sạc bổ sung khoảng 4–6 tuần một lần.
- Nếu loa có công tắc ngắt nguồn tổng, hãy gạt về OFF để giảm hao điện chờ.

## Thói quen 4: Tránh nóng và ẩm

Nhiệt độ cao làm ắc quy lão hoá nhanh hơn rất nhiều. Đừng để loa trong cốp ô tô giữa trưa hè hay ngoài ban công dưới nắng. Ẩm ướt thì gây gỉ cọc bình và mạch sạc.

![Loa kéo cất trong góc khô ráo, tránh nắng và ẩm để ắc quy bền lâu.](/img/blog/battery-2.webp)

## Thói quen 5: Dùng đúng bộ sạc

Bộ sạc đi kèm loa Alokio có mạch tự ngắt khi đầy và chế độ sạc duy trì. Dùng bộ sạc trôi nổi có điện áp không chuẩn có thể làm phồng bình hoặc sạc không đầy. Nếu mất sạc, hãy mua bộ sạc thay thế chính hãng hoặc mang loa đến trung tâm bảo hành.

## Dấu hiệu cần thay ắc quy

- Thời gian hát giảm còn dưới một nửa so với lúc mới mua.
- Sạc cả đêm nhưng đèn báo vẫn không lên đầy.
- Loa tự tắt khi bass đánh mạnh dù đèn báo còn pin.
- Bình ắc quy bị phồng, nứt hoặc có mùi lạ. Trường hợp này hãy ngưng dùng ngay.

## Thay ắc quy có khó không?

Với các mẫu loa kéo Alokio, khoang ắc quy nằm ở mặt sau, chỉ cần tháo bốn con vít và rút giắc cắm nhanh. Bình thay thế có sẵn trong mục Phụ kiện, cùng kích thước và có quai xách. Nếu không tự tin, bạn có thể mang loa đến bất kỳ điểm bảo hành nào để được thay miễn phí công.

Ắc quy cũ cần được thu gom đúng nơi quy định vì chứa chì và axit. Các cửa hàng Alokio nhận lại bình cũ khi bạn mua bình mới.

## Tóm tắt

- Dùng xong là sạc, đừng để loa cạn qua đêm.
- Không hát đến khi loa tự tắt.
- Cất lâu thì sạc bổ sung mỗi 4–6 tuần.
- Tránh nắng, nóng và ẩm.
- Dùng bộ sạc chính hãng.

Chăm sóc ắc quy đúng cách, chiếc loa kéo của bạn sẽ hát bền bỉ qua rất nhiều mùa tiệc.

## Câu hỏi thường gặp

**Vừa sạc vừa hát có hại ắc quy không?** Không hại nếu dùng bộ sạc chính hãng, nhưng ắc quy sẽ lâu đầy hơn và nóng hơn một chút. Nếu hát trong nhà, cắm sạc trong lúc hát là cách tốt để không bao giờ xả cạn.

**Có thể thay ắc quy axit-chì bằng pin lithium không?** Về kỹ thuật là có thể, nhưng cần mạch sạc và mạch bảo vệ phù hợp với pin lithium. Đừng tự thay khi chưa có hướng dẫn, vì sạc sai loại pin có thể gây nguy hiểm.`,
  },
];
