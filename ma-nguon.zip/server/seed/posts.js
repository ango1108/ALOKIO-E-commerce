// Bài viết blog mẫu (Markdown đơn giản: "## " là tiêu đề mục, dòng trống tách đoạn, "- " là gạch đầu dòng)
export const POSTS = [
  {
    slug: 'cau-chuyen-son-mai-va-kham-trai',
    title: 'Câu chuyện sơn mài và khảm trai trên Alokio Luxe',
    excerpt: 'Vì sao một chiếc loa bluetooth lại cần đến hai chất liệu thủ công lâu đời nhất của Việt Nam?',
    cover: 'material', tags: ['Alokio Luxe', 'Chất liệu'], products: ['p-halong', 'p-hoian'], days: 4,
    body: `Khi bắt đầu phác thảo Alokio Luxe, câu hỏi đầu tiên không phải là "bao nhiêu watt" mà là "chiếc loa này sẽ trông thế nào khi tắt nhạc". Một chiếc loa tốt nằm trong phòng bạn cả ngày, nhưng thời gian phát nhạc chỉ chiếm vài giờ. Phần còn lại, nó là một món đồ trang trí.

![Hạ Long Ngọc Trai: viền nhôm champagne phay xước ôm lấy mặt vải lanh dệt kim.](/img/blog/material-1.webp)

## Sơn mài: chiều sâu của bóng tối

Sơn mài truyền thống được phủ nhiều lớp, mỗi lớp khô rồi lại mài, cho đến khi bề mặt có chiều sâu như nhìn xuống mặt hồ lúc chạng vạng. Trên Alokio Luxe, chúng tôi dùng tinh thần đó cho phần thân: màu Huyền là đen ánh xanh, Ngọc Trai là trắng ngà ấm, Sương Sớm là xanh pastel như sương trên mặt nước.

## Khảm trai: ánh sáng đổi màu theo góc nhìn

Khảm trai là kỹ thuật ghép những mảnh vỏ trai mỏng lên bề mặt. Mỗi mảnh phản chiếu ánh sáng theo một cách riêng, nên khi bạn đi quanh chiếc loa, sắc màu thay đổi liên tục từ hồng sang xanh, từ bạc sang vàng. Trên Hạ Long, vòng khảm trai bao quanh núm điều khiển để mỗi lần bạn chỉnh âm lượng, ánh trai lại chuyển động.

![Núm vặn champagne trên Hội An Óc Chó, vân gỗ thật chạy dọc hai bên hông.](/img/blog/material-2.webp)

## Vì sao không dùng nhựa giả da?

Vì chúng tôi muốn Alokio Luxe có một bản sắc riêng, không giống bất kỳ thương hiệu loa nào trên thị trường. Vải lanh, nhôm champagne, gỗ óc chó và sơn mài là những chất liệu già đi một cách đẹp đẽ, càng dùng lâu càng có hồn.

- Sơn mài: thân loa, hông loa tại gia
- Khảm trai: viền núm và logo
- Vải lanh dệt kim: mặt lưới
- Nhôm phay champagne: núm vặn, khung`,
  },
  {
    slug: 'chon-loa-bluetooth-cao-cap-cho-phong-khach',
    title: 'Chọn loa bluetooth cao cấp cho phòng khách: 5 điều cần biết',
    excerpt: 'Diện tích phòng, công suất, kết nối TV và cả… màu sắc. Hướng dẫn chọn loa tại gia không hối tiếc.',
    cover: 'home', tags: ['Tư vấn', 'Loa tại gia'], products: ['p-hoian', 'p-hue', 'p-trangan'], days: 9,
    body: `Một chiếc loa tại gia đẹp có thể là điểm nhấn của cả phòng khách. Nhưng chọn sai kích thước thì hoặc là thiếu tiếng, hoặc là lãng phí. Dưới đây là năm điều nên cân nhắc.

![Hội An đặt trên tủ gỗ óc chó, đủ lấp đầy phòng khách 20–25 m².](/img/blog/home-1.webp)

## 1. Diện tích phòng

Phòng dưới 15 m² chỉ cần khoảng 40–60 W như Hội An. Phòng 15–30 m² nên chọn 80 W như Huế. Phòng khách rộng trên 25 m² hoặc không gian mở nên chọn loa ba đường tiếng như Tràng An 150 W.

## 2. Bạn có nối TV không?

Nếu muốn dùng loa cho cả TV, hãy chọn loa có HDMI ARC. Cổng này cho phép dùng remote TV để chỉnh âm lượng loa.

## 3. Đĩa than và nhạc có dây

Cổng RCA là lựa chọn cho người chơi đĩa than hoặc đầu CD. Hãy nhớ mâm đĩa cần có pre-amp phono.

## 4. Núm vặn hay ứng dụng?

Núm vặn analog cho cảm giác trực quan: chỉnh bass, treble bằng tay ngay lập tức. Ứng dụng tiện khi bạn ngồi xa loa. Dòng Luxe có cả hai.

![Tràng An màu Huyền cạnh cửa sổ: cặp loa stereo cho phòng khách lớn.](/img/blog/home-2.webp)

## 5. Màu sắc và chất liệu

Đừng xem nhẹ yếu tố thẩm mỹ. Loa sẽ ở đó mỗi ngày. Gỗ óc chó hợp nội thất ấm, Ngọc Trai hợp phòng sáng, Huyền hợp phong cách tối giản.`,
  },
  {
    slug: 'stereo-360-la-gi',
    title: 'Stereo 360° là gì và vì sao nó quan trọng với loa di động?',
    excerpt: 'Ngồi ở đâu quanh loa cũng nghe rõ: bí mật nằm ở cách bố trí driver.',
    cover: 'wave', tags: ['Công nghệ'], products: ['p-song', 'p-halong'], days: 15,
    body: `Loa di động thường được đặt giữa nhóm bạn: trên bàn picnic, cạnh hồ bơi, giữa bãi cát. Lúc đó không có "phía trước" của loa.

![Sóng nằm trên khăn tắm, nắng chiều phản chiếu trên lưới nhôm ôm ba mặt.](/img/blog/wave-1.webp)

## Stereo truyền thống

Loa stereo thông thường có kênh trái và kênh phải hướng về phía trước. Người ngồi phía sau sẽ nghe thiếu chi tiết.

## Stereo 360°

Với stereo 360°, các driver được bố trí để âm thanh toả đều mọi hướng nhưng vẫn giữ được cảm giác trái – phải. Sóng và Hạ Long dùng cách bố trí này.

![Hạ Long trên bãi cát: kháng nước IP67, chịu được cát và hơi muối.](/img/blog/wave-2.webp)

## Khi nào nên chọn?

- Bạn hay nghe nhạc ngoài trời, nhiều người
- Bạn đặt loa ở giữa phòng
- Bạn không muốn xoay loa mỗi khi đổi chỗ ngồi`,
  },
  {
    slug: 'ip67-va-chiec-loa-noi-tren-mat-nuoc',
    title: 'IP67 và chiếc loa nổi trên mặt nước',
    excerpt: 'IP67 khác IP68 thế nào, và tại sao chúng tôi muốn Hạ Long nổi được.',
    cover: 'water', tags: ['Công nghệ', 'Alokio Luxe'], products: ['p-giot', 'p-halong'], days: 21,
    body: `Chuẩn IP gồm hai chữ số: số thứ nhất là khả năng chống bụi (tối đa 6), số thứ hai là khả năng chống nước.

![Giọt ở mép nước: đủ nhẹ để nổi, đủ kín để không sợ sóng đánh.](/img/blog/water-1.webp)

## IP67

Chống bụi hoàn toàn và chịu được ngâm nước ở độ sâu 1 m trong 30 phút. Đủ để loa sống sót khi rơi xuống hồ bơi.

## IP68

Chịu ngâm sâu hơn và lâu hơn theo điều kiện nhà sản xuất công bố (ví dụ 1,5 m).

![Hạ Long trên thành hồ bơi đá travertine, quai da kem chống thấm.](/img/blog/water-2.webp)

## Nổi trên mặt nước

Chống nước là một chuyện, nổi được là chuyện khác: cần phân bố khối lượng và có khoang khí. Trong thiết kế, Giọt và Hạ Long được tính toán để nổi, giống hình ảnh ở trang chủ của chúng tôi.

Lưu ý: không sạc loa khi cổng còn ướt.`,
  },
  {
    slug: 'ghep-loa-tai-gia-voi-tv-qua-hdmi-arc',
    title: 'Ghép loa tại gia với TV qua HDMI ARC trong 3 bước',
    excerpt: 'Một sợi cáp, một remote, âm thanh rạp phim cho phòng khách.',
    cover: 'bar', tags: ['Hướng dẫn'], products: ['p-trangan', 'p-songhuong'], days: 28,
    body: `HDMI ARC (Audio Return Channel) cho phép TV gửi âm thanh ngược về loa qua chính sợi cáp HDMI.

![Sông Hương dưới TV: dải loa dài 65 cm, cao chưa tới 7 cm, không che màn hình.](/img/blog/bar-1.webp)

## Bước 1: Tìm đúng cổng

Trên TV, tìm cổng HDMI có ghi ARC hoặc eARC. Cắm một đầu cáp vào đó, đầu còn lại vào cổng HDMI của Tràng An hoặc Sông Hương.

## Bước 2: Bật HDMI-CEC

Trong cài đặt TV, bật HDMI-CEC (mỗi hãng gọi một tên khác nhau). Tính năng này giúp remote TV điều khiển được âm lượng loa.

![Buổi tối xem phim: một thanh loa thay cả dàn âm thanh vòm.](/img/blog/bar-2.webp)

## Bước 3: Chọn đầu ra âm thanh

Chọn đầu ra âm thanh là "HDMI ARC" hoặc "Loa ngoài". Xong!`,
  },
  {
    slug: 'cach-chon-loa-keo-3-4-hay-5-tac',
    title: 'Cách chọn loa kéo 3, 4 hay 5 tấc cho đúng nhu cầu',
    excerpt: '"Tấc" là gì, và vì sao loa kéo 5 tấc không phải lúc nào cũng tốt hơn.',
    cover: 'karaoke', tags: ['Karaoke', 'Tư vấn'], products: ['k-ak18', 'k-g95', 'k-vip12'], days: 6,
    body: `Trong giới loa kéo, "tấc" là đơn vị chỉ đường kính loa bass: 3 tấc khoảng 30 cm, 4 tấc khoảng 40 cm, 5 tấc khoảng 50 cm.

![AL-AK18 trên sân hiên: bass 5 tấc, họng kèn treble và hai micro không dây.](/img/blog/karaoke-1.webp)

## Loa kéo 3 tấc

Gọn nhẹ, dễ mang lên xuống cầu thang, đủ cho căn hộ và phòng karaoke nhỏ. Ví dụ: Alokio AL-VIP12.

## Loa kéo 4 tấc

Phân khúc "quốc dân": cân bằng giữa trọng lượng, công suất và giá. Ví dụ: AL-G95, AL-R95, VB-1.

## Loa kéo 5 tấc

Bass sâu và mạnh, phù hợp sân vườn, tiệc đông người, sự kiện nhỏ. Ví dụ: AL-AK18, WML-GD18. Đổi lại, loa nặng hơn (thường từ 25–30 kg).

![Bộ micro UHF đi kèm, tay cầm nặng tay, lưới thép chống hú.](/img/blog/karaoke-2.webp)

## Lời khuyên

Hãy chọn theo không gian sử dụng nhiều nhất, không phải theo con số lớn nhất.`,
  },
  {
    slug: 'chinh-echo-bass-de-hat-karaoke-hay',
    title: 'Chỉnh echo, bass để hát karaoke hay hơn',
    excerpt: 'Ba núm vặn quan trọng nhất trên loa kéo và cách vặn chúng.',
    cover: 'knobs', tags: ['Karaoke', 'Hướng dẫn'], products: ['k-ak18', 'k-vb71'], days: 12,
    body: `Bạn có thể thử vặn núm trực tiếp ở phần "Vặn thử" trên trang chủ của chúng tôi để nghe sự khác biệt.

![Cận cảnh bảng điều khiển: màn hình, núm echo, bass, treble trên mặt trên loa kéo.](/img/blog/knobs-1.webp)

## ECHO

Echo tạo tiếng vang giúp giọng hát mượt hơn. Mức vừa phải là khoảng 30–40%. Quá nhiều sẽ làm lời hát bị nhoè.

## BASS

Bass quá cao làm giọng nam bị đục, dễ hú. Hãy để bass ở mức trung tính rồi tăng dần.

## TREBLE

Treble giúp giọng hát sáng và rõ chữ. Tăng nhẹ nếu phòng có nhiều rèm, sofa (hấp thụ âm cao).

![Mặt trước loa kéo: lưới thép sơn tĩnh điện, viền đèn LED đổi màu theo nhạc.](/img/blog/knobs-2.webp)

## Mẹo chống hú

- Không hướng micro về phía loa
- Giảm MIC VOL trước khi tăng MASTER
- Đứng phía sau hoặc bên cạnh loa`,
  },
  {
    slug: 'bao-quan-ac-quy-loa-keo-dung-cach',
    title: 'Bảo quản ắc quy loa kéo đúng cách',
    excerpt: 'Ắc quy là bộ phận dễ hỏng nhất của loa kéo. Vài thói quen nhỏ giúp kéo dài tuổi thọ.',
    cover: 'battery', tags: ['Karaoke', 'Bảo quản'], products: ['k-acc-acquy', 'k-g95'], days: 18,
    body: `Phần lớn loa kéo dùng ắc quy 12 V. Ắc quy bị chai thường do để cạn kiệt quá lâu.

![Bình ắc quy 12 V thay thế: nhỏ gọn, cực đồng, có quai xách.](/img/blog/battery-1.webp)

## Sạc đầy sau mỗi lần dùng

Đừng để loa cạn pin rồi cất đi vài tuần. Hãy sạc đầy ngay sau khi dùng.

## Sạc định kỳ khi không dùng

Nếu lâu không dùng, hãy sạc lại khoảng 2–4 tuần một lần.

## Tránh nhiệt độ cao

Không để loa trong cốp xe hoặc dưới nắng gắt.

![Loa kéo cất trong góc khô ráo, tránh nắng và ẩm để ắc quy bền lâu.](/img/blog/battery-2.webp)

## Khi nào cần thay?

Khi thời lượng giảm còn dưới một nửa so với lúc mới. Ắc quy thay thế có sẵn trong mục Phụ kiện.`,
  },
];
