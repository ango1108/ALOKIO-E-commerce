// Bản HTML tĩnh: không có thư mục gốc phía máy chủ, mọi đường dẫn tính từ thư mục web.
export const ROOT = '';
export const PUBLIC = '';
