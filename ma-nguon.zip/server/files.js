// Danh sách file có trong thư mục web (tạo tự động khi đóng gói) – thay cho fs.existsSync.
import LIST from './files.json';
const SET = new Set(LIST);
export const hasFile = (...parts) => SET.has(parts.join('/').replace(/\/+/g, '/').replace(/^\//, ''));
