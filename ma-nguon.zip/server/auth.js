// Xác thực GIẢ LẬP (bản HTML tĩnh chạy hoàn toàn trên trình duyệt):
// - Mật khẩu được băm bằng hàm băm đơn giản kèm "muối" (chỉ để minh hoạ, không phải bảo mật thật).
// - "Phiên đăng nhập" là một token có chữ ký, lưu trong localStorage thay cho cookie.
const SECRET = 'alokio-demo-secret';

// Hàm băm 53-bit (cyrb53) – nhanh, đủ cho mục đích demo
export function hash53(str, seed = 0) {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

export function randomHex(n) {
  const a = new Uint8Array(n);
  crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function secret() { return SECRET; }

export function hashPassword(pw) {
  const salt = randomHex(8);
  return `demo$${salt}$${hash53(salt + ':' + pw)}${hash53(pw + ':' + salt, 7)}`;
}

export function verifyPassword(pw, stored) {
  if (!stored || !stored.startsWith('demo$')) return false;
  const [, salt, h] = stored.split('$');
  return h === `${hash53(salt + ':' + pw)}${hash53(pw + ':' + salt, 7)}`;
}

export function sign(value) {
  return (hash53(SECRET + value) + hash53(value + SECRET, 3) + hash53(value, 11)).replace(/[^a-z0-9]/g, '');
}

export function makeToken(userId, days = 7) {
  const exp = Date.now() + days * 864e5;
  const body = `${userId}.${exp}`;
  return `${body}.${sign(body)}`;
}

export function readToken(token) {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [uid, exp, sig] = parts;
  if (sig !== sign(`${uid}.${exp}`)) return null;
  if (Number(exp) < Date.now()) return null;
  return uid;
}

export function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(name, token, maxAgeSec) {
  return `${name}=${encodeURIComponent(token)}; Path=/; Max-Age=${maxAgeSec}`;
}

export const ROLES = {
  admin: { label: 'Quản trị viên', can: ['*'] },
  sales: { label: 'Nhân viên bán hàng', can: ['dashboard', 'orders', 'payments', 'customers', 'chat', 'reviews'] },
  warehouse: { label: 'Kho', can: ['dashboard', 'products', 'inventory', 'orders'] },
};

export function can(user, area) {
  if (!user || !ROLES[user.role]) return false;
  const c = ROLES[user.role].can;
  return c.includes('*') || c.includes(area);
}
