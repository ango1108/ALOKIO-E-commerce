// Logic thương mại dùng chung: giá, giỏ hàng, mã giảm giá, phí vận chuyển, trạng thái đơn.
import { ENGRAVING_PRICE, GIFTBOX_PRICE } from './seed/catalog.js';

export const ORDER_STATUSES = [
  { id: 'pending', label: 'Chờ xác nhận', color: 'warning' },
  { id: 'confirmed', label: 'Đã xác nhận', color: 'info' },
  { id: 'packing', label: 'Đang đóng gói', color: 'info' },
  { id: 'shipping', label: 'Đang giao', color: 'primary' },
  { id: 'completed', label: 'Hoàn thành', color: 'success' },
  { id: 'cancelled', label: 'Đã huỷ', color: 'danger' },
  { id: 'returned', label: 'Hoàn trả', color: 'muted' },
];
export const STATUS_LABEL = Object.fromEntries(ORDER_STATUSES.map((s) => [s.id, s.label]));

// Luồng chuyển trạng thái hợp lệ
export const TRANSITIONS = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['packing', 'cancelled'],
  packing: ['shipping', 'cancelled'],
  shipping: ['completed', 'returned'],
  completed: ['returned'],
  cancelled: [],
  returned: [],
};
export const canTransition = (from, to) => (TRANSITIONS[from] || []).includes(to);

export const PAYMENT_METHODS = [
  { id: 'cod', name: 'Thanh toán khi nhận hàng (COD)' },
  { id: 'vietqr', name: 'Chuyển khoản ngân hàng – VietQR động' },
  { id: 'wallet', name: 'Ví điện tử – QR động' },
  { id: 'card', name: 'Thẻ ATM nội địa / thẻ quốc tế' },
  { id: 'installment', name: 'Trả góp 0% qua thẻ' },
];
export const PAYMENT_LABEL = Object.fromEntries(PAYMENT_METHODS.map((p) => [p.id, p.name]));
export const PAY_STATUS_LABEL = {
  unpaid: 'Chưa thanh toán', pending: 'Chờ thanh toán', scanned: 'Đã quét mã', paid: 'Đã thanh toán',
  deposit: 'Đã đặt cọc', failed: 'Thất bại', expired: 'Hết hạn', refunded: 'Đã hoàn tiền', cod: 'Thu khi giao',
};

export function activeFlash(state, productId, now = Date.now()) {
  for (const f of state.flashSales || []) {
    if (!f.enabled || now < f.startsAt || now > f.endsAt) continue;
    const item = f.items.find((i) => i.productId === productId);
    if (item && item.sold < item.quota) return { sale: f, item };
  }
  return null;
}

export function unitPrice(state, product, options = {}) {
  const flash = activeFlash(state, product.id);
  let base = flash ? flash.item.price : product.price;
  if (options.engraving && product.engraving) base += ENGRAVING_PRICE;
  if (options.giftbox && product.line === 'luxe') base += GIFTBOX_PRICE;
  return { price: base, flash: !!flash };
}

export function shippingFee(state, weightKg, subtotal, method = 'standard') {
  const s = state.settings.shipping;
  if (method === 'express') return s.express;
  if (method === 'pickup') return 0;
  if (subtotal >= s.freeThreshold) return 0;
  const tier = s.tiers.find((t) => weightKg <= t.maxKg) || s.tiers[s.tiers.length - 1];
  return tier.fee;
}

export function checkCoupon(state, code, ctx) {
  if (!code) return { ok: false };
  const c = state.coupons.find((x) => x.code.toUpperCase() === String(code).trim().toUpperCase());
  if (!c || !c.enabled) return { ok: false, error: 'Mã giảm giá không tồn tại hoặc đã tắt.' };
  const now = Date.now();
  if (c.expiresAt && now > c.expiresAt) return { ok: false, error: 'Mã giảm giá đã hết hạn.' };
  if (c.limit && c.used >= c.limit) return { ok: false, error: 'Mã giảm giá đã hết lượt sử dụng.' };
  const base = c.line ? ctx.lines[c.line] || 0 : ctx.subtotal;
  if (c.minOrder && base < c.minOrder) {
    return { ok: false, error: `Đơn ${c.line === 'luxe' ? 'Alokio Luxe ' : c.line === 'karaoke' ? 'loa kéo ' : ''}tối thiểu ${fmt(c.minOrder)} để dùng mã này.` };
  }
  let discount = 0;
  let freeShip = false;
  if (c.type === 'percent') discount = Math.min(Math.round((base * c.value) / 100), c.max || Infinity);
  else if (c.type === 'fixed') discount = Math.min(c.value, base);
  else if (c.type === 'freeship') freeShip = true;
  return { ok: true, coupon: c, discount, freeShip };
}

/**
 * Tính tiền giỏ hàng phía server (nguồn sự thật — client chỉ hiển thị).
 * items: [{productId, finish, qty, options:{engraving, giftbox, knob, strap}}]
 */
export function priceCart(state, items, { coupon, shipping = 'standard', deposit = false } = {}) {
  const lines = [];
  const errors = [];
  const byLine = { luxe: 0, karaoke: 0 };
  let weight = 0;
  for (const it of items || []) {
    const p = state.products.find((x) => x.id === it.productId);
    if (!p || p.hidden) { errors.push('Một sản phẩm không còn bán và đã được bỏ khỏi giỏ.'); continue; }
    const qty = Math.max(1, Math.min(10, Number(it.qty) || 1));
    const finish = p.finishes.includes(it.finish) ? it.finish : p.finishes[0];
    const stock = p.stock[finish] ?? 0;
    const options = sanitizeOptions(p, it.options);
    const { price, flash } = unitPrice(state, p, options);
    if (stock < qty) errors.push(`${p.name} (${finish}) chỉ còn ${stock} sản phẩm.`);
    const total = price * qty;
    byLine[p.line] += total;
    weight += (p.weightKg || 1) * qty;
    lines.push({ productId: p.id, slug: p.slug, name: p.name, line: p.line, finish, qty, price, total, flash, options, stock, image: p.image });
  }
  const subtotal = lines.reduce((s, l) => s + l.total, 0);
  let discount = 0;
  let couponResult = null;
  let freeShip = false;
  if (coupon) {
    couponResult = checkCoupon(state, coupon, { subtotal, lines: byLine });
    if (couponResult.ok) { discount = couponResult.discount; freeShip = couponResult.freeShip; }
  }
  let ship = lines.length ? shippingFee(state, weight, subtotal - discount, shipping) : 0;
  if (freeShip && shipping === 'standard') ship = 0;
  const total = Math.max(0, subtotal - discount + ship);
  const depositAmount = deposit ? Math.round((total * state.settings.payments.depositPercent) / 100 / 1000) * 1000 : 0;
  const freeLeft = Math.max(0, state.settings.shipping.freeThreshold - (subtotal - discount));
  return {
    lines, subtotal, discount, shipping: ship, total, weight: Math.round(weight * 10) / 10, errors,
    coupon: couponResult && couponResult.ok ? couponResult.coupon.code : null,
    couponError: couponResult && !couponResult.ok ? couponResult.error : null,
    depositAmount, freeShipLeft: freeLeft, byLine,
  };
}

function sanitizeOptions(p, o = {}) {
  const out = {};
  if (p.engraving && o.engraving) out.engraving = String(o.engraving).slice(0, 18);
  if (p.line === 'luxe' && o.giftbox) out.giftbox = true;
  if (p.knobs && p.knobs.includes(o.knob)) out.knob = o.knob;
  if (p.straps && p.straps.includes(o.strap)) out.strap = o.strap;
  return out;
}

export function orderCode(date = new Date(), rnd = Math.random) {
  const yy = String(date.getFullYear()).slice(2);
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const tail = Math.floor(rnd() * 9000 + 1000);
  return `AL-${yy}${mm}${dd}-${tail}`;
}

export function fmt(n) {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + ' ₫';
}

export function maskName(name) {
  const parts = name.trim().split(/\s+/);
  const last = parts[parts.length - 1];
  return `${parts[0][0]}. ${last}`;
}
