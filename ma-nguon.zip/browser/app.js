// ALOKIO — "máy chủ giả lập" chạy NGAY TRONG TRÌNH DUYỆT (bản HTML tĩnh, không cần Node.js).
// Mỗi trang .html gọi handle() để dựng giao diện; các nút bấm gọi /api/... cũng được xử lý tại đây.
// Dữ liệu lưu trong localStorage (xem server/db.js).
import { load, db, save, reset } from '../server/db.js';
import { generate } from '../server/seed/index.js';
import { Router, send, json, readBody, redirect } from '../server/http.js';
import { publish, presence } from '../server/bus.js';
import { parseCookies, readToken, makeToken, sessionCookie, hashPassword, verifyPassword, can, ROLES } from '../server/auth.js';
import { priceCart, checkCoupon, canTransition, STATUS_LABEL, ORDER_STATUSES, activeFlash, fmt } from '../server/commerce.js';
import { createOrder, setPaymentStatus, updateOrderStatus, createPaymentSession, paymentPublic, publicOrder, adminOrderSummary, sweepExpired, log } from '../server/services.js';
import { buildVietQR, lanAddress, luhn, TEST_CARDS, WALLETS, paymentSig } from '../server/payments.js';
import { startSimulator, stopSimulator, simulateOrder } from '../server/simulator.js';
import { PROVINCES, WARDS, VN_OUTLINE } from '../server/seed/places.js';
import * as pages from '../server/views/pages.js';
import { homePage } from '../server/views/home.js';
import * as admin from '../server/views/admin.js';
import { siteUrl } from '../server/views/layout.js';
import { FINISHES } from '../server/seed/catalog.js';
import { POSTS } from '../server/seed/posts.js';

const HOST = 'local';
const PORT = 0;
const assetVersion = '1';

// Mỗi lần cập nhật nội dung bài viết, tăng số này: dữ liệu bài viết trong trình duyệt được làm mới
// mà KHÔNG xoá giỏ hàng, đơn hàng hay tài khoản đã có.
const CONTENT_REV = 2;
export function boot() {
  const st = load(() => generate());
  if (st && st.contentRev !== CONTENT_REV) {
    for (const p of st.posts || []) {
      const src = POSTS.find((x) => x.slug === p.slug);
      if (src) Object.assign(p, { title: src.title, excerpt: src.excerpt, body: src.body, cover: src.cover, tags: src.tags, products: src.products });
    }
    st.contentRev = CONTENT_REV; save();
  }
}

const r = new Router();

// ======================= TRANG CỬA HÀNG (render phía server → SEO) =======================
const page = (fn) => async (ctx) => { const out = await fn(ctx); send(ctx.req, ctx.res, out && out.status ? out.status : 200, String(out), 'text/html; charset=utf-8', { 'Cache-Control': 'no-cache' }); };
r.get('/', page(homePage));
r.get('/showroom', page(pages.showroom));
r.get('/cua-hang', page(pages.shop));
r.get('/danh-muc/:slug', page(pages.category));
r.get('/bo-suu-tap/:slug', page(pages.collection));
r.get('/san-pham/:slug', page(pages.product));
r.get('/flash-sale', page(pages.flashSale));
r.get('/tim-kiem', page(pages.search));
r.get('/so-sanh', page(pages.compare));
r.get('/yeu-thich', page(pages.wishlist));
r.get('/gio-hang', page(pages.cartPage));
r.get('/thanh-toan', page(pages.checkout));
r.get('/thanh-toan/:code', page(pages.payPage));
r.get('/sandbox/pay/:id', page(pages.sandbox));
r.get('/dat-hang-thanh-cong/:code', page(pages.success));
r.get('/tra-cuu-don-hang', page(pages.track));
r.get('/tai-khoan', page(pages.account));
r.get('/tai-khoan/don-hang/:code', page(pages.accountOrder));
r.get('/tai-khoan/dang-nhap', page(pages.login));
r.get('/tai-khoan/dang-ky', page(pages.register));
r.get('/tai-khoan/quen-mat-khau', page(pages.forgot));
r.get('/blog', page(pages.blog));
r.get('/blog/:slug', page(pages.post));
r.get('/gioi-thieu', page(pages.about));
r.get('/lien-he', page(pages.contact));
r.get('/ho-tro', page(pages.support));
r.get('/chinh-sach/:slug', page(pages.policy));
r.get('/dieu-khoan', page((ctx) => pages.policy({ ...ctx, params: { slug: 'dieu-khoan' } })));

// ======================= SEO =======================
r.get('/robots.txt', (ctx) => send(ctx.req, ctx.res, 200, `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /tai-khoan\nDisallow: /thanh-toan\nDisallow: /gio-hang\nDisallow: /sandbox\nDisallow: /studio\nDisallow: /api\nSitemap: ${siteUrl()}/sitemap.xml\n`, 'text/plain; charset=utf-8'));
r.get('/sitemap.xml', (ctx) => {
  const s = db();
  const u = (p, pri = 0.6, lm = Date.now()) => `<url><loc>${siteUrl()}${p}</loc><lastmod>${new Date(lm).toISOString().slice(0, 10)}</lastmod><priority>${pri}</priority></url>`;
  const urls = [u('/', 1), u('/cua-hang', 0.9), u('/showroom', 0.8), u('/flash-sale', 0.7), u('/blog', 0.7), u('/gioi-thieu', 0.4), u('/lien-he', 0.4), u('/ho-tro', 0.5), u('/tra-cuu-don-hang', 0.3),
    ...s.collections.map((c) => u('/bo-suu-tap/' + c.slug, 0.85)), ...s.categories.map((c) => u('/danh-muc/' + c.slug, 0.8)),
    ...s.products.filter((p) => !p.hidden).map((p) => u('/san-pham/' + p.slug, 0.9, p.updatedAt || p.createdAt)),
    ...s.posts.map((p) => u('/blog/' + p.slug, 0.6, p.publishedAt)),
    ...['doi-tra', 'bao-hanh', 'van-chuyen', 'bao-mat'].map((x) => u('/chinh-sach/' + x, 0.3))];
  send(ctx.req, ctx.res, 200, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.join('')}</urlset>`, 'application/xml; charset=utf-8');
});
r.get('/site.webmanifest', (ctx) => json(ctx.req, ctx.res, 200, { name: 'Alokio – Âm Thanh Việt', short_name: 'Alokio', start_url: '/', display: 'standalone', background_color: '#F7FAFD', theme_color: '#2B5C94', icons: [{ src: '/img/favicon.svg', sizes: 'any', type: 'image/svg+xml' }] }));

// ======================= API CÔNG KHAI =======================
r.get('/api/products', (ctx) => json(ctx.req, ctx.res, 200, { items: db().products.filter((p) => !p.hidden).map(productPublic) }));
r.get('/api/products/:id', (ctx) => {
  const p = db().products.find((x) => x.id === ctx.params.id || x.slug === ctx.params.id);
  if (!p || p.hidden) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy sản phẩm.' });
  json(ctx.req, ctx.res, 200, productPublic(p));
});
r.post('/api/cart/price', async (ctx) => {
  const b = await readBody(ctx.req);
  const priced = priceCart(db(), b.items || [], { coupon: b.coupon, shipping: b.shipping, deposit: b.deposit });
  json(ctx.req, ctx.res, 200, { ...priced, freeThreshold: db().settings.shipping.freeThreshold, depositMin: db().settings.payments.depositMin });
});
r.post('/api/coupon', async (ctx) => {
  const b = await readBody(ctx.req);
  const priced = priceCart(db(), b.items || [], { coupon: b.code });
  if (!priced.coupon) return json(ctx.req, ctx.res, 400, { error: priced.couponError || 'Mã giảm giá không hợp lệ.' });
  json(ctx.req, ctx.res, 200, { ok: true, code: priced.coupon, discount: priced.discount });
});
r.get('/api/search', (ctx) => {
  const q = norm(ctx.url.searchParams.get('q') || '');
  const s = db();
  const items = [];
  for (const p of s.products) if (!p.hidden && norm(`${p.name} ${p.tagline} ${p.category} ${p.highlights.join(' ')}`).includes(q)) items.push({ href: '/san-pham/' + p.slug, title: p.name, sub: `${fmt(p.price)} · ${p.tagline}`, image: p.image });
  for (const p of s.posts) if (norm(p.title + ' ' + p.excerpt).includes(q)) items.push({ href: '/blog/' + p.slug, title: p.title, sub: 'Cẩm nang' });
  json(ctx.req, ctx.res, 200, { items: items.slice(0, 8) });
});
r.get('/api/recent-orders', (ctx) => {
  const s = db();
  const items = s.orders.filter((o) => o.status !== 'cancelled').slice(0, 5).map((o) => ({ ...publicOrder(o), image: (s.products.find((p) => p.id === o.items[0]?.productId) || {}).image }));
  json(ctx.req, ctx.res, 200, { enabled: s.settings.recentTicker, items });
});
r.get('/api/flash', (ctx) => {
  const now = Date.now();
  const f = db().flashSales.find((x) => x.enabled && now >= x.startsAt && now <= x.endsAt);
  json(ctx.req, ctx.res, 200, { active: f ? { id: f.id, name: f.name, endsAt: f.endsAt, items: f.items } : null });
});
r.get('/api/presence', (ctx) => json(ctx.req, ctx.res, 200, presence()));
r.get('/api/places', (ctx) => json(ctx.req, ctx.res, 200, { provinces: PROVINCES.map(({ code, name }) => ({ code, name })), wards: WARDS }));
r.post('/api/newsletter', async (ctx) => {
  const b = await readBody(ctx.req);
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return json(ctx.req, ctx.res, 400, { error: 'Email chưa đúng định dạng.' });
  const s = db();
  if (!s.newsletter.includes(email)) s.newsletter.push(email);
  save();
  json(ctx.req, ctx.res, 200, { ok: true });
});
r.post('/api/appointment', async (ctx) => {
  const b = await readBody(ctx.req);
  if (!b.name || !/^0\d{9}$/.test(String(b.phone || '').replace(/\s/g, ''))) return json(ctx.req, ctx.res, 400, { error: 'Vui lòng nhập họ tên và số điện thoại hợp lệ (10 số).' });
  db().appointments.unshift({ at: Date.now(), name: String(b.name).slice(0, 80), phone: b.phone, date: b.date, product: b.product, note: String(b.note || '').slice(0, 300) });
  save(); publish('admin.appointment', { name: b.name });
  json(ctx.req, ctx.res, 200, { ok: true });
});
r.post('/api/restock', async (ctx) => {
  const b = await readBody(ctx.req);
  db().restockRequests.unshift({ at: Date.now(), productId: b.productId, finish: b.finish, contact: String(b.contact || '').slice(0, 80) });
  save(); json(ctx.req, ctx.res, 200, { ok: true });
});
r.post('/api/reviews', async (ctx) => {
  const b = await readBody(ctx.req);
  const s = db();
  const p = s.products.find((x) => x.id === b.productId);
  const stars = Math.round(Number(b.stars));
  if (!p || !(stars >= 1 && stars <= 5) || String(b.text || '').trim().length < 10 || !String(b.name || '').trim()) return json(ctx.req, ctx.res, 400, { error: 'Vui lòng chọn số sao, nhập tên và nội dung (ít nhất 10 ký tự).' });
  s.reviews.unshift({ id: 'rv-' + Date.now().toString(36), productId: p.id, name: String(b.name).slice(0, 60), stars, text: String(b.text).slice(0, 800), createdAt: Date.now(), status: 'pending', reply: '', sample: false });
  save(); publish('admin.review', { productId: p.id, name: p.name });
  json(ctx.req, ctx.res, 200, { ok: true, message: 'Cảm ơn bạn! Đánh giá sẽ hiển thị sau khi được duyệt.' });
});

// ---------- Chat ----------
r.post('/api/chat', async (ctx) => {
  const b = await readBody(ctx.req);
  const s = db();
  const text = String(b.text || '').trim().slice(0, 500);
  if (!text) return json(ctx.req, ctx.res, 400, { error: 'Tin nhắn trống.' });
  let c = b.id ? s.chats.find((x) => x.id === b.id) : null;
  let bot = null;
  const now = Date.now();
  if (!c) {
    c = { id: 'ch-' + now.toString(36), name: String(b.name || 'Khách ghé thăm').slice(0, 60), phone: '', status: 'open', unread: 0, createdAt: now, messages: [] };
    s.chats.unshift(c);
    bot = { from: 'bot', text: autoReply(text), at: now + 1 };
  }
  const m = { from: 'customer', text, at: now };
  c.messages.push(m); c.unread++; c.status = 'open'; c.updatedAt = now;
  if (bot) c.messages.push(bot);
  save();
  publish('admin.chat', { chatId: c.id, name: c.name, message: m });
  json(ctx.req, ctx.res, 200, { id: c.id, bot });
});
r.get('/api/chat/:id', (ctx) => {
  const c = db().chats.find((x) => x.id === ctx.params.id);
  if (!c) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy cuộc chat.' });
  json(ctx.req, ctx.res, 200, { id: c.id, messages: c.messages });
});

// ---------- Đặt hàng & thanh toán ----------
r.post('/api/orders', async (ctx) => {
  const b = await readBody(ctx.req);
  const errors = validateCheckout(b);
  if (Object.keys(errors).length) return json(ctx.req, ctx.res, 422, { error: 'Vui lòng kiểm tra lại thông tin.', fields: errors });
  const res = createOrder({
    items: b.items, contact: { name: b.name.trim(), phone: b.phone.replace(/\s/g, ''), email: (b.email || '').trim() },
    address: { name: b.name.trim(), phone: b.phone.replace(/\s/g, ''), province: b.province, ward: b.ward.trim(), street: b.street.trim() },
    shippingMethod: b.shipping, coupon: b.coupon,
    payment: { method: b.method, wallet: b.wallet, deposit: !!b.deposit, installment: b.installment ? { months: Number(b.installment) } : null },
    note: String(b.note || '').slice(0, 300), customerId: ctx.customer?.id || null,
  });
  if (res.error) return json(ctx.req, ctx.res, 400, { error: res.error });
  json(ctx.req, ctx.res, 200, { code: res.order.code, payment: res.payment ? paymentPublic(res.payment) : null, next: res.payment ? `/thanh-toan/${res.order.code}` : `/dat-hang-thanh-cong/${res.order.code}` });
});
r.get('/api/pay/:id', (ctx) => {
  const p = db().payments.find((x) => x.id === ctx.params.id);
  if (!p) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy phiên thanh toán.' });
  json(ctx.req, ctx.res, 200, paymentPublic(p));
});
r.get('/api/pay/:id/qr', (ctx) => {
  const s = db();
  const p = s.payments.find((x) => x.id === ctx.params.id);
  if (!p) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy phiên thanh toán.' });
  const url = (globalThis.__alk ? globalThis.__alk.abs(`/sandbox/pay/${p.id}?sig=${p.sig}`) : `/sandbox/pay/${p.id}?sig=${p.sig}`);
  const vq = s.settings.vietqr;
  const payload = p.method === 'vietqr' || p.method === 'deposit' ? buildVietQR({ bin: vq.bin, account: vq.account, amount: p.amount, content: `ALOKIO ${p.orderCode}` }) : null;
  json(ctx.req, ctx.res, 200, { ...paymentPublic(p), sandboxUrl: url, vietqr: payload, bank: vq, lan: null });
});
r.post('/api/pay/:id/renew', (ctx) => {
  const s = db();
  const p = s.payments.find((x) => x.id === ctx.params.id);
  if (!p) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy phiên thanh toán.' });
  if (p.status === 'paid') return json(ctx.req, ctx.res, 400, { error: 'Đơn đã được thanh toán.' });
  const o = s.orders.find((x) => x.code === p.orderCode);
  p.status = 'cancelled'; save();
  const np = createPaymentSession(o, p.method);
  json(ctx.req, ctx.res, 200, paymentPublic(np));
});
r.post('/api/pay/:id/scan', async (ctx) => {
  const b = await readBody(ctx.req);
  const p = db().payments.find((x) => x.id === ctx.params.id);
  if (!p || b.sig !== p.sig) return json(ctx.req, ctx.res, 403, { error: 'Mã thanh toán không hợp lệ.' });
  if (p.status === 'pending') { p.status = 'scanned'; p.updatedAt = Date.now(); save(); publish('payment.updated', paymentPublic(p)); }
  json(ctx.req, ctx.res, 200, paymentPublic(p));
});
r.post('/api/pay/:id/confirm', async (ctx) => {
  const b = await readBody(ctx.req);
  const p = db().payments.find((x) => x.id === ctx.params.id);
  if (!p || b.sig !== p.sig) return json(ctx.req, ctx.res, 403, { error: 'Mã thanh toán không hợp lệ.' });
  const res = setPaymentStatus(p, b.action === 'reject' ? 'failed' : 'paid', 'Cổng sandbox');
  if (res.error) return json(ctx.req, ctx.res, 400, res);
  json(ctx.req, ctx.res, 200, paymentPublic(p));
});
r.post('/api/pay/:id/card', async (ctx) => {
  const b = await readBody(ctx.req);
  const p = db().payments.find((x) => x.id === ctx.params.id);
  if (!p) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy phiên thanh toán.' });
  const num = String(b.number || '').replace(/\D/g, '');
  const fields = {};
  if (!luhn(num)) fields.number = 'Số thẻ không hợp lệ.';
  const [mm, yy] = String(b.exp || '').split('/').map((x) => Number(x));
  const expOk = mm >= 1 && mm <= 12 && yy >= 0 && new Date(2000 + yy, mm, 0) >= new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  if (!expOk) fields.exp = 'Ngày hết hạn không hợp lệ (MM/YY).';
  if (!/^\d{3,4}$/.test(String(b.cvc || '')) && !num.startsWith('9704')) fields.cvc = 'Mã CVC gồm 3–4 chữ số.';
  if (!String(b.holder || '').trim()) fields.holder = 'Nhập tên in trên thẻ.';
  if (Object.keys(fields).length) return json(ctx.req, ctx.res, 422, { error: 'Thông tin thẻ chưa hợp lệ.', fields });
  const test = TEST_CARDS[num];
  if (!test) return json(ctx.req, ctx.res, 422, { error: 'Sandbox chỉ chấp nhận thẻ thử nghiệm (xem gợi ý bên dưới).', fields: { number: 'Dùng thẻ thử nghiệm.' } });
  // Không lưu số thẻ: chỉ giữ 4 số cuối để hiển thị
  if (b.step === 'otp') {
    if (b.otp !== '123456') return json(ctx.req, ctx.res, 422, { error: 'Mã OTP không đúng (OTP demo: 123456).', fields: { otp: 'OTP không đúng.' } });
    if (!test.ok) { setPaymentStatus(p, 'failed', 'Cổng thẻ sandbox'); return json(ctx.req, ctx.res, 402, { error: test.reason, status: 'failed' }); }
    p.card = { brand: test.brand, last4: num.slice(-4) };
    const res = setPaymentStatus(p, 'paid', 'Cổng thẻ sandbox');
    if (res.error) return json(ctx.req, ctx.res, 400, res);
    return json(ctx.req, ctx.res, 200, { ...paymentPublic(p), status: 'paid' });
  }
  json(ctx.req, ctx.res, 200, { otpRequired: true, brand: test.brand, last4: num.slice(-4) });
});
r.get('/api/orders/:code/status', (ctx) => {
  const o = db().orders.find((x) => x.code === ctx.params.code);
  if (!o) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy đơn hàng.' });
  json(ctx.req, ctx.res, 200, { ...publicOrder(o), payStatus: o.payment.status, timeline: o.timeline.map((t) => ({ ...t, label: STATUS_LABEL[t.status] })) });
});
r.post('/api/track', async (ctx) => {
  const b = await readBody(ctx.req);
  const o = db().orders.find((x) => x.code.toUpperCase() === String(b.code || '').trim().toUpperCase() && x.contact.phone === String(b.phone || '').replace(/\s/g, ''));
  if (!o) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy đơn hàng khớp mã đơn và số điện thoại.' });
  json(ctx.req, ctx.res, 200, { code: o.code });
});

// ---------- Tài khoản khách ----------
r.post('/api/account/login', async (ctx) => {
  const b = await readBody(ctx.req);
  const c = db().customers.find((x) => x.email && x.email.toLowerCase() === String(b.email || '').trim().toLowerCase());
  if (!c || !verifyPassword(String(b.password || ''), c.pass)) return json(ctx.req, ctx.res, 401, { error: 'Email hoặc mật khẩu không đúng.' });
  json(ctx.req, ctx.res, 200, { ok: true, wishlist: c.wishlist || [] }, { 'Set-Cookie': sessionCookie('alk_c', makeToken(c.id), 7 * 86400) });
});
r.post('/api/account/register', async (ctx) => {
  const b = await readBody(ctx.req);
  const fields = {};
  const name = String(b.name || '').trim(), email = String(b.email || '').trim().toLowerCase(), phone = String(b.phone || '').replace(/\s/g, ''), pw = String(b.password || '');
  if (name.length < 2) fields.name = 'Nhập họ tên.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fields.email = 'Email chưa đúng định dạng.';
  if (!/^0\d{9}$/.test(phone)) fields.phone = 'Số điện thoại gồm 10 số, bắt đầu bằng 0.';
  if (pw.length < 8 || !/\d/.test(pw)) fields.password = 'Mật khẩu tối thiểu 8 ký tự và có ít nhất 1 chữ số.';
  const s = db();
  if (s.customers.some((c) => c.email && c.email.toLowerCase() === email)) fields.email = 'Email đã được đăng ký.';
  if (Object.keys(fields).length) return json(ctx.req, ctx.res, 422, { error: 'Vui lòng kiểm tra lại thông tin.', fields });
  const c = { id: 'c-' + Date.now().toString(36), name, email, phone, pass: hashPassword(pw), addresses: [], createdAt: Date.now(), note: '', wishlist: b.wishlist || [] };
  s.customers.push(c); save();
  log(name, 'Đăng ký tài khoản');
  json(ctx.req, ctx.res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('alk_c', makeToken(c.id), 7 * 86400) });
});
r.post('/api/account/logout', (ctx) => json(ctx.req, ctx.res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('alk_c', '', 0) }));
r.post('/api/account/wishlist', async (ctx) => {
  if (!ctx.customer) return json(ctx.req, ctx.res, 401, { error: 'Chưa đăng nhập.' });
  const b = await readBody(ctx.req);
  ctx.customer.wishlist = (b.ids || []).filter((id) => db().products.some((p) => p.id === id)).slice(0, 50); save();
  json(ctx.req, ctx.res, 200, { ok: true });
});
r.post('/api/account/profile', async (ctx) => {
  if (!ctx.customer) return json(ctx.req, ctx.res, 401, { error: 'Chưa đăng nhập.' });
  const b = await readBody(ctx.req);
  const c = ctx.customer;
  if (b.name) c.name = String(b.name).slice(0, 80);
  if (b.phone && /^0\d{9}$/.test(b.phone)) c.phone = b.phone;
  if (b.address && b.address.province && PROVINCES.some((p) => p.code === b.address.province)) {
    const prov = PROVINCES.find((p) => p.code === b.address.province);
    c.addresses = [{ id: 'a1', name: c.name, phone: c.phone, province: prov.code, provinceName: prov.name, ward: String(b.address.ward || '').slice(0, 80), street: String(b.address.street || '').slice(0, 120), default: true }];
  }
  if (b.newPassword) {
    if (!verifyPassword(String(b.oldPassword || ''), c.pass)) return json(ctx.req, ctx.res, 422, { error: 'Mật khẩu hiện tại không đúng.', fields: { oldPassword: 'Không đúng.' } });
    if (String(b.newPassword).length < 8) return json(ctx.req, ctx.res, 422, { error: 'Mật khẩu mới tối thiểu 8 ký tự.', fields: { newPassword: 'Tối thiểu 8 ký tự.' } });
    c.pass = hashPassword(String(b.newPassword));
  }
  save(); json(ctx.req, ctx.res, 200, { ok: true });
});
r.post('/api/account/orders/:code/cancel', (ctx) => {
  if (!ctx.customer) return json(ctx.req, ctx.res, 401, { error: 'Chưa đăng nhập.' });
  const o = db().orders.find((x) => x.code === ctx.params.code && x.customerId === ctx.customer.id);
  if (!o) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy đơn hàng.' });
  if (o.status !== 'pending') return json(ctx.req, ctx.res, 400, { error: 'Chỉ huỷ được đơn đang chờ xác nhận.' });
  const res = updateOrderStatus(o.code, 'cancelled', ctx.customer.name, 'Khách tự huỷ');
  json(ctx.req, ctx.res, res.error ? 400 : 200, res.error ? res : { ok: true });
});

// ======================= ADMIN =======================
r.get('/admin/dang-nhap', (ctx) => send(ctx.req, ctx.res, 200, admin.loginPage(ctx)));
r.post('/api/admin/login', async (ctx) => {
  const b = await readBody(ctx.req);
  const u = db().users.find((x) => x.email === String(b.email || '').trim().toLowerCase());
  if (!u || !verifyPassword(String(b.password || ''), u.pass)) return json(ctx.req, ctx.res, 401, { error: 'Email hoặc mật khẩu không đúng.' });
  log(u.name, 'Đăng nhập trang quản trị');
  json(ctx.req, ctx.res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('alk_a', makeToken(u.id, 1), 86400) });
});
r.post('/api/admin/logout', (ctx) => json(ctx.req, ctx.res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('alk_a', '', 0) }));
const ADMIN_PAGES = ['', 'phan-tich', 'don-hang', 'giao-dich', 'san-pham', 'kho', 'khach-hang', 'chat', 'ma-giam-gia', 'flash-sale', 'danh-gia', 'noi-dung', 'cai-dat', 'nhan-vien'];
for (const p of ADMIN_PAGES) r.get('/admin' + (p ? '/' + p : ''), adminGuard((ctx) => send(ctx.req, ctx.res, 200, admin.shell(ctx, p || 'tong-quan'), 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' })));
r.get('/admin/don-hang/:code', adminGuard((ctx) => send(ctx.req, ctx.res, 200, admin.shell(ctx, 'don-hang', ctx.params.code))));
r.get('/admin/don-hang/:code/in', adminGuard((ctx) => send(ctx.req, ctx.res, 200, admin.invoice(ctx, ctx.params.code, ctx.url.searchParams.get('kieu')))));

r.get('/api/admin/bootstrap', staffApi('dashboard', (ctx) => {
  const s = db();
  json(ctx.req, ctx.res, 200, {
    me: { name: ctx.staff.name, role: ctx.staff.role, roleLabel: ROLES[ctx.staff.role].label, can: ROLES[ctx.staff.role].can },
    statuses: ORDER_STATUSES, settings: s.settings, provinces: PROVINCES, outline: VN_OUTLINE,
    categories: s.categories, presence: presence(),
  });
}));
r.get('/api/admin/stats', staffApi('dashboard', (ctx) => json(ctx.req, ctx.res, 200, stats(Number(ctx.url.searchParams.get('days') || 30)))));
r.get('/api/admin/orders', staffApi('orders', (ctx) => {
  const s = db(); const q = ctx.url.searchParams;
  let list = s.orders;
  const st = q.get('status'), pm = q.get('method'), prov = q.get('province'), term = norm(q.get('q') || ''), from = Number(q.get('from') || 0), to = Number(q.get('to') || 0);
  if (st) list = list.filter((o) => o.status === st);
  if (pm) list = list.filter((o) => o.payment.method === pm);
  if (prov) list = list.filter((o) => o.address.province === prov);
  if (from) list = list.filter((o) => o.createdAt >= from);
  if (to) list = list.filter((o) => o.createdAt <= to);
  if (term) list = list.filter((o) => norm(`${o.code} ${o.contact.name} ${o.contact.phone} ${o.address.provinceName}`).includes(term));
  const sort = q.get('sort') || 'new';
  list = [...list].sort((a, b) => (sort === 'old' ? a.createdAt - b.createdAt : sort === 'total' ? b.total - a.total : b.createdAt - a.createdAt));
  if (q.get('format') === 'csv') {
    const rows = [['Mã đơn', 'Ngày', 'Khách', 'SĐT', 'Tỉnh/TP', 'Trạng thái', 'Thanh toán', 'TT thanh toán', 'Tổng tiền']].concat(list.map((o) => [o.code, new Date(o.createdAt).toLocaleString('vi-VN'), o.contact.name, o.contact.phone, o.address.provinceName, STATUS_LABEL[o.status], o.payment.method, o.payment.status, o.total]));
    const csv = '\uFEFF' + rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\r\n');
    return send(ctx.req, ctx.res, 200, csv, 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="don-hang-alokio.csv"' });
  }
  const limit = Math.min(500, Number(q.get('limit') || 25)), pageN = Math.max(1, Number(q.get('page') || 1));
  json(ctx.req, ctx.res, 200, { total: list.length, items: list.slice((pageN - 1) * limit, pageN * limit).map(adminOrderSummary) });
}));
r.get('/api/admin/orders/:code', staffApi('orders', (ctx) => {
  const o = db().orders.find((x) => x.code === ctx.params.code);
  if (!o) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy đơn hàng.' });
  json(ctx.req, ctx.res, 200, { ...o, payments: db().payments.filter((p) => p.orderCode === o.code).map(paymentPublic), allowed: ORDER_STATUSES.filter((s) => canTransition(o.status, s.id)).map((s) => s.id) });
}));
r.post('/api/admin/orders/:code/status', staffApi('orders', async (ctx) => {
  const b = await readBody(ctx.req);
  const res = updateOrderStatus(ctx.params.code, b.status, ctx.staff.name, String(b.note || '').slice(0, 200));
  json(ctx.req, ctx.res, res.error ? 400 : 200, res.error ? res : { ok: true });
}));
r.post('/api/admin/orders/:code/note', staffApi('orders', async (ctx) => {
  const b = await readBody(ctx.req);
  const o = db().orders.find((x) => x.code === ctx.params.code);
  if (!o || !String(b.text || '').trim()) return json(ctx.req, ctx.res, 400, { error: 'Nội dung ghi chú trống.' });
  o.internalNotes.push({ at: Date.now(), by: ctx.staff.name, text: String(b.text).slice(0, 400) }); save();
  json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/payments', staffApi('payments', (ctx) => {
  const q = ctx.url.searchParams; let list = db().payments;
  if (q.get('status')) list = list.filter((p) => p.status === q.get('status'));
  if (q.get('method')) list = list.filter((p) => p.method === q.get('method'));
  json(ctx.req, ctx.res, 200, { total: list.length, items: list.slice(0, 200).map((p) => ({ ...paymentPublic(p), createdAt: p.createdAt, card: p.card || null })) });
}));
r.post('/api/admin/payments/:id/mark', staffApi('payments', async (ctx) => {
  const b = await readBody(ctx.req);
  const p = db().payments.find((x) => x.id === ctx.params.id);
  if (!p) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy giao dịch.' });
  const res = setPaymentStatus(p, b.status === 'refunded' ? 'refunded' : 'paid', ctx.staff.name);
  json(ctx.req, ctx.res, res.error ? 400 : 200, res);
}));
r.get('/api/admin/products', staffApi('products', (ctx) => json(ctx.req, ctx.res, 200, { items: db().products })));
r.post('/api/admin/products', staffApi('products', async (ctx) => {
  const b = await readBody(ctx.req, 8 * 1024 * 1024);
  const s = db();
  let p = b.id ? s.products.find((x) => x.id === b.id) : null;
  const fields = {};
  if (!String(b.name || '').trim()) fields.name = 'Nhập tên sản phẩm.';
  if (!(Number(b.price) > 0)) fields.price = 'Giá phải lớn hơn 0.';
  if (Object.keys(fields).length) return json(ctx.req, ctx.res, 422, { error: 'Vui lòng kiểm tra lại.', fields });
  const isNew = !p;
  if (!p) {
    const slug = slugify(b.name);
    if (s.products.some((x) => x.slug === slug)) return json(ctx.req, ctx.res, 422, { error: 'Tên sản phẩm bị trùng.', fields: { name: 'Đã có sản phẩm cùng tên.' } });
    p = { id: 'p-' + Date.now().toString(36), slug, line: b.line || 'luxe', isConcept: b.line !== 'karaoke', needsVerify: false, finishes: ['ngoc-trai'], stock: { 'ngoc-trai': 0 }, model: { type: 'halong' }, specs: [], inBox: [], faq: [], highlights: [], description: [''], sold: 0, rating: 0, reviewCount: 0, createdAt: Date.now(), image: '/img/products/alokio-luxe-ha-long.webp', knobs: null, straps: null, engraving: false, note: '', links: b.line === 'karaoke' ? 'official' : null, weightKg: 1 };
    s.products.push(p);
  }
  const allowed = ['name', 'tagline', 'category', 'line', 'price', 'compareAt', 'hidden', 'highlights', 'specs', 'description', 'stock', 'finishes', 'needsVerify', 'isConcept', 'featured', 'weightKg', 'model'];
  for (const k of allowed) if (b[k] !== undefined) p[k] = b[k];
  p.price = Math.round(Number(p.price)); p.compareAt = p.compareAt ? Math.round(Number(p.compareAt)) : null;
  if (b.imageData && /^data:image\/(png|jpe?g|webp);base64,/.test(b.imageData)) {
    p.image = b.imageData; // ảnh lưu trực tiếp dạng data URL trong localStorage
  }
  p.updatedAt = Date.now();
  log(ctx.staff.name, `${isNew ? 'Thêm' : 'Cập nhật'} sản phẩm ${p.name}`);
  save();
  publish('product.updated', productPublic(p));
  json(ctx.req, ctx.res, 200, { ok: true, product: p });
}));
r.post('/api/admin/products/:id/stock', staffApi('inventory', async (ctx) => {
  const b = await readBody(ctx.req);
  const p = db().products.find((x) => x.id === ctx.params.id);
  if (!p || !p.finishes.includes(b.finish)) return json(ctx.req, ctx.res, 400, { error: 'Sản phẩm/màu không hợp lệ.' });
  const delta = Math.round(Number(b.delta) || 0);
  p.stock[b.finish] = Math.max(0, (p.stock[b.finish] || 0) + delta);
  db().inventoryLog.unshift({ at: Date.now(), by: ctx.staff.name, productId: p.id, name: p.name, finish: b.finish, delta, reason: String(b.reason || '').slice(0, 120), after: p.stock[b.finish] });
  log(ctx.staff.name, `${delta >= 0 ? 'Nhập' : 'Xuất'} kho ${p.name} (${b.finish}) ${delta}`);
  save(); publish('stock.changed', { productId: p.id, stock: p.stock, sold: p.sold }); publish('product.updated', productPublic(p));
  json(ctx.req, ctx.res, 200, { ok: true, stock: p.stock });
}));
r.get('/api/admin/inventory-log', staffApi('inventory', (ctx) => json(ctx.req, ctx.res, 200, { items: db().inventoryLog.slice(0, 100) })));
r.get('/api/admin/customers', staffApi('customers', (ctx) => {
  const s = db();
  const spend = {}; const cnt = {}; const last = {};
  for (const o of s.orders) { if (o.status === 'cancelled') continue; spend[o.customerId] = (spend[o.customerId] || 0) + o.total; cnt[o.customerId] = (cnt[o.customerId] || 0) + 1; last[o.customerId] = Math.max(last[o.customerId] || 0, o.createdAt); }
  const items = s.customers.map((c) => ({ id: c.id, name: c.name, email: c.email, phone: c.phone, province: c.addresses[0]?.provinceName || '', createdAt: c.createdAt, orders: cnt[c.id] || 0, spend: spend[c.id] || 0, last: last[c.id] || null, tier: (spend[c.id] || 0) >= 15e6 ? 'VIP' : (cnt[c.id] || 0) >= 2 ? 'Thân thiết' : 'Mới', note: c.note, hasAccount: !!c.pass }));
  items.sort((a, b) => b.spend - a.spend);
  json(ctx.req, ctx.res, 200, { items });
}));
r.get('/api/admin/customers/:id', staffApi('customers', (ctx) => {
  const s = db(); const c = s.customers.find((x) => x.id === ctx.params.id);
  if (!c) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy khách hàng.' });
  const { pass, ...rest } = c;
  json(ctx.req, ctx.res, 200, { ...rest, orders: s.orders.filter((o) => o.customerId === c.id).map(adminOrderSummary) });
}));
r.post('/api/admin/customers/:id/note', staffApi('customers', async (ctx) => {
  const b = await readBody(ctx.req); const c = db().customers.find((x) => x.id === ctx.params.id);
  if (!c) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy khách hàng.' });
  c.note = String(b.note || '').slice(0, 500); save(); json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/chats', staffApi('chat', (ctx) => json(ctx.req, ctx.res, 200, { items: db().chats.map((c) => ({ id: c.id, name: c.name, status: c.status, unread: c.unread, updatedAt: c.updatedAt || c.createdAt, last: c.messages[c.messages.length - 1] })) })));
r.get('/api/admin/chats/:id', staffApi('chat', (ctx) => {
  const c = db().chats.find((x) => x.id === ctx.params.id);
  if (!c) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy.' });
  c.unread = 0; save(); json(ctx.req, ctx.res, 200, c);
}));
r.post('/api/admin/chats/:id', staffApi('chat', async (ctx) => {
  const b = await readBody(ctx.req); const c = db().chats.find((x) => x.id === ctx.params.id);
  if (!c) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy.' });
  if (b.status) { c.status = b.status === 'resolved' ? 'resolved' : 'open'; save(); return json(ctx.req, ctx.res, 200, { ok: true }); }
  const text = String(b.text || '').trim().slice(0, 800);
  if (!text) return json(ctx.req, ctx.res, 400, { error: 'Tin nhắn trống.' });
  const m = { from: 'staff', text, at: Date.now(), by: ctx.staff.name };
  c.messages.push(m); c.updatedAt = m.at; save();
  publish('chat.message', { chatId: c.id, message: m });
  json(ctx.req, ctx.res, 200, { ok: true, message: m });
}));
r.get('/api/admin/coupons', staffApi('*', (ctx) => json(ctx.req, ctx.res, 200, { items: db().coupons })));
r.post('/api/admin/coupons', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req); const s = db();
  const code = String(b.code || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{3,16}$/.test(code)) return json(ctx.req, ctx.res, 422, { error: 'Mã gồm 3–16 chữ in hoa hoặc số.', fields: { code: 'Không hợp lệ.' } });
  let c = s.coupons.find((x) => x.code === code);
  if (!c) { c = { code, used: 0 }; s.coupons.unshift(c); }
  Object.assign(c, { type: ['percent', 'fixed', 'freeship'].includes(b.type) ? b.type : 'percent', value: Number(b.value) || 0, max: Number(b.max) || null, minOrder: Number(b.minOrder) || 0, line: b.line || null, limit: Number(b.limit) || null, enabled: b.enabled !== false, expiresAt: b.expiresAt ? Number(b.expiresAt) : null, desc: String(b.desc || '').slice(0, 120) });
  log(ctx.staff.name, `Lưu mã giảm giá ${code}`); save();
  json(ctx.req, ctx.res, 200, { ok: true });
}));
r.del('/api/admin/coupons/:code', staffApi('*', (ctx) => { const s = db(); s.coupons = s.coupons.filter((c) => c.code !== ctx.params.code); log(ctx.staff.name, `Xoá mã ${ctx.params.code}`); save(); json(ctx.req, ctx.res, 200, { ok: true }); }));
r.get('/api/admin/flash', staffApi('*', (ctx) => json(ctx.req, ctx.res, 200, { items: db().flashSales })));
r.post('/api/admin/flash', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req); const s = db();
  let f = b.id ? s.flashSales.find((x) => x.id === b.id) : null;
  if (!f) { f = { id: 'fs-' + Date.now().toString(36), items: [] }; s.flashSales.unshift(f); }
  f.name = String(b.name || 'Flash sale').slice(0, 60); f.enabled = !!b.enabled; f.startsAt = Number(b.startsAt) || Date.now(); f.endsAt = Number(b.endsAt) || Date.now() + 864e5;
  f.items = (b.items || []).filter((i) => s.products.some((p) => p.id === i.productId)).map((i) => ({ productId: i.productId, price: Math.round(Number(i.price)), quota: Math.round(Number(i.quota)) || 10, sold: Number(i.sold) || 0 }));
  log(ctx.staff.name, `Lưu flash sale ${f.name}`); save(); publish('flashsale.updated', { id: f.id });
  json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/reviews', staffApi('reviews', (ctx) => json(ctx.req, ctx.res, 200, { items: db().reviews.slice(0, 300).map((r) => ({ ...r, product: db().products.find((p) => p.id === r.productId)?.name })) })));
r.post('/api/admin/reviews/:id', staffApi('reviews', async (ctx) => {
  const b = await readBody(ctx.req); const s = db(); const rv = s.reviews.find((x) => x.id === ctx.params.id);
  if (!rv) return json(ctx.req, ctx.res, 404, { error: 'Không tìm thấy.' });
  if (b.status) rv.status = ['approved', 'hidden', 'pending'].includes(b.status) ? b.status : rv.status;
  if (b.reply !== undefined) rv.reply = String(b.reply).slice(0, 400);
  const p = s.products.find((x) => x.id === rv.productId);
  const ok = s.reviews.filter((x) => x.productId === p.id && x.status === 'approved');
  p.reviewCount = ok.length; p.rating = ok.length ? Math.round((ok.reduce((a, x) => a + x.stars, 0) / ok.length) * 10) / 10 : 0;
  save(); json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/content', staffApi('*', (ctx) => json(ctx.req, ctx.res, 200, { posts: db().posts, newsletter: db().newsletter, appointments: db().appointments })));
r.post('/api/admin/posts', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req); const s = db();
  if (!String(b.title || '').trim() || !String(b.body || '').trim()) return json(ctx.req, ctx.res, 422, { error: 'Nhập tiêu đề và nội dung.' });
  let p = b.id ? s.posts.find((x) => x.id === b.id) : null;
  if (!p) { p = { id: 'post-' + Date.now().toString(36), slug: slugify(b.title), publishedAt: Date.now(), author: ctx.staff.name, tags: ['Tin tức'], cover: 'material', products: [] }; s.posts.unshift(p); }
  Object.assign(p, { title: String(b.title).slice(0, 140), excerpt: String(b.excerpt || '').slice(0, 240), body: String(b.body).slice(0, 20000), tags: b.tags || p.tags });
  log(ctx.staff.name, `Lưu bài viết ${p.title}`); save();
  json(ctx.req, ctx.res, 200, { ok: true, post: p });
}));
r.del('/api/admin/posts/:id', staffApi('*', (ctx) => { const s = db(); s.posts = s.posts.filter((p) => p.id !== ctx.params.id); save(); json(ctx.req, ctx.res, 200, { ok: true }); }));
r.post('/api/admin/settings', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req); const s = db();
  const st = s.settings;
  if (b.announcement !== undefined) st.announcement = String(b.announcement).slice(0, 200);
  if (b.links) for (const k of ['facebook', 'tiktok', 'shopee']) if (/^https:\/\//.test(b.links[k] || '')) st.links[k] = b.links[k];
  if (b.shipping) { st.shipping.freeThreshold = Number(b.shipping.freeThreshold) || st.shipping.freeThreshold; st.shipping.express = Number(b.shipping.express) || st.shipping.express; if (Array.isArray(b.shipping.tiers)) st.shipping.tiers = b.shipping.tiers.map((t) => ({ maxKg: Number(t.maxKg), fee: Number(t.fee) })); }
  if (b.payments) { for (const k of ['cod', 'vietqr', 'wallet', 'card', 'installment']) if (b.payments[k] !== undefined) st.payments[k] = !!b.payments[k]; for (const k of ['depositPercent', 'depositMin', 'qrMinutes']) if (b.payments[k] !== undefined) st.payments[k] = Number(b.payments[k]); if (Array.isArray(b.payments.wallets)) st.payments.wallets = b.payments.wallets.filter((w) => WALLETS.some((x) => x.id === w)); }
  if (b.vietqr) { if (/^\d{6}$/.test(b.vietqr.bin)) st.vietqr.bin = b.vietqr.bin; if (/^\d{6,19}$/.test(b.vietqr.account)) st.vietqr.account = b.vietqr.account; if (b.vietqr.accountName) st.vietqr.accountName = String(b.vietqr.accountName).slice(0, 60); }
  if (b.simulator) { st.simulator.enabled = !!b.simulator.enabled; st.simulator.minSec = Math.max(5, Number(b.simulator.minSec) || 15); st.simulator.maxSec = Math.max(st.simulator.minSec, Number(b.simulator.maxSec) || 45); st.simulator.enabled ? startSimulator() : stopSimulator(); }
  if (b.recentTicker !== undefined) st.recentTicker = !!b.recentTicker;
  if (b.liveViewers !== undefined) st.liveViewers = !!b.liveViewers;
  log(ctx.staff.name, 'Cập nhật cài đặt'); save(); publish('settings.updated', { announcement: st.announcement, links: st.links });
  json(ctx.req, ctx.res, 200, { ok: true, settings: st });
}));
r.post('/api/admin/simulate', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req);
  const n = Math.min(20, Math.max(1, Number(b.count) || 1));
  const codes = [];
  for (let i = 0; i < n; i++) { const o = simulateOrder(); if (o) codes.push(o.code); }
  json(ctx.req, ctx.res, 200, { ok: true, codes });
}));
r.post('/api/admin/reset', staffApi('*', (ctx) => {
  stopSimulator(); reset(() => generate(Date.now() % 1e6)); log(ctx.staff.name, 'Khôi phục dữ liệu demo');
  publish('catalog.reset', {}); json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/analytics', staffApi('dashboard', (ctx) => json(ctx.req, ctx.res, 200, analytics(Number(ctx.url.searchParams.get('days') || 90)))));
r.get('/api/admin/activity', staffApi('dashboard', (ctx) => json(ctx.req, ctx.res, 200, { items: db().activity.slice(0, 120) })));
r.get('/api/admin/staff', staffApi('*', (ctx) => json(ctx.req, ctx.res, 200, { items: db().users.map(({ pass, ...u }) => ({ ...u, roleLabel: ROLES[u.role].label })), roles: ROLES })));
r.post('/api/admin/staff', staffApi('*', async (ctx) => {
  const b = await readBody(ctx.req); const s = db();
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || !ROLES[b.role] || String(b.name || '').trim().length < 2) return json(ctx.req, ctx.res, 422, { error: 'Nhập tên, email hợp lệ và vai trò.' });
  if (s.users.some((u) => u.email === email)) return json(ctx.req, ctx.res, 422, { error: 'Email đã tồn tại.' });
  if (String(b.password || '').length < 8) return json(ctx.req, ctx.res, 422, { error: 'Mật khẩu tối thiểu 8 ký tự.' });
  s.users.push({ id: 'u-' + Date.now().toString(36), email, name: String(b.name).slice(0, 60), role: b.role, pass: hashPassword(String(b.password)) });
  log(ctx.staff.name, `Thêm nhân viên ${email}`); save(); json(ctx.req, ctx.res, 200, { ok: true });
}));
r.get('/api/admin/lan', staffApi('dashboard', (ctx) => json(ctx.req, ctx.res, 200, { lan: lanAddress(), host: HOST, port: PORT })));

// ======================= Helpers =======================
function productPublic(p) {
  const s = db();
  const fl = activeFlash(s, p.id);
  return { id: p.id, slug: p.slug, name: p.name, line: p.line, category: p.category, price: p.price, compareAt: p.compareAt, flash: fl ? { price: fl.item.price, endsAt: fl.sale.endsAt, left: fl.item.quota - fl.item.sold, quota: fl.item.quota } : null, stock: p.stock, finishes: p.finishes, image: p.image, hidden: p.hidden, rating: p.rating, reviewCount: p.reviewCount, sold: p.sold, model: p.model, knobs: p.knobs, straps: p.straps, engraving: p.engraving, tagline: p.tagline, highlights: p.highlights };
}

function stats(days) {
  const s = db(); const now = Date.now(); const DAY = 864e5;
  const valid = s.orders.filter((o) => !['cancelled', 'returned'].includes(o.status));
  const inRange = (o, a, b) => o.createdAt >= a && o.createdAt < b;
  const cur = valid.filter((o) => inRange(o, now - days * DAY, now + 1));
  const prev = valid.filter((o) => inRange(o, now - 2 * days * DAY, now - days * DAY));
  const sum = (l) => l.reduce((a, o) => a + o.total, 0);
  const startToday = new Date(); startToday.setHours(0, 0, 0, 0);
  const today = valid.filter((o) => o.createdAt >= startToday.getTime());
  const series = [];
  for (let i = days - 1; i >= 0; i--) {
    const d0 = new Date(startToday.getTime() - i * DAY);
    const list = valid.filter((o) => inRange(o, d0.getTime(), d0.getTime() + DAY));
    series.push({ date: d0.getTime(), revenue: sum(list), orders: list.length });
  }
  const byMethod = {}; for (const o of cur) byMethod[o.payment.method] = (byMethod[o.payment.method] || 0) + o.total;
  const byStatus = {}; for (const o of s.orders) byStatus[o.status] = (byStatus[o.status] || 0) + 1;
  const prod = {}; for (const o of cur) for (const l of o.items) { prod[l.productId] = prod[l.productId] || { name: l.name, qty: 0, revenue: 0 }; prod[l.productId].qty += l.qty; prod[l.productId].revenue += l.total; }
  const heat = Array.from({ length: 7 }, () => Array(24).fill(0));
  for (const o of s.orders.filter((o) => o.createdAt > now - 90 * DAY)) { const d = new Date(o.createdAt); heat[(d.getDay() + 6) % 7][d.getHours()]++; }
  const byProv = {}; for (const o of cur) byProv[o.address.province] = (byProv[o.address.province] || 0) + 1;
  const newCustomers = s.customers.filter((c) => c.createdAt > now - days * DAY).length;
  const prevCustomers = s.customers.filter((c) => c.createdAt > now - 2 * days * DAY && c.createdAt <= now - days * DAY).length;
  const cancelled = s.orders.filter((o) => o.status === 'cancelled' && o.createdAt > now - days * DAY).length;
  const allCur = s.orders.filter((o) => o.createdAt > now - days * DAY).length;
  const low = s.products.filter((p) => !p.hidden && Object.values(p.stock).some((v) => v <= 3)).map((p) => ({ id: p.id, name: p.name, stock: p.stock }));
  const byLine = { luxe: 0, karaoke: 0 }; for (const o of cur) for (const l of o.items) byLine[l.line] = (byLine[l.line] || 0) + l.total;
  return {
    days, revenue: sum(cur), prevRevenue: sum(prev), orders: cur.length, prevOrders: prev.length, aov: cur.length ? sum(cur) / cur.length : 0, prevAov: prev.length ? sum(prev) / prev.length : 0,
    today: { revenue: sum(today), orders: today.length }, newCustomers, prevCustomers, cancelRate: allCur ? cancelled / allCur : 0,
    series, byMethod, byStatus, byLine, top: Object.entries(prod).map(([id, v]) => ({ id, ...v })).sort((a, b) => b.revenue - a.revenue).slice(0, 6),
    heat, byProv, low, recent: s.orders.slice(0, 8).map(adminOrderSummary), pending: s.orders.filter((o) => o.status === 'pending').length,
    unreadChats: s.chats.reduce((a, c) => a + (c.unread || 0), 0), pendingReviews: s.reviews.filter((r) => r.status === 'pending').length,
  };
}

// ---------- Phân tích chuyên sâu (trang "Phân tích") ----------
function analytics(days) {
  const s = db(); const now = Date.now(); const DAY = 864e5; const from = now - days * DAY;
  const bad = (o) => ['cancelled', 'returned'].includes(o.status);
  const all = s.orders.filter((o) => o.createdAt >= from);
  const valid = all.filter((o) => !bad(o));
  const sum = (l) => l.reduce((a, o) => a + o.total, 0);
  const pmap = Object.fromEntries(s.products.map((p) => [p.id, p]));
  const hash = (str) => { let h = 7; for (const c of str) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };

  const byProv = {};
  for (const o of valid) { const k = o.address.provinceName || '?'; byProv[k] = byProv[k] || { name: k, revenue: 0, orders: 0 }; byProv[k].revenue += o.total; byProv[k].orders++; }
  const weekday = Array.from({ length: 7 }, () => ({ revenue: 0, orders: 0 }));
  const hours = Array(24).fill(0);
  for (const o of valid) { const d = new Date(o.createdAt); const w = (d.getDay() + 6) % 7; weekday[w].revenue += o.total; weekday[w].orders++; hours[d.getHours()]++; }

  // theo tuần
  const W = Math.max(4, Math.ceil(days / 7));
  const weeks = Array.from({ length: W }, (_, i) => ({ start: now - (W - i) * 7 * DAY, revenue: 0, orders: 0, cancelled: 0, all: 0, methods: {} }));
  for (const o of all) {
    const i = Math.floor((o.createdAt - (now - W * 7 * DAY)) / (7 * DAY)); const w = weeks[Math.min(W - 1, Math.max(0, i))];
    w.all++;
    if (bad(o)) { w.cancelled++; continue; }
    w.revenue += o.total; w.orders++; w.methods[o.payment.method] = (w.methods[o.payment.method] || 0) + o.total;
  }
  for (const w of weeks) { w.aov = w.orders ? w.revenue / w.orders : 0; w.cancelRate = w.all ? w.cancelled / w.all : 0; }

  // khách hàng
  const cust = {};
  for (const o of s.orders.filter((x) => !bad(x))) { const k = o.customerId || o.contact.phone; cust[k] = cust[k] || { spend: 0, n: 0, first: o.createdAt }; cust[k].spend += o.total; cust[k].n++; cust[k].first = Math.min(cust[k].first, o.createdAt); }
  const seg = { VIP: { count: 0, revenue: 0 }, 'Thân thiết': { count: 0, revenue: 0 }, 'Mới': { count: 0, revenue: 0 } };
  for (const c of Object.values(cust)) { const k = c.spend >= 15e6 ? 'VIP' : c.n >= 2 ? 'Thân thiết' : 'Mới'; seg[k].count++; seg[k].revenue += c.spend; }
  const custList = Object.values(cust);
  const repeatRate = custList.length ? custList.filter((c) => c.n >= 2).length / custList.length : 0;
  const clv = custList.length ? custList.reduce((a, c) => a + c.spend, 0) / custList.length : 0;

  // sản phẩm, danh mục, màu
  const prod = {}, cat = {}, fin = {}, line = { luxe: 0, karaoke: 0 };
  for (const o of valid) for (const l of o.items) {
    const p = pmap[l.productId] || {};
    prod[l.productId] = prod[l.productId] || { name: l.name, qty: 0, revenue: 0 }; prod[l.productId].qty += l.qty; prod[l.productId].revenue += l.total;
    const cname = (s.categories.find((c) => c.slug === p.category) || {}).name || 'Khác';
    cat[cname] = (cat[cname] || 0) + l.total;
    if (l.finish) { fin[l.finish] = fin[l.finish] || { name: FINISHES[l.finish]?.name || l.finish, hex: FINISHES[l.finish]?.hex || '#999', qty: 0 }; fin[l.finish].qty += l.qty; }
    line[l.line] = (line[l.line] || 0) + l.total;
  }
  const ship = {}; for (const o of valid) ship[o.shippingMethod] = (ship[o.shippingMethod] || 0) + 1;
  const withCoupon = valid.filter((o) => o.coupon);

  // kênh bán (giả lập ổn định theo mã đơn) & phễu chuyển đổi (ước tính)
  const CH = [['Facebook', 30], ['TikTok Shop', 26], ['Shopee', 18], ['Google', 14], ['Trực tiếp', 12]];
  const channels = Object.fromEntries(CH.map(([k]) => [k, { orders: 0, revenue: 0 }]));
  for (const o of valid) { let x = hash(o.code) % 100; for (const [k, w] of CH) { if (x < w) { channels[k].orders++; channels[k].revenue += o.total; break; } x -= w; } }
  const paid = valid.filter((o) => ['paid', 'cod'].includes(o.payment.status) || o.status === 'completed').length;
  const funnel = [['Lượt truy cập', Math.round(all.length * 41.7)], ['Xem sản phẩm', Math.round(all.length * 16.4)], ['Thêm vào giỏ', Math.round(all.length * 4.3)], ['Bắt đầu thanh toán', Math.round(all.length * 1.85)], ['Đặt hàng', all.length], ['Đơn thành công', paid]];

  // mục tiêu tháng
  const m0 = new Date(); m0.setDate(1); m0.setHours(0, 0, 0, 0);
  const monthRevenue = sum(s.orders.filter((o) => !bad(o) && o.createdAt >= m0.getTime()));
  const daysInMonth = new Date(m0.getFullYear(), m0.getMonth() + 1, 0).getDate();
  const target = s.settings.monthlyTarget || 1.2e9;

  // cohort: khách theo tháng mua đầu tiên → tỉ lệ quay lại các tháng sau
  const monthKey = (t) => { const d = new Date(t); return d.getFullYear() * 12 + d.getMonth(); };
  const curM = monthKey(now);
  const byCust = {};
  for (const o of s.orders.filter((x) => !bad(x))) { const k = o.customerId || o.contact.phone; (byCust[k] = byCust[k] || []).push(monthKey(o.createdAt)); }
  const cohorts = [];
  for (let m = curM - 5; m <= curM; m++) {
    const members = Object.values(byCust).filter((ms) => Math.min(...ms) === m);
    const row = [];
    for (let k = 1; k <= 5 && m + k <= curM; k++) row.push(members.length ? members.filter((ms) => ms.some((x) => x >= m + 1 && x <= m + k)).length / members.length : 0);
    cohorts.push({ label: `T${(m % 12) + 1}/${String(Math.floor(m / 12)).slice(2)}`, size: members.length, row });
  }

  // giá trị tồn kho theo dòng
  const stockValue = {}; for (const p of s.products) { const n = Object.values(p.stock || {}).reduce((a, b) => a + b, 0); const k = p.line === 'luxe' ? 'Alokio Luxe' : 'Loa kéo karaoke'; stockValue[k] = (stockValue[k] || 0) + n * p.price; }

  return {
    days, revenue: sum(valid), orders: valid.length, aov: valid.length ? sum(valid) / valid.length : 0, cancelRate: all.length ? (all.length - valid.length) / all.length : 0,
    repeatRate, clv, customers: custList.length,
    provinces: Object.values(byProv).sort((a, b) => b.revenue - a.revenue).slice(0, 10), weekday, hours, weeks,
    segments: seg, products: Object.values(prod).sort((a, b) => b.revenue - a.revenue).slice(0, 8), categories: cat, finishes: Object.values(fin).sort((a, b) => b.qty - a.qty), line,
    shipping: ship, coupon: { orders: withCoupon.length, share: valid.length ? withCoupon.length / valid.length : 0, discount: withCoupon.reduce((a, o) => a + (o.discount || 0), 0) },
    channels, funnel, month: { revenue: monthRevenue, target, day: new Date().getDate(), daysInMonth }, cohorts, stockValue,
  };
}

function validateCheckout(b) {
  const f = {};
  if (!Array.isArray(b.items) || !b.items.length) f.items = 'Giỏ hàng trống.';
  if (String(b.name || '').trim().length < 2) f.name = 'Vui lòng nhập họ tên người nhận.';
  if (!/^0\d{9}$/.test(String(b.phone || '').replace(/\s/g, ''))) f.phone = 'Số điện thoại gồm 10 số, bắt đầu bằng 0.';
  if (b.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(b.email)) f.email = 'Email chưa đúng định dạng.';
  if (!PROVINCES.some((p) => p.code === b.province)) f.province = 'Chọn tỉnh/thành phố.';
  if (String(b.ward || '').trim().length < 2) f.ward = 'Nhập phường/xã/đặc khu.';
  if (String(b.street || '').trim().length < 4) f.street = 'Nhập số nhà, tên đường.';
  if (!['standard', 'express', 'pickup'].includes(b.shipping)) f.shipping = 'Chọn phương thức vận chuyển.';
  if (!['cod', 'vietqr', 'wallet', 'card', 'installment'].includes(b.method)) f.method = 'Chọn phương thức thanh toán.';
  if (b.method === 'wallet' && !WALLETS.some((w) => w.id === b.wallet)) f.wallet = 'Chọn ví điện tử.';
  if (b.method === 'installment' && ![3, 6, 9, 12].includes(Number(b.installment))) f.installment = 'Chọn kỳ hạn trả góp.';
  return f;
}

function sandboxBase() {
  return ''; // trang sandbox nằm ngay trong website (sandbox.html)
}

function autoReply(text) {
  const t = norm(text);
  if (/giao|ship|van chuyen/.test(t)) return 'Alokio giao toàn quốc: tiêu chuẩn 2–5 ngày, hoả tốc 2 giờ tại Hà Nội & TP.HCM. Đơn từ 3.000.000 ₫ được miễn phí vận chuyển.';
  if (/loa keo|karaoke|shopee|tiktok/.test(t)) return 'Loa kéo karaoke Alokio chính hãng có bán tại Shopee, TikTok Shop và Facebook của Alokio — bạn bấm nút liên hệ góc phải để mở nhé!';
  if (/con hang|mau|ngoc trai|ha long/.test(t)) return 'Bạn xem tồn kho theo từng màu ngay trên trang sản phẩm (cập nhật realtime). Nhân viên sẽ kiểm tra thêm và trả lời bạn ngay đây.';
  if (/tra gop|thanh toan|qr|momo|zalo/.test(t)) return 'Alokio hỗ trợ COD, VietQR, ví điện tử qua QR động, thẻ và trả góp 0% qua thẻ tín dụng.';
  return 'Cảm ơn bạn đã nhắn tin! Nhân viên Alokio sẽ trả lời trong ít phút.';
}

function norm(s) { return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase(); }
function slugify(s) { return norm(s).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

function adminGuard(fn) {
  return (ctx) => (ctx.staff ? fn(ctx) : redirect(ctx.res, '/admin/dang-nhap?next=' + encodeURIComponent(ctx.url.pathname)));
}
function staffApi(area, fn) {
  return (ctx) => {
    if (!ctx.staff) return json(ctx.req, ctx.res, 401, { error: 'Phiên đăng nhập quản trị đã hết hạn.' });
    if (area !== 'dashboard' && !(area === '*' ? can(ctx.staff, '*') : can(ctx.staff, area))) return json(ctx.req, ctx.res, 403, { error: 'Tài khoản của bạn không có quyền thực hiện thao tác này.' });
    return fn(ctx);
  };
}
function notFound(ctx) { send(ctx.req, ctx.res, 404, String(pages.notFound(ctx))); }

// ======================= Xử lý một "yêu cầu" =======================
// req = { method, url, body, cookie } → trả về { status, type, headers, body }
export async function handle({ method = 'GET', url = '/', body = null, cookie = '' } = {}) {
  const u = new URL(url, 'http://alokio.local');
  const res = { status: 200, type: 'text/html; charset=utf-8', headers: {}, body: '' };
  const req = { method, headers: { cookie, host: 'alokio.local' }, body };
  const ctx = { req, res, url: u, state: db(), params: {}, assetVersion };
  try {
    const cookies = parseCookies(req);
    const cid = readToken(cookies.alk_c);
    ctx.customer = cid ? db().customers.find((c) => c.id === cid) || null : null;
    const sid = readToken(cookies.alk_a);
    ctx.staff = sid ? db().users.find((x) => x.id === sid) || null : null;
    const pathname = u.pathname;
    const m = r.match(method, pathname.length > 1 ? pathname.replace(/\/$/, '') : pathname);
    if (!m) { notFound(ctx); return res; }
    ctx.params = m.params;
    ctx.state = db();
    await m.handler(ctx);
  } catch (err) {
    console.error('[alokio]', err);
    json(req, res, err.status || 500, { error: err.status ? err.message : 'Đã có lỗi xảy ra. Vui lòng thử lại.' });
  }
  return res;
}
