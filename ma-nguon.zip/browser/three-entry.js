// Gói 3D (three.js + các cảnh) – chỉ tải khi trang thật sự có cảnh 3D.
// Dùng chung âm thanh, giỏ hàng, realtime… với gói chính qua window.__alkShared.
import * as hero from '../client/three/hero.js';
import * as viewer from '../client/three/viewer.js';
import * as scenes from '../client/three/scenes.js';
import * as splash from '../client/three/splash.js';
import * as vnmap from '../client/three/vnmap.js';
import * as models from '../client/three/models.js';

window.__ALK3D = { hero, viewer, scenes, splash, vnmap, models, showroom: () => import('../client/pages/showroom.js') };
