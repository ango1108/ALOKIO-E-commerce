// Điểm vào cho prerender.mjs (chạy trong Node khi build)
import { handle, boot } from './app.js';
import { ROUTES, toFile } from './routes.js';
export default { handle, boot, ROUTES, toFile };
