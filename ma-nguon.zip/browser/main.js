// =====================================================================
// ALOKIO – bản HTML tĩnh: bộ khởi động chạy trên mọi trang .html
// 1) Nạp dữ liệu giả lập (localStorage), 2) dựng giao diện trang hiện tại,
// 3) chạy mã giao diện (3D, giỏ hàng, admin…), 4) giả lập "realtime" giữa các tab.
// =====================================================================
import { boot, handle } from './app.js';
import { toFile, fromLocation } from './routes.js';
import { onEvent, heartbeat, presence } from '../server/bus.js';
import { startSimulator, stopSimulator } from '../server/simulator.js';
import { sweepExpired } from '../server/services.js';
import { db, save } from '../server/db.js';
import { paintFixed } from '../client/paint.js';
import * as sharedAudio from '../client/audio.js';
import * as sharedCore from '../client/lib/core.js';
import * as sharedCart from '../client/lib/cart.js';
import * as sharedLive from '../client/lib/live.js';

// ---------- Gói 3D tải theo nhu cầu (js/alokio-3d.js) ----------
window.__alkShared = { audio: sharedAudio, core: sharedCore, cart: sharedCart, live: sharedLive };
let p3d = null;
window.__alk3d = (name) => {
  p3d = p3d || new Promise((resolve, reject) => {
    const sc = document.createElement('script');
    sc.src = 'js/alokio-3d.js';
    sc.onload = () => resolve(window.__ALK3D);
    sc.onerror = () => { p3d = null; reject(new Error('Không tải được gói 3D')); };
    document.head.appendChild(sc);
  });
  return p3d.then((m) => (name === 'showroom' ? m.showroom() : m[name]));
};

const COOKIE_KEY = 'alokio:session';
const TAB_ID = Math.random().toString(36).slice(2, 10);
const here = fromLocation();

// ---------- "Cookie" đăng nhập lưu trong localStorage (file:// không hỗ trợ cookie) ----------
function jar() { try { return JSON.parse(localStorage.getItem(COOKIE_KEY) || '{}'); } catch { return {}; } }
function cookieHeader() {
  const j = jar(); const now = Date.now();
  return Object.entries(j).filter(([, v]) => v.exp > now).map(([k, v]) => `${k}=${encodeURIComponent(v.value)}`).join('; ');
}
function applySetCookie(list) {
  if (!list) return;
  const j = jar();
  for (const c of [].concat(list)) {
    const [pair, ...attrs] = c.split(';');
    const i = pair.indexOf('=');
    const name = pair.slice(0, i).trim(); const value = decodeURIComponent(pair.slice(i + 1).trim());
    const ma = attrs.map((a) => a.trim()).find((a) => /^max-age=/i.test(a));
    const sec = ma ? Number(ma.split('=')[1]) : 86400;
    if (!value || sec <= 0) delete j[name]; else j[name] = { value, exp: Date.now() + sec * 1000 };
  }
  try { localStorage.setItem(COOKIE_KEY, JSON.stringify(j)); } catch { /* noop */ }
}

async function request(method, url, body) {
  const res = await handle({ method, url, body, cookie: cookieHeader() });
  applySetCookie(res.headers['Set-Cookie']);
  return res;
}

// ---------- Viết lại đường dẫn trong HTML: /img/x → img/x ; /san-pham/x → san-pham.html?slug=x ----------
const ASSET = /(["'(\s,=])\/(img|fonts|brand|uploads|audio|css|js|vendor)\//g;
export function fixAssets(str) { return str.replace(ASSET, '$1$2/'); }
function fixLinks(str) {
  return fixAssets(str).replace(/(\shref=)(["'])(\/(?!\/|api\/)[^"']*)\2/g, (_, a, q, v) => `${a}${q}${toFile(v.replace(/&amp;/g, '&')).replace(/&/g, '&amp;')}${q}`);
}

// ---------- Ghi đè fetch: mọi yêu cầu "/api/..." hay "/trang" được xử lý ngay trong trình duyệt ----------
const realFetch = window.fetch.bind(window);
window.fetch = async (input, init = {}) => {
  const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
  if (!(typeof url === 'string' && url.startsWith('/') && !url.startsWith('//'))) return realFetch(input, init);
  const method = (init.method || 'GET').toUpperCase();
  let body = null;
  if (init.body) { try { body = JSON.parse(init.body); } catch { body = {}; } }
  const res = await request(method, url, body);
  if (res.status === 303) return new Response('', { status: 200, headers: { 'X-Redirect': res.headers.Location } });
  const text = /json|html/.test(res.type) ? fixAssets(res.body) : res.body;
  return new Response(text, { status: res.status, headers: { 'Content-Type': res.type } });
};

// ---------- EventSource giả: nhận sự kiện từ "máy chủ" trong trình duyệt ----------
class LocalEventSource {
  constructor(url) {
    const u = new URL(url, 'http://alokio.local');
    this.scope = u.searchParams.get('scope') === 'admin' ? 'admin' : 'public';
    this.page = u.searchParams.get('page') || '';
    this.map = new Map();
    this.readyState = 1;
    this.off = onEvent((evt) => {
      if (this.scope === 'public' && evt.type.startsWith('admin.')) return;
      const set = this.map.get(evt.type);
      if (set) set.forEach((fn) => fn({ data: fixAssets(JSON.stringify(evt)), type: evt.type }));
    });
    liveInfo = { scope: this.scope, page: this.page };
    heartbeat(TAB_ID, liveInfo);
    if (this.scope === 'admin') becomeAdminTab();
  }
  addEventListener(type, fn) { if (!this.map.has(type)) this.map.set(type, new Set()); this.map.get(type).add(fn); }
  removeEventListener(type, fn) { this.map.get(type)?.delete(fn); }
  close() { this.off(); this.readyState = 2; }
}
window.EventSource = LocalEventSource;

let liveInfo = { scope: 'public', page: here.path };
let lastPresence = '';
function presenceTick() {
  heartbeat(TAB_ID, liveInfo);
  const p = presence();
  const key = JSON.stringify(p);
  if (key !== lastPresence) {
    lastPresence = key;
    // Chỉ báo cho các kết nối trong tab này
    const evt = { id: Date.now(), type: 'presence.count', data: p, at: Date.now() };
    for (const fn of presenceListeners) fn(evt);
  }
}
const presenceListeners = new Set();
onEvent(() => {});
window.addEventListener('pagehide', () => heartbeat(TAB_ID, null));

// ---------- Bộ mô phỏng đơn hàng: chỉ 1 tab quản trị "cầm trịch" ----------
const LEADER_KEY = 'alokio:sim-leader';
function becomeAdminTab() {
  const tick = () => {
    let L = null;
    try { L = JSON.parse(localStorage.getItem(LEADER_KEY) || 'null'); } catch { /* noop */ }
    const now = Date.now();
    const mine = !L || L.id === TAB_ID || now - L.t > 12000;
    if (mine) {
      try { localStorage.setItem(LEADER_KEY, JSON.stringify({ id: TAB_ID, t: now })); } catch { /* noop */ }
      if (!globalThis.__alkSimLeader) { globalThis.__alkSimLeader = true; startSimulator(); }
    } else if (globalThis.__alkSimLeader) { globalThis.__alkSimLeader = false; stopSimulator(); }
  };
  tick();
  setInterval(tick, 4000);
  window.addEventListener('pagehide', () => {
    try { const L = JSON.parse(localStorage.getItem(LEADER_KEY) || 'null'); if (L && L.id === TAB_ID) localStorage.removeItem(LEADER_KEY); } catch { /* noop */ }
  });
}

// ---------- Điều hướng ----------
function go(target) {
  const t = String(target || '/');
  location.href = t.startsWith('/') && !t.startsWith('//') ? toFile(t) : t;
}
function abs(vpath) { return new URL(toFile(vpath), location.href).href; }
window.__alk = { go, abs, toFile, path: () => here.path, search: () => here.search, request, paintFixed };

// Thẻ <a> được thêm sau (giỏ hàng, kết quả tìm kiếm…) → sửa href ngay khi xuất hiện
function fixAnchor(a) {
  const h = a.getAttribute('href');
  if (h && h.startsWith('/') && !h.startsWith('//') && !h.startsWith('/api/')) a.setAttribute('href', toFile(h));
}
function fixMedia(el) {
  for (const attr of ['src', 'poster']) {
    const v = el.getAttribute && el.getAttribute(attr);
    if (v && /^\/(img|fonts|brand|uploads|audio|css|js|vendor)\//.test(v)) el.setAttribute(attr, v.slice(1));
  }
}
function scan(node) {
  if (node.nodeType !== 1) return;
  if (node.tagName === 'A') fixAnchor(node); else fixMedia(node);
  node.querySelectorAll && node.querySelectorAll('a[href^="/"], img[src^="/"], source[src^="/"], video[poster^="/"]').forEach((el) => (el.tagName === 'A' ? fixAnchor(el) : fixMedia(el)));
}
new MutationObserver((list) => {
  for (const m of list) {
    if (m.type === 'attributes') scan(m.target);
    else m.addedNodes.forEach(scan);
  }
}).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['href', 'src', 'poster'] });

// Link tới /api/... (vd: Xuất CSV) → tạo file tải về ngay trên trình duyệt
document.addEventListener('click', async (e) => {
  const a = e.target.closest && e.target.closest('a[href]');
  if (!a) return;
  const h = a.getAttribute('href');
  if (h && h.startsWith('/api/')) {
    e.preventDefault();
    const res = await request('GET', h);
    const name = (/filename="([^"]+)"/.exec(res.headers['Content-Disposition'] || '') || [])[1] || 'du-lieu.txt';
    const url = URL.createObjectURL(new Blob([res.body], { type: res.type }));
    const dl = document.createElement('a'); dl.href = url; dl.download = name; document.body.appendChild(dl); dl.click(); dl.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
}, true);

// Form GET có action="/..." (tìm kiếm, bộ lọc) → chuyển sang trang .html tương ứng
document.addEventListener('submit', (e) => {
  const f = e.target;
  const act = f.getAttribute && f.getAttribute('action');
  if (e.defaultPrevented || !act || !act.startsWith('/') || (f.method || 'get').toLowerCase() !== 'get') return;
  e.preventDefault();
  const q = new URLSearchParams();
  for (const [k, v] of new FormData(f)) if (typeof v === 'string') q.append(k, v);
  go(act + (q.toString() ? (act.includes('?') ? '&' : '?') + q : ''));
});

// ---------- Dựng trang ----------
const MODULES = {
  site: () => import('../client/pages/site.js'),
  home: () => import('../client/pages/home.js'),
  product: () => import('../client/pages/product.js'),
  showroom: () => window.__alk3d('showroom'),
  shop: () => import('../client/pages/shop.js'),
  cart: () => import('../client/pages/cart.js'),
  checkout: () => import('../client/pages/checkout.js'),
  pay: () => import('../client/pages/pay.js'),
  sandbox: () => import('../client/pages/sandbox.js'),
  account: () => import('../client/pages/account.js'),
  admin: () => import('../client/pages/admin.js'),
  misc: () => import('../client/pages/misc.js'),
};

function sameStylesheet(href) {
  const clean = (x) => x.replace(/^\//, '').split('?')[0];
  return [...document.querySelectorAll('link[rel="stylesheet"]')].some((l) => clean(l.getAttribute('href')) === clean(href));
}

function runInline(code) {
  const s = document.createElement('script');
  s.textContent = code;
  document.head.appendChild(s);
  s.remove();
}

async function render() {
  boot();
  const res = await request('GET', here.path + here.search);
  if (res.status === 303) { location.replace(toFile(res.headers.Location)); return; }
  const doc = new DOMParser().parseFromString(fixLinks(res.body), 'text/html');

  // <html> và <head>
  for (const a of [...doc.documentElement.attributes]) document.documentElement.setAttribute(a.name, a.value);
  document.title = doc.title || document.title;
  const deferred = [];
  const inline = [];
  for (const el of [...doc.head.children]) {
    const tag = el.tagName;
    if (tag === 'TITLE') continue;
    if (tag === 'LINK') {
      const rel = el.getAttribute('rel');
      if (rel === 'stylesheet') { if (!sameStylesheet(el.getAttribute('href'))) document.head.appendChild(el); }
      else if (rel === 'icon' || rel === 'apple-touch-icon') document.head.appendChild(el);
      continue;
    }
    if (tag === 'SCRIPT') { collect(el); continue; }
    if (tag === 'STYLE') { document.head.appendChild(el); continue; }
    if (tag === 'META' && (el.getAttribute('name') === 'description' || el.getAttribute('name') === 'robots')) document.head.appendChild(el);
  }
  function collect(el) {
    const type = el.getAttribute('type') || '';
    const src = el.getAttribute('src');
    if (type === 'module' && src) { const m = /js\/([a-z-]+)\.js/.exec(src); if (m && MODULES[m[1]]) deferred.push(m[1]); return true; }
    if (!type || type === 'text/javascript') { inline.push(el.textContent); return true; }
    return false; // JSON, ld+json… giữ nguyên trong trang
  }

  // <body>
  const body = doc.body;
  body.querySelectorAll('script').forEach((el) => { if (collect(el)) el.remove(); });
  for (const a of [...document.body.attributes]) document.body.removeAttribute(a.name);
  for (const a of [...body.attributes]) document.body.setAttribute(a.name, a.value);
  const loader = document.getElementById('alk-loader');
  document.body.replaceChildren(...[...body.childNodes].map((n) => document.importNode(n, true)));
  if (loader) document.body.appendChild(loader); // giữ màn chờ cho tới khi trang sẵn sàng

  for (const code of inline) runInline(code);
  for (const name of deferred) await MODULES[name]();

  if (location.hash) {
    const t = document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (t) requestAnimationFrame(() => t.scrollIntoView());
  }
  hideLoader();
}

// ---------- Màn chờ (loa nổi trên sóng biển) ----------
const T0 = performance.now();
function hideLoader() {
  const el = document.getElementById('alk-loader');
  if (!el) return;
  let seen = false;
  try { seen = sessionStorage.getItem('alokio:seen') === '1'; sessionStorage.setItem('alokio:seen', '1'); } catch { /* noop */ }
  const minMs = seen ? 250 : 1500; // lần đầu vào web: cho khách kịp thấy màn chào
  const hero = document.querySelector('[data-hero-canvas]');
  const ready = new Promise((res) => {
    if (!hero || document.documentElement.classList.contains('lite')) return res();
    const done = () => (hero.classList.contains('is-ready') ? res() : null);
    const mo = new MutationObserver(() => { if (hero.classList.contains('is-ready')) { mo.disconnect(); res(); } });
    mo.observe(hero, { attributes: true, attributeFilter: ['class'] });
    done();
    setTimeout(res, 3500); // máy yếu: không chờ 3D quá lâu
  });
  ready.then(() => {
    setTimeout(() => {
      el.classList.add('is-out');
      setTimeout(() => el.remove(), 1000);
    }, Math.max(0, minMs - (performance.now() - T0)));
  });
}


// ---------- Việc chạy nền ----------
setInterval(() => { try { sweepExpired(); } catch (e) { console.error(e); } }, 15000);
setInterval(presenceTick, 8000);
presenceTick();
// EventSource giả cũng nhận "presence.count" của tab này
const _origOn = LocalEventSource.prototype.addEventListener;
LocalEventSource.prototype.addEventListener = function (type, fn) {
  _origOn.call(this, type, fn);
  if (type === 'presence.count') {
    const h = (evt) => fn({ data: JSON.stringify(evt), type: evt.type });
    presenceListeners.add(h);
    h({ id: Date.now(), type: 'presence.count', data: presence(), at: Date.now() });
  }
};

render().catch((err) => {
  console.error(err);
  document.getElementById('alk-loader')?.remove();
  document.body.innerHTML = '<div style="font-family:sans-serif;padding:40px;text-align:center"><h1>Không tải được trang</h1><p>' + String(err && err.message) + '</p><p><a href="index.html">Về trang chủ</a></p></div>';
});

export { db, save };
