// Bảng ánh xạ: "đường dẫn ảo" của website (vd /san-pham/loa-x)  ⇄  file .html thật (vd san-pham.html?slug=loa-x).
// Nhờ vậy chỉ cần bấm đúp index.html là web chạy, không cần máy chủ.
import { PRERENDERED } from './prerendered.js';
const PRE_FILE = { '/san-pham/:slug': ['san-pham', 'product'], '/blog/:slug': ['bai-viet', 'post'] };

export const ADMIN_SECTIONS = ['phan-tich', 'don-hang', 'giao-dich', 'san-pham', 'kho', 'khach-hang', 'chat', 'ma-giam-gia', 'flash-sale', 'danh-gia', 'noi-dung', 'cai-dat', 'nhan-vien'];

export const ROUTES = [
  ['/', 'index.html', 'Trang chủ'],
  ['/showroom', 'showroom.html', 'Showroom 3D'],
  ['/cua-hang', 'cua-hang.html', 'Cửa hàng'],
  ['/danh-muc/:slug', 'danh-muc.html', 'Danh mục'],
  ['/bo-suu-tap/:slug', 'bo-suu-tap.html', 'Bộ sưu tập'],
  ['/san-pham/:slug', 'san-pham.html', 'Sản phẩm'],
  ['/flash-sale', 'flash-sale.html', 'Flash sale'],
  ['/tim-kiem', 'tim-kiem.html', 'Tìm kiếm'],
  ['/so-sanh', 'so-sanh.html', 'So sánh'],
  ['/yeu-thich', 'yeu-thich.html', 'Yêu thích'],
  ['/gio-hang', 'gio-hang.html', 'Giỏ hàng'],
  ['/thanh-toan', 'thanh-toan.html', 'Thanh toán'],
  ['/thanh-toan/:code', 'thanh-toan-qr.html', 'Thanh toán QR'],
  ['/sandbox/pay/:id', 'sandbox.html', 'Cổng thanh toán sandbox'],
  ['/dat-hang-thanh-cong/:code', 'dat-hang-thanh-cong.html', 'Đặt hàng thành công'],
  ['/tra-cuu-don-hang', 'tra-cuu-don-hang.html', 'Tra cứu đơn hàng'],
  ['/tai-khoan', 'tai-khoan.html', 'Tài khoản'],
  ['/tai-khoan/don-hang/:code', 'tai-khoan-don-hang.html', 'Đơn hàng của tôi'],
  ['/tai-khoan/dang-nhap', 'dang-nhap.html', 'Đăng nhập'],
  ['/tai-khoan/dang-ky', 'dang-ky.html', 'Đăng ký'],
  ['/tai-khoan/quen-mat-khau', 'quen-mat-khau.html', 'Quên mật khẩu'],
  ['/blog', 'blog.html', 'Cẩm nang'],
  ['/blog/:slug', 'bai-viet.html', 'Bài viết'],
  ['/gioi-thieu', 'gioi-thieu.html', 'Giới thiệu'],
  ['/lien-he', 'lien-he.html', 'Liên hệ'],
  ['/ho-tro', 'ho-tro.html', 'Hỗ trợ'],
  ['/chinh-sach/:slug', 'chinh-sach.html', 'Chính sách'],
  ['/dieu-khoan', 'dieu-khoan.html', 'Điều khoản'],
  ['/admin/dang-nhap', 'admin-dang-nhap.html', 'Đăng nhập quản trị'],
  ['/admin', 'admin.html', 'Quản trị'],
  ['/admin/don-hang/:code/in', 'admin-in-don.html', 'In chứng từ'],
  ['/admin/don-hang/:code', 'admin-chi-tiet-don.html', 'Chi tiết đơn'],
  ...ADMIN_SECTIONS.map((s) => ['/admin/' + s, 'admin-' + s + '.html', 'Quản trị']),
  ['/404', '404.html', 'Không tìm thấy'],
];

const compiled = ROUTES.map(([pattern, file]) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/\/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '/([^/?#]+)'; }) + '/?$');
  return { pattern, file, keys, re };
});

// "/san-pham/loa-x?mau=den#atelier"  →  "san-pham.html?slug=loa-x&mau=den#atelier"
export function toFile(vpath) {
  const s = String(vpath);
  if (!s.startsWith('/') || s.startsWith('//')) return s;
  const hashI = s.indexOf('#');
  const hash = hashI >= 0 ? s.slice(hashI) : '';
  const rest = hashI >= 0 ? s.slice(0, hashI) : s;
  const qI = rest.indexOf('?');
  const path = (qI >= 0 ? rest.slice(0, qI) : rest) || '/';
  const query = qI >= 0 ? rest.slice(qI + 1) : '';
  for (const r of compiled) {
    const m = r.re.exec(path.length > 1 ? path.replace(/\/$/, '') : path);
    if (!m) continue;
    const pre = PRE_FILE[r.pattern];
    if (pre && PRERENDERED[pre[1]].includes(decodeURIComponent(m[1]))) {
      const qs2 = new URLSearchParams(query).toString();
      return `${pre[0]}--${decodeURIComponent(m[1])}.html` + (qs2 ? '?' + qs2 : '') + hash;
    }
    const q = new URLSearchParams();
    r.keys.forEach((k, i) => q.set(k, decodeURIComponent(m[i + 1])));
    for (const [k, v] of new URLSearchParams(query)) q.append(k, v);
    const qs = q.toString();
    return r.file + (qs ? '?' + qs : '') + hash;
  }
  return '404.html?path=' + encodeURIComponent(path) + hash;
}

// Đọc ngược từ địa chỉ trang đang mở → đường dẫn ảo
export function fromLocation(loc = location) {
  let file = decodeURIComponent(loc.pathname.split('/').pop() || '');
  if (!file || !file.endsWith('.html')) file = 'index.html';
  const q = new URLSearchParams(loc.search);
  const pm = file.match(/^(san-pham|bai-viet)--(.+)\.html$/);
  if (pm) { const qs = q.toString(); return { path: (pm[1] === 'san-pham' ? '/san-pham/' : '/blog/') + encodeURIComponent(pm[2]), search: qs ? '?' + qs : '' }; }
  const cands = compiled.filter((r) => r.file === file);
  if (!cands.length) return { path: '/404', search: '' };
  const r = cands.find((c) => c.keys.every((k) => q.has(k))) || cands[0];
  if (file === '404.html' && q.get('path')) return { path: q.get('path'), search: '' };
  let path = r.pattern;
  for (const k of r.keys) { path = path.replace(':' + k, encodeURIComponent(q.get(k) || '')); q.delete(k); }
  const qs = q.toString();
  return { path, search: qs ? '?' + qs : '' };
}

export const SHELL_FILES = [...new Set(ROUTES.map((r) => r[1]))];
